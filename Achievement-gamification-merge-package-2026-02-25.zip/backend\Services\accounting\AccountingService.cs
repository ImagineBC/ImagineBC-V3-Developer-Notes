using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Npgsql;
using Dapper;
using ImagineBC.MainService.Services;

namespace ImagineBC.MainService.Services.Accounting
{
    /// <summary>Thrown when ledger debits and credits for a transaction do not balance. Prevents commit. Caller should return 400 Bad Request.</summary>
    public sealed class LedgerOutOfBalanceException : InvalidOperationException
    {
        public LedgerOutOfBalanceException(string message, decimal sumDebit, decimal sumCredit) : base(message)
        {
            SumDebit = sumDebit;
            SumCredit = sumCredit;
        }
        public decimal SumDebit { get; }
        public decimal SumCredit { get; }
    }

    //--------------------------------------------------------------------------------------------------------
    //--balance vector
    public sealed class BalanceVector
    {
        public string Owner { get; }
        public decimal Transferable;
        public decimal NonTransferable;
        public decimal Community;
        public decimal Special;
        public decimal Overflow;
        public decimal Subscription;

        public decimal Total =>
            Transferable
            + NonTransferable
            + Community
            + Special
            + Overflow
            + Subscription;

        private BalanceVector(string owner)
        {
            if (string.IsNullOrWhiteSpace(owner))
                throw new ArgumentException(nameof(owner));

            Owner = owner;
        }

        public static BalanceVector Debit(string? owner) =>
            new BalanceVector(NormalizeOwner(owner));

        public static BalanceVector Credit(string? owner) =>
            new BalanceVector(NormalizeOwner(owner));

        public static BalanceVector CreditTransferable(
            string? owner,
            decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount));

            return new BalanceVector(NormalizeOwner(owner))
            {
                Transferable = amount
            };
        }

        public static BalanceVector ForSpend(
            string? owner,
            decimal transferable = 0m,
            decimal nonTransferable = 0m,
            decimal community = 0m,
            decimal special = 0m,
            decimal subscription = 0m)
        {
            return new BalanceVector(NormalizeOwner(owner))
            {
                Transferable = transferable,
                NonTransferable = nonTransferable,
                Community = community,
                Special = special,
                Subscription = subscription
            };
        }

        public BalanceVector CloneForReceiver(string? newOwner)
        {
            return new BalanceVector(NormalizeOwner(newOwner))
            {
                Transferable = Transferable,
                NonTransferable = NonTransferable,
                Community = Community,
                Special = Special,
                Overflow = Overflow,
                Subscription = Subscription
            };
        }

        private static string NormalizeOwner(string? owner)
        {
            if (string.IsNullOrWhiteSpace(owner))
                throw new ArgumentException("BalanceVector owner is required");

            return owner;
        }

        public bool IsZero()
        {
            return Transferable == 0m
                && NonTransferable == 0m
                && Community == 0m
                && Special == 0m
                && Overflow == 0m
                && Subscription == 0m;
        }
    }


    //--------------------------------------------------------------------------------------------------------
    //--wallet snapshot

    public sealed class WalletSnapshot
    {
        public string ReferralCode { get; internal set; } = string.Empty;
        public decimal Transferable { get; internal set; }
        public decimal NonTransferable { get; internal set; }
        public decimal Community { get; internal set; }
        public decimal Special { get; internal set; }
        public decimal Overflow { get; internal set; }
        public decimal Subscription { get; internal set; }
        public decimal TotalPoints { get; internal set; }
        public string SubscriptionDetailsJson { get; internal set; } = "{}";

        internal WalletSnapshot()
        {
        }

        // FACTORY
        public static WalletSnapshot FromReader(IDataReader reader)
        {
            return new WalletSnapshot
            {
                ReferralCode = reader["referral_code"] == DBNull.Value
                    ? string.Empty
                    : reader["referral_code"].ToString()!,
                Transferable = Convert.ToDecimal(reader["transferable"]),
                NonTransferable = Convert.ToDecimal(reader["nontransferable"]),
                Community = Convert.ToDecimal(reader["community"]),
                Special = Convert.ToDecimal(reader["special"]),
                Overflow = Convert.ToDecimal(reader["overflow"]),
                Subscription = Convert.ToDecimal(reader["subscription"]),
                SubscriptionDetailsJson = reader["subscription_details"]?.ToString() ?? "{}"
            };
        }

        // MUTATIONS

        public void ApplyDebit(BalanceVector vector)
        {
            Transferable -= vector.Transferable;
            NonTransferable -= vector.NonTransferable;
            Community -= vector.Community;
            Special -= vector.Special;
            Subscription -= vector.Subscription;
            RecalculateTotalPoints();
        }

        public void ApplyCredit(BalanceVector vector)
        {
            Transferable += vector.Transferable;
            NonTransferable += vector.NonTransferable;
            Community += vector.Community;
            Special += vector.Special;
            Subscription += vector.Subscription;
            RecalculateTotalPoints();
        }

        public void ConsumeSubscriptionBalance(decimal amount)
        {
            if (amount <= 0) return;

            if (Subscription < amount)
                throw new InvalidOperationException("Insufficient subscription balance");

            Subscription -= amount;
            RecalculateTotalPoints();
        }

        // TOTALS

        public void RecalculateTotalPoints()
        {
            TotalPoints = Transferable
                          + NonTransferable
                          + Community
                          + Special
                          + Overflow
                          + Subscription;
        }
    }

    //--------------------------------------------------------------------------------------------------------
    //--reward distribution persistence (preview guardrail: no-op or throwing)

    /// <summary>Abstraction for reward-distribution persistence. Preview uses no-op or throwing implementation to guarantee zero DB writes.</summary>
    public interface IRewardDistributionPersistence
    {
        void DebitCampaignBalances(IDbConnection conn, IDbTransaction tx, string campaignIdOrReferral, decimal amount, CampaignBalances balances, string mode);
        void ApplyVectors(BalanceVector debit, IReadOnlyList<BalanceVector> credits, string transactionType, JObject payload, JObject metadata, string mode, NpgsqlConnection conn, NpgsqlTransaction tx);
        void WriteLedger(string txId, string transactionType, BalanceVector debit, IReadOnlyList<BalanceVector> credits, JObject payload, JObject metadata, string mode, NpgsqlConnection conn, NpgsqlTransaction tx);
        void MarkIntentConsumed(IDbConnection conn, IDbTransaction tx, Guid intentId);
    }

    /// <summary>No-op implementation for preview: all methods do nothing.</summary>
    public sealed class NoOpRewardDistributionPersistence : IRewardDistributionPersistence
    {
        public void DebitCampaignBalances(IDbConnection conn, IDbTransaction tx, string campaignIdOrReferral, decimal amount, CampaignBalances balances, string mode) { }
        public void ApplyVectors(BalanceVector debit, IReadOnlyList<BalanceVector> credits, string transactionType, JObject payload, JObject metadata, string mode, NpgsqlConnection conn, NpgsqlTransaction tx) { }
        public void WriteLedger(string txId, string transactionType, BalanceVector debit, IReadOnlyList<BalanceVector> credits, JObject payload, JObject metadata, string mode, NpgsqlConnection conn, NpgsqlTransaction tx) { }
        public void MarkIntentConsumed(IDbConnection conn, IDbTransaction tx, Guid intentId) { }
    }

    /// <summary>Throwing implementation for preview guardrail: any write attempt throws.</summary>
    public sealed class ThrowingRewardDistributionPersistence : IRewardDistributionPersistence
    {
        private static InvalidOperationException PreviewWriteException() =>
            new InvalidOperationException("Preview mode: writing is not allowed. All persistence must be no-op in preview.");

        public void DebitCampaignBalances(IDbConnection conn, IDbTransaction tx, string campaignIdOrReferral, decimal amount, CampaignBalances balances, string mode) => throw PreviewWriteException();
        public void ApplyVectors(BalanceVector debit, IReadOnlyList<BalanceVector> credits, string transactionType, JObject payload, JObject metadata, string mode, NpgsqlConnection conn, NpgsqlTransaction tx) => throw PreviewWriteException();
        public void WriteLedger(string txId, string transactionType, BalanceVector debit, IReadOnlyList<BalanceVector> credits, JObject payload, JObject metadata, string mode, NpgsqlConnection conn, NpgsqlTransaction tx) => throw PreviewWriteException();
        public void MarkIntentConsumed(IDbConnection conn, IDbTransaction tx, Guid intentId) => throw PreviewWriteException();
    }

    /// <summary>One row for ledger display. Amount is signed; entry_type is DEBIT or CREDIT. All amounts rounded to 6 decimals. TransactionType = business operation; TransactionCode = posting code (BO/PI/etc).</summary>
    public sealed class RewardDistributionLedgerRowDto
    {
        public string ReferralCode { get; set; } = "";
        public string PointType { get; set; } = "";
        public decimal Amount { get; set; }
        public string EntryType { get; set; } = "";
        public string TransactionType { get; set; } = "";
        public string TransactionCode { get; set; } = "";
        public string SubLedgerName { get; set; } = "";
        public string AccountNumber { get; set; } = "";
    }

    /// <summary>One row for bank subledger display (1100 restricted cash pending). Debit/Credit to 6 decimals; no DB.</summary>
    public sealed class BankSubLedgerRowDto
    {
        public string Description { get; set; } = "";
        public decimal DebitAmount { get; set; }
        public decimal CreditAmount { get; set; }
        public string GlAccountCode { get; set; } = "";
        public string PostingCode { get; set; } = "";
        public string PointType { get; set; } = "";
        public string ReferralCode { get; set; } = "";
        public string ReferralLabel { get; set; } = "";
    }

    /// <summary>Pure builder for bank_sub_ledger display rows from distribution amounts. Descriptions come from subledger_definition table (caller loads via Get1100SubledgerDefinitions).</summary>
    public static class BankSubLedgerRowBuilder
    {
        /// <summary>Builds bank subledger rows (description, debit, credit, gl_account_code) for preview. descriptions: [0]=Member Cash, [1]=IMBC, [2]=SC, [3]=GP (from subledger_definition). All amounts Round6. Optional referral metadata populates PostingCode, PointType, ReferralCode, ReferralLabel for each row.</summary>
        public static List<BankSubLedgerRowDto> Build(
            IReadOnlyList<string> descriptions,
            decimal amount,
            decimal imagineBcAmount,
            decimal totalSocialCause,
            decimal genesisPoolAmount,
            string subledgerGlAccountCode,
            string? debitOwner = null,
            string? imagineBcReferral = null,
            string? genesisPoolReferral = null,
            string? donationPoolReferral = null,
            string? debitPointType = null,
            decimal? sellerReferrerKeeps = null,
            decimal? buyerReferrerAmount = null,
            decimal? sellerKeeps = null,
            string? sellerReferrer = null,
            string? buyerReferrer = null,
            string? sellerReferral = null)
        {
            if (descriptions == null || descriptions.Count < 4)
                throw new ArgumentException("descriptions must have at least 4 elements (Member Cash, IMBC, SC, GP)", nameof(descriptions));
            var list = new List<BankSubLedgerRowDto>();
            decimal R(decimal x) => AccountingHelpers.Round6(x);

            void Add(string description, decimal debitAmt, decimal creditAmt, string postingCode, string pointType, string referralCode, string referralLabel)
            {
                if (debitAmt == 0m && creditAmt == 0m) return;
                list.Add(new BankSubLedgerRowDto
                {
                    Description = description,
                    DebitAmount = R(debitAmt),
                    CreditAmount = R(creditAmt),
                    GlAccountCode = subledgerGlAccountCode,
                    PostingCode = postingCode ?? "",
                    PointType = pointType ?? "",
                    ReferralCode = referralCode ?? "",
                    ReferralLabel = referralLabel ?? ""
                });
            }

            Add(descriptions[0], 0m, amount, debitOwner != null ? "BO" : "", "encumbered", debitOwner ?? "", "");
            if (imagineBcAmount > 0m) Add(descriptions[1], imagineBcAmount, 0m, imagineBcReferral != null ? "IBCI" : "", "transferable", imagineBcReferral ?? "", "IMBC");
            if (totalSocialCause > 0m) Add(descriptions[2], 0m, totalSocialCause, donationPoolReferral != null ? "SCO" : "", "community", donationPoolReferral ?? "", "SC");
            if (genesisPoolAmount > 0m) Add(descriptions[3], genesisPoolAmount, 0m, genesisPoolReferral != null ? "GPI" : "", "transferable", genesisPoolReferral ?? "", "GP");
            if (sellerReferrerKeeps.GetValueOrDefault() > 0m && !string.IsNullOrWhiteSpace(sellerReferrer)) Add(descriptions[0], sellerReferrerKeeps!.Value, 0m, "PRI", "transferable", sellerReferrer ?? "", "PRI");
            if (buyerReferrerAmount.GetValueOrDefault() > 0m && !string.IsNullOrWhiteSpace(buyerReferrer)) Add(descriptions[0], buyerReferrerAmount!.Value, 0m, "BRI", "transferable", buyerReferrer ?? "", "BRI");
            if (sellerKeeps.GetValueOrDefault() > 0m && !string.IsNullOrWhiteSpace(sellerReferral)) Add(descriptions[0], sellerKeeps!.Value, 0m, "PI", "transferable", sellerReferral ?? "", "PI");

            return list;
        }

        /// <summary>Derives distribution amounts from debit/credits for bank subledger preview (no DB).</summary>
        public static (decimal amount, decimal imagineBcAmount, decimal totalSocialCause, decimal genesisPoolAmount) GetAmountsFromVectors(
            BalanceVector debit,
            IReadOnlyList<BalanceVector> credits,
            string imagineBcReferral,
            string donationPoolReferral,
            string genesisPoolReferral)
        {
            decimal R(decimal x) => AccountingHelpers.Round6(x);
            decimal amount = R(debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription);
            decimal imagineBcAmount = 0m, totalSocialCause = 0m, genesisPoolAmount = 0m;
            foreach (var c in credits)
            {
                if (c.Owner == imagineBcReferral)
                    imagineBcAmount += c.Transferable + c.Subscription + c.Community;
                else if (c.Owner == donationPoolReferral)
                    totalSocialCause += c.Community + c.Transferable;
                else if (c.Owner == genesisPoolReferral)
                    genesisPoolAmount += c.Transferable + c.Subscription + c.Community;
            }
            return (amount, R(imagineBcAmount), R(totalSocialCause), R(genesisPoolAmount));
        }
    }

    /// <summary>Pure ledger row builder: derives display rows from debit + credits (canonical vectors). No DB. Round6 for amounts. GL only; no bank-pending narrative in SubLedgerName.</summary>
    public static class RewardDistributionLedgerRowBuilder
    {
        private const string ImbcGlReward = "4000";

        public static List<RewardDistributionLedgerRowDto> Build(
            BalanceVector debit,
            IReadOnlyList<BalanceVector> credits,
            string sellerReferral,
            string imagineBcReferral,
            string genesisPoolReferral,
            string donationPoolReferral,
            string? buyerReferrer,
            string? sellerReferrer)
        {
            var list = new List<RewardDistributionLedgerRowDto>();
            decimal Round6(decimal x) => AccountingHelpers.Round6(x);

            // GL ledger rows only; no bank-pending narrative in SubLedgerName (those appear in bank subledger section).
            void Add(string referral, string pointType, decimal amount, string entryType, string transactionType, string code, string accountNumber)
            {
                if (amount == 0m) return;
                list.Add(new RewardDistributionLedgerRowDto
                {
                    ReferralCode = referral ?? "",
                    PointType = pointType,
                    Amount = Round6(amount),
                    EntryType = entryType,
                    TransactionType = transactionType,
                    TransactionCode = code,
                    SubLedgerName = "",
                    AccountNumber = accountNumber
                });
            }

            string Pt(BalanceVector v)
            {
                if (v.Transferable != 0m) return "transferable";
                if (v.Subscription != 0m) return "subscription";
                if (v.Community != 0m) return "community";
                return "transferable";
            }

            const string businessTransactionType = "reward_distribution";
            var debitPt = Pt(debit);
            if (debit.Transferable != 0m) Add(debit.Owner, "encumbered", -debit.Transferable, "DEBIT", businessTransactionType, "BO", "2100");
            if (debit.Subscription != 0m) Add(debit.Owner, "encumbered", -debit.Subscription, "DEBIT", businessTransactionType, "BO", "2100");

            foreach (var c in credits)
            {
                if (c.IsZero()) continue;
                var owner = c.Owner;
                if (c.Transferable != 0m)
                {
                    if (owner == sellerReferral) Add(owner, "transferable", c.Transferable, "CREDIT", businessTransactionType, "PI", "2100");
                    else if (owner == sellerReferrer) Add(owner, "transferable", c.Transferable, "CREDIT", businessTransactionType, "PRI", "2100");
                    else if (owner == buyerReferrer) Add(owner, "transferable", c.Transferable, "CREDIT", businessTransactionType, "BRI", "2100");
                    else if (owner == imagineBcReferral) Add(owner, "transferable", c.Transferable, "CREDIT", businessTransactionType, "IBCI", ImbcGlReward);
                    else if (owner == genesisPoolReferral)
                    {
                        var amt = Round6(c.Transferable);
                        Add(owner, "transferable", amt, "CREDIT", businessTransactionType, "GPI", "4100");
                        Add(owner, "transferable", amt, "CREDIT", businessTransactionType, "GPA", "2310");
                        Add(owner, "transferable", -amt, "DEBIT", businessTransactionType, "GPA", "5000");
                    }
                    else Add(owner, "transferable", c.Transferable, "CREDIT", businessTransactionType, "SCO", "2300");
                }
                if (c.Subscription != 0m)
                {
                    if (owner == sellerReferral) Add(owner, "subscription", c.Subscription, "CREDIT", businessTransactionType, "PI", "2100");
                    else if (owner == sellerReferrer) Add(owner, "subscription", c.Subscription, "CREDIT", businessTransactionType, "PRI", "2100");
                    else if (owner == buyerReferrer) Add(owner, "subscription", c.Subscription, "CREDIT", businessTransactionType, "BRI", "2100");
                    else if (owner == imagineBcReferral) Add(owner, "subscription", c.Subscription, "CREDIT", businessTransactionType, "IBCI", ImbcGlReward);
                    else if (owner == genesisPoolReferral)
                    {
                        var amt = Round6(c.Subscription);
                        Add(owner, "subscription", amt, "CREDIT", businessTransactionType, "GPI", "4100");
                        Add(owner, "subscription", amt, "CREDIT", businessTransactionType, "GPA", "2310");
                        Add(owner, "subscription", -amt, "DEBIT", businessTransactionType, "GPA", "5000");
                    }
                    else Add(owner, "subscription", c.Subscription, "CREDIT", businessTransactionType, "SCO", "2300");
                }
                if (c.Community != 0m) Add(owner, "community", c.Community, "CREDIT", businessTransactionType, "SCO", "2300");
            }

            return list;
        }
    }

    //--------------------------------------------------------------------------------------------------------
    //--balance service

    public sealed class BalanceService
    {
        private readonly string _connectionString;
        private readonly LedgerWriteService _ledger;
        private readonly DebugTraceService? _debugTrace;

        public BalanceService(
            string connectionString,
            LedgerWriteService ledger,
            DebugTraceService? debugTrace = null)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _ledger = ledger ?? throw new ArgumentNullException(nameof(ledger));
            _debugTrace = debugTrace;
        }

        // LOAD WALLET

        public WalletSnapshot LoadWalletSnapshot(
            string referralCode,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            if (string.IsNullOrWhiteSpace(referralCode))
                throw new ArgumentException(nameof(referralCode));
            if (conn == null)
                throw new ArgumentNullException(nameof(conn));
            if (tx == null)
                throw new ArgumentNullException(nameof(tx));

            var tableName = "memberwalletbalances";

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = $@"
                    SELECT transferable, nontransferable, community, special, overflow, subscription, totalpoints, subscription_details
                    FROM {tableName}
                    WHERE referral_code = @referral
                    FOR UPDATE
                ";
                cmd.Parameters.AddWithValue("@referral", referralCode);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new WalletSnapshot
                    {
                        ReferralCode = referralCode,
                        Transferable = reader.GetDecimal(0),
                        NonTransferable = reader.GetDecimal(1),
                        Community = reader.GetDecimal(2),
                        Special = reader.GetDecimal(3),
                        Overflow = reader.GetDecimal(4),
                        Subscription = reader.GetDecimal(5),
                        TotalPoints = reader.GetDecimal(6),
                        SubscriptionDetailsJson = reader.IsDBNull(7) ? "{}" : reader.GetString(7)
                    };
                }
            }

            // WALLET DOES NOT EXIST — CREATE IT ATOMICALLY
            using (var insert = conn.CreateCommand())
            {
                insert.Transaction = tx;
                insert.CommandText = $@"
                    INSERT INTO {tableName}
                        (referral_code, transferable, nontransferable, community, special, overflow, subscription, totalpoints)
                    VALUES
                        (@referral, 0, 0, 0, 0, 0, 0, 0)
                ";
                insert.Parameters.AddWithValue("@referral", referralCode);
                insert.ExecuteNonQuery();
            }

            // RELOAD UNDER THE SAME TRANSACTION + LOCK
            using (var reload = conn.CreateCommand())
            {
                reload.Transaction = tx;
                reload.CommandText = $@"
                    SELECT transferable, nontransferable, community, special, overflow, subscription, totalpoints, subscription_details
                    FROM {tableName}
                    WHERE referral_code = @referral
                    FOR UPDATE
                ";
                reload.Parameters.AddWithValue("@referral", referralCode);

                using var reader = reload.ExecuteReader();
                if (!reader.Read())
                    throw new InvalidOperationException($"Wallet bootstrap failed for referral {referralCode}");

                return new WalletSnapshot
                {
                    ReferralCode = referralCode,
                    Transferable = reader.GetDecimal(0),
                    NonTransferable = reader.GetDecimal(1),
                    Community = reader.GetDecimal(2),
                    Special = reader.GetDecimal(3),
                    Overflow = reader.GetDecimal(4),
                    Subscription = reader.GetDecimal(5),
                    TotalPoints = reader.GetDecimal(6),
                    SubscriptionDetailsJson = reader.IsDBNull(7) ? "{}" : reader.GetString(7)
                };
            }
        }

        //--persist wallet
        private static void PersistWallet(
            WalletSnapshot wallet,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            if (wallet == null)
                throw new ArgumentNullException(nameof(wallet));
            if (conn == null)
                throw new ArgumentNullException(nameof(conn));
            if (tx == null)
                throw new ArgumentNullException(nameof(tx));

            var tableName = "memberwalletbalances";

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                UPDATE {tableName}
                SET
                    transferable = @transferable,
                    nontransferable = @nontransferable,
                    community = @community,
                    special = @special,
                    overflow = @overflow,
                    subscription = @subscription,
                    totalpoints = @total
                WHERE referral_code = @referral
            ";

            cmd.Parameters.AddWithValue("@transferable", wallet.Transferable);
            cmd.Parameters.AddWithValue("@nontransferable", wallet.NonTransferable);
            cmd.Parameters.AddWithValue("@community", wallet.Community);
            cmd.Parameters.AddWithValue("@special", wallet.Special);
            cmd.Parameters.AddWithValue("@overflow", wallet.Overflow);
            cmd.Parameters.AddWithValue("@subscription", wallet.Subscription);
            cmd.Parameters.AddWithValue("@total", wallet.TotalPoints);
            cmd.Parameters.AddWithValue("@referral", wallet.ReferralCode);

            cmd.ExecuteNonQuery();
        }

        //--ensure wallet balance history partition exists
        // Creates the partition for the current date if it doesn't exist
        // This prevents "23514: no partition found" errors when inserting into partitioned table
        private static void EnsureWalletBalanceHistoryPartition(
            bool isTest,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // Test table is not partitioned, no need to ensure partition
            if (isTest)
                return;

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;

            // Use PostgreSQL's date functions to ensure partition exists for current date
            // This is idempotent - won't fail if partition already exists
            // Check using pg_inherits to find child partitions of wallet_balance_history
            cmd.CommandText = @"
                DO $$
                DECLARE
                    partition_date DATE := CURRENT_DATE;
                    partition_name TEXT := 'wallet_balance_history_' || TO_CHAR(partition_date, 'YYYY_MM_DD');
                    partition_start TIMESTAMPTZ := partition_date;
                    partition_end TIMESTAMPTZ := partition_date + INTERVAL '1 day';
                    parent_oid OID := 'public.wallet_balance_history'::regclass;
                BEGIN
                    -- Check if partition already exists by looking for the table name in public schema
                    IF NOT EXISTS (
                        SELECT 1 FROM pg_class c
                        JOIN pg_namespace n ON n.oid = c.relnamespace
                        WHERE n.nspname = 'public'
                          AND c.relname = partition_name
                    ) THEN
                        EXECUTE format('
                            CREATE TABLE %I PARTITION OF public.wallet_balance_history
                            FOR VALUES FROM (%L) TO (%L)
                        ', partition_name, partition_start, partition_end);
                    END IF;
                EXCEPTION
                    WHEN duplicate_table THEN
                        -- Partition already exists, ignore
                        NULL;
                END $$;
            ";

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Npgsql.PostgresException ex) when (ex.SqlState == "42P07") // duplicate_table
            {
                // Partition already exists, ignore this error
                // This can happen if partition was created between check and create
            }
        }

        //--snapshot wallet balance for audit trail
        // Snapshot all point types to capture complete wallet state at transaction time
        private static void SnapshotWalletBalance(
            WalletSnapshot wallet,
            string txId,
            bool isTest,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            if (wallet == null)
                throw new ArgumentNullException(nameof(wallet));
            if (string.IsNullOrWhiteSpace(txId))
                throw new ArgumentException("Transaction ID is required", nameof(txId));
            if (conn == null)
                throw new ArgumentNullException(nameof(conn));
            if (tx == null)
                throw new ArgumentNullException(nameof(tx));

            var tableName = "wallet_balance_history";

            // CRITICAL: Ensure partition exists before inserting (only for production table)
            // This prevents "23514: no partition found" errors
            EnsureWalletBalanceHistoryPartition(isTest, conn, tx);

            // Snapshot all point types to capture complete wallet state
            // This provides full audit trail even if some balances are zero
            var pointTypes = new[]
            {
                ("transferable", wallet.Transferable),
                ("nonTransferable", wallet.NonTransferable),
                ("community", wallet.Community),
                ("special", wallet.Special),
                ("overflow", wallet.Overflow),
                ("subscription", wallet.Subscription)
            };

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;

            // Build batch insert for all point types
            var values = new List<string>();
            var parameters = new List<NpgsqlParameter>();
            var paramIndex = 0;

            foreach (var (pointType, balance) in pointTypes)
            {
                var referralParam = new NpgsqlParameter($"@ref{paramIndex}", wallet.ReferralCode);
                var pointTypeParam = new NpgsqlParameter($"@pt{paramIndex}", pointType);
                var balanceParam = new NpgsqlParameter($"@bal{paramIndex}", balance);
                var txIdParam = new NpgsqlParameter($"@txid{paramIndex}", txId);

                parameters.Add(referralParam);
                parameters.Add(pointTypeParam);
                parameters.Add(balanceParam);
                parameters.Add(txIdParam);

                values.Add($"({referralParam.ParameterName}, {pointTypeParam.ParameterName}, {balanceParam.ParameterName}, NOW(), {txIdParam.ParameterName}, NOW())");
                paramIndex++;
            }

            if (values.Count == 0)
                return;

            cmd.CommandText = $@"
                INSERT INTO {tableName} (
                    referral_code,
                    point_type,
                    balance,
                    transaction_date,
                    tx_id,
                    created_at
                )
                VALUES {string.Join(", ", values)}
                ON CONFLICT (referral_code, point_type, tx_id, transaction_date) DO NOTHING
            ";

            foreach (var param in parameters)
            {
                cmd.Parameters.Add(param);
            }

            cmd.ExecuteNonQuery();
        }

        //--apply vectors
        // NOTE: This now operates entirely within the caller's connection/transaction.
        // There is no internal connection/transaction creation or commit here anymore.
        public void ApplyVectors(
            BalanceVector debit,
            IReadOnlyList<BalanceVector> credits,
            string transactionType,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            if (debit == null)
                throw new ArgumentNullException(nameof(debit));
            if (credits == null)
                throw new ArgumentNullException(nameof(credits));
            if (payload == null)
                throw new ArgumentNullException(nameof(payload));
            if (metadata == null)
                throw new ArgumentNullException(nameof(metadata));

            var isTest = mode != "production";
            
            _debugTrace?.Write($"[APPLY_VECTORS] 🔵 START: Type={transactionType}, Mode={mode}, Debit Owner={debit.Owner}, Credits Count={credits.Count}");

            // ---------------- APPLY DEBIT ----------------
            _debugTrace?.Write($"[APPLY_VECTORS] 📝 Applying debit: Owner={debit.Owner}, T={debit.Transferable}, NT={debit.NonTransferable}, C={debit.Community}, S={debit.Subscription}, O={debit.Overflow}");
            try
            {
                ApplySingleVector(
                    debit,
                    true,
                    transactionType,
                    payload,
                    metadata,
                    isTest,
                    conn,
                    tx);
                _debugTrace?.Write($"[APPLY_VECTORS] ✅ Debit applied successfully");
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[APPLY_VECTORS] ❌ ERROR applying debit: {ex.Message}");
                throw;
            }

            // ---------------- APPLY CREDITS ----------------
            _debugTrace?.Write($"[APPLY_VECTORS] 📝 Applying {credits.Count} credit(s)");
            int creditIndex = 0;
            foreach (var credit in credits)
            {
                creditIndex++;
                _debugTrace?.Write($"[APPLY_VECTORS] 📝 Credit #{creditIndex}: Owner={credit.Owner}, T={credit.Transferable}, NT={credit.NonTransferable}, C={credit.Community}, S={credit.Subscription}, O={credit.Overflow}");
                try
                {
                    ApplySingleVector(
                        credit,
                        false,
                        transactionType,
                        payload,
                        metadata,
                        isTest,
                        conn,
                        tx);
                    _debugTrace?.Write($"[APPLY_VECTORS] ✅ Credit #{creditIndex} applied successfully");
                }
                catch (Exception ex)
                {
                    _debugTrace?.Write($"[APPLY_VECTORS] ❌ ERROR applying credit #{creditIndex}: {ex.Message}");
                    throw;
                }
            }

            _debugTrace?.Write($"[APPLY_VECTORS] ✅ COMPLETE: All vectors applied successfully");

        }

        public void WriteLedger(
            string txId,
            string transactionType,
            BalanceVector debit,
            IReadOnlyList<BalanceVector> credits,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            var isTest = !string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
            var ledgerTable = "ledger";
            
            // Serialize metadata once (performance optimization)
            var metadataJson = metadata?.ToString() ?? "{}";
            
            // Extract transaction description from metadata (if provided)
            var txDescription = metadata?.Value<string>("txDescription");
            
            // Cache account codes per point type and referral code (performance optimization)
            // Key format: "pointType|referralCode" or just "pointType" if referralCode is null
            var accountCodeCache = new Dictionary<string, string>();
            string GetAccountCode(string pointType, string? referralCode = null)
            {
                var cacheKey = referralCode != null ? $"{pointType}|{referralCode}" : pointType;
                if (!accountCodeCache.TryGetValue(cacheKey, out var code))
                {
                    code = AccountingHelpers.ResolveAccountCode(conn, tx, transactionType ?? "", pointType, referralCode);
                    accountCodeCache[cacheKey] = code;
                }
                return code;
            }

            // Collect all inserts for batch processing
            var inserts = new List<(string owner, string pointType, decimal amount, string txSubtype)>();
            
            void AddInsert(string owner, string pointType, decimal amount, string txSubtype)
            {
                if (amount != 0m)
                {
                    inserts.Add((owner, pointType, amount, txSubtype));
                }
            }

            // ---------------- DEBIT ---------------- 
            AddInsert(debit.Owner, "transferable", -debit.Transferable, "WD");
            AddInsert(debit.Owner, "nonTransferable", -debit.NonTransferable, "UD");
            AddInsert(debit.Owner, "community", -debit.Community, "CD");
            AddInsert(debit.Owner, "special", -debit.Special, "UD");
            AddInsert(debit.Owner, "subscription", -debit.Subscription, "UD");
            AddInsert(debit.Owner, "overflow", -debit.Overflow, "DO");

            // ---------------- CREDITS ---------------- 
            foreach (var c in credits)
            {
                AddInsert(c.Owner, "transferable", c.Transferable, "WD");
                AddInsert(c.Owner, "nonTransferable", c.NonTransferable, "UD");
                AddInsert(c.Owner, "community", c.Community, "CD");
                AddInsert(c.Owner, "special", c.Special, "UD");
                AddInsert(c.Owner, "subscription", c.Subscription, "UD");
                AddInsert(c.Owner, "overflow", c.Overflow, "DO");
            }
            
            // CRITICAL: Ensure partition exists before inserting (only for production table)
            // This prevents "23514: no partition found" errors
            EnsureLedgerPartition(isTest, conn, tx);
            
            // Batch insert all entries in a single query (performance optimization)
            if (inserts.Count > 0)
            {
                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                
                var values = new List<string>();
                var paramIndex = 0;
                var parameters = new List<NpgsqlParameter>();
                
                foreach (var (owner, pointType, amount, txSubtype) in inserts)
                {
                    // For reward_distribution credits, pass the owner (referral code) to resolve correct account code
                    // (ImagineBC → 4100, Genesis Pool → 2310, members → 2100)
                    var accountCode = GetAccountCode(pointType, transactionType?.ToUpper() == "REWARD_DISTRIBUTION" && amount >= 0 ? owner : null);
                    var absoluteAmount = Math.Abs(amount);
                    var entryType = amount >= 0 ? "CREDIT" : "DEBIT";
                    
                    values.Add($"(@tx_id_{paramIndex}, @referral_code_{paramIndex}, @tx_type_{paramIndex}, @posting_code_{paramIndex}, @tx_subtype_{paramIndex}, @point_type_{paramIndex}, @account_number_{paramIndex}, @amount_{paramIndex}, NOW(), @metadata_{paramIndex}::jsonb, 'v3', @is_test_{paramIndex}, @tx_description_{paramIndex}, @entry_type_{paramIndex})");
                    
                    parameters.Add(new NpgsqlParameter($"@tx_id_{paramIndex}", txId));
                    parameters.Add(new NpgsqlParameter($"@referral_code_{paramIndex}", owner));
                    parameters.Add(new NpgsqlParameter($"@tx_type_{paramIndex}", transactionType));
                    parameters.Add(new NpgsqlParameter($"@posting_code_{paramIndex}", DBNull.Value));
                    parameters.Add(new NpgsqlParameter($"@tx_subtype_{paramIndex}", txSubtype));
                    parameters.Add(new NpgsqlParameter($"@point_type_{paramIndex}", pointType));
                    parameters.Add(new NpgsqlParameter($"@account_number_{paramIndex}", accountCode));
                    parameters.Add(new NpgsqlParameter($"@amount_{paramIndex}", absoluteAmount));
                    parameters.Add(new NpgsqlParameter($"@metadata_{paramIndex}", metadataJson));
                    parameters.Add(new NpgsqlParameter($"@is_test_{paramIndex}", isTest));
                    parameters.Add(new NpgsqlParameter($"@tx_description_{paramIndex}", (object?)txDescription ?? DBNull.Value));
                    parameters.Add(new NpgsqlParameter($"@entry_type_{paramIndex}", entryType));
                    
                    paramIndex++;
                }
                
                cmd.CommandText = $@"
                    INSERT INTO {ledgerTable} (
                        tx_id,
                        referral_code,
                        tx_type,
                        posting_code,
                        tx_subtype,
                        point_type,
                        account_number,
                        amount,
                        transaction_date,
                        metadata,
                        source_system,
                        is_test,
                        tx_description,
                        entry_type
                    )
                    VALUES {string.Join(", ", values)};
                ";
                
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }
                cmd.ExecuteNonQuery();
            }
        }

        //--ensure ledger partition exists
        // Creates the partition for the current date if it doesn't exist
        // This prevents "23514: no partition found" errors when inserting into partitioned ledger table
        private void EnsureLedgerPartition(
            bool isTest,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // Test table is not partitioned, no need to ensure partition
            if (isTest)
                return;

            var partitionDate = DateTime.UtcNow.Date;
            var partitionName = $"ledger_{partitionDate:yyyy_MM_dd}";
            var partitionStart = partitionDate.ToString("yyyy-MM-dd HH:mm:ss.ffffffZ");
            var partitionEnd = partitionDate.AddDays(1).ToString("yyyy-MM-dd HH:mm:ss.ffffffZ");

            _debugTrace?.Write($"[EnsureLedgerPartition] Checking partition: {partitionName} for date {partitionDate:yyyy-MM-dd}");

            // Check if partition exists
            using (var checkCmd = conn.CreateCommand())
            {
                checkCmd.Transaction = tx;
                checkCmd.CommandText = @"
                    SELECT 1 FROM pg_class c
                    JOIN pg_namespace n ON n.oid = c.relnamespace
                    WHERE n.nspname = 'public' 
                      AND c.relname = @partitionName;";
                checkCmd.Parameters.AddWithValue("partitionName", partitionName);

                var exists = checkCmd.ExecuteScalar() != null;

                if (!exists)
                {
                    _debugTrace?.Write($"[EnsureLedgerPartition] Partition {partitionName} does not exist. Creating...");
                    try
                    {
                        using var createCmd = conn.CreateCommand();
                        createCmd.Transaction = tx;
                        createCmd.CommandText = $@"
                            CREATE TABLE IF NOT EXISTS public.{partitionName} PARTITION OF public.ledger
                            FOR VALUES FROM ('{partitionStart}') TO ('{partitionEnd}');";
                        createCmd.ExecuteNonQuery();
                        _debugTrace?.Write($"[EnsureLedgerPartition] ✅ Created partition: {partitionName} for range '{partitionStart}' to '{partitionEnd}'");
                    }
                    catch (Npgsql.PostgresException pex) when (pex.SqlState == "42P07") // duplicate_table
                    {
                        // This can happen in a race condition if another concurrent transaction
                        // created the partition just before this one. It's safe to ignore.
                        _debugTrace?.Write($"[EnsureLedgerPartition] ℹ️ Partition {partitionName} already exists (race condition), continuing.");
                    }
                    catch (Exception ex)
                    {
                        _debugTrace?.Write($"[EnsureLedgerPartition] ❌ Error creating partition {partitionName}: {ex.Message}, StackTrace: {ex.StackTrace}");
                        throw; // Re-throw if it's another type of error
                    }
                }
                else
                {
                    _debugTrace?.Write($"[EnsureLedgerPartition] ℹ️ Partition {partitionName} for {partitionDate:yyyy-MM-dd} already exists.");
                }
            }
        }

        private void ApplySingleVector(
            BalanceVector vector,
            bool isDebit,
            string transactionType,
            JObject payload,
            JObject metadata,
            bool isTest,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            var wallet = LoadWalletSnapshot(
                vector.Owner,
                isTest ? "test" : "production",
                conn,
                tx
            );

            if (isDebit)
                wallet.ApplyDebit(vector);
            else
                wallet.ApplyCredit(vector);

            PersistWallet(wallet, isTest ? "test" : "production", conn, tx);

            // Snapshot balance for audit trail (after wallet is persisted)
            var txId = metadata?.Value<string>("txId");
            if (!string.IsNullOrWhiteSpace(txId))
            {
                SnapshotWalletBalance(wallet, txId, isTest, conn, tx);
            }
        }

        //--apply balance delta
        public bool ApplyBalanceDelta(
            string referralCode,
            string pointType,
            decimal delta,
            JObject metadata,
            string mode)
        {
            if (string.IsNullOrWhiteSpace(referralCode))
                throw new ArgumentException(nameof(referralCode));
            if (string.IsNullOrWhiteSpace(pointType))
                throw new ArgumentException(nameof(pointType));

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            using var tx = conn.BeginTransaction();

            var wallet = LoadWalletSnapshot(referralCode, mode, conn, tx);

            switch (pointType)
            {
                case "transferable":
                    wallet.Transferable += delta;
                    break;
                case "nontransferable":
                    wallet.NonTransferable += delta;
                    break;
                case "community":
                    wallet.Community += delta;
                    break;
                case "special":
                    wallet.Special += delta;
                    break;
                case "subscription":
                    wallet.Subscription += delta;
                    break;
                default:
                    throw new InvalidOperationException($"Unsupported point type: {pointType}");
            }

            if (wallet.Transferable < 0m
                || wallet.NonTransferable < 0m
                || wallet.Community < 0m
                || wallet.Special < 0m
                || wallet.Subscription < 0m)
            {
                tx.Rollback();
                return false;
            }

            wallet.RecalculateTotalPoints();
            PersistWallet(wallet, mode, conn, tx);

            tx.Commit();
            return true;
        }

        //----------------------------------------------------------------------------------------------------
        //--
        public bool ApplyMemberPointsPurchaseCredit(
            string memberReferral,
            decimal netAmount,
            string fundingMethod,
            decimal processingFee,
            JObject metadata,
            string mode)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
                throw new InvalidOperationException("memberReferral is required");

            if (netAmount <= 0)
                throw new InvalidOperationException("netAmount must be greater than zero");

            if (fundingMethod == "credit_card" && processingFee < 0)
                throw new InvalidOperationException("processingFee must be >= 0");

            // -----------------------------------------------------------------
            // ACCOUNTING RULE (LOCKED):
            // - ONLY credit nonTransferable
            // - NO debit
            // - Processing fee NEVER touches member balances
            // -----------------------------------------------------------------

            var accountingMetadata = metadata ?? new JObject();
            accountingMetadata["fundingMethod"] = fundingMethod;
            accountingMetadata["processingFee"] = processingFee;
            accountingMetadata["source"] = "external_funding";

            // Credit member non-transferable balance
            return ApplyBalanceDelta(
                memberReferral,
                "nonTransferable",
                netAmount,
                accountingMetadata,
                mode
            );
        }

        public JObject ExecuteRewardDistribution(
            Guid secureToken,
            string mode)
        {
            var start = DateTime.UtcNow;
            var txId = Guid.NewGuid().ToString("N");
            
            // _debugTrace?.Write($"[REWARD_DIST] START: SecureToken={secureToken}, Mode={mode}, TxId={txId}");
            
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var tx = conn.BeginTransaction();

            try
            {
                // 1. Load intent (authoritative)
                // _debugTrace?.Write($"[REWARD_DIST] Step 1: Loading transaction intent...");
                var intent = LoadRewardDistributionIntent(
                    conn,
                    tx,
                    secureToken,
                    mode
                );
                // _debugTrace?.Write($"[REWARD_DIST] Intent loaded: Id={intent.Id}, Seller={intent.SellerReferral}, Buyer={intent.BuyerReferral}, Amount={intent.RewardAmount}");

                // Validate intent has required data
                if (string.IsNullOrWhiteSpace(intent.BuyerReferral) && !intent.BuyerCampaignId.HasValue)
                {
                    throw new InvalidOperationException(
                        $"Transaction intent {intent.Id} has empty buyer_referral and buyer_campaign_id. " +
                        $"SellerReferral: '{intent.SellerReferral}', " +
                        $"RewardAmount: {intent.RewardAmount}"
                    );
                }

                // Guardrail: Check for duplicate reward distribution (same seller + same campaign + same day)
                // Combined into single query for performance (performance optimization)
                var campaignIdForCheck = intent.BuyerCampaignId.HasValue 
                    ? intent.BuyerCampaignId.Value 
                    : (Guid?)null;
                var campaignReferralForCheck = intent.BuyerReferral;
                
                var ledgerTable = "ledger";
                var todayStart = DateTime.UtcNow.Date;
                var todayEnd = todayStart.AddDays(1);
                
                // Single combined query to check for duplicates (performance optimization)
                dynamic? existingReward = conn.QueryFirstOrDefault<dynamic>(
                    $@"SELECT id, tx_id, transaction_date
                       FROM {ledgerTable}
                       WHERE tx_type = 'reward_distribution'
                         AND referral_code = @sellerReferral
                         AND transaction_date >= @todayStart
                         AND transaction_date < @todayEnd
                         AND (
                             (@campaignId IS NOT NULL AND metadata->>'buyerCampaignId' = @campaignId)
                             OR (@campaignReferral IS NOT NULL AND metadata->>'buyerReferral' = @campaignReferral)
                         )
                       LIMIT 1",
                    new 
                    { 
                        sellerReferral = intent.SellerReferral,
                        todayStart = todayStart,
                        todayEnd = todayEnd,
                        campaignId = campaignIdForCheck?.ToString() ?? (string?)null,
                        campaignReferral = string.IsNullOrWhiteSpace(campaignReferralForCheck) ? (string?)null : campaignReferralForCheck
                    },
                    tx
                );
                
                if (existingReward != null)
                {
                    var existingDate = existingReward.transaction_date != null 
                        ? ((DateTime)existingReward.transaction_date).ToString("yyyy-MM-dd HH:mm:ss UTC")
                        : "unknown";
                    var existingTxId = existingReward.tx_id?.ToString() ?? "unknown";
                    throw new InvalidOperationException(
                        $"Duplicate reward distribution prevented: Seller '{intent.SellerReferral}' " +
                        $"has already received a reward_distribution for campaign " +
                        $"{(campaignIdForCheck?.ToString() ?? campaignReferralForCheck ?? "unknown")} today. " +
                        $"Existing transaction ID: {existingTxId}, " +
                        $"Created at: {existingDate}"
                    );
                }
                // _debugTrace?.Write($"[REWARD_DIST] No duplicate found - proceeding with distribution");

                // 2. Load campaign balances (TEST vs PROD)
                // Use BuyerCampaignId (UUID) if available, otherwise fallback to BuyerReferral
                var campaignIdentifier = intent.BuyerCampaignId.HasValue 
                    ? intent.BuyerCampaignId.Value.ToString() 
                    : intent.BuyerReferral;
                // _debugTrace?.Write($"[REWARD_DIST] Step 2: Loading campaign balances for {campaignIdentifier}...");
                CampaignBalances balances = LoadCampaignBalancesByCampaignIdOrReferral(conn, tx, campaignIdentifier);
                // _debugTrace?.Write($"[REWARD_DIST] Campaign balances: Community={balances.Community}, Transferable={balances.Transferable}");

                // 3. Debit campaign balances (community -> transferable)
                // _debugTrace?.Write($"[REWARD_DIST] Step 3: Debiting campaign balances...");
                DebitCampaignBalances(
                    conn,
                    tx,
                    campaignIdentifier,
                    intent.RewardAmount,
                    balances,
                    mode
                );
                // _debugTrace?.Write($"[REWARD_DIST] Campaign balances debited: {intent.RewardAmount}");

                // 4. Resolve system referral codes (needed for distribution engine)
                // _debugTrace?.Write($"[REWARD_DIST] Step 4: Resolving system referral codes...");
                var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
                var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
                var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);
                // _debugTrace?.Write($"[REWARD_DIST] System referrals: IMAGINEBC={imagineBcReferral}, GENESIS={genesisPoolReferral}, DONATION={donationPoolReferral}");

                // 5. Run full distribution engine and capture vectors
                // _debugTrace?.Write($"[REWARD_DIST] Step 5: Running distribution engine...");
                var (debit, credits) = RunRewardDistributionEngine(
                    conn,
                    tx,
                    intent,
                    mode,
                    imagineBcReferral,
                    genesisPoolReferral,
                    donationPoolReferral
                );
                // _debugTrace?.Write($"[REWARD_DIST] Distribution complete: Debit Owner={debit.Owner}, Credits Count={credits.Count}");

                // 6. Write ledger entries
                // _debugTrace?.Write($"[REWARD_DIST] Step 6: Writing ledger entries to ledger...");
                WriteLedger(
                    txId,
                    "reward_distribution",
                    debit,
                    credits,
                    intent.ToPayload(),
                    intent.ToMetadata(),
                    mode,
                    conn,
                    tx
                );
                // _debugTrace?.Write($"[REWARD_DIST] Ledger entries written successfully");

                // 7. Mark intent consumed
                // _debugTrace?.Write($"[REWARD_DIST] Step 7: Marking intent as consumed...");
                MarkTransactionIntentConsumed(
                    conn,
                    tx,
                    intent.Id
                );

                tx.Commit();
                // _debugTrace?.Write($"[REWARD_DIST] SUCCESS: Transaction committed. ExecutionMs={(int)(DateTime.UtcNow - start).TotalMilliseconds}");

                // 9. Return result in same format as ProcessTransaction
                // Add accountCode and ensure lowercase "owner" for frontend display
                var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "reward_distribution", "transferable");
                
                var debitWithAccountCode = new JObject
                {
                    ["owner"] = debit.Owner,
                    ["transferable"] = debit.Transferable,
                    ["nonTransferable"] = debit.NonTransferable,
                    ["community"] = debit.Community,
                    ["special"] = debit.Special,
                    ["overflow"] = debit.Overflow,
                    ["subscription"] = debit.Subscription,
                    ["total"] = debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription,
                    ["accountCode"] = debitAccountCode
                };
                
                var creditsArray = new JArray();
                foreach (var c in credits)
                {
                    // Resolve account code per credit based on owner (ImagineBC → 4100, Genesis Pool → 2310, members → 2100)
                    var creditPointType = c.Transferable > 0 ? "transferable" : 
                        c.NonTransferable > 0 ? "nonTransferable" : 
                        c.Community > 0 ? "community" : 
                        c.Subscription > 0 ? "subscription" : "transferable";
                    var creditAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "reward_distribution", creditPointType, c.Owner);
                    
                    creditsArray.Add(new JObject
                    {
                        ["owner"] = c.Owner,
                        ["transferable"] = c.Transferable,
                        ["nonTransferable"] = c.NonTransferable,
                        ["community"] = c.Community,
                        ["special"] = c.Special,
                        ["overflow"] = c.Overflow,
                        ["subscription"] = c.Subscription,
                        ["total"] = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription,
                        ["accountCode"] = creditAccountCode
                    });
                }
                
                // Construct JObject directly to avoid serialization issues with nested JObjects
                // Note: Display name resolution is handled by frontend test tool only
                var result = new JObject
                {
                    ["ok"] = true,
                    ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                    ["debit"] = debitWithAccountCode,
                    ["credits"] = creditsArray,
                    ["transactionType"] = "reward_distribution",
                    ["mode"] = mode,
                    ["txId"] = txId,
                    ["systemReferrals"] = new JObject
                    {
                        ["imaginebc"] = imagineBcReferral,
                        ["genesisPool"] = genesisPoolReferral,
                        ["donationPool"] = donationPoolReferral
                    }
                };
                
                return result;
            }
            catch (Exception)
            {
                tx.Rollback();
                // _debugTrace?.Write($"[REWARD_DIST] ERROR: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Preview reward distribution: uses production pipeline (RunRewardDistributionEngine + voluntary donation) and pure ledger row builder.
        /// Used by Test Tools (TEST and PRODUCTION mode) and test-scenarios/execute. Same logic for both; mode only affects campaign lookup.
        /// previewGuard must be no-op or throwing; it is never called but ensures no write can occur in preview. Zero DB writes.
        /// </summary>
        public JObject PreviewRewardDistribution(TransactionIntent intent, string mode, IRewardDistributionPersistence previewGuard)
        {
            var start = DateTime.UtcNow;
            var txId = Guid.NewGuid().ToString("N");
            var isProduction = string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
            mode = isProduction ? "production" : "test";

            if (string.IsNullOrWhiteSpace(intent.BuyerReferral) && !intent.BuyerCampaignId.HasValue)
                throw new InvalidOperationException("Intent must have buyerReferral or buyerCampaignId");

            // Single preview path: always use DB for system referrals and account names; zero writes via previewGuard.
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            using var tx = conn.BeginTransaction();

            try
            {
                var campaignIdentifier = intent.BuyerCampaignId.HasValue
                    ? intent.BuyerCampaignId.Value.ToString()
                    : intent.BuyerReferral;

                // Production: resolve BuyerReferral from campaign if needed and validate campaign exists. Test: skip campaign load.
                if (mode == "production")
                {
                    if (string.IsNullOrWhiteSpace(intent.BuyerReferral) && intent.BuyerCampaignId.HasValue)
                    {
                        var campaignRef = conn.QueryFirstOrDefault<string>(
                            @"SELECT channelreferral FROM campaigns WHERE id = @id LIMIT 1",
                            new { id = intent.BuyerCampaignId.Value },
                            tx);
                        if (!string.IsNullOrWhiteSpace(campaignRef))
                            intent.BuyerReferral = campaignRef;
                    }
                    _debugTrace?.Write($"[PreviewRewardDistribution] mode=production about to lookup campaigns with referral={campaignIdentifier}");
                    _ = LoadCampaignBalancesByCampaignIdOrReferral(conn, tx, campaignIdentifier);
                }

                var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
                var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
                var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);

                BalanceVector debit;
                List<BalanceVector> credits;
                var sellerDonationPercent = intent.SellerDonationPercent ?? 0m;
                var sellerReferrerDonationPercent = intent.SellerReferrerDonationPercent ?? 0m;
                if (sellerDonationPercent > 0m || sellerReferrerDonationPercent > 0m)
                {
                    // Use smart-contract-style distribution so preview shows social cause (SCO) splits
                    var payerReferral = intent.BuyerReferral ?? campaignIdentifier ?? string.Empty;
                    (debit, credits) = BuildRewardDistributionVectorsSmartContractStyle(
                        intent.RewardAmount,
                        payerReferral,
                        intent.SellerReferral,
                        intent.BuyerReferrer,
                        intent.SellerReferrer,
                        sellerDonationPercent,
                        sellerReferrerDonationPercent,
                        imagineBcReferral,
                        genesisPoolReferral,
                        donationPoolReferral,
                        intent.IsSponsored);
                }
                else
                {
                    (debit, credits) = RunRewardDistributionEngine(
                        conn,
                        tx,
                        intent,
                        mode,
                        imagineBcReferral,
                        genesisPoolReferral,
                        donationPoolReferral,
                        null);
                }

                var ledgerDtos = RewardDistributionLedgerRowBuilder.Build(
                    debit,
                    credits,
                    intent.SellerReferral,
                    imagineBcReferral,
                    genesisPoolReferral,
                    donationPoolReferral,
                    string.IsNullOrWhiteSpace(intent.BuyerReferrer) ? null : intent.BuyerReferrer,
                    string.IsNullOrWhiteSpace(intent.SellerReferrer) ? null : intent.SellerReferrer);

                // GAAP: compute SCO split for 2300 (two credit rows) and 1100 (two debit rows)
                var rewardAmount = AccountingHelpers.Round6(intent.RewardAmount);
                var buyerRefShare = AccountingHelpers.Round6(rewardAmount * 0.10m);
                var sellerRefShare = AccountingHelpers.Round6(rewardAmount * 0.05m);
                var buyerReferrerToSc = string.IsNullOrWhiteSpace(intent.BuyerReferrer) ? buyerRefShare : 0m;
                var sellerReferrerToSc = string.IsNullOrWhiteSpace(intent.SellerReferrer) ? sellerRefShare : AccountingHelpers.Round6(sellerRefShare * ((intent.SellerReferrerDonationPercent ?? 0m) / 100m));

                var ledgerRows = new JArray();
                foreach (var dto in ledgerDtos)
                {
                    var amt = AccountingHelpers.Round6(dto.Amount);
                    var debitAmt = dto.EntryType == "DEBIT" ? Math.Abs(amt) : 0m;
                    var creditAmt = dto.EntryType == "CREDIT" ? amt : 0m;
                    var accountName = AccountingHelpers.GetAccountName(conn, tx, dto.AccountNumber);
                    var referralLabel = (string?)null;
                    if (string.Equals(dto.ReferralCode, imagineBcReferral, StringComparison.Ordinal)) referralLabel = "IMBC";
                    else if (string.Equals(dto.ReferralCode, genesisPoolReferral, StringComparison.Ordinal)) referralLabel = "GP";
                    else if (string.Equals(dto.ReferralCode, donationPoolReferral, StringComparison.Ordinal)) referralLabel = "SCP";

                    // Split single 2300 CREDIT (donation pool) into two detail rows: buyer referrer (0.10) and seller referrer (0.05)
                    if (string.Equals(dto.ReferralCode, donationPoolReferral, StringComparison.Ordinal) && dto.AccountNumber == "2300" && dto.EntryType == "CREDIT"
                        && buyerReferrerToSc > 0m && sellerReferrerToSc > 0m && amt == AccountingHelpers.Round6(buyerReferrerToSc + sellerReferrerToSc))
                    {
                        ledgerRows.Add(new JObject
                        {
                            ["referral_code"] = dto.ReferralCode,
                            ["referral_label"] = referralLabel ?? "",
                            ["tx_type"] = dto.TransactionType,
                            ["posting_code"] = dto.TransactionCode,
                            ["point_type"] = dto.PointType,
                            ["point_type_abbrev"] = AccountingHelpers.GetPointTypeAbbrev(dto.PointType),
                            ["account_number"] = dto.AccountNumber,
                            ["accountName"] = accountName ?? "",
                            ["subLedgerName"] = dto.SubLedgerName,
                            ["transactionCode"] = dto.TransactionCode,
                            ["amount"] = buyerReferrerToSc,
                            ["entry_type"] = "CREDIT",
                            ["debit"] = 0m,
                            ["credit"] = buyerReferrerToSc
                        });
                        ledgerRows.Add(new JObject
                        {
                            ["referral_code"] = dto.ReferralCode,
                            ["referral_label"] = referralLabel ?? "",
                            ["tx_type"] = dto.TransactionType,
                            ["posting_code"] = dto.TransactionCode,
                            ["point_type"] = dto.PointType,
                            ["point_type_abbrev"] = AccountingHelpers.GetPointTypeAbbrev(dto.PointType),
                            ["account_number"] = dto.AccountNumber,
                            ["accountName"] = accountName ?? "",
                            ["subLedgerName"] = dto.SubLedgerName,
                            ["transactionCode"] = dto.TransactionCode,
                            ["amount"] = sellerReferrerToSc,
                            ["entry_type"] = "CREDIT",
                            ["debit"] = 0m,
                            ["credit"] = sellerReferrerToSc
                        });
                        continue;
                    }

                    ledgerRows.Add(new JObject
                    {
                        ["referral_code"] = dto.ReferralCode,
                        ["referral_label"] = referralLabel ?? "",
                        ["tx_type"] = dto.TransactionType,
                        ["posting_code"] = dto.TransactionCode,
                        ["point_type"] = dto.PointType,
                        ["point_type_abbrev"] = AccountingHelpers.GetPointTypeAbbrev(dto.PointType),
                        ["account_number"] = dto.AccountNumber,
                        ["accountName"] = accountName ?? "",
                        ["subLedgerName"] = dto.SubLedgerName,
                        ["transactionCode"] = dto.TransactionCode,
                        ["amount"] = amt,
                        ["entry_type"] = dto.EntryType,
                        ["debit"] = debitAmt,
                        ["credit"] = creditAmt
                    });
                }

                // GAAP: add SCO debit entries to 1100 (SC Cash Pending) for unassigned buyer/seller referrer shares
                var accountName1100 = AccountingHelpers.GetAccountName(conn, tx, "1100");
                if (buyerReferrerToSc > 0m)
                {
                    ledgerRows.Add(new JObject
                    {
                        ["referral_code"] = donationPoolReferral,
                        ["referral_label"] = "SCP",
                        ["tx_type"] = "reward_distribution",
                        ["posting_code"] = "SCO",
                        ["point_type"] = "transferable",
                        ["point_type_abbrev"] = AccountingHelpers.GetPointTypeAbbrev("transferable"),
                        ["account_number"] = "1100",
                        ["accountName"] = accountName1100 ?? "",
                        ["subLedgerName"] = "SC Cash Pending",
                        ["transactionCode"] = "SCO",
                        ["amount"] = -buyerReferrerToSc,
                        ["entry_type"] = "DEBIT",
                        ["debit"] = buyerReferrerToSc,
                        ["credit"] = 0m
                    });
                }
                if (sellerReferrerToSc > 0m)
                {
                    ledgerRows.Add(new JObject
                    {
                        ["referral_code"] = donationPoolReferral,
                        ["referral_label"] = "SCP",
                        ["tx_type"] = "reward_distribution",
                        ["posting_code"] = "SCO",
                        ["point_type"] = "transferable",
                        ["point_type_abbrev"] = AccountingHelpers.GetPointTypeAbbrev("transferable"),
                        ["account_number"] = "1100",
                        ["accountName"] = accountName1100 ?? "",
                        ["subLedgerName"] = "SC Cash Pending",
                        ["transactionCode"] = "SCO",
                        ["amount"] = -sellerReferrerToSc,
                        ["entry_type"] = "DEBIT",
                        ["debit"] = sellerReferrerToSc,
                        ["credit"] = 0m
                    });
                }

                var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "reward_distribution", "transferable");
                var debitWithAccountCode = new JObject
                {
                    ["owner"] = debit.Owner,
                    ["total"] = AccountingHelpers.Round6(debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription),
                    ["accountCode"] = debitAccountCode
                };

                var creditsArray = new JArray();
                foreach (var c in credits)
                {
                    var total = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription;
                    var creditPointType = c.Transferable > 0 ? "transferable" : c.NonTransferable > 0 ? "nonTransferable" : c.Community > 0 ? "community" : "transferable";
                    var creditAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "reward_distribution", creditPointType, c.Owner);
                    creditsArray.Add(new JObject
                    {
                        ["owner"] = c.Owner,
                        ["total"] = AccountingHelpers.Round6(total),
                        ["accountCode"] = creditAccountCode
                    });
                }

                var (prodAmount, prodImbc, prodSc, prodGp) = BankSubLedgerRowBuilder.GetAmountsFromVectors(debit, credits, imagineBcReferral, donationPoolReferral, genesisPoolReferral);
                decimal sellerKeepsPreview = credits.Where(c => c.Owner == intent.SellerReferral).Sum(c => c.Transferable + c.Subscription + c.Community);
                decimal sellerReferrerKeepsPreview = credits.Where(c => c.Owner == intent.SellerReferrer).Sum(c => c.Transferable + c.Subscription + c.Community);
                decimal buyerReferrerAmountPreview = credits.Where(c => c.Owner == intent.BuyerReferrer).Sum(c => c.Transferable + c.Subscription + c.Community);
                var defs1100 = AccountingHelpers.Get1100SubledgerDefinitions(conn, tx);
                var names1100 = defs1100.Select(d => d.Name).ToList();
                var debitPointType = debit.Transferable != 0m ? "transferable" : debit.Subscription != 0m ? "subscription" : "community";
                var prodBankSubLedgerDtos = BankSubLedgerRowBuilder.Build(names1100, prodAmount, prodImbc, prodSc, prodGp, "1100", debit.Owner, imagineBcReferral, genesisPoolReferral, donationPoolReferral, debitPointType, sellerReferrerKeepsPreview, buyerReferrerAmountPreview, sellerKeepsPreview, intent.SellerReferrer, intent.BuyerReferrer, intent.SellerReferral);
                var bankSubLedgerRows = new JArray();
                foreach (var dto in prodBankSubLedgerDtos)
                {
                    var bankDebit = AccountingHelpers.Round6(dto.DebitAmount);
                    var bankCredit = AccountingHelpers.Round6(dto.CreditAmount);
                    bankSubLedgerRows.Add(new JObject
                    {
                        ["description"] = dto.Description,
                        ["gl_account_code"] = dto.GlAccountCode,
                        ["debit"] = bankDebit,
                        ["credit"] = bankCredit
                    });
                    // Do not add the single SC credit (0.15) to ledgerRows; we only show the two SCO debits (0.10 and 0.05) to 1100
                    if (dto.ReferralLabel == "SC" && bankCredit > 0m && bankDebit == 0m)
                        continue;
                    ledgerRows.Add(new JObject
                    {
                        ["referral_code"] = dto.ReferralCode ?? "",
                        ["referral_label"] = dto.ReferralLabel ?? "",
                        ["tx_type"] = "reward_distribution",
                        ["posting_code"] = dto.PostingCode ?? "",
                        ["point_type"] = dto.PointType ?? "",
                        ["point_type_abbrev"] = AccountingHelpers.GetPointTypeAbbrev(dto.PointType),
                        ["account_number"] = dto.GlAccountCode,
                        ["accountName"] = accountName1100 ?? "",
                        ["subLedgerName"] = dto.Description ?? "",
                        ["transactionCode"] = dto.PostingCode ?? "",
                        ["amount"] = bankDebit != 0m ? -bankDebit : bankCredit,
                        ["entry_type"] = bankDebit != 0m ? "DEBIT" : "CREDIT",
                        ["debit"] = bankDebit,
                        ["credit"] = bankCredit
                    });
                }

                tx.Rollback();

                return new JObject
                {
                    ["ok"] = true,
                    ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                    ["debit"] = debitWithAccountCode,
                    ["credits"] = creditsArray,
                    ["ledgerRows"] = ledgerRows,
                    ["bankSubLedgerRows"] = bankSubLedgerRows
                };
            }
            catch (Exception)
            {
                tx.Rollback();
                throw;
            }
        }

        //----------------------------------------------------------------------------------------------------
        //--external funding credit
        public JObject ApplyExternalFundingCredit(
            string memberReferral,
            decimal netAmount,
            decimal processingFee,
            string transactionType,
            string fundingMethod,
            string mode
        )
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
                throw new Exception("memberReferral is required");

            if (netAmount <= 0)
                throw new Exception("netAmount must be greater than zero");

            if (fundingMethod == "credit_card" && processingFee <= 0)
                throw new Exception("processingFee required for credit card transactions");

            /* 
            WriteLedgerEntry(new LedgerEntry
            {
                referral = memberReferral,
                direction = "credit",
                pointType = "nonTransferable",
                amount = netAmount,
                transactionType = transactionType,
                mode = mode,
                metadata = new JObject
                {
                    ["fundingMethod"] = fundingMethod
                }
            });
            */

            // --------------------------------------------------------------------
            // LEDGER ENTRY — PROCESSING FEE (PLATFORM SIDE)
            // --------------------------------------------------------------------
            if (fundingMethod == "credit_card")
            {
                /*
                WriteLedgerEntry(new LedgerEntry
                {
                    referral = "PLATFORM",
                    direction = "credit",
                    pointType = "processing_fee",
                    amount = processingFee,
                    transactionType = transactionType,
                    mode = mode,
                    metadata = new JObject
                    {
                        ["fundingMethod"] = fundingMethod
                    }
                });
                */  
            }

            return new JObject
            {
                ["ok"] = true,
                ["credited"] = netAmount,
                ["processingFee"] = processingFee
            };
        }

        //----------------------------------------------------------------------------------------------------
        //--private helpers for reward distribution

        /// <summary>
        /// Loads a pending reward_distribution intent by secure token (for execute-via-ProcessTransaction path).
        /// </summary>
        public TransactionIntent GetRewardDistributionIntentBySecureToken(Guid secureToken, string mode)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            using var tx = conn.BeginTransaction();
            return LoadRewardDistributionIntent(conn, tx, secureToken, mode);
        }

        /// <summary>
        /// Marks a transaction intent as consumed (for execute-via-ProcessTransaction path).
        /// </summary>
        public void MarkIntentConsumed(Guid intentId)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            using var tx = conn.BeginTransaction();
            MarkTransactionIntentConsumed(conn, tx, intentId);
            tx.Commit();
        }

        /// <summary>
        /// Returns true if a reward_distribution already exists for the same seller and campaign today (duplicate guard).
        /// </summary>
        public bool ExistsDuplicateRewardDistributionToday(string sellerReferral, Guid? buyerCampaignId, string? buyerReferral)
        {
            var ledgerTable = "ledger";
            var todayStart = DateTime.UtcNow.Date;
            var todayEnd = todayStart.AddDays(1);
            var campaignIdStr = buyerCampaignId?.ToString();
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            var count = conn.QueryFirstOrDefault<long>(
                $@"SELECT COUNT(*) FROM {ledgerTable}
                   WHERE tx_type = 'reward_distribution'
                     AND referral_code = @sellerReferral
                     AND transaction_date >= @todayStart
                     AND transaction_date < @todayEnd
                     AND (
                         (@campaignId IS NOT NULL AND metadata->>'buyerCampaignId' = @campaignId)
                         OR (@campaignReferral IS NOT NULL AND metadata->>'buyerReferral' = @campaignReferral)
                     )",
                new
                {
                    sellerReferral,
                    todayStart,
                    todayEnd,
                    campaignId = campaignIdStr ?? (string?)null,
                    campaignReferral = string.IsNullOrWhiteSpace(buyerReferral) ? (string?)null : buyerReferral
                });
            return count > 0;
        }

        private TransactionIntent LoadRewardDistributionIntent(
            IDbConnection conn,
            IDbTransaction tx,
            Guid secureToken,
            string mode)
        {
            // First, let's verify what's actually in the database
            using (var checkCmd = conn.CreateCommand())
            {
                checkCmd.Transaction = tx;
                checkCmd.CommandText = @"
                    SELECT seller_referrer, buyer_referrer
                    FROM transaction_intents
                    WHERE secure_token = @token
                      AND transaction_type = 'reward_distribution'
                      AND mode = @mode
                      AND status = 'pending'
                ";
                var tokenParam = checkCmd.CreateParameter();
                tokenParam.ParameterName = "@token";
                tokenParam.Value = secureToken;
                checkCmd.Parameters.Add(tokenParam);
                
                var modeParam = checkCmd.CreateParameter();
                modeParam.ParameterName = "@mode";
                modeParam.Value = mode;
                checkCmd.Parameters.Add(modeParam);
                
                using (var reader = checkCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var dbSellerRef = reader.IsDBNull(0) ? null : reader.GetString(0);
                        var dbBuyerRef = reader.IsDBNull(1) ? null : reader.GetString(1);
                        // _debugTrace?.Write($"[LoadRewardDistributionIntent] RAW DB VALUES: seller_referrer='{dbSellerRef ?? "NULL"}', buyer_referrer='{dbBuyerRef ?? "NULL"}'");
                    }
                }
            }
            
            var intent = conn.QuerySingleOrDefault<TransactionIntent>(
                @"SELECT 
                    id,
                    secure_token AS SecureToken,
                    status AS Status,
                    transaction_type AS TransactionType,
                    mode AS Mode,
                    seller_referral AS SellerReferral,
                    buyer_referral AS BuyerReferral,
                    buyer_campaign_id::uuid AS BuyerCampaignId,
                    seller_referrer AS SellerReferrer,
                    buyer_referrer AS BuyerReferrer,
                    seller_display_name AS SellerDisplayName,
                    buyer_display_name AS BuyerDisplayName,
                    reward_amount AS RewardAmount,
                    is_sponsored AS IsSponsored,
                    sponsored_channel_referral AS SponsoredChannelReferral,
                    sponsored_channel_display_name AS SponsoredChannelDisplayName,
                    sponsored_content_id AS SponsoredContentId,
                    is_donation AS IsDonation,
                    donation_channel_referral AS DonationChannelReferral,
                    donation_channel_display_name AS DonationChannelDisplayName,
                    donation_amount AS DonationAmount,
                    created_at AS CreatedAt,
                    consumed_at AS ConsumedAt
                  FROM transaction_intents
                  WHERE secure_token = @token
                    AND transaction_type = 'reward_distribution'
                    AND mode = @mode
                    AND status = 'pending'",
                new { token = secureToken, mode },
                tx
            );
            if (intent == null)
                throw new InvalidOperationException(
                    "Invalid, consumed, or missing reward_distribution intent."
                );
            
            // Require at least one of buyer_referral or buyer_campaign_id
            if (string.IsNullOrWhiteSpace(intent.BuyerReferral) && !intent.BuyerCampaignId.HasValue)
            {
                throw new InvalidOperationException(
                    $"Transaction intent loaded but buyer_referral and buyer_campaign_id are empty. Intent ID: {intent.Id}, SecureToken: {secureToken}"
                );
            }
            
            // _debugTrace?.Write($"[LoadRewardDistributionIntent] Loaded referrers: SellerReferrer='{intent.SellerReferrer ?? "null"}', BuyerReferrer='{intent.BuyerReferrer ?? "null"}'");
            
            return intent;
        }

        internal CampaignBalances LoadCampaignBalancesByCampaignIdOrReferral(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignIdOrReferral) // Accept UUID or referral for backward compatibility
        {
            // Try UUID first (new way), fallback to referral (old way)
            Guid campaignId;
            bool isUuid = Guid.TryParse(campaignIdOrReferral, out campaignId);
            
            var balances = isUuid
                ? conn.QuerySingleOrDefault<CampaignBalances>(
                    @"SELECT
                          community_point_balance   AS Community,
                          transferable_point_balance AS Transferable
                      FROM campaigns
                      WHERE id = @id",
                    new { id = campaignId },
                    tx
                  )
                : conn.QuerySingleOrDefault<CampaignBalances>(
                    @"SELECT
                          community_point_balance   AS Community,
                          transferable_point_balance AS Transferable
                      FROM campaigns
                      WHERE channelreferral = @referral",
                    new { referral = campaignIdOrReferral },
                    tx
                  );

            if (balances == null)
            {
                throw new InvalidOperationException(
                    $"Campaign {(isUuid ? $"with ID '{campaignId}'" : $"with referral '{campaignIdOrReferral}'")} not found in campaigns. " +
                    "Ensure the campaign is created before executing reward distribution."
                );
            }

            return balances;
        }

        private bool TryLoadCampaignBalancesByCampaignIdOrReferral(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignIdOrReferral,
            out CampaignBalances? balances)
        {
            Guid campaignId;
            bool isUuid = Guid.TryParse(campaignIdOrReferral, out campaignId);
            balances = isUuid
                ? conn.QuerySingleOrDefault<CampaignBalances>(
                    @"SELECT
                          community_point_balance   AS Community,
                          transferable_point_balance AS Transferable
                      FROM campaigns
                      WHERE id = @id",
                    new { id = campaignId },
                    tx
                  )
                : conn.QuerySingleOrDefault<CampaignBalances>(
                    @"SELECT
                          community_point_balance   AS Community,
                          transferable_point_balance AS Transferable
                      FROM campaigns
                      WHERE channelreferral = @referral",
                    new { referral = campaignIdOrReferral },
                    tx
                  );
            return balances != null;
        }

        private CampaignBalances LoadProductionCampaignBalances(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignReferral)
        {
            // Existing production logic — DO NOT CHANGE
            return LoadCampaignBalances(
                conn,
                tx,
                campaignReferral
            );
        }

        /// <summary>
        /// Build ledger-shaped rows in-memory for TEST preview (no DB write). Same shape as SELECT from ledger table.
        /// </summary>
        private static JArray BuildLedgerRowsInMemory(string txType, BalanceVector debit, IReadOnlyList<BalanceVector> credits)
        {
            var rows = new List<(string referralCode, string pointType, decimal amount, string txSubtype)>();
            void Add(string owner, string pointType, decimal amount, string txSubtype)
            {
                if (amount != 0m)
                    rows.Add((owner, pointType, amount, txSubtype));
            }
            Add(debit.Owner, "transferable", -debit.Transferable, "WD");
            Add(debit.Owner, "nonTransferable", -debit.NonTransferable, "UD");
            Add(debit.Owner, "community", -debit.Community, "CD");
            Add(debit.Owner, "special", -debit.Special, "UD");
            Add(debit.Owner, "subscription", -debit.Subscription, "UD");
            Add(debit.Owner, "overflow", -debit.Overflow, "DO");
            foreach (var c in credits)
            {
                Add(c.Owner, "transferable", c.Transferable, "WD");
                Add(c.Owner, "nonTransferable", c.NonTransferable, "UD");
                Add(c.Owner, "community", c.Community, "CD");
                Add(c.Owner, "special", c.Special, "UD");
                Add(c.Owner, "subscription", c.Subscription, "UD");
                Add(c.Owner, "overflow", c.Overflow, "DO");
            }
            var arr = new JArray();
            foreach (var (referralCode, pointType, amount, txSubtype) in rows)
            {
                arr.Add(new JObject
                {
                    ["referral_code"] = referralCode ?? "",
                    ["tx_type"] = txType,
                    ["tx_subtype"] = txSubtype,
                    ["point_type"] = pointType,
                    ["account_number"] = "reward_distribution",
                    ["amount"] = amount
                });
            }
            return arr;
        }

        private void DebitCampaignBalances(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignIdOrReferral, // Accept UUID or referral for backward compatibility
            decimal amount,
            CampaignBalances balances,
            string mode)
        {
            decimal remaining = amount;
            decimal fromCommunity = Math.Min(balances.Community, remaining);
            remaining -= fromCommunity;
            decimal fromTransferable = Math.Min(balances.Transferable, remaining);
            remaining -= fromTransferable;

            if (remaining > 0)
                throw new InvalidOperationException(
                    "Insufficient campaign balance for reward distribution."
                );

            if (fromCommunity > 0)
            {
                ApplyCampaignDebit(
                    conn,
                    tx,
                    campaignIdOrReferral,
                    "community",
                    fromCommunity,
                    mode
                );
            }

            if (fromTransferable > 0)
            {
                ApplyCampaignDebit(
                    conn,
                    tx,
                    campaignIdOrReferral,
                    "transferable",
                    fromTransferable,
                    mode
                );
            }
        }

        /// <summary>
        /// Builds debit and credit vectors using the same fixed 70/5/10/10/5 split and donation %
        /// logic as ExecuteSmartContractStyleDistribution. Used by PreviewRewardDistribution and
        /// (legacy) ExecuteRewardDistribution. No DB writes; pure math.
        /// </summary>
        private static (BalanceVector debit, List<BalanceVector> credits) BuildRewardDistributionVectorsSmartContractStyle(
            decimal amount,
            string payerReferral,
            string sellerReferral,
            string? buyerReferrer,
            string? sellerReferrer,
            decimal sellerDonationPercent,
            decimal sellerReferrerDonationPercent,
            string imagineBcReferral,
            string genesisPoolReferral,
            string donationPoolReferral,
            bool isSponsored)
        {
            // Non-GP allocations first (Round6); GP last as balancing remainder per bucket
            decimal sellerAmount = AccountingHelpers.Round6(amount * 0.70m);
            decimal sellerReferrerAmount = AccountingHelpers.Round6(amount * 0.05m);
            decimal buyerReferrerAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal imagineBcAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal genesisPoolAmount = AccountingHelpers.Round6(amount - sellerAmount - sellerReferrerAmount - buyerReferrerAmount - imagineBcAmount);

            decimal sellerKeeps = sellerAmount;
            decimal sellerToSocialCause = 0m;
            if (sellerDonationPercent > 0m)
            {
                sellerToSocialCause = AccountingHelpers.Round6(sellerAmount * (sellerDonationPercent / 100m));
                sellerKeeps = sellerAmount - sellerToSocialCause;
            }

            decimal sellerReferrerKeeps = sellerReferrerAmount;
            decimal sellerReferrerToSocialCause = 0m;
            if (sellerReferrerDonationPercent > 0m && !string.IsNullOrWhiteSpace(sellerReferrer))
            {
                sellerReferrerToSocialCause = AccountingHelpers.Round6(sellerReferrerAmount * (sellerReferrerDonationPercent / 100m));
                sellerReferrerKeeps = sellerReferrerAmount - sellerReferrerToSocialCause;
            }

            decimal buyerReferrerToSocialCause = 0m;
            if (string.IsNullOrWhiteSpace(buyerReferrer))
            {
                buyerReferrerToSocialCause = buyerReferrerAmount;
                buyerReferrerAmount = 0m;
            }

            if (string.IsNullOrWhiteSpace(sellerReferrer))
            {
                sellerReferrerToSocialCause += sellerReferrerAmount;
                sellerReferrerKeeps = 0m;
                sellerReferrerAmount = 0m;
            }

            var debit = BalanceVector.ForSpend(payerReferral);
            if (isSponsored)
                debit.Subscription = amount;
            else
                debit.Transferable = amount;

            var credits = new List<BalanceVector>();
            if (sellerKeeps > 0m) { var c = BalanceVector.Credit(sellerReferral); c.Transferable = sellerKeeps; credits.Add(c); }
            if (sellerToSocialCause > 0m) { var c = BalanceVector.Credit(donationPoolReferral); c.Transferable = sellerToSocialCause; credits.Add(c); }
            if (sellerReferrerKeeps > 0m && !string.IsNullOrWhiteSpace(sellerReferrer)) { var c = BalanceVector.Credit(sellerReferrer); c.Transferable = sellerReferrerKeeps; credits.Add(c); }
            if (sellerReferrerToSocialCause > 0m) { var c = BalanceVector.Credit(donationPoolReferral); c.Transferable = sellerReferrerToSocialCause; credits.Add(c); }
            if (buyerReferrerAmount > 0m && !string.IsNullOrWhiteSpace(buyerReferrer)) { var c = BalanceVector.Credit(buyerReferrer); c.Transferable = buyerReferrerAmount; credits.Add(c); }
            if (buyerReferrerToSocialCause > 0m) { var c = BalanceVector.Credit(donationPoolReferral); c.Transferable = buyerReferrerToSocialCause; credits.Add(c); }
            if (imagineBcAmount > 0m) { var c = BalanceVector.Credit(imagineBcReferral); c.Transferable = imagineBcAmount; credits.Add(c); }
            if (genesisPoolAmount > 0m) { var c = BalanceVector.Credit(genesisPoolReferral); c.Transferable = genesisPoolAmount; credits.Add(c); }

            return (debit, credits);
        }

        /// <summary>
        /// One ledger entry shape for reward_distribution preview (no account code; resolved by caller).
        /// </summary>
        private sealed class RewardDistributionLedgerEntryShape
        {
            public string ReferralCode { get; set; } = "";
            public string TransactionCode { get; set; } = "";
            public string PointType { get; set; } = "";
            public decimal Amount { get; set; }
            public string? SubLedgerDescription { get; set; }
        }

        /// <summary>
        /// Builds the list of ledger entry shapes (referral, txCode, pointType, amount, subLedgerDesc) for reward_distribution
        /// in the same order as ExecuteSmartContractStyleDistribution. Caller resolves account code and looks up account name.
        /// </summary>
        private static List<RewardDistributionLedgerEntryShape> BuildRewardDistributionLedgerEntryShapes(
            decimal amount,
            string payerReferral,
            string sellerReferral,
            string? buyerReferrer,
            string? sellerReferrer,
            decimal sellerDonationPercent,
            decimal sellerReferrerDonationPercent,
            string imagineBcReferral,
            string donationPoolReferral,
            string genesisPoolReferral,
            bool isSponsored)
        {
            string pt = isSponsored ? "subscription" : "transferable";
            decimal sellerAmount = AccountingHelpers.Round6(amount * 0.70m);
            decimal sellerReferrerAmount = AccountingHelpers.Round6(amount * 0.05m);
            decimal buyerReferrerAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal imagineBcAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal genesisPoolAmount = AccountingHelpers.Round6(amount - sellerAmount - sellerReferrerAmount - buyerReferrerAmount - imagineBcAmount);

            decimal sellerKeeps = sellerAmount;
            decimal sellerToSocialCause = 0m;
            if (sellerDonationPercent > 0m)
            {
                sellerToSocialCause = AccountingHelpers.Round6(sellerAmount * (sellerDonationPercent / 100m));
                sellerKeeps = sellerAmount - sellerToSocialCause;
            }
            decimal sellerReferrerKeeps = sellerReferrerAmount;
            decimal sellerReferrerToSocialCause = 0m;
            if (sellerReferrerDonationPercent > 0m && !string.IsNullOrWhiteSpace(sellerReferrer))
            {
                sellerReferrerToSocialCause = AccountingHelpers.Round6(sellerReferrerAmount * (sellerReferrerDonationPercent / 100m));
                sellerReferrerKeeps = sellerReferrerAmount - sellerReferrerToSocialCause;
            }
            decimal buyerReferrerToSocialCause = 0m;
            if (string.IsNullOrWhiteSpace(buyerReferrer)) { buyerReferrerToSocialCause = buyerReferrerAmount; buyerReferrerAmount = 0m; }
            if (string.IsNullOrWhiteSpace(sellerReferrer)) { sellerReferrerToSocialCause += sellerReferrerAmount; sellerReferrerKeeps = 0m; sellerReferrerAmount = 0m; }
            decimal totalSocialCause = AccountingHelpers.Round6(sellerToSocialCause + sellerReferrerToSocialCause + buyerReferrerToSocialCause);

            var list = new List<RewardDistributionLedgerEntryShape>();
            void Add(string referral, string txCode, string pointType, decimal amt, string? subLedgerDesc)
            {
                if (amt == 0m) return;
                list.Add(new RewardDistributionLedgerEntryShape
                {
                    ReferralCode = referral,
                    TransactionCode = txCode,
                    PointType = pointType,
                    Amount = amt,
                    SubLedgerDescription = subLedgerDesc
                });
            }
            const string subLedgerMember = "Member Cash Posting - Smart Contract Purchase";
            const string subLedgerImbc = "IMBC Cash Pending - Smart Contract Distribution";
            const string subLedgerGp = "GP Cash Pending - Smart Contract Distribution";

            Add(payerReferral, "BO", pt, -amount, subLedgerMember);
            if (sellerKeeps > 0m) Add(sellerReferral, "PI", pt, sellerKeeps, null);
            if (sellerToSocialCause > 0m) Add(donationPoolReferral, "SCO", "transferable", sellerToSocialCause, null);
            if (sellerReferrerKeeps > 0m && !string.IsNullOrWhiteSpace(sellerReferrer)) Add(sellerReferrer, "PRI", pt, sellerReferrerKeeps, null);
            if (sellerReferrerToSocialCause > 0m) Add(donationPoolReferral, "SCO", "transferable", sellerReferrerToSocialCause, null);
            if (buyerReferrerAmount > 0m && !string.IsNullOrWhiteSpace(buyerReferrer)) Add(buyerReferrer, "BRI", pt, buyerReferrerAmount, null);
            if (buyerReferrerToSocialCause > 0m) Add(donationPoolReferral, "SCO", "transferable", buyerReferrerToSocialCause, null);
            if (imagineBcAmount > 0m) Add(imagineBcReferral, "IBCI", pt, imagineBcAmount, subLedgerImbc);
            if (genesisPoolAmount > 0m)
            {
                Add(genesisPoolReferral, "GPI", pt, genesisPoolAmount, subLedgerGp);
                Add(genesisPoolReferral, "GPA", pt, genesisPoolAmount, null);
                Add(genesisPoolReferral, "GPA", pt, -genesisPoolAmount, null);
            }
            return list;
        }

        private static string ResolveRewardDistributionAccountCode(
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string txCode,
            string pointType,
            decimal amount,
            string imbcGlAccountCode)
        {
            if (txCode == "SCO") return "2300";
            if (txCode == "IBCI") return imbcGlAccountCode;
            if (txCode == "GPI") return "4100";
            if (txCode == "GPA") return amount < 0m ? "5000" : "2310";
            return AccountingHelpers.ResolveAccountCode(conn, tx, txCode, pointType);
        }

        private (BalanceVector debit, List<BalanceVector> credits) RunRewardDistributionEngine(
            IDbConnection? conn,
            IDbTransaction? tx,
            TransactionIntent intent,
            string mode,
            string imagineBcReferral,
            string genesisPoolReferral,
            string donationPoolReferral,
            JObject? overridePayload = null)
        {
            // ------------------------------------------------------------------
            // 1. Use referrers from payload (frontend/test tool provides them)
            // ------------------------------------------------------------------
            var sellerReferral = intent.SellerReferral;
            var sellerReferrer = intent.SellerReferrer; // Use from payload, not resolved
            
            // Explicit null/empty check
            if (string.IsNullOrWhiteSpace(sellerReferrer)) sellerReferrer = null;
            // _debugTrace?.Write($"[RUN_REWARD_DIST] Seller referrer from intent: '{sellerReferrer ?? "null"}' (SellerReferral={sellerReferral})");

            // ------------------------------------------------------------------
            // 2. Use buyer referrer from payload
            // ------------------------------------------------------------------
            var buyerReferral = intent.BuyerReferral;
            var buyerReferrer = intent.BuyerReferrer; // Use from payload, not resolved
            
            // Explicit null/empty check
            if (string.IsNullOrWhiteSpace(buyerReferrer)) buyerReferrer = null;
            // _debugTrace?.Write($"[RUN_REWARD_DIST] Buyer referrer from intent: '{buyerReferrer ?? "null"}' (BuyerReferral={buyerReferral})");

            // ------------------------------------------------------------------
            // 3. Build distribution context
            // ------------------------------------------------------------------
            var context = new DistributionContext
            {
                TransactionType = "reward_distribution",
                Mode = mode,

                GrossAmount = intent.RewardAmount,

                SellerReferral = sellerReferral,
                SellerReferrerReferral = sellerReferrer,

                BuyerReferral = buyerReferral,
                BuyerReferrerReferral = buyerReferrer,

                IsSponsored = intent.IsSponsored,
                SponsoredChannelReferral = intent.SponsoredChannelReferral,

                IsDonation = intent.IsDonation,
                DonationChannelReferral = intent.DonationChannelReferral,
                DonationAmount = intent.DonationAmount
            };

            // System referral codes are now passed as parameters (resolved in ExecuteRewardDistribution)

            // ------------------------------------------------------------------
            // 5. Build vectors - DEBIT THE BUYER (campaign), not the seller
            // ------------------------------------------------------------------
            // The buyer (campaign) is debited because they're paying out the reward
            var debit = BalanceVector.Debit(context.BuyerReferral);

            decimal distributableAmount = context.GrossAmount;

            // Donation is deducted from seller earnings BEFORE distribution
            if (context.IsDonation && context.DonationAmount > 0m)
            {
                if (context.DonationAmount > distributableAmount)
                    throw new InvalidOperationException("Donation exceeds distributable amount");

                distributableAmount -= context.DonationAmount.Value;
            }

            // Sponsored campaigns route earnings into subscription balance
            if (context.IsSponsored)
            {
                debit.Subscription = distributableAmount;
            }
            else
            {
                debit.Transferable = distributableAmount;
            }

            // Run canonical distribution logic
            var engine = new DistributionEngine();
            // _debugTrace?.Write($"[RUN_REWARD_DIST] Calling Distribute: Type={context.TransactionType}, Seller={context.SellerReferral}, BuyerRef='{context.BuyerReferrerReferral ?? "null"}', SellerRef='{context.SellerReferrerReferral ?? "null"}'");
            // _debugTrace?.Write($"[RUN_REWARD_DIST] Distribution parameters - buyerReferrer='{context.BuyerReferrerReferral ?? "null"}', sellerReferrer='{context.SellerReferrerReferral ?? "null"}'");
            var credits = engine.Distribute(
                context.TransactionType,
                debit,
                context.SellerReferral,                 // channelReferral == seller (gets 70%)
                imagineBcReferral,                       // platform (gets 10%)
                genesisPoolReferral,                    // genesis pool (gets 5%)
                donationPoolReferral,                   // donation pool (only if referrers are null)
                context.BuyerReferrerReferral,          // buyerReferrer (7th param)
                context.SellerReferrerReferral           // sellerReferrer (8th param)
            ).ToList();
            // _debugTrace?.Write($"[RUN_REWARD_DIST] Distribute returned {credits.Count} credit vectors");

            // Donation credit (if applicable)
            if (context.IsDonation && context.DonationAmount > 0m)
            {
                credits.Add(
                    BalanceVector.Credit(context.DonationChannelReferral)
                        .WithTransferable(context.DonationAmount.Value)
                );
            }

            // Apply voluntary donation split (Transaction Type 8) if enabled
            // Note: ExecuteRewardDistribution is in BalanceService class, so we apply donation logic inline here
            // Read voluntary donation from override payload if provided, otherwise from intent's payload
            var payloadToUse = overridePayload ?? intent.ToPayload();
            var voluntaryDonation = payloadToUse["voluntaryDonation"] as JObject;
            if (voluntaryDonation != null && (voluntaryDonation.Value<bool?>("enabled") ?? false))
            {
                var donationAmount = voluntaryDonation.Value<decimal?>("donationAmount");
                var donationPercentage = voluntaryDonation.Value<decimal?>("donationPercentage");
                var recipientChannelReferral = voluntaryDonation.Value<string>("recipientChannelReferral");
                
                // Calculate donation amount from percentage if amount not provided
                if (!donationAmount.HasValue && donationPercentage.HasValue && donationPercentage.Value > 0)
                {
                    // Find seller's transferable earnings to calculate donation amount
                    var sellerVector = credits.FirstOrDefault(cv => cv.Owner == context.SellerReferral);
                    if (sellerVector != null && sellerVector.Transferable > 0)
                    {
                        donationAmount = Math.Round(sellerVector.Transferable * (donationPercentage.Value / 100m), 2);
                    }
                }

                if (donationAmount.HasValue && donationAmount.Value > 0 && !string.IsNullOrWhiteSpace(recipientChannelReferral))
                {
                    // Find seller's credit vector
                    var sellerVector = credits.FirstOrDefault(cv => cv.Owner == context.SellerReferral);
                    if (sellerVector != null && donationAmount.Value <= sellerVector.Transferable)
                    {
                        // Apply split: reduce seller's transferable, create credit for nonprofit channel
                        sellerVector.Transferable -= donationAmount.Value;

                        // Find or create nonprofit channel credit vector
                        var nonprofitVector = credits.FirstOrDefault(cv => cv.Owner == recipientChannelReferral);
                        if (nonprofitVector == null)
                        {
                            nonprofitVector = BalanceVector.Credit(recipientChannelReferral);
                            nonprofitVector.Transferable = donationAmount.Value;
                            credits.Add(nonprofitVector);
                        }
                        else
                        {
                            nonprofitVector.Transferable += donationAmount.Value;
                        }

                        // Add metadata
                        var donationMetadata = new JObject
                        {
                            ["voluntaryDonation"] = new JObject
                            {
                                ["enabled"] = true,
                                ["percentage"] = voluntaryDonation.Value<decimal?>("donationPercentage") ?? 0m,
                                ["donationAmount"] = donationAmount.Value,
                                ["donationSource"] = "seller_transferable",
                                ["recipientChannel"] = recipientChannelReferral,
                                ["authorization"] = "preconfigured"
                            }
                        };
                        context.ToMetadata().Merge(donationMetadata);
                    }
                    else if (sellerVector == null)
                    {
                        throw new InvalidOperationException($"Seller {context.SellerReferral} not found in credit vectors");
                    }
                    else
                    {
                        throw new InvalidOperationException($"Donation amount {donationAmount.Value} exceeds seller transferable earnings {sellerVector.Transferable}");
                    }
                }
            }

            // ------------------------------------------------------------------
            // 5. Apply all balance mutations atomically (skip when conn/tx null, e.g. test preview without DB)
            // ------------------------------------------------------------------
            if (conn != null && tx != null)
            {
                var balanceService = new BalanceService(
                    _connectionString,
                    new LedgerWriteService(_connectionString)
                );

                balanceService.ApplyVectors(
                    debit,
                    credits,
                    context.TransactionType,
                    context.ToPayload(),
                    context.ToMetadata(),
                    context.Mode,
                    (NpgsqlConnection)conn,
                    (NpgsqlTransaction)tx
                );
            }

            return (debit, credits);
        }

        private void MarkTransactionIntentConsumed(
            IDbConnection conn,
            IDbTransaction tx,
            Guid intentId)
        {
            conn.Execute(
                @"UPDATE transaction_intents
                  SET status = 'consumed',
                      consumed_at = now()
                  WHERE id = @id",
                new { id = intentId },
                tx
            );
        }

        private CampaignBalances LoadCampaignBalances(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignReferral)
        {
            // Production campaigns table uses different column names and structure
            // Production campaigns are identified by UUID id, not referral
            // If campaignReferral is a UUID, use it as id; otherwise this is an error for production
            Guid campaignId;
            if (!Guid.TryParse(campaignReferral, out campaignId))
            {
                throw new InvalidOperationException(
                    $"Production campaigns must be identified by UUID id, not referral code. " +
                    $"Received: '{campaignReferral}'. " +
                    "For production mode, use buyerCampaignId (UUID) instead of buyerReferral."
                );
            }

            var balances = conn.QuerySingleOrDefault<CampaignBalances>(
                @"SELECT
                      community_point_balance   AS Community,
                      transferable_point_balance AS Transferable
                  FROM campaigns
                  WHERE id = @id",
                new { id = campaignId },
                tx
            );

            if (balances == null)
            {
                throw new InvalidOperationException(
                    $"Campaign with id '{campaignId}' not found in campaigns table. " +
                    "Ensure the campaign exists before executing reward distribution."
                );
            }

            return balances;
        }

        private void ApplyCampaignDebit(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignIdOrReferral, // Accept UUID or referral for backward compatibility
            string balanceType,
            decimal amount,
            string mode)
        {
            var tableName = "campaigns";
            
            string balanceColumn = balanceType == "community" ? "community_point_balance" : "transferable_point_balance";

            // Try UUID first (new way), fallback to referral (old way, TEST only)
            Guid campaignId;
            bool isUuid = Guid.TryParse(campaignIdOrReferral, out campaignId);
            
            if (isUuid)
            {
                // Use UUID to identify campaign (works for both TEST and PROD)
                conn.Execute(
                    $@"UPDATE {tableName}
                       SET {balanceColumn} = {balanceColumn} - @amount
                       WHERE id = @id",
                    new { amount, id = campaignId },
                    tx
                );
            }
            else
            {
                conn.Execute(
                    $@"UPDATE {tableName}
                       SET {balanceColumn} = {balanceColumn} - @amount
                       WHERE channelreferral = @referral",
                    new { amount, referral = campaignIdOrReferral },
                    tx
                );
            }
        }

        private string? ResolveMemberOrChannelReferrer(
            IDbConnection conn,
            IDbTransaction tx,
            string referral,
            string mode)
        {
            var membersTable = "members";
            var channelTable = "channel";

            // Try to resolve as member first
            var memberReferrer = conn.QuerySingleOrDefault<string>(
                $@"SELECT referrer FROM {membersTable} WHERE assignedreferral = @referral",
                new { referral },
                tx
            );

            if (!string.IsNullOrWhiteSpace(memberReferrer))
                return memberReferrer;

            // If not found as member, try as channel
            var channelReferrer = conn.QuerySingleOrDefault<string>(
                $@"SELECT referredby FROM {channelTable} WHERE assignedreferral = @referral",
                new { referral },
                tx
            );

            return channelReferrer;
        }

        private string? ResolveCampaignReferrer(
            IDbConnection conn,
            IDbTransaction tx,
            string campaignReferral,
            string mode)
        {
            var tableName = "campaigns";

            // Try UUID first (new way), fallback to referral (old way, TEST only)
            Guid campaignId;
            bool isUuid = Guid.TryParse(campaignReferral, out campaignId);
            
            if (isUuid)
            {
                // Use UUID to identify campaign (works for both TEST and PROD)
                return conn.QuerySingleOrDefault<string>(
                    $@"SELECT referredby FROM {tableName} WHERE id = @id",
                    new { id = campaignId },
                    tx
                );
            }
            else
            {
                return conn.QuerySingleOrDefault<string>(
                    $@"SELECT referredby FROM {tableName} WHERE channelreferral = @referral",
                    new { referral = campaignReferral },
                    tx
                );
            }
        }

        private string ResolveSystemReferral(
            string tokenKey,
            IDbConnection conn,
            IDbTransaction tx)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
                SELECT stringvalue
                FROM tokens
                WHERE key = @key
            ";
            var param = cmd.CreateParameter();
            param.ParameterName = "@key";
            param.Value = tokenKey;
            cmd.Parameters.Add(param);

            var result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new InvalidOperationException($"Missing system referral token: {tokenKey}");

            return result.ToString()!;
        }

    }

    //--------------------------------------------------------------------------------------------------------
    //--distribution engine

    public sealed class DistributionEngine
    {
        private readonly IDbConnection? _conn;
        private readonly IDbTransaction? _tx;

        private const decimal ChannelRate = 0.70m;
        private const decimal PlatformRate = 0.10m;
        private const decimal GenesisBaseRate = 0.05m;
        private const decimal SellerReferrerRate = 0.05m;
        private const decimal BuyerReferrerRate = 0.10m;

        public DistributionEngine()
        {
            // Parameterless constructor for backward compatibility
        }

        public DistributionEngine(IDbConnection conn, IDbTransaction tx)
        {
            _conn = conn ?? throw new ArgumentNullException(nameof(conn));
            _tx = tx ?? throw new ArgumentNullException(nameof(tx));
        }

        public void Execute(DistributionContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            if (_conn == null || _tx == null)
                throw new InvalidOperationException("DistributionEngine requires connection and transaction");

            if (context.GrossAmount <= 0m)
                throw new InvalidOperationException("GrossAmount must be > 0");

            // ------------------------------------------------------------
            // 1. Build SELLER debit vector
            // ------------------------------------------------------------
            var debit = BalanceVector.Debit(context.SellerReferral);

            decimal distributableAmount = context.GrossAmount;

            // Donation is deducted from seller earnings BEFORE distribution
            if (context.IsDonation && context.DonationAmount > 0m)
            {
                if (context.DonationAmount > distributableAmount)
                    throw new InvalidOperationException("Donation exceeds distributable amount");

                distributableAmount -= context.DonationAmount.Value;
            }

            // Sponsored campaigns route earnings into subscription balance
            if (context.IsSponsored)
            {
                debit.Subscription = distributableAmount;
            }
            else
            {
                debit.Transferable = distributableAmount;
            }

            // ------------------------------------------------------------
            // 2. Run canonical distribution logic
            // ------------------------------------------------------------
            var credits = Distribute(
                context.TransactionType,
                debit,
                context.SellerReferral,                 // channelReferral == seller
                "IMAGINEBC",                             // platform
                "GENESIS_POOL",                          // genesis pool
                "DONATION_POOL",                         // donation pool
                context.BuyerReferrerReferral,
                context.SellerReferrerReferral
            ).ToList();

            // ------------------------------------------------------------
            // 3. Donation credit (if applicable)
            // ------------------------------------------------------------
            if (context.IsDonation && context.DonationAmount > 0m)
            {
                credits.Add(
                    BalanceVector.Credit(context.DonationChannelReferral)
                        .WithTransferable(context.DonationAmount.Value)
                );
            }

            // ------------------------------------------------------------
            // 4. Apply all balance mutations atomically
            // ------------------------------------------------------------
            var npgsqlConn = (NpgsqlConnection)_conn;
            var npgsqlTx = (NpgsqlTransaction)_tx;

            var balanceService = new BalanceService(
                npgsqlConn.ConnectionString,
                new LedgerWriteService(npgsqlConn.ConnectionString)
            );

            balanceService.ApplyVectors(
                debit,
                credits,
                context.TransactionType,
                context.ToPayload(),
                context.ToMetadata(),
                context.Mode,
                npgsqlConn,
                npgsqlTx
            );
        }

        public IReadOnlyList<BalanceVector> Distribute(
            string transactionType,
            BalanceVector debit,
            string channelReferral,
            string imagineBcReferral,
            string genesisPoolReferral,
            string donationPoolReferral,
            string? buyerReferrer,
            string? sellerReferrer)
        {
            if (debit == null)
                throw new ArgumentNullException(nameof(debit));

            // Only distribution-based transactions participate
            var supportedTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "subscription_purchase_distribution",
                "subscription_renewal_distribution",
                "offer_purchase_distribution",
                "content_purchase_distribution",
                "comment_payment_distribution",
                "reward_distribution"
            };
            
            if (!supportedTypes.Contains(transactionType))
            {
                return Array.Empty<BalanceVector>();
            }

            var credits = new Dictionary<string, BalanceVector>();

            BalanceVector Get(string owner)
            {
                if (!credits.TryGetValue(owner, out var vec))
                {
                    vec = BalanceVector.Credit(owner);
                    credits[owner] = vec;
                }
                return vec;
            }

            void DistributeBalance(
                decimal amount,
                Action<BalanceVector, decimal> apply)
            {
                if (amount <= 0m)
                    return;

                amount = AccountingHelpers.Round6(amount);
                decimal allocated = 0m;

                decimal channelShare = AccountingHelpers.Round6(amount * 0.70m);
                decimal platformShare = AccountingHelpers.Round6(amount * 0.10m);
                decimal sellerRefShare = AccountingHelpers.Round6(amount * 0.05m);
                decimal buyerRefShare = AccountingHelpers.Round6(amount * 0.10m);

                apply(Get(channelReferral), channelShare);
                allocated += channelShare;

                apply(Get(imagineBcReferral), platformShare);
                allocated += platformShare;

                bool hasSellerReferrer = !string.IsNullOrWhiteSpace(sellerReferrer);
                bool hasBuyerReferrer = !string.IsNullOrWhiteSpace(buyerReferrer);

                if (hasSellerReferrer)
                {
                    var sellerRefKey = $"SELLER_REF_{sellerReferrer}";
                    if (!credits.TryGetValue(sellerRefKey, out var sellerRefVec))
                    {
                        sellerRefVec = BalanceVector.Credit(sellerReferrer);
                        credits[sellerRefKey] = sellerRefVec;
                    }
                    apply(sellerRefVec, sellerRefShare);
                }
                else
                {
                    apply(Get(donationPoolReferral), sellerRefShare);
                }
                allocated += sellerRefShare;

                if (hasBuyerReferrer)
                {
                    var buyerRefKey = $"BUYER_REF_{buyerReferrer}";
                    if (!credits.TryGetValue(buyerRefKey, out var buyerRefVec))
                    {
                        buyerRefVec = BalanceVector.Credit(buyerReferrer);
                        credits[buyerRefKey] = buyerRefVec;
                    }
                    apply(buyerRefVec, buyerRefShare);
                }
                else
                {
                    apply(Get(donationPoolReferral), buyerRefShare);
                }
                allocated += buyerRefShare;

                // GP last as balancing remainder per bucket
                decimal genesisTotal = AccountingHelpers.Round6(amount - allocated);

                if (genesisTotal > 0m)
                {
                    apply(Get(genesisPoolReferral), genesisTotal);
                }
            }

            // ------------------------------------------------------------
            // APPLY PER BALANCE (1:1)
            // ------------------------------------------------------------
            DistributeBalance(debit.Transferable,
                (v, a) => v.Transferable += a);

            DistributeBalance(debit.NonTransferable,
                (v, a) => v.NonTransferable += a);

            DistributeBalance(debit.Community,
                (v, a) => v.Community += a);

            DistributeBalance(debit.Subscription,
                (v, a) => v.Subscription += a);

            DistributeBalance(debit.Overflow,
                (v, a) => v.Overflow += a);

            DistributeBalance(debit.Special,
                (v, a) => v.Special += a);

            return credits.Values.ToList();
        }

    }

    //--------------------------------------------------------------------------------------------------------
    //--guardrail evaluation service

    public sealed class GuardrailEvaluationService
    {
        private readonly string _connectionString;

        public GuardrailEvaluationService(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        // ENTRY POINT — HARD FAIL GUARDRAILS

        public bool Evaluate(
            string transactionType,
            JObject payload,
            JObject metadata,
            string mode,
            out string guardrailKey,
            out string rejectionReason)
        {
            guardrailKey = $"{transactionType}:{mode}";
            rejectionReason = string.Empty;

            if (string.IsNullOrWhiteSpace(transactionType))
            {
                rejectionReason = "missing_transaction_type";
                return false;
            }

            if (payload == null)
            {
                rejectionReason = "missing_payload";
                return false;
            }

            return transactionType switch
            {
                "member_to_member_transfer" => EvaluateMemberTransfer(payload, mode, out rejectionReason),

                // All other transaction types currently pass
                _ => true
            };
        }

        // MEMBER → MEMBER TRANSFER

        private bool EvaluateMemberTransfer(
            JObject payload,
            string mode,
            out string rejectionReason)
        {
            rejectionReason = string.Empty;

            var fromMember = payload.Value<string>("fromMember");
            var amount = payload.Value<decimal?>("amount");

            if (string.IsNullOrWhiteSpace(fromMember))
            {
                rejectionReason = "missing_from_member";
                return false;
            }

            if (amount == null || amount <= 0)
            {
                rejectionReason = "invalid_amount";
                return false;
            }

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            // REPUTATION CHECK
            int reputation;
            var membersTable = "members";
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = $@"
                    SELECT reputationscore
                    FROM {membersTable}
                    WHERE referral_code = @member
                ";
                cmd.Parameters.AddWithValue("@member", fromMember);
                var result = cmd.ExecuteScalar();
                reputation = result == null ? 0 : Convert.ToInt32(result);
            }

            int reputationLimit = 1200; // Fallback for TRANSFER-ELIGIBILITY
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT tokeninteger
                    FROM tokens
                    WHERE key = 'TRANSFER-ELIGIBILITY'
                ";
                var result = cmd.ExecuteScalar();
                if (result != null)
                    reputationLimit = Convert.ToInt32(result);
            }

            if (reputation < reputationLimit)
            {
                rejectionReason = "insufficient_reputation";
                return false;
            }

            // WEEKLY TRANSFER LIMIT
            decimal weeklyLimit = 150m;
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT tokendecimal
                    FROM tokens
                    WHERE key = 'TRANSFER-AMOUNT-LIMIT'
                ";
                var result = cmd.ExecuteScalar();
                if (result != null)
                    weeklyLimit = Convert.ToDecimal(result);
            }

            decimal alreadyTransferred;
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COALESCE(SUM(amount), 0)
                    FROM finance_transaction_guardrail_log
                    WHERE transaction_type = 'member_to_member_transfer'
                      AND member_id = @member
                      AND created_at >= date_trunc('week', now())
                      AND created_at < date_trunc('week', now()) + interval '7 days'
                ";
                cmd.Parameters.AddWithValue("@member", fromMember);
                alreadyTransferred = Convert.ToDecimal(cmd.ExecuteScalar());
            }

            if (alreadyTransferred + amount.Value > weeklyLimit)
            {
                rejectionReason = "weekly_transfer_limit_exceeded";
                return false;
            }

            return true;
        }
    }

    //--------------------------------------------------------------------------------------------------------
    //--guardrail log service

    public sealed class GuardrailLogService
    {
        private readonly string _connectionString;

        public GuardrailLogService(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        //--record transaction
        public void RecordTransaction(
            string transactionType,
            string guardrailKey,
            string memberId,
            string objectId,
            decimal amount,
            string mode)
        {
            if (string.IsNullOrWhiteSpace(transactionType))
                throw new ArgumentException(nameof(transactionType));
            if (string.IsNullOrWhiteSpace(guardrailKey))
                throw new ArgumentException(nameof(guardrailKey));
            if (string.IsNullOrWhiteSpace(mode))
                throw new ArgumentException(nameof(mode));

            // Decide which table to use based on mode,
            // but always write "production" into the mode column to satisfy
            // the existing CHECK constraint on both tables.
            var useProduction = mode == "production";
            var table = useProduction
                ? "finance_transaction_guardrail_log"
                : "finance_transaction_guardrail_log";

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var cmd = conn.CreateCommand();
            cmd.CommandText =
                $@"INSERT INTO {table}
                    (transaction_type, guardrail_key, member_id, object_id, amount, mode)
                VALUES
                    (@type, @key, @member, @object, @amount, @mode)";
            cmd.Parameters.AddWithValue("@type", transactionType);
            cmd.Parameters.AddWithValue("@key", guardrailKey);
            cmd.Parameters.AddWithValue("@member", (object?)memberId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@object", (object?)objectId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@amount", amount);

            // Keep DB constraint happy: log mode as "production"
            cmd.Parameters.AddWithValue("@mode", "production");

            cmd.ExecuteNonQuery();
        }

    }

    //--------------------------------------------------------------------------------------------------------
    //--ledger write service
    public sealed class LedgerWriteService
    {
        private readonly string _connectionString;

        public LedgerWriteService(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        //--write GP row
        public bool WriteGpRow(decimal amount, JObject metadata, string mode)
        {
            var tableName = mode == "production"
                ? "gp_ledger"
                : "gp_ledger";

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
                INSERT INTO {tableName}
                    (referral_code, tx_type, amount, metadata)
                VALUES
                    ('GENESIS_POOL', 'genesis_pool', @amount, @metadata)
            ";

            cmd.Parameters.AddWithValue("@amount", amount);
            cmd.Parameters.Add(
                new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                {
                    Value = (metadata ?? new JObject())
                        .ToString(Newtonsoft.Json.Formatting.None)
                });

            cmd.ExecuteNonQuery();
            return true;
        }

        public decimal GetGenesisPoolBalance(string mode)
        {
            var tableName = mode == "production"
                ? "gp_ledger"
                : "gp_ledger";

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
                SELECT COALESCE(SUM(amount), 0)
                FROM {tableName}
                WHERE referral_code = 'GENESIS_POOL'
            ";

            var result = cmd.ExecuteScalar();
            return result == null || result == DBNull.Value ? 0m : (decimal)result;
        }

        //--write encumbered

        public bool WriteEncumbered(
            string referralCode,
            string campaignId,
            decimal delta,
            JObject metadata,
            string mode)
        {
            if (string.IsNullOrWhiteSpace(referralCode))
                throw new ArgumentException(nameof(referralCode));
            if (string.IsNullOrWhiteSpace(campaignId))
                throw new ArgumentException(nameof(campaignId));

            var tableName = mode == "production"
                ? "encumbered_ledger"
                : "encumbered_ledger";

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
                INSERT INTO {tableName}
                    (referral_code, campaign_id, tx_id, amount_delta, metadata)
                VALUES
                    (@referral, @campaign, gen_random_uuid()::text, @amount, @metadata)
            ";

            cmd.Parameters.AddWithValue("@referral", referralCode);
            cmd.Parameters.AddWithValue("@campaign", campaignId);
            cmd.Parameters.AddWithValue("@amount", delta);
            cmd.Parameters.Add(
                new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                {
                    Value = (metadata ?? new JObject())
                        .ToString(Newtonsoft.Json.Formatting.None)
                });

            cmd.ExecuteNonQuery();
            return true;
        }

        /// <summary>
        /// Writes encumbered_ledger row using existing connection and transaction, with explicit tx_id
        /// so the same tx_id can be used for the main ledger encumbrance row (single-transaction consistency).
        /// </summary>
        public bool WriteEncumbered(
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string referralCode,
            string campaignId,
            string txId,
            decimal delta,
            JObject metadata,
            string mode)
        {
            if (conn == null) throw new ArgumentNullException(nameof(conn));
            if (tx == null) throw new ArgumentNullException(nameof(tx));
            if (string.IsNullOrWhiteSpace(referralCode)) throw new ArgumentException(nameof(referralCode));
            if (string.IsNullOrWhiteSpace(campaignId)) throw new ArgumentException(nameof(campaignId));
            if (string.IsNullOrWhiteSpace(txId)) throw new ArgumentException(nameof(txId));

            var tableName = mode == "production" ? "encumbered_ledger" : "encumbered_ledger";

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                INSERT INTO {tableName}
                    (referral_code, campaign_id, tx_id, amount_delta, metadata)
                VALUES
                    (@referral, @campaign, @tx_id, @amount, @metadata)
            ";

            cmd.Parameters.AddWithValue("@referral", referralCode);
            cmd.Parameters.AddWithValue("@campaign", campaignId);
            cmd.Parameters.AddWithValue("@tx_id", txId);
            cmd.Parameters.AddWithValue("@amount", delta);
            cmd.Parameters.Add(
                new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                {
                    Value = (metadata ?? new JObject()).ToString(Newtonsoft.Json.Formatting.None)
                });

            cmd.ExecuteNonQuery();
            return true;
        }

        /// <summary>
        /// Writes a single main-ledger row for an encumbrance operation (point_type=encumbered, tx_subtype=ED).
        /// Must be called within the same transaction as WriteEncumbered(conn, tx, ...) with the same tx_id.
        /// </summary>
        public void WriteEncumbranceMainLedgerEntry(
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string txId,
            string referralCode,
            string campaignId,
            decimal amount,
            JObject metadata,
            string mode)
        {
            if (conn == null) throw new ArgumentNullException(nameof(conn));
            if (tx == null) throw new ArgumentNullException(nameof(tx));
            if (string.IsNullOrWhiteSpace(txId)) throw new ArgumentException(nameof(txId));
            if (string.IsNullOrWhiteSpace(referralCode)) throw new ArgumentException(nameof(referralCode));
            if (string.IsNullOrWhiteSpace(campaignId)) throw new ArgumentException(nameof(campaignId));

            var ledgerTable = mode == "production" ? "ledger" : "ledger";
            var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "ENCUMBRANCE", "encumbered");
            var absoluteAmount = Math.Abs(amount);
            var entryType = amount >= 0 ? "CREDIT" : "DEBIT";

            var meta = metadata ?? new JObject();
            if (meta["campaign_id"] == null)
                meta["campaign_id"] = campaignId;

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                INSERT INTO {ledgerTable} (
                    tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount,
                    transaction_date, metadata, source_system, is_test, tx_description, entry_type)
                VALUES (
                    @tx_id, @referral_code, 'encumbrance', NULL, 'ED', 'encumbered', @account_number, @amount,
                    NOW(), @metadata::jsonb, 'v3', @is_test, @tx_description, @entry_type)
            ";

            cmd.Parameters.AddWithValue("@tx_id", txId);
            cmd.Parameters.AddWithValue("@referral_code", referralCode);
            cmd.Parameters.AddWithValue("@account_number", accountCode);
            cmd.Parameters.AddWithValue("@amount", absoluteAmount);
            cmd.Parameters.AddWithValue("@metadata", meta.ToString(Newtonsoft.Json.Formatting.None));
            cmd.Parameters.AddWithValue("@is_test", mode == "test");
            cmd.Parameters.AddWithValue("@tx_description", (object?)($"Encumbrance ED - campaign {campaignId}") ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@entry_type", entryType);

            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Writes both main-ledger encumbrance row and encumbered_ledger row in a single transaction with the same tx_id.
        /// </summary>
        public bool WriteEncumbrancePair(
            string referralCode,
            string campaignId,
            string txId,
            decimal delta,
            JObject metadata,
            string mode)
        {
            if (string.IsNullOrWhiteSpace(referralCode)) throw new ArgumentException(nameof(referralCode));
            if (string.IsNullOrWhiteSpace(campaignId)) throw new ArgumentException(nameof(campaignId));
            if (string.IsNullOrWhiteSpace(txId)) throw new ArgumentException(nameof(txId));

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                WriteEncumbranceMainLedgerEntry(conn, tx, txId, referralCode, campaignId, delta, metadata ?? new JObject(), mode);
                WriteEncumbered(conn, tx, referralCode, campaignId, txId, delta, metadata ?? new JObject(), mode);
                tx.Commit();
                return true;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        public decimal GetEncumberedBalance(
            string referralCode,
            string campaignId,
            string mode)
        {
            if (string.IsNullOrWhiteSpace(referralCode))
                throw new ArgumentException(nameof(referralCode));
            if (string.IsNullOrWhiteSpace(campaignId))
                throw new ArgumentException(nameof(campaignId));

            var tableName = mode == "production"
                ? "encumbered_ledger"
                : "encumbered_ledger";

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            using var cmd = conn.CreateCommand();
            cmd.CommandText = $@"
                SELECT COALESCE(SUM(amount_delta), 0)
                FROM {tableName}
                WHERE referral_code = @referral
                  AND campaign_id = @campaign
            ";

            cmd.Parameters.AddWithValue("@referral", referralCode);
            cmd.Parameters.AddWithValue("@campaign", campaignId);

            var result = cmd.ExecuteScalar();
            return result == null || result == DBNull.Value ? 0m : (decimal)result;
        }

        //--insert ledger row

        private static void InsertLedgerRow(
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string transactionType,
            string referral,
            string? counterparty,
            JObject payload,
            decimal amount,
            string mode)
        {
            if (conn == null)
                throw new ArgumentNullException(nameof(conn));
            if (tx == null)
                throw new ArgumentNullException(nameof(tx));

            var tableName = mode == "production"
                ? "ledger"
                : "ledger";

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                INSERT INTO {tableName}
                    (tx_id, referral_code, counterparty_code, tx_type, point_type, amount, gross_amount, net_amount, metadata, source_system, is_test)
                VALUES
                    (
                        gen_random_uuid()::text,
                        @referral,
                        @counterparty,
                        @tx_type,
                        'transferable',
                        @amount,
                        @amount,
                        @amount,
                        @metadata,
                        'v3',
                        @is_test
                    )
            ";

            cmd.Parameters.AddWithValue("@referral", referral);
            cmd.Parameters.AddWithValue("@counterparty", (object?)counterparty ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@tx_type", transactionType);
            cmd.Parameters.AddWithValue("@amount", amount);
            cmd.Parameters.Add(
                new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                {
                    Value = (payload ?? new JObject())
                        .ToString(Newtonsoft.Json.Formatting.None)
                });
            cmd.Parameters.AddWithValue("@is_test", mode == "test");

            cmd.ExecuteNonQuery();
        }

        private static decimal SumVector(BalanceVector v)
        {
            return v.Transferable
                   + v.NonTransferable
                   + v.Community
                   + v.Special
                   + v.Overflow
                   + v.Subscription;
        }
    }

    //--------------------------------------------------------------------------------------------------------
    //--gp service

    public sealed class GpService
    {
        private readonly LedgerWriteService _ledger;
        private readonly BalanceService _balances;
        private readonly ILogger<GpService> _logger;

        public GpService(
            LedgerWriteService ledger,
            BalanceService balances,
            ILogger<GpService> logger)
        {
            _ledger = ledger ?? throw new ArgumentNullException(nameof(ledger));
            _balances = balances ?? throw new ArgumentNullException(nameof(balances));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public bool Credit(decimal amount, JObject meta, string mode)
        {
            if (amount <= 0m) return true;
            return _ledger.WriteGpRow(amount, meta, mode);
        }

        public bool Debit(decimal amount, JObject meta, string mode)
        {
            if (amount <= 0m) return true;

            decimal available = GetBalance(mode);
            if (available < amount)
            {
                _logger.LogError("GpService.Debit: insufficient GP balance");
                return false;
            }

            return _ledger.WriteGpRow(-amount, meta, mode);
        }

        public bool DistributeToMember(
            string referralCode,
            decimal amount,
            JObject meta,
            string mode)
        {
            if (amount <= 0m) return true;

            decimal available = GetBalance(mode);
            if (available < amount)
            {
                _logger.LogError("GpService.DistributeToMember: insufficient GP balance");
                return false;
            }

            bool ok = _balances.ApplyBalanceDelta(
                referralCode,
                "transferable",
                amount,
                meta,
                mode);

            if (!ok)
            {
                _logger.LogError("GpService.DistributeToMember: balance credit failed");
                return false;
            }

            return _ledger.WriteGpRow(-amount, meta, mode);
        }

        public decimal GetBalance(string mode)
        {
            return _ledger.GetGenesisPoolBalance(mode);
        }
    }

    //--------------------------------------------------------------------------------------------------------
    //--encumbrance service
    public sealed class EncumbranceService
    {
        private readonly LedgerWriteService _ledger;
        private readonly BalanceService _balances;
        private readonly ILogger<EncumbranceService> _logger;

        public EncumbranceService(
            LedgerWriteService ledger,
            BalanceService balances,
            ILogger<EncumbranceService> logger)
        {
            _ledger = ledger ?? throw new ArgumentNullException(nameof(ledger));
            _balances = balances ?? throw new ArgumentNullException(nameof(balances));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public bool CreateEncumbrance(
            string referralCode,
            string campaignId,
            decimal amount,
            JObject meta,
            string mode)
        {
            if (amount <= 0m) return true;

            bool ok = _balances.ApplyBalanceDelta(
                referralCode,
                "transferable",
                -amount,
                meta,
                mode);

            if (!ok)
            {
                _logger.LogError("EncumbranceService.CreateEncumbrance: debit failed");
                return false;
            }

            var txId = Guid.NewGuid().ToString("N");
            return _ledger.WriteEncumbrancePair(referralCode, campaignId, txId, amount, meta, mode);
        }

        public bool ApplyCampaignSpend(
            string referralCode,
            string campaignId,
            decimal gross,
            decimal tax,
            JObject meta,
            string mode)
        {
            decimal required = Math.Round(gross + tax, 6);
            decimal available = GetEncumberedBalance(referralCode, campaignId, mode);

            if (available < required)
            {
                _logger.LogError("EncumbranceService.ApplyCampaignSpend: insufficient balance");
                return false;
            }

            var txId = Guid.NewGuid().ToString("N");
            return _ledger.WriteEncumbrancePair(referralCode, campaignId, txId, -required, meta, mode);
        }

        public bool ReleaseEncumbrance(
            string referralCode,
            string campaignId,
            JObject meta,
            string mode)
        {
            decimal remaining = GetEncumberedBalance(referralCode, campaignId, mode);
            if (remaining <= 0m) return true;

            bool ok = _balances.ApplyBalanceDelta(
                referralCode,
                "transferable",
                remaining,
                meta,
                mode);

            if (!ok)
            {
                _logger.LogError("EncumbranceService.ReleaseEncumbrance: credit failed");
                return false;
            }

            var txId = Guid.NewGuid().ToString("N");
            return _ledger.WriteEncumbrancePair(referralCode, campaignId, txId, -remaining, meta, mode);
        }

        private decimal GetEncumberedBalance(
            string referralCode,
            string campaignId,
            string mode)
        {
            return _ledger.GetEncumberedBalance(
                referralCode,
                campaignId,
                mode);
        }
    }

    //--------------------------------------------------------------------------------------------------------
    //--transaction processing service
    public sealed class TransactionProcessingService
    {
        private readonly BalanceService _balances;
        private readonly DistributionEngine _distribution;
        private readonly GuardrailEvaluationService _guardrails;
        private readonly GuardrailLogService _guardrailLog;
        private readonly DebugTraceService _debugTrace;
        private readonly string _connectionString;
        private readonly ExternalPaymentService? _externalPayment;
        private readonly TokenService? _tokenService;
        private readonly CountriesService? _countriesService;

        public TransactionProcessingService(
            BalanceService balances,
            DistributionEngine distribution,
            GuardrailEvaluationService guardrails,
            GuardrailLogService guardrailLog,
            DebugTraceService debugTrace,
            string connectionString,
            ExternalPaymentService? externalPayment = null,
            TokenService? tokenService = null,
            CountriesService? countriesService = null)
        {
            _balances = balances ?? throw new ArgumentNullException(nameof(balances));
            _distribution = distribution ?? throw new ArgumentNullException(nameof(distribution));
            _guardrails = guardrails ?? throw new ArgumentNullException(nameof(guardrails));
            _guardrailLog = guardrailLog ?? throw new ArgumentNullException(nameof(guardrailLog));
            _debugTrace = debugTrace ?? throw new ArgumentNullException(nameof(debugTrace));
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _externalPayment = externalPayment;
            _tokenService = tokenService;
            _countriesService = countriesService;
        }

        //----------------------------------------------------------------------------------------------------
        //--helper methods

        /// <summary>
        /// Get credit card surcharge percentage from TokenService
        /// Uses key 'CC-STRIPE-SURCHARGE' with fallback to 3% (0.03) if not found
        /// </summary>
        private decimal GetCreditCardSurchargePercentage()
        {
            const decimal defaultSurcharge = 0.03m; // 3% default

            if (_tokenService == null)
            {
                _debugTrace?.Write("[GetCreditCardSurchargePercentage] TokenService not available, using default 3%");
                return defaultSurcharge;
            }

            try
            {
                var tokenValue = _tokenService.Get("CC-STRIPE-SURCHARGE");
                
                if (tokenValue == null)
                {
                    _debugTrace?.Write("[GetCreditCardSurchargePercentage] Token 'CC-STRIPE-SURCHARGE' not found, using default 3%");
                    return defaultSurcharge;
                }

                // Handle different token value types
                decimal surchargePercent;
                if (tokenValue is decimal decValue)
                {
                    surchargePercent = decValue;
                }
                else if (tokenValue is int intValue)
                {
                    surchargePercent = intValue / 100m; // Convert percentage (e.g., 3) to decimal (0.03)
                }
                else if (tokenValue is string strValue && decimal.TryParse(strValue, out var parsed))
                {
                    surchargePercent = parsed;
                    // If the string looks like a percentage (e.g., "3" or "3%"), convert to decimal
                    if (surchargePercent > 1m && surchargePercent <= 100m)
                    {
                        surchargePercent = surchargePercent / 100m;
                    }
                }
                else
                {
                    _debugTrace?.Write($"[GetCreditCardSurchargePercentage] Token 'CC-STRIPE-SURCHARGE' has invalid type {tokenValue.GetType()}, using default 3%");
                    return defaultSurcharge;
                }

                // Validate range (should be between 0 and 1 for decimal, or reasonable percentage)
                if (surchargePercent < 0m || surchargePercent > 1m)
                {
                    _debugTrace?.Write($"[GetCreditCardSurchargePercentage] Token 'CC-STRIPE-SURCHARGE' value {surchargePercent} out of range, using default 3%");
                    return defaultSurcharge;
                }

                _debugTrace?.Write($"[GetCreditCardSurchargePercentage] Using surcharge percentage: {surchargePercent * 100}% from token");
                return surchargePercent;
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[GetCreditCardSurchargePercentage] Error getting token: {ex.Message}, using default 3%");
                return defaultSurcharge;
            }
        }

        //----------------------------------------------------------------------------------------------------
        //--referrer resolution helpers (BACKEND OWNED)

        private string? ResolveMemberReferrer(
            string memberReferral,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string mode = "production")
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
                return null;

            var membersTable = "members";
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                SELECT referrer
                FROM {membersTable}
                WHERE assignedreferral = @referral
            ";
            cmd.Parameters.AddWithValue("@referral", memberReferral);

            var result = cmd.ExecuteScalar();
            return result == null || result == DBNull.Value ? null : result.ToString();
        }

        private string? ResolveChannelReferrer(
            string channelReferral,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string mode = "production")
        {
            if (string.IsNullOrWhiteSpace(channelReferral))
                return null;

            var channelTable = "channel";
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                SELECT referredby
                FROM {channelTable}
                WHERE assignedreferral = @referral
            ";
            cmd.Parameters.AddWithValue("@referral", channelReferral);

            var result = cmd.ExecuteScalar();
            return result == null || result == DBNull.Value ? null : result.ToString();
        }

        private string ResolveSystemReferral(
            string tokenKey,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
                SELECT stringvalue
                FROM tokens
                WHERE key = @key
            ";
            cmd.Parameters.AddWithValue("@key", tokenKey);

            var result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new InvalidOperationException($"Missing system referral token: {tokenKey}");

            return result.ToString()!;
        }

        /// <summary>
        /// Check if a country allows credit card charges
        /// </summary>
        private bool CheckCountryAllowsCreditCard(NpgsqlConnection conn, string countryIso2)
        {
            try
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
                    SELECT allows_credit_card_charges
                    FROM countries
                    WHERE iso2 = @iso2
                      AND is_active = TRUE
                    LIMIT 1;";
                cmd.Parameters.AddWithValue("iso2", countryIso2.ToUpper());

                var result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    return Convert.ToBoolean(result);
                }

                // If country not found, default to false (restrictive)
                _debugTrace.Write($"[CheckCountryAllowsCreditCard] Country {countryIso2} not found, defaulting to false");
                return false;
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[CheckCountryAllowsCreditCard] Error checking country {countryIso2}: {ex.Message}");
                // On error, default to false (restrictive)
                return false;
            }
        }

        //----------------------------------------------------------------------------------------------------
        //--
        private JArray BuildLedgerReadbackRows(
            string txId,
            string mode,
            NpgsqlConnection conn)
        {
            var ledgerRows = new JArray();

            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT
                        referral_code,
                        tx_type,
                        point_type,
                        account_number,
                        amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";

                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            return ledgerRows;
        }


        //----------------------------------------------------------------------------------------------------
        //--single transaction entry point
        public JObject ProcessTransaction(
            string transactionType,
            JObject payload,
            JObject metadata,
            string mode)
        {
            mode = mode == "production" ? "production" : "test";
            var start = DateTime.UtcNow;

            _debugTrace?.Write($"[TX START] type={transactionType}, mode={mode}");

            if (string.IsNullOrWhiteSpace(transactionType))
                throw new ArgumentException(nameof(transactionType));
            if (payload == null)
                throw new ArgumentNullException(nameof(payload));
            if (metadata == null)
                throw new ArgumentNullException(nameof(metadata));

            var txId =
                metadata.Value<string>("txId")
                ?? Guid.NewGuid().ToString("N");

            metadata["txId"] = txId;

            _debugTrace?.Write($"[TX ID] {txId}");

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            using var tx = conn.BeginTransaction();

            // OLD SCAFFOLDED CODE REMOVED - member_points_purchase is now handled by ProcessMemberPointsPurchase method below

            // ============================================================
            // TRANSACTION TYPE 1: reward_distribution
            // ============================================================
            if (transactionType == "reward_distribution")
            {
                return ProcessRewardDistribution(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 2: offer_purchase_distribution
            // ============================================================
            if (transactionType == "offer_purchase_distribution")
            {
                return ProcessOfferPurchaseDistribution(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 3: content_purchase_distribution
            // ============================================================
            if (transactionType == "content_purchase_distribution")
            {
                return ProcessContentPurchaseDistribution(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 4: comment_payment_distribution
            // ============================================================
            if (transactionType == "comment_payment_distribution")
            {
                return ProcessCommentPaymentDistribution(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 5: subscription_purchase_distribution
            // ============================================================
            if (transactionType == "subscription_purchase_distribution")
            {
                return ProcessSubscriptionPurchaseDistribution(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 6: donation_distribution
            // ============================================================
            if (transactionType == "donation_distribution")
            {
                return ProcessDonationDistribution(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 7: member_points_purchase
            // ============================================================
            if (transactionType == "member_points_purchase")
            {
                return ProcessMemberPointsPurchase(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 11: member_to_member_transfer
            // ============================================================
            if (transactionType == "member_to_member_transfer")
            {
                return ProcessMemberToMemberTransfer(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 19: campaign_balance_credit
            // ============================================================
            if (transactionType == "campaign_balance_credit")
            {
                return ProcessCampaignBalanceCredit(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 21: campaign_invoice_funding
            // ============================================================
            if (transactionType == "campaign_invoice_funding")
            {
                _debugTrace?.Write($"[ProcessTransaction] Routing to ProcessCampaignInvoiceFunding");
                return ProcessCampaignInvoiceFunding(payload, metadata, mode, conn, tx, start);
            }

            // ============================================================
            // TRANSACTION TYPE 20: smart_contract_distribution
            // ============================================================
            if (transactionType == "smart_contract_distribution")
            {
                return ProcessSmartContractDistribution(payload, metadata, mode, conn, tx, start);
            }

            // If we reach here, the transaction type didn't match any specific handler
            // This will fall through to the generic handler which expects "balances" in payload
            _debugTrace?.Write($"[ProcessTransaction] ⚠️ WARNING: Transaction type '{transactionType}' did not match any specific handler. Falling through to generic handler.");
            _debugTrace?.Write($"[ProcessTransaction] Available handlers: reward_distribution, offer_purchase_distribution, content_purchase_distribution, comment_payment_distribution, subscription_purchase_distribution, donation_distribution, member_points_purchase, member_to_member_transfer, campaign_balance_credit, campaign_invoice_funding, smart_contract_distribution");

            // ---------------- NORMALIZE PAYLOAD ----------------
            var member =
                payload.Value<string>("memberReferral")
                ?? payload.Value<string>("member")
                ?? string.Empty;

            var channelReferral =
                payload.Value<string>("channelReferral")
                ?? payload.Value<string>("channel")
                ?? string.Empty;

            var balancesObj = payload["balances"] as JObject;
            if (balancesObj == null)
                throw new InvalidOperationException("No balances supplied");
            
            if (!balancesObj.Properties().Any())
                throw new InvalidOperationException("No balances supplied");

            // At this point, balancesObj is guaranteed to be non-null
            JObject validatedBalances = balancesObj;
            string balancesJson = validatedBalances.ToString(Newtonsoft.Json.Formatting.None);
            _debugTrace?.Write(
                $"[INPUT BALANCES] {balancesJson ?? string.Empty}"
            );

            // ---------------- BUILD DEBIT VECTOR ----------------
            var debit = BalanceVector.ForSpend(member);

            foreach (var prop in validatedBalances.Properties())
            {
                var amount = prop.Value.Value<decimal>();
                if (amount <= 0m) continue;

                switch (prop.Name)
                {
                    case "transferable": debit.Transferable = amount; break;
                    case "nonTransferable": debit.NonTransferable = amount; break;
                    case "community": debit.Community = amount; break;
                    case "subscription": debit.Subscription = amount; break;
                    case "overflow": debit.Overflow = amount; break;
                    case "special": debit.Special = amount; break;
                    default:
                        throw new InvalidOperationException($"Unsupported balance type: {prop.Name}");
                }
            }

            _debugTrace?.Write(
                $"[DEBIT VECTOR] T={debit.Transferable}, NT={debit.NonTransferable}, C={debit.Community}, S={debit.Subscription}, O={debit.Overflow}, SP={debit.Special}"
            );

            // ---------------- GUARDRAILS ----------------
            if (!_guardrails.Evaluate(
                    transactionType,
                    payload,
                    metadata,
                    mode,
                    out var guardrailKey,
                    out var rejectionReason))
            {
                _debugTrace?.Write($"[GUARDRAIL FAIL] reason={rejectionReason}");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = rejectionReason ?? "guardrail_violation"
                };
            }

            _debugTrace?.Write("[GUARDRAILS] passed");

            // ---------------- DISTRIBUTION ----------------
            var creditVectors =
                _distribution.Distribute(
                    transactionType,
                    debit,
                    channelReferral,
                    ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx),
                    ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx),
                    ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx),
                    ResolveMemberReferrer(member, conn, tx, mode),
                    ResolveChannelReferrer(channelReferral, conn, tx, mode)).ToList();

            _debugTrace?.Write($"[CREDIT COUNT] {creditVectors.Count}");

            foreach (var cv in creditVectors)
            {
                _debugTrace?.Write(
                    $"[CREDIT VECTOR] owner={cv.Owner}, T={cv.Transferable}, NT={cv.NonTransferable}, C={cv.Community}, S={cv.Subscription}"
                );
            }

            // Apply voluntary donation split (Transaction Type 8) if enabled
            // Note: For generic transaction handler, channelReferral is the seller
            creditVectors = ApplyVoluntaryDonationSplit(
                creditVectors,
                channelReferral, // seller is the channel
                payload,
                metadata,
                conn,
                tx);

            // ---------------- APPLY + LEDGER ----------------
            _balances.ApplyVectors(
                debit,
                creditVectors.ToList(), // Convert IReadOnlyList to List for ApplyVectors
                transactionType,
                payload,
                metadata,
                mode,
                conn,
                tx);

            WriteLedger(
                txId,
                transactionType,
                debit,
                creditVectors,
                payload,
                metadata,
                mode,
                conn,
                tx
            );

            AccountingHelpers.ValidateTransactionBalance(conn, tx, txId, "ledger");
            tx.Commit();

            _debugTrace?.Write("[LEDGER] committed");

            // ---------------- LEDGER READBACK ----------------
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["amount"] = r.GetDecimal(3)
                    });
                }
            }

            _debugTrace?.Write(
                $"[LEDGER READBACK] rows={ledgerRows.Count}, data={ledgerRows.ToString(Newtonsoft.Json.Formatting.None)}"
            );

            var result = JObject.FromObject(new
            {
                ok = true,
                executionMs =
                    (int)(DateTime.UtcNow - start).TotalMilliseconds,
                debit = debit,
                credits = creditVectors,
                ledger = ledgerRows
            });

            _debugTrace?.Write(
                $"[RETURN OBJECT] {result.ToString(Newtonsoft.Json.Formatting.None)}"
            );

            return result;
        }

        // ============================================================
        // TRANSACTION TYPE 1: reward_distribution
        // ============================================================
        private JObject ProcessRewardDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            // Normalize mode (same as ProcessTransaction)
            mode = mode?.ToLower() == "production" ? "production" : "test";
            
            // Ensure metadata is not null
            if (metadata == null)
            {
                metadata = new JObject();
            }
            
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            _debugTrace?.Write($"[ProcessRewardDistribution] 🔵 ENTRY: txId={txId}, mode={mode}");
            _debugTrace?.Write($"[ProcessRewardDistribution] Starting, mode={mode}, txId={txId}");
            
            var sellerReferral = payload.Value<string>("sellerReferral")
                ?? throw new InvalidOperationException("sellerReferral is required");
            
            // Parse buyerCampaignId from string (JSON typically sends Guids as strings)
            Guid? buyerCampaignId = null;
            var buyerCampaignIdStr = payload.Value<string>("buyerCampaignId");
            if (!string.IsNullOrWhiteSpace(buyerCampaignIdStr))
            {
                if (Guid.TryParse(buyerCampaignIdStr, out var parsedGuid))
                {
                    buyerCampaignId = parsedGuid;
                }
            }
            
            var buyerReferral = payload.Value<string>("buyerReferral");
            
            if (!buyerCampaignId.HasValue && string.IsNullOrWhiteSpace(buyerReferral))
                throw new InvalidOperationException("buyerCampaignId or buyerReferral is required");
            
            var rewardAmount = payload.Value<decimal?>("rewardAmount")
                ?? throw new InvalidOperationException("rewardAmount is required");
            
            if (rewardAmount <= 0)
                throw new InvalidOperationException("rewardAmount must be greater than 0");
            
            _debugTrace?.Write($"[ProcessRewardDistribution] ✅ Validation passed - sellerReferral={sellerReferral}, buyerCampaignId={buyerCampaignId}, buyerReferral={buyerReferral ?? "NULL"}, rewardAmount={rewardAmount}");
            
            var sellerReferrer = payload.Value<string>("sellerReferrer");
            var buyerReferrer = payload.Value<string>("buyerReferrer");
            var isSponsored = payload.Value<bool?>("isSponsored") ?? false;
            var sponsoredChannelReferral = payload.Value<string>("sponsoredChannelReferral");
            var isDonation = payload.Value<bool?>("isDonation") ?? false;
            var donationChannelReferral = payload.Value<string>("donationChannelReferral");
            var donationAmount = payload.Value<decimal?>("donationAmount");
            
            // txId already declared above (line 3026), no need to redeclare
            
            // Load campaign balances
            var campaignIdentifier = buyerCampaignId.HasValue 
                ? buyerCampaignId.Value.ToString() 
                : buyerReferral;
            if (string.IsNullOrEmpty(campaignIdentifier))
                throw new InvalidOperationException("Campaign identifier (buyerCampaignId or buyerReferral) is required for reward distribution.");
            
            // Load campaign balances from campaigns table
            CampaignBalances balances = _balances.LoadCampaignBalancesByCampaignIdOrReferral(conn, tx, campaignIdentifier);
            
            // Debit campaign balances (duplicate logic from BalanceService)
            decimal remaining = rewardAmount;
            decimal fromCommunity = Math.Min(balances.Community, remaining);
            remaining -= fromCommunity;
            decimal fromTransferable = Math.Min(balances.Transferable, remaining);
            remaining -= fromTransferable;
            
            if (remaining > 0)
                throw new InvalidOperationException("Insufficient campaign balance for reward distribution.");
            
            // Apply campaign debits
            if (fromCommunity > 0)
            {
                using var cmd1 = conn.CreateCommand();
                cmd1.Transaction = tx;
                var tableName = "campaigns";
                var balanceColumn = "community_point_balance";
                object idValue;
                string idColumn;
                if (Guid.TryParse(campaignIdentifier, out var guidId))
                {
                    idColumn = "id";
                    idValue = guidId;
                }
                else
                {
                    idColumn = "channelreferral";
                    idValue = campaignIdentifier ?? throw new InvalidOperationException("Campaign identifier cannot be null");
                }
                
                cmd1.CommandText = $@"
                    UPDATE {tableName}
                    SET {balanceColumn} = {balanceColumn} - @amount
                    WHERE {idColumn} = @id";
                cmd1.Parameters.AddWithValue("@amount", fromCommunity);
                cmd1.Parameters.AddWithValue("@id", idValue);
                cmd1.ExecuteNonQuery();
            }
            
            if (fromTransferable > 0)
            {
                using var cmd2 = conn.CreateCommand();
                cmd2.Transaction = tx;
                var tableName = "campaigns";
                var balanceColumn = "transferable_point_balance";
                object idValue;
                string idColumn;
                if (Guid.TryParse(campaignIdentifier, out var guidId))
                {
                    idColumn = "id";
                    idValue = guidId;
                }
                else
                {
                    idColumn = "channelreferral";
                    idValue = campaignIdentifier ?? throw new InvalidOperationException("Campaign identifier cannot be null");
                }
                
                cmd2.CommandText = $@"
                    UPDATE {tableName}
                    SET {balanceColumn} = {balanceColumn} - @amount
                    WHERE {idColumn} = @id";
                cmd2.Parameters.AddWithValue("@amount", fromTransferable);
                cmd2.Parameters.AddWithValue("@id", idValue);
                cmd2.ExecuteNonQuery();
            }
            
            // Reward distribution: invoke Smart Contract engine (70/5/10/10/5, donation %, missing referrer → 2300, IMBC→4000, GP→2310, Restricted Cash 1100 subledger)
            var payerReferral = buyerReferral ?? campaignIdentifier ?? string.Empty;
            var rewardSellerReferrer = string.IsNullOrWhiteSpace(sellerReferrer) ? null : sellerReferrer;
            var rewardBuyerReferrer = string.IsNullOrWhiteSpace(buyerReferrer) ? null : buyerReferrer;
            var rewardSellerDonationPercent = metadata.Value<decimal?>("sellerDonatedatapercent") ?? 0m;
            var rewardSellerReferrerDonationPercent = metadata.Value<decimal?>("sellerReferrerDonatedatapercent") ?? 0m;
            var isTest = !string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
            
            var (debit, credits) = ExecuteSmartContractStyleDistribution(
                conn, tx, txId, rewardAmount, payerReferral, sellerReferral, "transferable",
                rewardBuyerReferrer, rewardSellerReferrer, rewardSellerDonationPercent, rewardSellerReferrerDonationPercent,
                mode, isTest, payload, metadata!, "reward_distribution", "4000", "1100");
            
            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "BO", "transferable");
            var debitWithAccountCode = new JObject
            {
                ["owner"] = debit.Owner,
                ["transferable"] = debit.Transferable,
                ["nonTransferable"] = debit.NonTransferable,
                ["community"] = debit.Community,
                ["special"] = debit.Special,
                ["overflow"] = debit.Overflow,
                ["subscription"] = debit.Subscription,
                ["total"] = debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription,
                ["accountCode"] = debitAccountCode
            };
            var creditsArray = new JArray();
            foreach (var c in credits)
            {
                var pointType = c.Transferable > 0 ? "transferable" : c.NonTransferable > 0 ? "nonTransferable" : c.Community > 0 ? "community" : c.Subscription > 0 ? "subscription" : "transferable";
                var creditAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "PI", pointType);
                creditsArray.Add(new JObject
                {
                    ["owner"] = c.Owner,
                    ["transferable"] = c.Transferable,
                    ["nonTransferable"] = c.NonTransferable,
                    ["community"] = c.Community,
                    ["special"] = c.Special,
                    ["overflow"] = c.Overflow,
                    ["subscription"] = c.Subscription,
                    ["total"] = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription,
                    ["accountCode"] = creditAccountCode
                });
            }

            AccountingHelpers.ValidateTransactionBalance(conn, tx, txId, "ledger");
            tx.Commit();
            var result = new JObject
            {
                ["ok"] = true,
                ["txId"] = txId,
                ["debit"] = debitWithAccountCode,
                ["credits"] = creditsArray,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds
            };
            _debugTrace?.Write($"[ProcessRewardDistribution] ✅ COMPLETE: ok=true, txId={txId}, executionMs={(int)(DateTime.UtcNow - start).TotalMilliseconds}");
            return result;
        }

        // ============================================================
        // TRANSACTION TYPE 2: offer_purchase_distribution
        // ============================================================
        private JObject ProcessOfferPurchaseDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[ProcessOfferPurchaseDistribution] Starting, mode={mode}");
            _debugTrace?.Write($"[ProcessOfferPurchaseDistribution] Payload keys: {string.Join(", ", payload.Properties().Select(p => p.Name))}");
            
            var buyerReferral = payload.Value<string>("buyerReferral")
                ?? payload.Value<string>("memberReferral")
                ?? payload.Value<string>("member")
                ?? throw new InvalidOperationException("buyerReferral is required");
            
            _debugTrace?.Write($"[ProcessOfferPurchaseDistribution] BuyerReferral={buyerReferral}");

            // Seller is always a channel for offer_purchase_distribution (not a member)
            var sellerReferral = payload.Value<string>("sellerReferral")
                ?? throw new InvalidOperationException("sellerReferral is required");

            var purchasePrice = payload.Value<decimal?>("purchasePrice")
                ?? throw new InvalidOperationException("purchasePrice is required");

            // Check if this is a resume (approval granted)
            var resumeToken = payload.Value<string>("resumeToken");
            var approved = payload.Value<bool?>("approved") ?? false;
            var fundingToken = payload.Value<string>("fundingToken");

            if (!string.IsNullOrWhiteSpace(resumeToken) && approved && !string.IsNullOrWhiteSpace(fundingToken))
            {
                // RESUME PATH: Execute after approval
                return ExecuteOfferPurchaseResume(
                    resumeToken,
                    fundingToken,
                    buyerReferral,
                    sellerReferral,
                    purchasePrice,
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    start);
            }

            // PREFLIGHT PATH: Calculate funding needs, create payment intent
            return ExecuteOfferPurchasePreflight(
                buyerReferral,
                sellerReferral,
                purchasePrice,
                payload,
                metadata,
                mode,
                conn,
                tx);
        }

        private JObject ExecuteOfferPurchasePreflight(
            string buyerReferral,
            string sellerReferral,
            decimal purchasePrice,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // 0. Validate country allows credit card charges (if shortfall requires credit card)
            var wallet = _balances.LoadWalletSnapshot(buyerReferral, mode, conn, tx);
            var transferableAvailable = wallet.Transferable;
            var transferableUsed = Math.Min(transferableAvailable, purchasePrice);
            var shortfall = purchasePrice - transferableUsed;

            // If shortfall requires credit card, validate country
            if (shortfall > 0)
            {
                var countryIso2 = payload.Value<string>("countryIso2");
                if (string.IsNullOrWhiteSpace(countryIso2))
                {
                    _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] Missing countryIso2 in payload");
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = "countryIso2 is required for credit card transactions"
                    };
                }

                var countryAllowsCreditCard = CheckCountryAllowsCreditCard(conn, countryIso2);
                _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] Country={countryIso2}, AllowsCreditCard={countryAllowsCreditCard}");

                if (!countryAllowsCreditCard)
                {
                    _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] Country {countryIso2} does not allow credit card charges");
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = $"Credit card transactions are not allowed for country {countryIso2}"
                    };
                }
            }

            // 1. Load buyer wallet snapshot (READ ONLY, NO MUTATION)
            // Debug logging
            _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] Buyer={buyerReferral}, Price={purchasePrice}, Available={transferableAvailable}, Used={transferableUsed}, Shortfall={shortfall}, Mode={mode}");

            // 2. If no shortfall, proceed directly to execution
            if (shortfall <= 0)
            {
                _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] No shortfall detected, executing immediately");
                // No external funding needed - execute immediately
                return ExecuteOfferPurchaseDistribution(
                    buyerReferral,
                    sellerReferral,
                    purchasePrice,
                    transferableUsed,
                    0m, // externalAmount
                    0m, // surcharge
                    null, // no external payment
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    DateTime.UtcNow);
            }

            // 3. Calculate surcharge and total charge
            _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] Shortfall detected: {shortfall}, creating payment intent");
            
            // Get surcharge percentage from TokenService, fallback to 3% (0.03)
            decimal surchargePercentage = GetCreditCardSurchargePercentage();
            var surcharge = Math.Round(shortfall * surchargePercentage, 2);
            var totalCharge = shortfall + surcharge;
            
            _debugTrace?.Write($"[OFFER_PURCHASE_PREFLIGHT] Surcharge={surcharge}, TotalCharge={totalCharge}");

            // 4. Create payment intent
            var secureToken = Guid.NewGuid();
            var intentId = Guid.NewGuid();

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO transaction_payment_intents (
                        id, secure_token, transaction_type, member_referral,
                        gross_amount, transferable_used, external_required,
                        external_amount, surcharge_amount, funding_method,
                        status, payload_snapshot, metadata_snapshot, mode
                    ) VALUES (
                        @id, @secureToken, @transactionType, @memberReferral,
                        @grossAmount, @transferableUsed, @externalRequired,
                        @externalAmount, @surchargeAmount, @fundingMethod,
                        @status, @payloadSnapshot::jsonb, @metadataSnapshot::jsonb, @mode
                    )";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@secureToken", secureToken);
                cmd.Parameters.AddWithValue("@transactionType", "offer_purchase_distribution");
                cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                cmd.Parameters.AddWithValue("@grossAmount", purchasePrice);
                cmd.Parameters.AddWithValue("@transferableUsed", transferableUsed);
                cmd.Parameters.AddWithValue("@externalRequired", true);
                cmd.Parameters.AddWithValue("@externalAmount", shortfall);
                cmd.Parameters.AddWithValue("@surchargeAmount", surcharge);
                cmd.Parameters.AddWithValue("@fundingMethod", "credit_card");
                cmd.Parameters.AddWithValue("@status", "pending_approval");
                cmd.Parameters.AddWithValue("@payloadSnapshot", payload.ToString());
                cmd.Parameters.AddWithValue("@metadataSnapshot", metadata.ToString());
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();

            // 5. Get exchange rate and currency info for non-US countries
            string? memberCountryIso2 = payload.Value<string>("countryIso2");
            string? memberCurrencyCode = null;
            decimal? memberExchangeRate = null;
            decimal? memberConvertedAmount = null;

            if (!string.IsNullOrWhiteSpace(memberCountryIso2) && memberCountryIso2.ToUpper() != "US" && _countriesService != null)
            {
                // Get exchange rate from cache (no database reads)
                memberExchangeRate = _countriesService.GetExchangeRateUsdToCountry(memberCountryIso2);
                
                // Get currency code from cached countries
                var countries = _countriesService.GetAllCountriesForManagement();
                var country = countries.FirstOrDefault(c => 
                    (c.ContainsKey("iso2") ? c["iso2"]?.ToString() : null)?.ToUpper() == memberCountryIso2.ToUpper());
                
                if (country != null)
                {
                    memberCurrencyCode = country.ContainsKey("currencyCode") ? country["currencyCode"]?.ToString() : null;
                    
                    // Calculate converted amount if we have exchange rate
                    if (memberExchangeRate.HasValue && memberExchangeRate.Value > 0)
                    {
                        memberConvertedAmount = Math.Round(totalCharge * memberExchangeRate.Value, 2);
                    }
                }
            }

            // 6. Return approval required response
            var response = new JObject
            {
                ["ok"] = false,
                ["requiresApproval"] = true,
                ["approvalType"] = "credit_card",
                ["transactionType"] = "offer_purchase_distribution",
                ["transferableUsed"] = transferableUsed,
                ["externalRequired"] = shortfall,
                ["surcharge"] = surcharge,
                ["totalCharge"] = totalCharge,
                ["resumeToken"] = secureToken.ToString()
            };

            // Add country and currency info if available
            if (!string.IsNullOrWhiteSpace(memberCountryIso2))
            {
                response["countryIso2"] = memberCountryIso2;
            }
            if (!string.IsNullOrWhiteSpace(memberCurrencyCode))
            {
                response["currencyCode"] = memberCurrencyCode;
            }
            if (memberExchangeRate.HasValue)
            {
                response["exchangeRate"] = memberExchangeRate.Value;
            }
            if (memberConvertedAmount.HasValue)
            {
                response["convertedAmount"] = memberConvertedAmount.Value;
            }

            return response;
        }

        private JObject ExecuteOfferPurchaseResume(
            string resumeToken,
            string fundingToken,
            string buyerReferral,
            string sellerReferral,
            decimal purchasePrice,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            // 1. Resolve intent
            Guid intentGuid;
            if (!Guid.TryParse(resumeToken, out intentGuid))
                return new JObject { ["ok"] = false, ["error"] = "Invalid resumeToken" };

            Guid intentId;
            decimal transferableUsed;
            decimal externalAmount;
            decimal surchargeAmount;

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    SELECT id, transferable_used, external_amount, surcharge_amount, status
                    FROM transaction_payment_intents
                    WHERE secure_token = @secureToken
                      AND transaction_type = 'offer_purchase_distribution'
                      AND status = 'pending_approval'
                ";
                cmd.Parameters.AddWithValue("@secureToken", intentGuid);

                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return new JObject { ["ok"] = false, ["error"] = "Payment intent not found or already processed" };

                intentId = reader.GetGuid(0);
                transferableUsed = reader.GetDecimal(1);
                externalAmount = reader.GetDecimal(2);
                surchargeAmount = reader.GetDecimal(3);
                var status = reader.GetString(4);

                if (status != "pending_approval")
                    return new JObject { ["ok"] = false, ["error"] = $"Payment intent status is {status}, expected pending_approval" };
            }

            // 2. Execute Stripe charge (via ExternalPaymentService)
            // GAAP COMPLIANCE: 
            // - Customer pays: shortfall + surcharge (e.g., 50 + 1.5 = 51.5)
            // - Stripe processes: total charge (51.5)
            // - Stripe fee: ~1.5 (on the total)
            // - Net funded for points: shortfall amount (50) - Stripe fee on shortfall portion
            // - Surcharge: Separate revenue, not part of points transaction
            string? providerChargeId = null;
            decimal processingFee = 0m;
            decimal netFunded = 0m;

            // Total charge to customer = shortfall + surcharge
            var totalChargeToCustomer = externalAmount + surchargeAmount;

            if (_externalPayment != null && totalChargeToCustomer > 0)
            {
                var amountCents = (int)Math.Round(totalChargeToCustomer * 100);
                var (success, chargeId, gross, fee, net, error) = _externalPayment.CreateAndCapturePayment(
                    buyerReferral,
                    amountCents,
                    fundingToken
                ).GetAwaiter().GetResult();

                if (!success)
                    return new JObject { ["ok"] = false, ["error"] = error ?? "Payment failed" };

                providerChargeId = chargeId;
                processingFee = fee;
                // GAAP COMPLIANCE: Net funded must equal the shortfall amount for points to balance
                // Customer pays: shortfall + surcharge (e.g., 50 + 1.5 = 51.5)
                // Stripe processes: 51.5, takes fee (~1.5), we receive: ~50
                // However, we MUST fund exactly 50 points to balance the transaction
                // The Stripe fee is a cost of doing business, but doesn't reduce the points we fund
                // The surcharge revenue is recorded separately in the ledger
                netFunded = externalAmount; // Fund the full shortfall amount (50), not net after fees
            }
            else
            {
                // Mock for testing when ExternalPaymentService not available
                providerChargeId = $"ch_mock_{Guid.NewGuid():N}";
                // Stripe fee is on the total charge
                processingFee = Math.Round(totalChargeToCustomer * 0.029m + 0.30m, 2);
                // GAAP COMPLIANCE: Net funded must equal the shortfall amount for points to balance
                // We MUST fund exactly the shortfall amount (50), not net after Stripe fees
                // The Stripe fee is a cost of doing business, but doesn't reduce the points we fund
                netFunded = externalAmount; // Fund the full shortfall amount (50), not net after fees
            }

            // 3. Persist external payment ledger
            Guid externalPaymentId = Guid.NewGuid();
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO external_payment_ledger (
                        id, intent_id, member_referral, provider,
                        provider_charge_id, gross_charge_amount,
                        processing_fee_amount, net_funded_amount,
                        currency, transaction_type, status, mode, metadata
                    ) VALUES (
                        @id, @intentId, @memberReferral, @provider,
                        @providerChargeId, @grossChargeAmount,
                        @processingFeeAmount, @netFundedAmount,
                        @currency, @transactionType, @status, @mode, @metadata::jsonb
                    )";
                cmd.Parameters.AddWithValue("@id", externalPaymentId);
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                cmd.Parameters.AddWithValue("@provider", "stripe");
                cmd.Parameters.AddWithValue("@providerChargeId", providerChargeId ?? "");
                cmd.Parameters.AddWithValue("@grossChargeAmount", totalChargeToCustomer);
                cmd.Parameters.AddWithValue("@processingFeeAmount", processingFee);
                cmd.Parameters.AddWithValue("@netFundedAmount", netFunded);
                cmd.Parameters.AddWithValue("@currency", "USD");
                cmd.Parameters.AddWithValue("@transactionType", "offer_purchase_distribution");
                cmd.Parameters.AddWithValue("@status", "captured");
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.Parameters.AddWithValue("@metadata", metadata.ToString());
                cmd.ExecuteNonQuery();
            }

            // 4. Update payment intent status
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    UPDATE transaction_payment_intents
                    SET status = 'approved',
                        funding_token = @fundingToken,
                        consumed_at = CURRENT_TIMESTAMP
                    WHERE id = @id
                ";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@fundingToken", fundingToken);
                cmd.ExecuteNonQuery();
            }

            // 5. Execute the distribution
            return ExecuteOfferPurchaseDistribution(
                buyerReferral,
                sellerReferral,
                purchasePrice,
                transferableUsed,
                netFunded, // externalAmount (net after fees)
                surchargeAmount,
                externalPaymentId,
                payload,
                metadata,
                mode,
                conn,
                tx,
                start);
        }

        // Helper to build credits array for frontend balance check
        // GAAP COMPLIANCE: The surcharge is CASH REVENUE, not points, so it's NOT included in the points balance.
        // The surcharge is recorded separately in the ledger with account code CC_PROC_FEE_REV.
        // For GAAP compliance: Points transaction must balance independently (debits = credits).
        // The surcharge (1.5) is cash revenue that ImagineBC receives, separate from the points transaction.
        private JArray BuildCreditsArray(
            List<BalanceVector> credits,
            Guid? externalPaymentId,
            decimal surchargeAmount,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            var creditsArray = new JArray(credits.Select(c => 
            {
                var creditTotal = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription;
                // GAAP compliance: Every credit must have an account code
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "offer_purchase_distribution", "transferable");
                return JObject.FromObject(new
                {
                    owner = c.Owner,
                    transferable = c.Transferable,
                    nonTransferable = c.NonTransferable,
                    community = c.Community,
                    special = c.Special,
                    overflow = c.Overflow,
                    subscription = c.Subscription,
                    total = creditTotal,
                    accountCode = accountCode
                });
            }));

            // NOTE: Surcharge is NOT added here because it's cash revenue, not points.
            // The surcharge is recorded separately in the ledger with account code CC_PROC_FEE_REV.
            // The points transaction balances: 100 debits = 100 credits (without surcharge).

            return creditsArray;
        }

        // Seller is always a channel for offer_purchase_distribution (not a member)
        private JObject ExecuteOfferPurchaseDistribution(
            string buyerReferral,
            string sellerReferral, // Channel referral, not member referral
            decimal purchasePrice,
            decimal transferableUsed,
            decimal externalNetAmount,
            decimal surchargeAmount,
            Guid? externalPaymentId,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // 1. Debit buyer (transferable + external net)
            var totalDebit = transferableUsed + externalNetAmount;
            var debit = BalanceVector.ForSpend(buyerReferral);
            debit.Transferable = totalDebit;

            // 2. Custom distribution (NO ENGINE) - 91% seller, 6% ImagineBC, 3% Genesis Pool
            var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
            var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);

            var credits = new List<BalanceVector>
            {
                BalanceVector.CreditTransferable(sellerReferral, Math.Round(purchasePrice * 0.91m, 2)),
                BalanceVector.CreditTransferable(imagineBcReferral, Math.Round(purchasePrice * 0.06m, 2)),
                BalanceVector.CreditTransferable(genesisPoolReferral, Math.Round(purchasePrice * 0.03m, 2))
            };

            // 3. Apply voluntary donation split (Transaction Type 8) if enabled
            credits = ApplyVoluntaryDonationSplit(
                credits,
                sellerReferral, // seller is the channel
                payload,
                metadata,
                conn,
                tx);

            // 4. Apply vectors
            _balances.ApplyVectors(
                debit,
                credits,
                "offer_purchase_distribution",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 4. Write ledger entries
            WriteLedger(
                txId,
                "offer_purchase_distribution",
                debit,
                credits,
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 5. Write CC processing fee to ledger (if external payment exists)
            // GAAP COMPLIANCE: Surcharge is cash revenue, requires double-entry bookkeeping
            // - Debit: Cash (recorded in external_payment_ledger via Stripe)
            // - Credit: Revenue (CC_PROC_FEE_REV account)
            // The cash side is handled by external_payment_ledger, so we only record the revenue credit here.
            // This is acceptable GAAP practice when cash is handled by external payment processors.
            if (externalPaymentId.HasValue && surchargeAmount > 0)
            {
                var feeMetadata = new JObject
                {
                    ["externalPaymentId"] = externalPaymentId.Value.ToString(),
                    ["fundingSource"] = "credit_card",
                    ["surchargeAmount"] = surchargeAmount,
                    ["accountingNote"] = "Cash debit recorded in external_payment_ledger via Stripe"
                };

                // Write fee as revenue (credit to CC_PROC_FEE_REV account)
                // NOTE: The corresponding cash debit is recorded in external_payment_ledger
                // This maintains GAAP compliance by separating cash handling from revenue recognition
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    var ledgerTable = "ledger";
                    var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "offer_purchase_distribution", "transferable");
                    
                    // Platform fee revenue maps to 4100 - Transaction Fees Revenue (GAAP)
                    var platformFeeAccount = AccountingHelpers.ResolvePlatformFeeAccount();
                    
                    cmd.CommandText = $@"
                        INSERT INTO {ledgerTable} (
                            tx_id, referral_code, tx_type, posting_code, point_type, account_number,
                            amount, transaction_date, metadata, source_system, created_at, entry_type
                        ) VALUES (
                            @txId, @referralCode, @txType, @postingCode, @pointType, @accountNumber,
                            @amount, CURRENT_TIMESTAMP, @metadata::jsonb, @sourceSystem, CURRENT_TIMESTAMP, @entryType
                        )";
                    cmd.Parameters.AddWithValue("@txId", txId);
                    cmd.Parameters.AddWithValue("@referralCode", imagineBcReferral); // Platform receives fee
                    cmd.Parameters.AddWithValue("@txType", "offer_purchase_distribution");
                    cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                    cmd.Parameters.AddWithValue("@pointType", "transferable");
                    cmd.Parameters.AddWithValue("@accountNumber", platformFeeAccount);
                    cmd.Parameters.AddWithValue("@amount", surchargeAmount);
                    cmd.Parameters.AddWithValue("@metadata", feeMetadata.ToString());
                    cmd.Parameters.AddWithValue("@sourceSystem", "accounting_service");
                    cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                    cmd.ExecuteNonQuery();
                }
            }

            tx.Commit();

            // 6. Read back ledger rows with account numbers (GAAP compliance - every entry must have an account number)
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            // 7. Return result with account codes (GAAP compliance)
            var debitTotal = debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription;
            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "offer_purchase_distribution", "transferable");
            
            // Include system referral codes for frontend display name resolution
            // Note: imagineBcReferral and genesisPoolReferral are already defined above, reuse them
            var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);
            
            return new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    nonTransferable = debit.NonTransferable,
                    community = debit.Community,
                    special = debit.Special,
                    overflow = debit.Overflow,
                    subscription = debit.Subscription,
                    total = debitTotal,
                    accountCode = debitAccountCode
                }),
                ["credits"] = BuildCreditsArray(credits, externalPaymentId, surchargeAmount, conn, tx),
                ["ledger"] = ledgerRows,
                ["transactionType"] = "offer_purchase_distribution",
                ["mode"] = mode,
                ["txId"] = txId,
                ["systemReferrals"] = new JObject
                {
                    ["imaginebc"] = imagineBcReferral,
                    ["genesisPool"] = genesisPoolReferral,
                    ["donationPool"] = donationPoolReferral
                }
            };
        }

        // ============================================================
        // TRANSACTION TYPE 3: content_purchase_distribution
        // ============================================================
        private JObject ProcessContentPurchaseDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[ProcessContentPurchaseDistribution] Starting, mode={mode}");
            _debugTrace?.Write($"[ProcessContentPurchaseDistribution] Payload keys: {string.Join(", ", payload.Properties().Select(p => p.Name))}");
            
            var buyerReferral = payload.Value<string>("buyerReferral")
                ?? payload.Value<string>("memberReferral")
                ?? payload.Value<string>("member")
                ?? throw new InvalidOperationException("buyerReferral is required");
            
            _debugTrace?.Write($"[ProcessContentPurchaseDistribution] BuyerReferral={buyerReferral}");

            // Seller is always a channel for content_purchase_distribution
            var sellerReferral = payload.Value<string>("sellerReferral")
                ?? payload.Value<string>("channelReferral")
                ?? throw new InvalidOperationException("sellerReferral is required");

            var purchasePrice = payload.Value<decimal?>("purchasePrice")
                ?? throw new InvalidOperationException("purchasePrice is required");

            var contentId = payload.Value<long?>("contentId")
                ?? throw new InvalidOperationException("contentId is required");

            // Check if this is a resume (approval granted)
            var resumeToken = payload.Value<string>("resumeToken");
            var approved = payload.Value<bool?>("approved") ?? false;
            var fundingToken = payload.Value<string>("fundingToken");

            if (!string.IsNullOrWhiteSpace(resumeToken) && approved && !string.IsNullOrWhiteSpace(fundingToken))
            {
                // RESUME PATH: Execute after approval
                return ExecuteContentPurchaseResume(
                    resumeToken,
                    fundingToken,
                    buyerReferral,
                    sellerReferral,
                    purchasePrice,
                    contentId,
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    start);
            }

            // PREFLIGHT PATH: Calculate funding needs, create payment intent
            return ExecuteContentPurchasePreflight(
                buyerReferral,
                sellerReferral,
                purchasePrice,
                contentId,
                payload,
                metadata,
                mode,
                conn,
                tx);
        }

        private JObject ExecuteContentPurchasePreflight(
            string buyerReferral,
            string sellerReferral,
            decimal purchasePrice,
            long contentId,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // 1. Load buyer wallet snapshot (READ ONLY, NO MUTATION)
            var wallet = _balances.LoadWalletSnapshot(buyerReferral, mode, conn, tx);
            
            // 2. Resolve usable subscription amount
            decimal usableSubscriptionPoints = ResolveUsableSubscriptionPoints(
                wallet.SubscriptionDetailsJson,
                sellerReferral,
                contentId);

            _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] UsableSubscriptionPoints={usableSubscriptionPoints} for channel={sellerReferral}, contentId={contentId}");

            // 3. Calculate funding mix using LOCKED PRIORITY:
            // Subscription → Non-transferable → Community → Transferable → Overflow
            var debit = BalanceVector.ForSpend(buyerReferral);
            decimal remainingPrice = purchasePrice;
            decimal internalFundingTotal = 0m;

            // Priority 1: Subscription (conditional)
            if (usableSubscriptionPoints > 0 && remainingPrice > 0)
            {
                var subscriptionUsed = Math.Min(usableSubscriptionPoints, remainingPrice);
                debit.Subscription = subscriptionUsed;
                remainingPrice -= subscriptionUsed;
                internalFundingTotal += subscriptionUsed;
            }

            // Priority 2: Non-transferable
            if (remainingPrice > 0 && wallet.NonTransferable > 0)
            {
                var nonTransferableUsed = Math.Min(wallet.NonTransferable, remainingPrice);
                debit.NonTransferable = nonTransferableUsed;
                remainingPrice -= nonTransferableUsed;
                internalFundingTotal += nonTransferableUsed;
            }

            // Priority 3: Community
            if (remainingPrice > 0 && wallet.Community > 0)
            {
                var communityUsed = Math.Min(wallet.Community, remainingPrice);
                debit.Community = communityUsed;
                remainingPrice -= communityUsed;
                internalFundingTotal += communityUsed;
            }

            // Priority 4: Transferable
            if (remainingPrice > 0 && wallet.Transferable > 0)
            {
                var transferableUsed = Math.Min(wallet.Transferable, remainingPrice);
                debit.Transferable = transferableUsed;
                remainingPrice -= transferableUsed;
                internalFundingTotal += transferableUsed;
            }

            // Priority 5: Overflow
            if (remainingPrice > 0 && wallet.Overflow > 0)
            {
                var overflowUsed = Math.Min(wallet.Overflow, remainingPrice);
                debit.Overflow = overflowUsed;
                remainingPrice -= overflowUsed;
                internalFundingTotal += overflowUsed;
            }

            var shortfall = remainingPrice;

            _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] Buyer={buyerReferral}, Price={purchasePrice}, InternalFunding={internalFundingTotal}, Shortfall={shortfall}, Mode={mode}");

            // 4. If no shortfall, proceed directly to execution
            if (shortfall <= 0)
            {
                _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] No shortfall detected, executing immediately");
                // No external funding needed - execute immediately
                return ExecuteContentPurchaseDistribution(
                    buyerReferral,
                    sellerReferral,
                    purchasePrice,
                    contentId,
                    debit,
                    null, // no external payment
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    DateTime.UtcNow);
            }

            // 5. Validate country allows credit card charges (if shortfall requires credit card)
            var countryIso2 = payload.Value<string>("countryIso2");
            if (string.IsNullOrWhiteSpace(countryIso2))
            {
                _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] Missing countryIso2 in payload");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = "countryIso2 is required for credit card transactions"
                };
            }

            var countryAllowsCreditCard = CheckCountryAllowsCreditCard(conn, countryIso2);
            _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] Country={countryIso2}, AllowsCreditCard={countryAllowsCreditCard}");

            if (!countryAllowsCreditCard)
            {
                _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] Country {countryIso2} does not allow credit card charges");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Credit card transactions are not allowed for country {countryIso2}"
                };
            }

            // 6. Calculate surcharge and total charge
            _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] Shortfall detected: {shortfall}, creating payment intent");
            
            decimal surchargePercentage = GetCreditCardSurchargePercentage();
            var surcharge = Math.Round(shortfall * surchargePercentage, 2);
            var totalCharge = shortfall + surcharge;
            
            _debugTrace?.Write($"[CONTENT_PURCHASE_PREFLIGHT] Surcharge={surcharge}, TotalCharge={totalCharge}");

            // 7. Create payment intent
            var secureToken = Guid.NewGuid();
            var intentId = Guid.NewGuid();

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO transaction_payment_intents (
                        id, secure_token, transaction_type, member_referral,
                        gross_amount, transferable_used, external_required,
                        external_amount, surcharge_amount, funding_method,
                        status, payload_snapshot, metadata_snapshot, mode
                    ) VALUES (
                        @id, @secureToken, @transactionType, @memberReferral,
                        @grossAmount, @transferableUsed, @externalRequired,
                        @externalAmount, @surchargeAmount, @fundingMethod,
                        @status, @payloadSnapshot::jsonb, @metadataSnapshot::jsonb, @mode
                    )";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@secureToken", secureToken);
                cmd.Parameters.AddWithValue("@transactionType", "content_purchase_distribution");
                cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                cmd.Parameters.AddWithValue("@grossAmount", purchasePrice);
                
                // Calculate total internal points used (all buckets)
                var totalInternalUsed = debit.Subscription + debit.NonTransferable + debit.Community + debit.Transferable + debit.Overflow;
                cmd.Parameters.AddWithValue("@transferableUsed", totalInternalUsed);
                cmd.Parameters.AddWithValue("@externalRequired", true);
                cmd.Parameters.AddWithValue("@externalAmount", shortfall);
                cmd.Parameters.AddWithValue("@surchargeAmount", surcharge);
                cmd.Parameters.AddWithValue("@fundingMethod", "credit_card");
                cmd.Parameters.AddWithValue("@status", "pending_approval");
                cmd.Parameters.AddWithValue("@payloadSnapshot", payload.ToString());
                cmd.Parameters.AddWithValue("@metadataSnapshot", metadata.ToString());
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();

            // 8. Get exchange rate and currency info for non-US countries
            string? memberCurrencyCode = null;
            decimal? memberExchangeRate = null;
            decimal? memberConvertedAmount = null;

            if (!string.IsNullOrWhiteSpace(countryIso2) && countryIso2.ToUpper() != "US" && _countriesService != null)
            {
                // Get exchange rate from cache (no database reads)
                memberExchangeRate = _countriesService.GetExchangeRateUsdToCountry(countryIso2);
                
                // Get currency code from cached countries
                var countries = _countriesService.GetAllCountriesForManagement();
                var country = countries.FirstOrDefault(c => 
                    (c.ContainsKey("iso2") ? c["iso2"]?.ToString() : null)?.ToUpper() == countryIso2.ToUpper());
                
                if (country != null)
                {
                    memberCurrencyCode = country.ContainsKey("currencyCode") ? country["currencyCode"]?.ToString() : null;
                    
                    // Calculate converted amount if we have exchange rate
                    if (memberExchangeRate.HasValue && memberExchangeRate.Value > 0)
                    {
                        memberConvertedAmount = Math.Round(totalCharge * memberExchangeRate.Value, 2);
                    }
                }
            }

            // 9. Return approval required response
            var response = new JObject
            {
                ["ok"] = false,
                ["requiresApproval"] = true,
                ["approvalType"] = "credit_card",
                ["transactionType"] = "content_purchase_distribution",
                ["subscriptionUsed"] = debit.Subscription,
                ["nonTransferableUsed"] = debit.NonTransferable,
                ["communityUsed"] = debit.Community,
                ["transferableUsed"] = debit.Transferable,
                ["overflowUsed"] = debit.Overflow,
                ["externalRequired"] = shortfall,
                ["surcharge"] = surcharge,
                ["totalCharge"] = totalCharge,
                ["resumeToken"] = secureToken.ToString()
            };

            // Add country and currency info if available
            if (!string.IsNullOrWhiteSpace(countryIso2))
            {
                response["countryIso2"] = countryIso2;
            }
            if (!string.IsNullOrWhiteSpace(memberCurrencyCode))
            {
                response["currencyCode"] = memberCurrencyCode;
            }
            if (memberExchangeRate.HasValue)
            {
                response["exchangeRate"] = memberExchangeRate.Value;
            }
            if (memberConvertedAmount.HasValue)
            {
                response["convertedAmount"] = memberConvertedAmount.Value;
            }

            return response;
        }

        private JObject ExecuteContentPurchaseResume(
            string resumeToken,
            string fundingToken,
            string buyerReferral,
            string sellerReferral,
            decimal purchasePrice,
            long contentId,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            // 1. Resolve intent
            Guid intentGuid;
            if (!Guid.TryParse(resumeToken, out intentGuid))
                return new JObject { ["ok"] = false, ["error"] = "Invalid resumeToken" };

            Guid intentId;
            decimal totalInternalUsed;
            decimal externalAmount;
            decimal surchargeAmount;

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    SELECT id, transferable_used, external_amount, surcharge_amount, status
                    FROM transaction_payment_intents
                    WHERE secure_token = @secureToken
                      AND transaction_type = 'content_purchase_distribution'
                      AND status = 'pending_approval'
                ";
                cmd.Parameters.AddWithValue("@secureToken", intentGuid);

                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return new JObject { ["ok"] = false, ["error"] = "Payment intent not found or already processed" };

                intentId = reader.GetGuid(0);
                totalInternalUsed = reader.GetDecimal(1);
                externalAmount = reader.GetDecimal(2);
                surchargeAmount = reader.GetDecimal(3);
                var status = reader.GetString(4);

                if (status != "pending_approval")
                    return new JObject { ["ok"] = false, ["error"] = $"Payment intent status is {status}, expected pending_approval" };
            }

            // 2. Execute Stripe charge (via ExternalPaymentService)
            string? providerChargeId = null;
            decimal processingFee = 0m;
            decimal netFunded = 0m;

            var totalChargeToCustomer = externalAmount + surchargeAmount;

            if (_externalPayment != null && totalChargeToCustomer > 0)
            {
                var amountCents = (int)Math.Round(totalChargeToCustomer * 100);
                var (success, chargeId, gross, fee, net, error) = _externalPayment.CreateAndCapturePayment(
                    buyerReferral,
                    amountCents,
                    fundingToken
                ).GetAwaiter().GetResult();

                if (!success)
                    return new JObject { ["ok"] = false, ["error"] = error ?? "Payment failed" };

                providerChargeId = chargeId;
                processingFee = fee;
                netFunded = externalAmount; // Fund the full shortfall amount
            }
            else
            {
                // Mock for testing when ExternalPaymentService not available
                providerChargeId = $"ch_mock_{Guid.NewGuid():N}";
                processingFee = Math.Round(totalChargeToCustomer * 0.029m + 0.30m, 2);
                netFunded = externalAmount;
            }

            // 3. Persist external payment ledger
            Guid externalPaymentId = Guid.NewGuid();
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO external_payment_ledger (
                        id, intent_id, member_referral, provider,
                        provider_charge_id, gross_charge_amount,
                        processing_fee_amount, net_funded_amount,
                        currency, transaction_type, status, mode, metadata
                    ) VALUES (
                        @id, @intentId, @memberReferral, @provider,
                        @providerChargeId, @grossChargeAmount,
                        @processingFeeAmount, @netFundedAmount,
                        @currency, @transactionType, @status, @mode, @metadata::jsonb
                    )";
                cmd.Parameters.AddWithValue("@id", externalPaymentId);
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                cmd.Parameters.AddWithValue("@provider", "stripe");
                cmd.Parameters.AddWithValue("@providerChargeId", providerChargeId ?? "");
                cmd.Parameters.AddWithValue("@grossChargeAmount", totalChargeToCustomer);
                cmd.Parameters.AddWithValue("@processingFeeAmount", processingFee);
                cmd.Parameters.AddWithValue("@netFundedAmount", netFunded);
                cmd.Parameters.AddWithValue("@currency", "USD");
                cmd.Parameters.AddWithValue("@transactionType", "content_purchase_distribution");
                cmd.Parameters.AddWithValue("@status", "captured");
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.Parameters.AddWithValue("@metadata", metadata.ToString());
                cmd.ExecuteNonQuery();
            }

            // 4. Update payment intent status
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    UPDATE transaction_payment_intents
                    SET status = 'approved',
                        funding_token = @fundingToken,
                        consumed_at = CURRENT_TIMESTAMP
                    WHERE id = @id
                ";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@fundingToken", fundingToken);
                cmd.ExecuteNonQuery();
            }

            // 5. Reconstruct debit vector from payment intent (we need to reload wallet to get subscription details)
            var wallet = _balances.LoadWalletSnapshot(buyerReferral, mode, conn, tx);
            var usableSubscriptionPoints = ResolveUsableSubscriptionPoints(
                wallet.SubscriptionDetailsJson,
                sellerReferral,
                contentId);

            var debit = BalanceVector.ForSpend(buyerReferral);
            decimal remainingPrice = purchasePrice;

            // Reconstruct debit using same priority order
            if (usableSubscriptionPoints > 0 && remainingPrice > 0)
            {
                var subscriptionUsed = Math.Min(usableSubscriptionPoints, remainingPrice);
                debit.Subscription = subscriptionUsed;
                remainingPrice -= subscriptionUsed;
            }
            if (remainingPrice > 0 && wallet.NonTransferable > 0)
            {
                var nonTransferableUsed = Math.Min(wallet.NonTransferable, remainingPrice);
                debit.NonTransferable = nonTransferableUsed;
                remainingPrice -= nonTransferableUsed;
            }
            if (remainingPrice > 0 && wallet.Community > 0)
            {
                var communityUsed = Math.Min(wallet.Community, remainingPrice);
                debit.Community = communityUsed;
                remainingPrice -= communityUsed;
            }
            if (remainingPrice > 0 && wallet.Transferable > 0)
            {
                var transferableUsed = Math.Min(wallet.Transferable, remainingPrice);
                debit.Transferable = transferableUsed;
                remainingPrice -= transferableUsed;
            }
            if (remainingPrice > 0 && wallet.Overflow > 0)
            {
                var overflowUsed = Math.Min(wallet.Overflow, remainingPrice);
                debit.Overflow = overflowUsed;
                remainingPrice -= overflowUsed;
            }

            // Add external funding
            debit.Transferable += netFunded;

            // 6. Execute the distribution
            return ExecuteContentPurchaseDistribution(
                buyerReferral,
                sellerReferral,
                purchasePrice,
                contentId,
                debit,
                externalPaymentId,
                payload,
                metadata,
                mode,
                conn,
                tx,
                start);
        }

        private JObject ExecuteContentPurchaseDistribution(
            string buyerReferral,
            string sellerReferral,
            decimal purchasePrice,
            long contentId,
            BalanceVector debit,
            Guid? externalPaymentId,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // 1. Update subscription details if subscription points were used
            if (debit.Subscription > 0)
            {
                UpdateSubscriptionDetailsAfterPurchase(
                    buyerReferral,
                    sellerReferral,
                    contentId,
                    debit.Subscription,
                    mode,
                    conn,
                    tx);
            }

            // 2. Smart contract distribution
            var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
            var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
            var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);
            var buyerReferrer = ResolveMemberReferrer(buyerReferral, conn, tx, mode);
            var sellerReferrer = ResolveChannelReferrer(sellerReferral, conn, tx, mode);

            var creditVectors = _distribution.Distribute(
                "content_purchase_distribution",
                debit,
                sellerReferral,
                imagineBcReferral,
                genesisPoolReferral,
                donationPoolReferral,
                buyerReferrer,
                sellerReferrer).ToList();

            // 3. Apply voluntary donation split (Transaction Type 8) if enabled
            creditVectors = ApplyVoluntaryDonationSplit(
                creditVectors,
                sellerReferral,
                payload,
                metadata,
                conn,
                tx);

            // 4. Apply vectors
            _balances.ApplyVectors(
                debit,
                creditVectors,
                "content_purchase_distribution",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 5. Write ledger entries
            WriteLedger(
                txId,
                "content_purchase_distribution",
                debit,
                creditVectors,
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 6. Insert into memberpurchases (SUCCESS ONLY)
            var currency = payload.Value<string>("currency") ?? "USD";
            InsertMemberPurchase(
                buyerReferral,
                sellerReferral,
                contentId,
                purchasePrice,
                currency,
                externalPaymentId?.ToString(),
                mode,
                conn,
                tx);

            // 6. Write CC processing fee to ledger (if external payment exists)
            decimal surchargeAmount = 0m;
            if (externalPaymentId.HasValue)
            {
                // Get surcharge from payment intent
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        SELECT surcharge_amount
                        FROM transaction_payment_intents
                        WHERE id = (SELECT intent_id FROM external_payment_ledger WHERE id = @externalPaymentId)
                    ";
                    cmd.Parameters.AddWithValue("@externalPaymentId", externalPaymentId.Value);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        surchargeAmount = Convert.ToDecimal(result);
                    }
                }

                if (surchargeAmount > 0)
                {
                    var feeMetadata = new JObject
                    {
                        ["externalPaymentId"] = externalPaymentId.Value.ToString(),
                        ["fundingSource"] = "credit_card",
                        ["surchargeAmount"] = surchargeAmount,
                        ["accountingNote"] = "Cash debit recorded in external_payment_ledger via Stripe"
                    };

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        var ledgerTable = "ledger";
                        var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "content_purchase_distribution", "transferable");
                        
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (
                                tx_id, referral_code, tx_type, posting_code, point_type, account_code,
                                amount, transaction_date, metadata, source_system, created_at, entry_type
                            ) VALUES (
                                @txId, @referralCode, @txType, @postingCode, @pointType, @accountCode,
                                @amount, CURRENT_TIMESTAMP, @metadata::jsonb, @sourceSystem, CURRENT_TIMESTAMP, @entryType
                            )";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referralCode", imagineBcReferral);
                        cmd.Parameters.AddWithValue("@txType", "content_purchase_distribution");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "transferable");
                        cmd.Parameters.AddWithValue("@accountCode", "CC_PROC_FEE_REV");
                        cmd.Parameters.AddWithValue("@amount", surchargeAmount);
                        cmd.Parameters.AddWithValue("@metadata", feeMetadata.ToString());
                        cmd.Parameters.AddWithValue("@sourceSystem", "accounting_service");
                        cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                        cmd.ExecuteNonQuery();
                    }
                }
            }

            tx.Commit();

            // 7. Read back ledger rows
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            // Emit gamification event for content purchase (fire and forget)
            if (!string.IsNullOrWhiteSpace(buyerReferral))
            {
                _ = Task.Run(async () =>
                {
                    try
                    {
                        var gamificationService = new GamificationService(_connectionString, null, null);
                        await gamificationService.ProcessEventAsync("CONTENT_PURCHASED", buyerReferral);
                    }
                    catch { /* Gamification should never block purchase flow */ }
                });
            }

            // 8. Return result
            var debitTotal = debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription;
            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "content_purchase_distribution", "transferable");
            
            var creditsArray = new JArray(creditVectors.Select(c => 
            {
                var creditTotal = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription;
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "content_purchase_distribution", "transferable");
                return JObject.FromObject(new
                {
                    owner = c.Owner,
                    transferable = c.Transferable,
                    nonTransferable = c.NonTransferable,
                    community = c.Community,
                    special = c.Special,
                    overflow = c.Overflow,
                    subscription = c.Subscription,
                    total = creditTotal,
                    accountCode = accountCode
                });
            }));
            
            return new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    nonTransferable = debit.NonTransferable,
                    community = debit.Community,
                    special = debit.Special,
                    overflow = debit.Overflow,
                    subscription = debit.Subscription,
                    total = debitTotal,
                    accountCode = debitAccountCode
                }),
                ["credits"] = creditsArray,
                ["ledger"] = ledgerRows,
                ["transactionType"] = "content_purchase_distribution",
                ["mode"] = mode,
                ["txId"] = txId,
                ["systemReferrals"] = new JObject
                {
                    ["imaginebc"] = imagineBcReferral,
                    ["genesisPool"] = genesisPoolReferral,
                    ["donationPool"] = donationPoolReferral
                }
            };
        }

        // ============================================================
        // TRANSACTION TYPE 8: member_voluntary_donation
        // Helper: Apply voluntary donation split to credit vectors
        // ============================================================
        /// <summary>
        /// Applies voluntary donation split to seller's transferable earnings.
        /// This is NOT a standalone transaction - it modifies credit vectors atomically within the source transaction.
        /// </summary>
        /// <param name="creditVectors">Credit vectors from smart contract distribution</param>
        /// <param name="sellerReferral">The seller's referral code (who earned the transferable points)</param>
        /// <param name="payload">Transaction payload (may contain voluntaryDonation)</param>
        /// <param name="metadata">Transaction metadata (will be updated with donation info)</param>
        /// <param name="conn">Database connection</param>
        /// <param name="tx">Database transaction</param>
        /// <returns>Modified credit vectors list with donation split applied</returns>
        private List<BalanceVector> ApplyVoluntaryDonationSplit(
            List<BalanceVector> creditVectors,
            string sellerReferral,
            JObject payload,
            JObject metadata,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // Check if voluntary donation is enabled in payload
            var voluntaryDonation = payload["voluntaryDonation"] as JObject;
            if (voluntaryDonation == null)
                return creditVectors; // No donation configured, return unchanged

            var enabled = voluntaryDonation.Value<bool?>("enabled") ?? false;
            if (!enabled)
                return creditVectors; // Donation disabled, return unchanged

            var donationAmount = voluntaryDonation.Value<decimal?>("donationAmount");
            var recipientChannelReferral = voluntaryDonation.Value<string>("recipientChannelReferral");

            // Validate required fields
            if (!donationAmount.HasValue || donationAmount.Value <= 0)
            {
                _debugTrace?.Write($"[VOLUNTARY_DONATION] Invalid donationAmount: {donationAmount}");
                throw new InvalidOperationException("voluntaryDonation.donationAmount must be a positive number");
            }

            if (string.IsNullOrWhiteSpace(recipientChannelReferral))
            {
                _debugTrace?.Write($"[VOLUNTARY_DONATION] Missing recipientChannelReferral");
                throw new InvalidOperationException("voluntaryDonation.recipientChannelReferral is required");
            }

            // Validate recipient channel exists
            var channelTable = "channel";
            bool channelExists = false;
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = $@"
                    SELECT COUNT(1)
                    FROM {channelTable}
                    WHERE assignedreferral = @channelReferral
                ";
                cmd.Parameters.AddWithValue("@channelReferral", recipientChannelReferral);
                var result = cmd.ExecuteScalar();
                channelExists = result != null && result != DBNull.Value && Convert.ToInt32(result) > 0;
            }

            if (!channelExists)
            {
                _debugTrace?.Write($"[VOLUNTARY_DONATION] Recipient channel {recipientChannelReferral} not found");
                throw new InvalidOperationException($"Recipient channel {recipientChannelReferral} not found");
            }

            // Find seller's credit vector
            var sellerVector = creditVectors.FirstOrDefault(cv => cv.Owner == sellerReferral);
            if (sellerVector == null)
            {
                _debugTrace?.Write($"[VOLUNTARY_DONATION] Seller {sellerReferral} not found in credit vectors");
                throw new InvalidOperationException($"Seller {sellerReferral} not found in credit vectors");
            }

            // Validate donation amount doesn't exceed seller's transferable earnings
            if (donationAmount.Value > sellerVector.Transferable)
            {
                _debugTrace?.Write($"[VOLUNTARY_DONATION] Donation amount {donationAmount.Value} exceeds seller transferable {sellerVector.Transferable}");
                throw new InvalidOperationException($"Donation amount {donationAmount.Value} exceeds seller transferable earnings {sellerVector.Transferable}");
            }

            // Apply split: reduce seller's transferable, create credit for nonprofit channel
            var donationAmountValue = donationAmount.Value;
            sellerVector.Transferable -= donationAmountValue;

            // Find or create nonprofit channel credit vector
            var nonprofitVector = creditVectors.FirstOrDefault(cv => cv.Owner == recipientChannelReferral);
            if (nonprofitVector == null)
            {
                // Create new credit vector for nonprofit channel
                nonprofitVector = BalanceVector.Credit(recipientChannelReferral);
                nonprofitVector.Transferable = donationAmountValue;
                creditVectors.Add(nonprofitVector);
            }
            else
            {
                // Add to existing nonprofit channel credit vector
                nonprofitVector.Transferable += donationAmountValue;
            }

            // Add voluntary donation metadata
            var donationPercentage = voluntaryDonation.Value<decimal?>("donationPercentage");
            var donationMetadata = new JObject
            {
                ["voluntaryDonation"] = new JObject
                {
                    ["enabled"] = true,
                    ["percentage"] = donationPercentage ?? 0m,
                    ["donationAmount"] = donationAmountValue,
                    ["donationSource"] = "seller_transferable",
                    ["recipientChannel"] = recipientChannelReferral,
                    ["authorization"] = "preconfigured"
                }
            };
            metadata.Merge(donationMetadata);

            _debugTrace?.Write($"[VOLUNTARY_DONATION] Applied split: Seller {sellerReferral} transferable reduced by {donationAmountValue}, Nonprofit {recipientChannelReferral} credited {donationAmountValue}");

            return creditVectors;
        }

        // Helper: Resolve usable subscription points for a channel-level subscription (contentId = NULL)
        private decimal ResolveUsableChannelSubscriptionPoints(string subscriptionDetailsJson, string channelReferral)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(subscriptionDetailsJson) || subscriptionDetailsJson == "{}")
                    return 0m;

                // Parse as array (channel subscriptions are stored as array)
                var details = JArray.Parse(subscriptionDetailsJson);
                
                // Find the subscription entry for this channel
                foreach (var item in details)
                {
                    if (item is JObject subObj)
                    {
                        var subChannelReferral = subObj["channelReferral"]?.ToString();
                        if (subChannelReferral == channelReferral)
                        {
                            var balance = subObj["balance"]?.Value<decimal?>();
                            return balance.HasValue && balance.Value > 0 ? balance.Value : 0m;
                        }
                    }
                }

                return 0m;
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[ResolveUsableChannelSubscriptionPoints] Error parsing subscriptionDetails: {ex.Message}");
                // If parsing as array fails, try as object (backward compatibility)
                try
                {
                    var details = JObject.Parse(subscriptionDetailsJson);
                    var channel = details[channelReferral];
                    if (channel != null)
                    {
                        // Check for null key (channel-level subscription)
                        var nullContent = channel["null"] as JObject;
                        if (nullContent != null)
                        {
                            var balance = nullContent["balance"]?.Value<decimal?>();
                            return balance.HasValue && balance.Value > 0 ? balance.Value : 0m;
                        }
                    }
                }
                catch
                {
                    // Ignore second parse attempt
                }
                return 0m;
            }
        }

        // Helper: Resolve usable subscription points for a specific channel/content
        private decimal ResolveUsableSubscriptionPoints(string subscriptionDetailsJson, string channelReferral, long contentId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(subscriptionDetailsJson) || subscriptionDetailsJson == "{}")
                    return 0m;

                var details = JObject.Parse(subscriptionDetailsJson);
                var channel = details[channelReferral];
                if (channel == null)
                    return 0m;

                var content = channel[contentId.ToString()];
                if (content == null)
                    return 0m;

                var pointValue = content["pointValue"];
                if (pointValue == null)
                    return 0m;

                var value = pointValue.Value<decimal?>();
                return value.HasValue && value.Value > 0 ? value.Value : 0m;
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[ResolveUsableSubscriptionPoints] Error parsing subscriptionDetails: {ex.Message}");
                return 0m;
            }
        }

        // Helper: Update subscription details after purchase (decrement pointValue and recalculate subscription balance)
        private void UpdateSubscriptionDetailsAfterPurchase(
            string buyerReferral,
            string sellerReferral,
            long contentId,
            decimal subscriptionUsed,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            try
            {
                var tableName = "memberwalletbalances";

                // Load current subscription details
                string currentDetailsJson;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        SELECT subscription_details
                        FROM {tableName}
                        WHERE referral_code = @referral
                        FOR UPDATE
                    ";
                    cmd.Parameters.AddWithValue("@referral", buyerReferral);
                    var result = cmd.ExecuteScalar();
                    currentDetailsJson = result?.ToString() ?? "{}";
                }

                // Parse and update
                var details = string.IsNullOrWhiteSpace(currentDetailsJson) || currentDetailsJson == "{}"
                    ? new JObject()
                    : JObject.Parse(currentDetailsJson);

                var channel = details[sellerReferral] as JObject;
                if (channel == null)
                {
                    channel = new JObject();
                    details[sellerReferral] = channel;
                }

                var contentIdStr = contentId.ToString();
                var content = channel[contentIdStr] as JObject;
                if (content == null)
                {
                    content = new JObject();
                    channel[contentIdStr] = content;
                }

                var currentPointValue = content["pointValue"]?.Value<decimal?>() ?? 0m;
                var newPointValue = Math.Max(0m, currentPointValue - subscriptionUsed);
                content["pointValue"] = newPointValue;

                // Recalculate total subscription balance (sum of all pointValues)
                decimal totalSubscription = 0m;
                foreach (var ch in details.Properties())
                {
                    if (ch.Value is JObject channelObj)
                    {
                        foreach (var cont in channelObj.Properties())
                        {
                            if (cont.Value is JObject contentObj)
                            {
                                var pv = contentObj["pointValue"]?.Value<decimal?>() ?? 0m;
                                totalSubscription += pv;
                            }
                        }
                    }
                }

                // Update database
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        UPDATE {tableName}
                        SET subscription = @subscription,
                            subscription_details = @subscriptionDetails::jsonb,
                            totalpoints = transferable + nontransferable + community + special + overflow + @subscription,
                            last_updated = NOW()
                        WHERE referral_code = @referral
                    ";
                    cmd.Parameters.AddWithValue("@referral", buyerReferral);
                    cmd.Parameters.AddWithValue("@subscription", totalSubscription);
                    cmd.Parameters.AddWithValue("@subscriptionDetails", details.ToString());
                    cmd.ExecuteNonQuery();
                }

                _debugTrace?.Write($"[UpdateSubscriptionDetailsAfterPurchase] Updated subscription balance to {totalSubscription} for {buyerReferral}");
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[UpdateSubscriptionDetailsAfterPurchase] Error: {ex.Message}");
                throw;
            }
        }

        // ============================================================
        // TRANSACTION TYPE 4: comment_payment_distribution
        // ============================================================
        private JObject ProcessCommentPaymentDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[ProcessCommentPaymentDistribution] Starting, mode={mode}");
            _debugTrace?.Write($"[ProcessCommentPaymentDistribution] Payload keys: {string.Join(", ", payload.Properties().Select(p => p.Name))}");
            
            // 1. Validate payload (HARD REQUIREMENTS)
            var buyerReferral = payload.Value<string>("memberReferral")
                ?? payload.Value<string>("buyerReferral")
                ?? throw new InvalidOperationException("memberReferral is required");

            var commentId = payload.Value<string>("commentId")
                ?? throw new InvalidOperationException("commentId is required");

            var amount = payload.Value<decimal?>("amount")
                ?? 0.10m; // Default to 0.10 for tests

            if (amount <= 0)
                throw new InvalidOperationException("amount must be greater than zero");

            // Seller is provided in payload (can be member or channel)
            var sellerReferral = payload.Value<string>("sellerReferral")
                ?? throw new InvalidOperationException("sellerReferral is required");

            var sellerType = payload.Value<string>("sellerType") ?? "member"; // member or channel

            _debugTrace?.Write($"[ProcessCommentPaymentDistribution] Buyer={buyerReferral}, Seller={sellerReferral} ({sellerType}), CommentId={commentId}, Amount={amount}");

            // 2. Load buyer wallet snapshot (only community, transferable, overflow)
            var wallet = _balances.LoadWalletSnapshot(buyerReferral, mode, conn, tx);

            // 3. Calculate debit vector using LOCKED PRIORITY: Community → Transferable → Overflow
            var debit = BalanceVector.ForSpend(buyerReferral);
            decimal remainingAmount = amount;

            // Priority 1: Community
            if (remainingAmount > 0 && wallet.Community > 0)
            {
                var communityUsed = Math.Min(wallet.Community, remainingAmount);
                debit.Community = communityUsed;
                remainingAmount -= communityUsed;
            }

            // Priority 2: Transferable
            if (remainingAmount > 0 && wallet.Transferable > 0)
            {
                var transferableUsed = Math.Min(wallet.Transferable, remainingAmount);
                debit.Transferable = transferableUsed;
                remainingAmount -= transferableUsed;
            }

            // Priority 3: Overflow
            if (remainingAmount > 0 && wallet.Overflow > 0)
            {
                var overflowUsed = Math.Min(wallet.Overflow, remainingAmount);
                debit.Overflow = overflowUsed;
                remainingAmount -= overflowUsed;
            }

            // 4. If insufficient points, reject transaction
            if (remainingAmount > 0)
            {
                _debugTrace?.Write($"[ProcessCommentPaymentDistribution] Insufficient points. Remaining: {remainingAmount}");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Insufficient points. Required: {amount}, Available: {amount - remainingAmount}, Shortfall: {remainingAmount}"
                };
            }

            // 5. Standard smart contract distribution
            var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
            var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
            var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);
            var buyerReferrer = ResolveMemberReferrer(buyerReferral, conn, tx, mode);
            var sellerReferrer = sellerType == "member" 
                ? ResolveMemberReferrer(sellerReferral, conn, tx, mode)
                : ResolveChannelReferrer(sellerReferral, conn, tx, mode);

            var creditVectors = _distribution.Distribute(
                "comment_payment_distribution",
                debit,
                sellerReferral,
                imagineBcReferral,
                genesisPoolReferral,
                donationPoolReferral,
                buyerReferrer,
                sellerReferrer).ToList();

            // 6. Apply voluntary donation split (Transaction Type 8) if enabled
            creditVectors = ApplyVoluntaryDonationSplit(
                creditVectors,
                sellerReferral,
                payload,
                metadata,
                conn,
                tx);

            // 7. Apply vectors
            _balances.ApplyVectors(
                debit,
                creditVectors,
                "comment_payment_distribution",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 7. Write ledger entries
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // Add comment-specific metadata to ledger
            var ledgerMetadata = new JObject
            {
                ["commentId"] = commentId,
                ["sellerReferral"] = sellerReferral,
                ["sellerType"] = sellerType,
                ["buyerReferral"] = buyerReferral
            };
            metadata.Merge(ledgerMetadata);

            WriteLedger(
                txId,
                "comment_payment_distribution",
                debit,
                creditVectors,
                payload,
                metadata,
                mode,
                conn,
                tx);

            tx.Commit();

            // 9. Read back ledger rows
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            // 9. Return result
            var debitTotal = debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription;
            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "comment_payment_distribution", "transferable");
            
            var creditsArray = new JArray(creditVectors.Select(c => 
            {
                var creditTotal = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription;
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "comment_payment_distribution", "transferable");
                return JObject.FromObject(new
                {
                    owner = c.Owner,
                    transferable = c.Transferable,
                    nonTransferable = c.NonTransferable,
                    community = c.Community,
                    special = c.Special,
                    overflow = c.Overflow,
                    subscription = c.Subscription,
                    total = creditTotal,
                    accountCode = accountCode
                });
            }));
            
            return new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    nonTransferable = debit.NonTransferable,
                    community = debit.Community,
                    special = debit.Special,
                    overflow = debit.Overflow,
                    subscription = debit.Subscription,
                    total = debitTotal,
                    accountCode = debitAccountCode
                }),
                ["credits"] = creditsArray,
                ["ledger"] = ledgerRows,
                ["transactionType"] = "comment_payment_distribution",
                ["mode"] = mode,
                ["txId"] = txId,
                ["systemReferrals"] = new JObject
                {
                    ["imaginebc"] = imagineBcReferral,
                    ["genesisPool"] = genesisPoolReferral,
                    ["donationPool"] = donationPoolReferral
                }
            };
        }

        // ============================================================
        // TRANSACTION TYPE 11: member_to_member_transfer
        // ============================================================
        private JObject ProcessMemberToMemberTransfer(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            mode = mode?.ToLower() == "production" ? "production" : "test";
            
            _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Starting, mode={mode}");
            
            // 1. Extract payload fields
            var fromMember = payload.Value<string>("fromMember")
                ?? throw new InvalidOperationException("fromMember is required");
            
            var toMember = payload.Value<string>("toMember")
                ?? throw new InvalidOperationException("toMember is required");
            
            if (fromMember == toMember)
                throw new InvalidOperationException("fromMember and toMember must be different");
            
            // 2. Extract balances object
            var balancesObj = payload["balances"] as JObject;
            if (balancesObj == null || !balancesObj.Properties().Any())
                throw new InvalidOperationException("balances object is required with at least one balance type");
            
            decimal transferableAmount = 0m;
            decimal communityAmount = 0m;
            
            foreach (var prop in balancesObj.Properties())
            {
                var amount = prop.Value.Value<decimal>();
                if (amount <= 0m) continue;
                
                switch (prop.Name.ToLower())
                {
                    case "transferable":
                        transferableAmount = amount;
                        break;
                    case "community":
                        communityAmount = amount;
                        break;
                    default:
                        throw new InvalidOperationException($"Unsupported balance type for member_to_member_transfer: {prop.Name}. Only 'transferable' and 'community' are allowed.");
                }
            }
            
            if (transferableAmount == 0m && communityAmount == 0m)
                throw new InvalidOperationException("At least one balance amount (transferable or community) must be greater than 0");
            
            _debugTrace?.Write($"[ProcessMemberToMemberTransfer] From={fromMember}, To={toMember}, Transferable={transferableAmount}, Community={communityAmount}");
            
            // 3. Validate balances in PRODUCTION mode only (skip validation for system accounts)
            if (mode == "production")
            {
                // Check if fromMember is a system account (system accounts have unlimited points for rewards)
                bool isSystemAccount = false;
                try
                {
                    var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
                    var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
                    var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);
                    
                    isSystemAccount = fromMember.Equals(imagineBcReferral, StringComparison.OrdinalIgnoreCase) ||
                                     fromMember.Equals(genesisPoolReferral, StringComparison.OrdinalIgnoreCase) ||
                                     fromMember.Equals(donationPoolReferral, StringComparison.OrdinalIgnoreCase);
                }
                catch
                {
                    // If we can't resolve system referrals, assume it's not a system account and validate normally
                    isSystemAccount = false;
                }
                
                if (!isSystemAccount)
                {
                    var fromMemberSnapshot = _balances.LoadWalletSnapshot(fromMember, mode, conn, tx);
                    
                    if (transferableAmount > 0m && fromMemberSnapshot.Transferable < transferableAmount)
                    {
                        _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Insufficient transferable balance: required={transferableAmount}, available={fromMemberSnapshot.Transferable}");
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = "insufficient_transferable_balance",
                            ["required"] = transferableAmount,
                            ["available"] = fromMemberSnapshot.Transferable
                        };
                    }
                    
                    if (communityAmount > 0m && fromMemberSnapshot.Community < communityAmount)
                    {
                        _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Insufficient community balance: required={communityAmount}, available={fromMemberSnapshot.Community}");
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = "insufficient_community_balance",
                            ["required"] = communityAmount,
                            ["available"] = fromMemberSnapshot.Community
                        };
                    }
                }
                else
                {
                    _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Skipping balance validation for system account: {fromMember}");
                }
            }
            
            // 4. Generate transaction ID
            var txId = metadata?.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            if (metadata == null)
                metadata = new JObject();
            metadata["txId"] = txId;
            
            // Extract transaction description from payload and add to metadata
            var txDescription = payload.Value<string>("txDescription");
            if (!string.IsNullOrWhiteSpace(txDescription))
            {
                metadata["txDescription"] = txDescription;
            }
            
            // 5. Build debit vector (fromMember/Buyer - amounts are removed)
            var debit = BalanceVector.ForSpend(fromMember);
            debit.Transferable = transferableAmount;
            debit.Community = communityAmount;
            
            // 6. Build credit vector (toMember/Seller - same amounts are added)
            var credit = BalanceVector.Credit(toMember);
            credit.Transferable = transferableAmount;
            credit.Community = communityAmount;
            
            _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Debit: Owner={debit.Owner}, T={debit.Transferable}, C={debit.Community}");
            _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Credit: Owner={credit.Owner}, T={credit.Transferable}, C={credit.Community}");
            
            // 7. Apply balance changes
            _balances.ApplyVectors(
                debit,
                new List<BalanceVector> { credit },
                "member_to_member_transfer",
                payload,
                metadata,
                mode,
                conn,
                tx);
            
            // 8. Write to ledger
            WriteLedger(
                txId,
                "member_to_member_transfer",
                debit,
                new List<BalanceVector> { credit },
                payload,
                metadata,
                mode,
                conn,
                tx);
            
            tx.Commit();
            
            _debugTrace?.Write("[ProcessMemberToMemberTransfer] Transaction committed");
            
            // 9. Read back ledger entries
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);
                
                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }
            
            // 10. Return result
            var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "member_to_member_transfer", "transferable");
            
            var result = new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["txId"] = txId,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    community = debit.Community,
                    total = debit.Transferable + debit.Community,
                    accountCode = accountCode
                }),
                ["credit"] = JObject.FromObject(new
                {
                    owner = credit.Owner,
                    transferable = credit.Transferable,
                    community = credit.Community,
                    total = credit.Transferable + credit.Community,
                    accountCode = accountCode
                }),
                ["ledger"] = ledgerRows
            };
            
            _debugTrace?.Write($"[ProcessMemberToMemberTransfer] Result: {result.ToString(Newtonsoft.Json.Formatting.None)}");
            
            return result;
        }

        // ============================================================
        // TRANSACTION TYPE 19: campaign_balance_credit
        // ============================================================
        private JObject ProcessCampaignBalanceCredit(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            mode = mode?.ToLower() == "production" ? "production" : "test";
            
            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Starting, mode={mode}");
            
            // 1. Extract payload fields
            var campaignIdStr = payload.Value<string>("campaignId");
            var campaignReferral = payload.Value<string>("campaignReferral");
            
            if (string.IsNullOrWhiteSpace(campaignIdStr) && string.IsNullOrWhiteSpace(campaignReferral))
                throw new InvalidOperationException("campaignId or campaignReferral is required");
            
            var paymentSource = payload.Value<string>("paymentSource")
                ?? throw new InvalidOperationException("paymentSource is required (wallet_balances or other_payment_form)");
            
            if (paymentSource != "wallet_balances" && paymentSource != "other_payment_form")
                throw new InvalidOperationException($"Invalid paymentSource: {paymentSource}. Must be 'wallet_balances' or 'other_payment_form'");
            
            // 2. Extract invoice channel referral from metadata (if available) - this is the channel that created the invoice
            // Otherwise, load campaign from campaigns table and get channel referral
            string? invoiceChannelReferral = metadata?.Value<string>("invoiceChannelReferral");
            string? campaignChannelReferral = null;
            Guid? campaignIdGuid = null;
            bool isUuid = Guid.TryParse(campaignIdStr, out var parsedGuid);
            
            var tableName = "campaigns";
            
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                if (isUuid && !string.IsNullOrWhiteSpace(campaignIdStr))
                {
                    campaignIdGuid = parsedGuid;
                    cmd.CommandText = $"SELECT channelreferral FROM {tableName} WHERE id = @id";
                    cmd.Parameters.AddWithValue("@id", parsedGuid);
                }
                else if (!string.IsNullOrWhiteSpace(campaignReferral))
                {
                    if (mode == "production")
                        throw new InvalidOperationException("Production campaigns must be identified by UUID id, not referral code");
                    cmd.CommandText = $"SELECT channelreferral FROM {tableName} WHERE channelreferral = @referral";
                    cmd.Parameters.AddWithValue("@referral", campaignReferral);
                }
                else
                {
                    throw new InvalidOperationException("campaignId (UUID) or campaignReferral is required");
                }
                
                var scalarResult = cmd.ExecuteScalar();
                if (scalarResult == null || scalarResult == DBNull.Value)
                {
                    var identifier = isUuid ? $"id {campaignIdStr}" : $"referral {campaignReferral}";
                    throw new InvalidOperationException($"Campaign with {identifier} not found in {tableName} table");
                }
                campaignChannelReferral = scalarResult.ToString();
            }
            
            if (string.IsNullOrWhiteSpace(campaignChannelReferral))
                throw new InvalidOperationException($"Campaign has no channelreferral");
            
            // Use invoice's channel referral for ledger entries if available, otherwise fall back to campaign's channel referral
            string ledgerChannelReferral = !string.IsNullOrWhiteSpace(invoiceChannelReferral) 
                ? invoiceChannelReferral 
                : campaignChannelReferral;
            
            // Validate that we have a valid referral code
            if (string.IsNullOrWhiteSpace(ledgerChannelReferral))
            {
                throw new InvalidOperationException("ledgerChannelReferral cannot be null or empty. InvoiceChannelReferral was null/empty and CampaignChannelReferral is also null/empty.");
            }
            
            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Campaign ID={campaignIdStr ?? campaignReferral}, CampaignChannelReferral={campaignChannelReferral}, InvoiceChannelReferral={invoiceChannelReferral ?? "N/A"}, LedgerChannelReferral={ledgerChannelReferral}, PaymentSource={paymentSource}");
            
            // 3. Get partner referral (from payload or from campaign's channel referral)
            var partnerReferral = payload.Value<string>("partnerReferral") ?? campaignChannelReferral;
            
            // 4. Extract amounts based on payment source
            decimal transferableAmount = 0m;
            decimal communityAmount = 0m;
            BalanceVector? debit = null;
            int? brandIdForDebit = null;
            
            if (paymentSource == "wallet_balances" || paymentSource == "campaignbrands_balances")
            {
                // Extract from balances object
                var balancesObj = payload["balances"] as JObject;
                if (balancesObj == null || !balancesObj.Properties().Any())
                    throw new InvalidOperationException($"balances object is required when paymentSource is '{paymentSource}'");
                
                foreach (var prop in balancesObj.Properties())
                {
                    var amount = prop.Value.Value<decimal>();
                    if (amount <= 0m) continue;
                    
                    switch (prop.Name.ToLower())
                    {
                        case "transferable":
                            transferableAmount = amount;
                            break;
                        case "community":
                            communityAmount = amount;
                            break;
                        default:
                            throw new InvalidOperationException($"Unsupported balance type for campaign_balance_credit: {prop.Name}. Only 'transferable' and 'community' are allowed.");
                    }
                }
                
                if (transferableAmount == 0m && communityAmount == 0m)
                    throw new InvalidOperationException($"At least one balance amount (transferable or community) must be greater than 0 when using {paymentSource}");
                
                if (paymentSource == "wallet_balances")
                {
                    // Validate partner wallet has sufficient balances (PRODUCTION mode only)
                    if (mode == "production")
                    {
                        var partnerWallet = _balances.LoadWalletSnapshot(partnerReferral, mode, conn, tx);
                        
                        if (transferableAmount > 0m && partnerWallet.Transferable < transferableAmount)
                        {
                            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Insufficient transferable balance: required={transferableAmount}, available={partnerWallet.Transferable}");
                            return new JObject
                            {
                                ["ok"] = false,
                                ["error"] = "insufficient_transferable_balance",
                                ["required"] = transferableAmount,
                                ["available"] = partnerWallet.Transferable
                            };
                        }
                        
                        if (communityAmount > 0m && partnerWallet.Community < communityAmount)
                        {
                            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Insufficient community balance: required={communityAmount}, available={partnerWallet.Community}");
                            return new JObject
                            {
                                ["ok"] = false,
                                ["error"] = "insufficient_community_balance",
                                ["required"] = communityAmount,
                                ["available"] = partnerWallet.Community
                            };
                        }
                    }
                    
                    // Build debit vector for partner wallet
                    debit = BalanceVector.ForSpend(partnerReferral);
                    debit.Transferable = transferableAmount;
                    debit.Community = communityAmount;
                    
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Wallet debit: Partner={partnerReferral}, T={transferableAmount}, C={communityAmount}");
                }
                else // campaignbrands_balances
                {
                    // Get brand ID from payload
                    var brandIdNullable = payload.Value<int?>("brandId")
                        ?? (payload.Value<long?>("brandId") != null ? (int?)payload.Value<long>("brandId") : null);
                    
                    if (!brandIdNullable.HasValue || brandIdNullable.Value <= 0)
                        throw new InvalidOperationException("brandId is required and must be a positive integer when paymentSource is 'campaignbrands_balances'");
                    
                    brandIdForDebit = brandIdNullable.Value;
                    
                    // Validate brand has sufficient balances (PRODUCTION mode only)
                    if (mode == "production")
                    {
                        decimal brandTransferable = 0m;
                        decimal brandCommunity = 0m;
                        
                        using (var cmd = conn.CreateCommand())
                        {
                            cmd.Transaction = tx;
                            cmd.CommandText = @"
                                SELECT transferable_point_balance, community_point_balance
                                FROM campaignbrands
                                WHERE id = @id";
                            cmd.Parameters.AddWithValue("@id", brandIdForDebit.Value);
                            
                            using (var reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    brandTransferable = reader.IsDBNull("transferable_point_balance") ? 0m : reader.GetDecimal("transferable_point_balance");
                                    brandCommunity = reader.IsDBNull("community_point_balance") ? 0m : reader.GetDecimal("community_point_balance");
                                }
                                else
                                {
                                    throw new InvalidOperationException($"Brand with id {brandIdForDebit.Value} not found in campaignbrands table");
                                }
                            }
                        }
                        
                        if (transferableAmount > 0m && brandTransferable < transferableAmount)
                        {
                            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Insufficient brand transferable balance: required={transferableAmount}, available={brandTransferable}");
                            return new JObject
                            {
                                ["ok"] = false,
                                ["error"] = "insufficient_brand_transferable_balance",
                                ["required"] = transferableAmount,
                                ["available"] = brandTransferable
                            };
                        }
                        
                        if (communityAmount > 0m && brandCommunity < communityAmount)
                        {
                            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Insufficient brand community balance: required={communityAmount}, available={brandCommunity}");
                            return new JObject
                            {
                                ["ok"] = false,
                                ["error"] = "insufficient_brand_community_balance",
                                ["required"] = communityAmount,
                                ["available"] = brandCommunity
                            };
                        }
                    }
                    
                    // Build empty debit vector (we'll debit campaignbrands directly, not through wallet system)
                    debit = BalanceVector.ForSpend(partnerReferral); // Empty debit vector
                    
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] CampaignBrands debit: BrandId={brandIdForDebit.Value}, T={transferableAmount}, C={communityAmount}");
                }
            }
            else // other_payment_form
            {
                // Extract transferable amount only
                var transferableAmtNullable = payload.Value<decimal?>("transferableAmount");
                if (!transferableAmtNullable.HasValue || transferableAmtNullable.Value <= 0)
                    throw new InvalidOperationException("transferableAmount is required and must be greater than 0 when paymentSource is 'other_payment_form'");
                
                transferableAmount = transferableAmtNullable.Value;
                // No debit for other payment form
                debit = BalanceVector.ForSpend(partnerReferral); // Empty debit vector
                
                _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Other payment form: Transferable={transferableAmount}, No wallet debit");
            }
            
            // 5. Generate transaction ID and extract transaction description
            // Ensure metadata is never null
            if (metadata == null)
                metadata = new JObject();
            
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;
            
            // Extract transaction description from metadata (if provided)
            var txDescription = metadata.Value<string>("txDescription");
            
            // 6. Credit campaign balances in campaigns table
            if (transferableAmount > 0m)
            {
                var transferableColumn = mode == "production" ? "transferable_point_balance" : "transferable_balance";
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    if (isUuid && campaignIdGuid.HasValue)
                    {
                        cmd.CommandText = $@"
                            UPDATE {tableName}
                            SET {transferableColumn} = {transferableColumn} + @amount
                            WHERE id = @id";
                        cmd.Parameters.AddWithValue("@amount", transferableAmount);
                        cmd.Parameters.AddWithValue("@id", campaignIdGuid.Value);
                    }
                    else
                    {
                        cmd.CommandText = $@"
                            UPDATE {tableName}
                            SET {transferableColumn} = {transferableColumn} + @amount
                            WHERE channelreferral = @referral";
                        cmd.Parameters.AddWithValue("@amount", transferableAmount);
                        cmd.Parameters.AddWithValue("@referral", campaignReferral ?? string.Empty);
                    }
                    var rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        var identifier = isUuid ? $"id {campaignIdStr}" : $"referral {campaignReferral}";
                        throw new InvalidOperationException($"Failed to update campaign {identifier} transferable balance");
                    }
                }
                _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Credited campaign {campaignIdStr ?? campaignReferral} transferable balance: +{transferableAmount}");
            }
            
            if (communityAmount > 0m)
            {
                var communityColumn = mode == "production" ? "community_point_balance" : "community_balance";
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    if (isUuid && campaignIdGuid.HasValue)
                    {
                        cmd.CommandText = $@"
                            UPDATE {tableName}
                            SET {communityColumn} = {communityColumn} + @amount
                            WHERE id = @id";
                        cmd.Parameters.AddWithValue("@amount", communityAmount);
                        cmd.Parameters.AddWithValue("@id", campaignIdGuid.Value);
                    }
                    else
                    {
                        cmd.CommandText = $@"
                            UPDATE {tableName}
                            SET {communityColumn} = {communityColumn} + @amount
                            WHERE channelreferral = @referral";
                        cmd.Parameters.AddWithValue("@amount", communityAmount);
                        cmd.Parameters.AddWithValue("@referral", campaignReferral ?? string.Empty);
                    }
                    var rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        var identifier = isUuid ? $"id {campaignIdStr}" : $"referral {campaignReferral}";
                        throw new InvalidOperationException($"Failed to update campaign {identifier} community balance");
                    }
                }
                _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Credited campaign {campaignIdStr ?? campaignReferral} community balance: +{communityAmount}");
            }
            
            // 7. Apply wallet debit if using wallet balances
            if (paymentSource == "wallet_balances" && !debit.IsZero())
            {
                // Create empty credit vector (campaign balances are updated directly, not through wallet system)
                var emptyCredit = BalanceVector.Credit(partnerReferral);
                
                _balances.ApplyVectors(
                    debit,
                    new List<BalanceVector> { emptyCredit }, // Empty credit since we're updating campaign table directly
                    "campaign_balance_credit",
                    payload,
                    metadata!, // metadata is guaranteed to be non-null after initialization check above
                    mode,
                    conn,
                    tx);
                
                _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Applied wallet debit for partner {partnerReferral}");
            }
            
            // 7b. Debit campaignbrands balances if using campaignbrands_balances
            if (paymentSource == "campaignbrands_balances" && brandIdForDebit.HasValue)
            {
                if (transferableAmount > 0m)
                {
                    var transferableColumn = mode == "production" ? "transferable_point_balance" : "transferable_balance";
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            UPDATE campaignbrands
                            SET {transferableColumn} = {transferableColumn} - @amount
                            WHERE id = @id";
                        cmd.Parameters.AddWithValue("@amount", transferableAmount);
                        cmd.Parameters.AddWithValue("@id", brandIdForDebit.Value);
                        var rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected == 0)
                            throw new InvalidOperationException($"Failed to debit brand {brandIdForDebit.Value} transferable balance");
                    }
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Debited brand {brandIdForDebit.Value} transferable balance: -{transferableAmount}");
                }
                
                if (communityAmount > 0m)
                {
                    var communityColumn = mode == "production" ? "community_point_balance" : "community_balance";
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            UPDATE campaignbrands
                            SET {communityColumn} = {communityColumn} - @amount
                            WHERE id = @id";
                        cmd.Parameters.AddWithValue("@amount", communityAmount);
                        cmd.Parameters.AddWithValue("@id", brandIdForDebit.Value);
                        var rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected == 0)
                            throw new InvalidOperationException($"Failed to debit brand {brandIdForDebit.Value} community balance");
                    }
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Debited brand {brandIdForDebit.Value} community balance: -{communityAmount}");
                }
            }
            
            // 8. Write to ledger
            // For campaign balance credit, we need to write ledger entries manually since campaign balances aren't in memberwalletbalances
            var ledgerTable = "ledger";
            
            // CRITICAL: Ensure partition exists before inserting (only for production table)
            // This prevents "23514: no partition found" errors
            var isTest = !string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
            EnsureLedgerPartition(isTest, conn, tx);
            
            // Write debit entries for wallet balances (if any)
            if (paymentSource == "wallet_balances" && !debit.IsZero())
            {
                if (debit.Transferable > 0m)
                {
                    var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "campaign_balance_credit", "transferable");
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, point_type, account_number, amount, metadata, transaction_date, created_at, entry_type)
                            VALUES (@txId, @referral, @txType, @postingCode, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @entryType)";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referral", partnerReferral);
                        cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "transferable");
                        cmd.Parameters.AddWithValue("@accountCode", accountCode);
                        cmd.Parameters.AddWithValue("@amount", debit.Transferable);
                        cmd.Parameters.Add( 
                            new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                            {
                                Value = metadata!.ToString(Newtonsoft.Json.Formatting.None)
                            });
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        cmd.ExecuteNonQuery();
                    }
                }
                
                if (debit.Community > 0m)
                {
                    var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "campaign_balance_credit", "community");
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, point_type, account_number, amount, metadata, transaction_date, created_at, entry_type)
                            VALUES (@txId, @referral, @txType, @postingCode, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @entryType)";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referral", partnerReferral);
                        cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "community");
                        cmd.Parameters.AddWithValue("@accountCode", accountCode);
                        cmd.Parameters.AddWithValue("@amount", debit.Community);
                        cmd.Parameters.Add( 
                            new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                            {
                                Value = metadata!.ToString(Newtonsoft.Json.Formatting.None)
                            });
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            
            // Write debit entries for campaignbrands balances (if any)
            if (paymentSource == "campaignbrands_balances" && brandIdForDebit.HasValue)
            {
                // Get brand's assignedreferral for ledger entry
                string? brandAssignedReferral = null;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = "SELECT assignedreferral FROM campaignbrands WHERE id = @id";
                    cmd.Parameters.AddWithValue("@id", brandIdForDebit.Value);
                    var scalarResult = cmd.ExecuteScalar();
                    if (scalarResult != null && scalarResult != DBNull.Value)
                        brandAssignedReferral = scalarResult.ToString();
                }
                
                if (string.IsNullOrWhiteSpace(brandAssignedReferral))
                    throw new InvalidOperationException($"Brand {brandIdForDebit.Value} has no assignedreferral");
                
                if (transferableAmount > 0m)
                {
                    var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "campaign_balance_credit", "transferable");
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, point_type, account_number, amount, metadata, transaction_date, created_at, entry_type)
                            VALUES (@txId, @referral, @txType, @postingCode, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @entryType)";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referral", brandAssignedReferral);
                        cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "transferable");
                        cmd.Parameters.AddWithValue("@accountCode", accountCode);
                        cmd.Parameters.AddWithValue("@amount", transferableAmount);
                        var debitMetadata = new JObject(metadata!)
                        {
                            ["brandId"] = brandIdForDebit.Value,
                            ["isDebit"] = true,
                            ["paymentSource"] = "campaignbrands_balances"
                        };
                        cmd.Parameters.Add(
                            new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                            {
                                Value = debitMetadata.ToString(Newtonsoft.Json.Formatting.None)
                            });
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        cmd.ExecuteNonQuery();
                    }
                }
                
                if (communityAmount > 0m)
                {
                    var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "campaign_balance_credit", "community");
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, point_type, account_number, amount, metadata, transaction_date, created_at, entry_type)
                            VALUES (@txId, @referral, @txType, @postingCode, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @entryType)";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referral", brandAssignedReferral);
                        cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "community");
                        cmd.Parameters.AddWithValue("@accountCode", accountCode);
                        cmd.Parameters.AddWithValue("@amount", communityAmount);
                        var debitMetadata = new JObject(metadata!)
                        {
                            ["brandId"] = brandIdForDebit.Value,
                            ["isDebit"] = true,
                            ["paymentSource"] = "campaignbrands_balances"
                        };
                        cmd.Parameters.Add(
                            new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                            {
                                Value = debitMetadata.ToString(Newtonsoft.Json.Formatting.None)
                            });
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            
            // Write credit entries for campaign (using invoice's channel referral if available, otherwise campaign's channelreferral)
            if (transferableAmount > 0m)
            {
                _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Writing transferable credit ledger entry: referral={ledgerChannelReferral}, amount={transferableAmount}");
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "campaign_balance_credit", "transferable");
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, metadata, transaction_date, created_at, tx_description, entry_type)
                        VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @txDescription, @entryType)";
                    cmd.Parameters.AddWithValue("@txId", txId);
                    // Ensure referral_code is never null or empty
                    if (string.IsNullOrWhiteSpace(ledgerChannelReferral))
                    {
                        throw new InvalidOperationException($"ledgerChannelReferral is null or empty when inserting transferable credit. InvoiceChannelReferral={invoiceChannelReferral ?? "NULL"}, CampaignChannelReferral={campaignChannelReferral ?? "NULL"}");
                    }
                    cmd.Parameters.AddWithValue("@referral", ledgerChannelReferral);
                    cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                    cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                    cmd.Parameters.AddWithValue("@txSubtype", "WD"); // Withdrawable point type code
                    cmd.Parameters.AddWithValue("@pointType", "transferable");
                    cmd.Parameters.AddWithValue("@accountCode", accountCode);
                    cmd.Parameters.AddWithValue("@amount", transferableAmount);
                    cmd.Parameters.AddWithValue("@txDescription", (object?)txDescription ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                    var creditMetadata = new JObject(metadata!)
                    {
                        ["campaignId"] = campaignIdStr ?? campaignReferral,
                        ["isCredit"] = true
                    };
                    cmd.Parameters.Add(
                        new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                        {
                            Value = creditMetadata.ToString(Newtonsoft.Json.Formatting.None)
                        });
                    cmd.ExecuteNonQuery();
                }
            }
            
            if (communityAmount > 0m)
            {
                _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Writing community credit ledger entry: referral={ledgerChannelReferral}, amount={communityAmount}");
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "campaign_balance_credit", "community");
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, metadata, transaction_date, created_at, tx_description, entry_type)
                        VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @txDescription, @entryType)";
                    cmd.Parameters.AddWithValue("@txId", txId);
                    // Ensure referral_code is never null or empty
                    if (string.IsNullOrWhiteSpace(ledgerChannelReferral))
                    {
                        throw new InvalidOperationException($"ledgerChannelReferral is null or empty when inserting community credit. InvoiceChannelReferral={invoiceChannelReferral ?? "NULL"}, CampaignChannelReferral={campaignChannelReferral ?? "NULL"}");
                    }
                    cmd.Parameters.AddWithValue("@referral", ledgerChannelReferral);
                    cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                    cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                    cmd.Parameters.AddWithValue("@txSubtype", "CD"); // Community point type code
                    cmd.Parameters.AddWithValue("@pointType", "community");
                    cmd.Parameters.AddWithValue("@accountCode", accountCode);
                    cmd.Parameters.AddWithValue("@amount", communityAmount);
                    cmd.Parameters.AddWithValue("@txDescription", (object?)txDescription ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                    var creditMetadata = new JObject(metadata!)
                    {
                        ["campaignId"] = campaignIdStr ?? campaignReferral,
                        ["isCredit"] = true
                    };
                    cmd.Parameters.Add(
                        new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                        {
                            Value = creditMetadata.ToString(Newtonsoft.Json.Formatting.None)
                        });
                    cmd.ExecuteNonQuery();
                }
            }
            
            // Write debit entries for other_payment_form (external payments like credit card)
            // The debit goes against ImagineBC's referral code to balance the campaign credit
            if (paymentSource == "other_payment_form")
            {
                var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
                
                if (transferableAmount > 0m)
                {
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Writing transferable debit ledger entry for external payment: referral={imagineBcReferral}, amount={transferableAmount}");
                    // Use gl_account_code from metadata if provided (from selected bank account), otherwise default to 1100
                    var accountCode = metadata?.Value<string>("glAccountCode") ?? "1100"; // Default to Invoice cash receipts if not specified
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Using account code: {accountCode} for transferable debit");
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, metadata, transaction_date, created_at, tx_description, entry_type)
                            VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @txDescription, @entryType)";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referral", imagineBcReferral);
                        cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@txSubtype", "WD"); // Withdrawable point type code
                        cmd.Parameters.AddWithValue("@pointType", "transferable");
                        cmd.Parameters.AddWithValue("@accountCode", accountCode);
                        cmd.Parameters.AddWithValue("@amount", transferableAmount);
                        cmd.Parameters.AddWithValue("@txDescription", (object?)txDescription ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        var debitMetadata = new JObject(metadata!)
                        {
                            ["campaignId"] = campaignIdStr ?? campaignReferral,
                            ["isDebit"] = true,
                            ["paymentSource"] = "other_payment_form",
                            ["accountingNote"] = "External payment debit (cash) to balance campaign balance credit"
                        };
                        cmd.Parameters.Add(
                            new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                            {
                                Value = debitMetadata.ToString(Newtonsoft.Json.Formatting.None)
                            });
                        cmd.ExecuteNonQuery();
                    }
                }
                
                if (communityAmount > 0m)
                {
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Writing community debit ledger entry for external payment: referral={imagineBcReferral}, amount={communityAmount}");
                    // Use gl_account_code from metadata if provided (from selected bank account), otherwise default to 1100
                    var accountCode = metadata?.Value<string>("glAccountCode") ?? "1100"; // Default to Invoice cash receipts if not specified
                    _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Using account code: {accountCode} for community debit");
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, metadata, transaction_date, created_at, tx_description, entry_type)
                            VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @txDescription, @entryType)";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referral", imagineBcReferral);
                        cmd.Parameters.AddWithValue("@txType", "campaign_balance_credit");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@txSubtype", "CD"); // Community point type code
                        cmd.Parameters.AddWithValue("@pointType", "community");
                        cmd.Parameters.AddWithValue("@accountCode", accountCode);
                        cmd.Parameters.AddWithValue("@amount", communityAmount);
                        cmd.Parameters.AddWithValue("@txDescription", (object?)txDescription ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        var debitMetadata = new JObject(metadata!)
                        {
                            ["campaignId"] = campaignIdStr ?? campaignReferral,
                            ["isDebit"] = true,
                            ["paymentSource"] = "other_payment_form",
                            ["accountingNote"] = "External payment debit (cash) to balance campaign balance credit"
                        };
                        cmd.Parameters.Add(
                            new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                            {
                                Value = debitMetadata.ToString(Newtonsoft.Json.Formatting.None)
                            });
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            
            tx.Commit();
            
            _debugTrace?.Write("[ProcessCampaignBalanceCredit] Transaction committed");
            
            // 9. Read back ledger entries
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, posting_code, point_type, account_number, amount
                    FROM {ledgerTable}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);
                
                using (var reader = read.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ledgerRows.Add(new JObject
                        {
                            ["referral_code"] = reader["referral_code"]?.ToString() ?? "",
                            ["tx_type"] = reader["tx_type"]?.ToString() ?? "",
                            ["posting_code"] = reader["posting_code"]?.ToString(),
                            ["point_type"] = reader["point_type"]?.ToString() ?? "",
                            ["account_number"] = reader["account_number"]?.ToString() ?? "",
                            ["amount"] = reader["amount"] != DBNull.Value ? Convert.ToDecimal(reader["amount"]) : 0m
                        });
                    }
                }
            }
            
            // 10. Build response
            var result = new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["txId"] = txId,
                ["campaignId"] = campaignIdStr ?? campaignReferral,
                ["paymentSource"] = paymentSource,
                ["debit"] = debit != null && !debit.IsZero() ? JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    community = debit.Community,
                    total = debit.Transferable + debit.Community
                }) : null,
                ["credit"] = JObject.FromObject(new
                {
                    owner = campaignChannelReferral,
                    campaignId = campaignIdStr ?? campaignReferral,
                    transferable = transferableAmount,
                    community = communityAmount,
                    total = transferableAmount + communityAmount
                }),
                ["ledger"] = ledgerRows
            };
            
            _debugTrace?.Write($"[ProcessCampaignBalanceCredit] Result: {result.ToString(Newtonsoft.Json.Formatting.None)}");
            
            return result;
        }

        // ============================================================
        // TRANSACTION TYPE 21: campaign_invoice_funding
        // ============================================================
        /// <summary>
        /// Processes campaign funding via invoice payment.
        /// Creates DEBIT entry (account 1200) and CREDIT entry (account 2100).
        /// Both entries use the same referral code (channelReferral/gvPartner.id) and track campaign ID.
        /// Transaction description: "Campaign Invoice"
        /// </summary>
        private JObject ProcessCampaignInvoiceFunding(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            mode = mode?.ToLower() == "production" ? "production" : "test";
            
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] 🔵 STARTING: mode={mode}");
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] Payload: {payload.ToString(Newtonsoft.Json.Formatting.None)}");
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] Metadata: {metadata?.ToString(Newtonsoft.Json.Formatting.None) ?? "null"}");
            
            // 1. Extract payload fields
            var campaignIdStr = payload.Value<string>("campaignId");
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] Extracted campaignId: {campaignIdStr ?? "NULL"}");
            
            if (string.IsNullOrWhiteSpace(campaignIdStr))
                throw new InvalidOperationException("campaignId is required");
            
            if (!Guid.TryParse(campaignIdStr, out var campaignIdGuid))
            {
                _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ❌ ERROR: Invalid campaignId format: {campaignIdStr}");
                throw new InvalidOperationException($"Invalid campaignId format: {campaignIdStr}");
            }
            
            var channelReferral = payload.Value<string>("channelReferral");
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] Extracted channelReferral: {channelReferral ?? "NULL"}");
            
            if (string.IsNullOrWhiteSpace(channelReferral))
            {
                _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ❌ ERROR: channelReferral is required");
                throw new InvalidOperationException("channelReferral is required");
            }
            
            var amount = payload.Value<decimal?>("amount");
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] Extracted amount: {amount?.ToString() ?? "NULL"}");
            
            if (!amount.HasValue)
            {
                _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ❌ ERROR: amount is required");
                throw new InvalidOperationException("amount is required");
            }
            
            if (amount.Value <= 0m)
            {
                _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ❌ ERROR: amount must be greater than 0, got {amount.Value}");
                throw new InvalidOperationException("amount must be greater than 0");
            }
            
            // 2. Get transaction ID
            var txId = metadata?.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            if (metadata == null) metadata = new JObject();
            metadata["txId"] = txId;
            
            // 3. Determine ledger table based on mode
            var ledgerTable = "ledger";
            
            // 4. Transaction description
            var txDescription = "Campaign Invoice";
            
            // 5. Create DEBIT entry (account 1200, buyer)
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] 📝 Writing DEBIT entry: referral={channelReferral}, account=1200, amount={amount.Value}, txId={txId}");
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = $@"
                    INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, metadata, transaction_date, created_at, tx_description, entry_type)
                    VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @txDescription, @entryType)";
                cmd.Parameters.AddWithValue("@txId", txId);
                cmd.Parameters.AddWithValue("@referral", channelReferral);
                cmd.Parameters.AddWithValue("@txType", "campaign_invoice_funding");
                cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                cmd.Parameters.AddWithValue("@txSubtype", "ARED"); // Accounts Receivable Entry - Debit
                cmd.Parameters.AddWithValue("@pointType", "transferable"); // Required field, using transferable for invoice funding
                cmd.Parameters.AddWithValue("@accountCode", "1200"); // DEBIT account code
                cmd.Parameters.AddWithValue("@amount", amount.Value);
                cmd.Parameters.AddWithValue("@txDescription", txDescription);
                cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                
                var debitMetadata = new JObject
                {
                    ["campaignId"] = campaignIdStr,
                    ["isDebit"] = true,
                    ["paymentSource"] = "invoice",
                    ["accountingNote"] = "Campaign invoice funding - DEBIT entry (buyer)"
                };
                
                // Add any additional metadata from input
                if (metadata != null)
                {
                    if (metadata["invoiceId"] != null)
                        debitMetadata["invoiceId"] = metadata["invoiceId"];
                    if (metadata["invoiceNumber"] != null)
                        debitMetadata["invoiceNumber"] = metadata["invoiceNumber"];
                }
                
                cmd.Parameters.Add(
                    new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                    {
                        Value = debitMetadata.ToString(Newtonsoft.Json.Formatting.None)
                    });
                
                try
                {
                    var rowsAffected = cmd.ExecuteNonQuery();
                    _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ✅ DEBIT entry inserted. Rows affected: {rowsAffected}");
                }
                catch (Exception ex)
                {
                    _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ❌ ERROR inserting DEBIT entry: {ex.Message}. StackTrace: {ex.StackTrace}");
                    throw;
                }
            }
            
            // 6. Create CREDIT entry (account 2100)
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] 📝 Writing CREDIT entry: referral={channelReferral}, account=2100, amount={amount.Value}, txId={txId}");
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = $@"
                    INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, metadata, transaction_date, created_at, tx_description, entry_type)
                    VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, @metadata, NOW(), NOW(), @txDescription, @entryType)";
                cmd.Parameters.AddWithValue("@txId", txId);
                cmd.Parameters.AddWithValue("@referral", channelReferral);
                cmd.Parameters.AddWithValue("@txType", "campaign_invoice_funding");
                cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                cmd.Parameters.AddWithValue("@txSubtype", "ARED"); // Accounts Receivable Entry - Credit
                cmd.Parameters.AddWithValue("@pointType", "transferable"); // Required field, using transferable for invoice funding
                cmd.Parameters.AddWithValue("@accountCode", "2100"); // CREDIT account code
                cmd.Parameters.AddWithValue("@amount", amount.Value);
                cmd.Parameters.AddWithValue("@txDescription", txDescription);
                cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                
                var creditMetadata = new JObject
                {
                    ["campaignId"] = campaignIdStr,
                    ["isCredit"] = true,
                    ["paymentSource"] = "invoice",
                    ["accountingNote"] = "Campaign invoice funding - CREDIT entry"
                };
                
                // Add any additional metadata from input
                if (metadata != null)
                {
                    if (metadata["invoiceId"] != null)
                        creditMetadata["invoiceId"] = metadata["invoiceId"];
                    if (metadata["invoiceNumber"] != null)
                        creditMetadata["invoiceNumber"] = metadata["invoiceNumber"];
                }
                
                cmd.Parameters.Add(
                    new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb)
                    {
                        Value = creditMetadata.ToString(Newtonsoft.Json.Formatting.None)
                    });
                
                try
                {
                    var rowsAffected = cmd.ExecuteNonQuery();
                    _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ✅ CREDIT entry inserted. Rows affected: {rowsAffected}");
                }
                catch (Exception ex)
                {
                    _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] ❌ ERROR inserting CREDIT entry: {ex.Message}. StackTrace: {ex.StackTrace}");
                    throw;
                }
            }
            
            // 7. Commit transaction
            _debugTrace?.Write("[ProcessCampaignInvoiceFunding] 💾 Committing transaction...");
            tx.Commit();
            
            _debugTrace?.Write("[ProcessCampaignInvoiceFunding] ✅ Transaction committed successfully");
            
            // 8. Read back ledger entries
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, posting_code, account_number, amount, entry_type
                    FROM {ledgerTable}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);
                
                using (var reader = read.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ledgerRows.Add(new JObject
                        {
                            ["referral_code"] = reader["referral_code"]?.ToString() ?? "",
                            ["tx_type"] = reader["tx_type"]?.ToString() ?? "",
                            ["posting_code"] = reader["posting_code"]?.ToString(),
                            ["account_number"] = reader["account_number"]?.ToString() ?? "",
                            ["amount"] = reader["amount"] != DBNull.Value ? Convert.ToDecimal(reader["amount"]) : 0m,
                            ["entry_type"] = reader["entry_type"]?.ToString() ?? ""
                        });
                    }
                }
            }
            
            // 9. Build response
            var result = new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["txId"] = txId,
                ["campaignId"] = campaignIdStr,
                ["channelReferral"] = channelReferral,
                ["amount"] = amount,
                ["ledger"] = ledgerRows
            };
            
            _debugTrace?.Write($"[ProcessCampaignInvoiceFunding] Result: {result.ToString(Newtonsoft.Json.Formatting.None)}");
            
            return result;
        }

        // ============================================================
        // SHARED: Smart Contract distribution engine (70/5/10/10/5 + donation + ledger + subledger)
        // Used by both smart_contract_distribution and reward_distribution. Caller commits or rolls back.
        // ============================================================
        private (BalanceVector debit, List<BalanceVector> credits) ExecuteSmartContractStyleDistribution(
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string txId,
            decimal amount,
            string payerReferral,
            string sellerReferral,
            string payerPointType,
            string? buyerReferrer,
            string? sellerReferrer,
            decimal sellerDonationPercent,
            decimal sellerReferrerDonationPercent,
            string mode,
            bool isTest,
            JObject payload,
            JObject metadata,
            string transactionTypeLabel,
            string imbcGlAccountCode,
            string subledgerGlAccountCode)
        {
            var ledgerTable = "ledger";
            amount = AccountingHelpers.Round6(amount);
            var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
            var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
            var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);

            // Fixed 70/5/10/10/5 split: non-GP allocations Round6 first; GP last as balancing remainder
            decimal sellerAmount = AccountingHelpers.Round6(amount * 0.70m);
            decimal sellerReferrerAmount = AccountingHelpers.Round6(amount * 0.05m);
            decimal buyerReferrerAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal imagineBcAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal genesisPoolAmount = AccountingHelpers.Round6(amount - sellerAmount - sellerReferrerAmount - buyerReferrerAmount - imagineBcAmount);

            decimal sellerKeeps = sellerAmount;
            decimal sellerToSocialCause = 0m;
            if (sellerDonationPercent > 0m)
            {
                sellerToSocialCause = AccountingHelpers.Round6(sellerAmount * (sellerDonationPercent / 100m));
                sellerKeeps = sellerAmount - sellerToSocialCause;
            }

            decimal sellerReferrerKeeps = sellerReferrerAmount;
            decimal sellerReferrerToSocialCause = 0m;
            if (sellerReferrerDonationPercent > 0m && !string.IsNullOrWhiteSpace(sellerReferrer))
            {
                sellerReferrerToSocialCause = AccountingHelpers.Round6(sellerReferrerAmount * (sellerReferrerDonationPercent / 100m));
                sellerReferrerKeeps = sellerReferrerAmount - sellerReferrerToSocialCause;
            }

            decimal buyerReferrerToSocialCause = 0m;
            if (string.IsNullOrWhiteSpace(buyerReferrer))
            {
                buyerReferrerToSocialCause = buyerReferrerAmount;
                buyerReferrerAmount = 0m;
            }

            if (string.IsNullOrWhiteSpace(sellerReferrer))
            {
                sellerReferrerToSocialCause += sellerReferrerAmount;
                sellerReferrerKeeps = 0m;
                sellerReferrerAmount = 0m;
            }

            decimal totalSocialCause = AccountingHelpers.Round6(sellerToSocialCause + sellerReferrerToSocialCause + buyerReferrerToSocialCause);
            string creditPointType = payerPointType.ToLower() == "community" ? "community" : "transferable";

            var debit = BalanceVector.ForSpend(payerReferral);
            switch (payerPointType.ToLower())
            {
                case "transferable": debit.Transferable = amount; break;
                case "nontransferable": debit.NonTransferable = amount; break;
                case "community": debit.Community = amount; break;
                case "special": debit.Special = amount; break;
                case "subscription": debit.Subscription = amount; break;
                case "overflow": debit.Overflow = amount; break;
                default: debit.Transferable = amount; break;
            }

            var credits = new List<BalanceVector>();
            if (sellerKeeps > 0m) { var c = BalanceVector.Credit(sellerReferral); if (creditPointType == "community") c.Community = sellerKeeps; else c.Transferable = sellerKeeps; credits.Add(c); }
            if (sellerToSocialCause > 0m) { var c = BalanceVector.Credit(donationPoolReferral); c.Transferable = sellerToSocialCause; credits.Add(c); }
            if (sellerReferrerKeeps > 0m && !string.IsNullOrWhiteSpace(sellerReferrer)) { var c = BalanceVector.Credit(sellerReferrer); if (creditPointType == "community") c.Community = sellerReferrerKeeps; else c.Transferable = sellerReferrerKeeps; credits.Add(c); }
            if (sellerReferrerToSocialCause > 0m) { var c = BalanceVector.Credit(donationPoolReferral); c.Transferable = sellerReferrerToSocialCause; credits.Add(c); }
            if (buyerReferrerAmount > 0m && !string.IsNullOrWhiteSpace(buyerReferrer)) { var c = BalanceVector.Credit(buyerReferrer); if (creditPointType == "community") c.Community = buyerReferrerAmount; else c.Transferable = buyerReferrerAmount; credits.Add(c); }
            if (buyerReferrerToSocialCause > 0m) { var c = BalanceVector.Credit(donationPoolReferral); c.Transferable = buyerReferrerToSocialCause; credits.Add(c); }
            if (imagineBcAmount > 0m) { var c = BalanceVector.Credit(imagineBcReferral); if (creditPointType == "community") c.Community = imagineBcAmount; else c.Transferable = imagineBcAmount; credits.Add(c); }
            if (genesisPoolAmount > 0m) { var c = BalanceVector.Credit(genesisPoolReferral); if (creditPointType == "community") c.Community = genesisPoolAmount; else c.Transferable = genesisPoolAmount; credits.Add(c); }

            _balances.ApplyVectors(debit, credits, transactionTypeLabel, payload, metadata, mode, conn, tx);

            EnsureLedgerPartition(isTest, conn, tx);
            string GetSubCode(string pt) => pt.ToLower() switch { "transferable" => "WD", "overflow" => "DO", "community" => "CD", "encumbered" => "ED", _ => "WD" };
            void WriteLedgerEntry(string owner, string txCode, string pointType, decimal entryAmount, string accountCode, string? txDescriptionOverride = null)
            {
                if (entryAmount == 0m) return;
                var roundedAmount = AccountingHelpers.Round6(Math.Abs(entryAmount));
                var subCode = GetSubCode(pointType);
                var entryType = entryAmount >= 0 ? "CREDIT" : "DEBIT";
                var txDescription = !string.IsNullOrEmpty(txDescriptionOverride) ? txDescriptionOverride : $"{transactionTypeLabel} - {txCode}-{subCode}";
                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = $@"INSERT INTO {ledgerTable} (tx_id, referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount, transaction_date, metadata, source_system, is_test, tx_description, entry_type)
                    VALUES (@txId, @referral, @txType, @postingCode, @txSubtype, @pointType, @accountCode, @amount, NOW(), @metadata::jsonb, 'v3', @isTest, @txDescription, @entryType)";
                cmd.Parameters.AddWithValue("@txId", txId);
                cmd.Parameters.AddWithValue("@referral", owner);
                cmd.Parameters.AddWithValue("@txType", transactionTypeLabel);
                cmd.Parameters.AddWithValue("@postingCode", txCode);
                cmd.Parameters.AddWithValue("@txSubtype", subCode);
                cmd.Parameters.AddWithValue("@pointType", pointType);
                cmd.Parameters.AddWithValue("@accountCode", accountCode);
                cmd.Parameters.AddWithValue("@amount", roundedAmount);
                cmd.Parameters.Add(new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb) { Value = metadata.ToString(Newtonsoft.Json.Formatting.None) });
                cmd.Parameters.AddWithValue("@isTest", isTest);
                cmd.Parameters.AddWithValue("@txDescription", txDescription);
                cmd.Parameters.AddWithValue("@entryType", entryType);
                cmd.ExecuteNonQuery();
            }

            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "BO", payerPointType);
            WriteLedgerEntry(payerReferral, "BO", payerPointType, -amount, debitAccountCode);
            if (sellerKeeps > 0m) WriteLedgerEntry(sellerReferral, "PI", creditPointType, sellerKeeps, AccountingHelpers.ResolveAccountCode(conn, tx, "PI", creditPointType));
            if (sellerToSocialCause > 0m) WriteLedgerEntry(donationPoolReferral, "SCO", "transferable", sellerToSocialCause, "2300", "");
            if (sellerReferrerKeeps > 0m && !string.IsNullOrWhiteSpace(sellerReferrer)) WriteLedgerEntry(sellerReferrer, "PRI", creditPointType, sellerReferrerKeeps, AccountingHelpers.ResolveAccountCode(conn, tx, "PRI", creditPointType));
            if (sellerReferrerToSocialCause > 0m) WriteLedgerEntry(donationPoolReferral, "SCO", "transferable", sellerReferrerToSocialCause, "2300", "");
            if (buyerReferrerAmount > 0m && !string.IsNullOrWhiteSpace(buyerReferrer)) WriteLedgerEntry(buyerReferrer, "BRI", creditPointType, buyerReferrerAmount, AccountingHelpers.ResolveAccountCode(conn, tx, "BRI", creditPointType));
            if (buyerReferrerToSocialCause > 0m) WriteLedgerEntry(donationPoolReferral, "SCO", "transferable", buyerReferrerToSocialCause, "2300", "");
            if (buyerReferrerToSocialCause > 0m) WriteLedgerEntry(donationPoolReferral, "SCO", "transferable", -buyerReferrerToSocialCause, "1100", "SC Cash Pending");
            if (sellerReferrerToSocialCause > 0m) WriteLedgerEntry(donationPoolReferral, "SCO", "transferable", -sellerReferrerToSocialCause, "1100", "SC Cash Pending");
            if (imagineBcAmount > 0m) WriteLedgerEntry(imagineBcReferral, "IBCI", creditPointType, imagineBcAmount, imbcGlAccountCode);
            // 4-line GP package: GPI (1100 + 4100), GPA (2310 + 5000) – same genesisPoolAmount on all four
            if (genesisPoolAmount > 0m)
            {
                WriteLedgerEntry(genesisPoolReferral, "GPI", creditPointType, genesisPoolAmount, "4100");   // CR 4100 Genesis Pool Revenue
                WriteLedgerEntry(genesisPoolReferral, "GPA", creditPointType, genesisPoolAmount, "2310");  // CR 2310 Due to Genesis Pool
                WriteLedgerEntry(genesisPoolReferral, "GPA", creditPointType, -genesisPoolAmount, "5000"); // DR 5000 Genesis Pool Allocation
            }

            string defaultBankAccountCode = "000001";
            var defs1100 = AccountingHelpers.Get1100SubledgerDefinitions(conn, tx);
            void CreateBankSubLedgerEntry(long subledgerDefinitionId, string description, decimal debitAmt, decimal creditAmt, string glAccountCode)
            {
                if (debitAmt == 0m && creditAmt == 0m) return;
                debitAmt = AccountingHelpers.Round6(debitAmt);
                creditAmt = AccountingHelpers.Round6(creditAmt);
                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;
                cmd.CommandText = @"SELECT COALESCE(MAX(running_balance), 0) FROM bank_sub_ledger WHERE bank_account_id = @bankAccountId";
                cmd.Parameters.AddWithValue("@bankAccountId", defaultBankAccountCode);
                var lastBalance = cmd.ExecuteScalar();
                decimal runningBalance = lastBalance != null && lastBalance != DBNull.Value ? Convert.ToDecimal(lastBalance) : 0m;
                runningBalance = AccountingHelpers.Round6(runningBalance - debitAmt + creditAmt);
                cmd.Parameters.Clear();
                cmd.CommandText = @"INSERT INTO bank_sub_ledger (bank_account_id, legal_entity, currency, transaction_date, description, debit_amount, credit_amount, running_balance, gl_account_code, subledger_definition_id, metadata, created_at)
                    VALUES (@bankAccountId, @legalEntity, @currency, NOW(), @description, @debitAmt, @creditAmt, @runningBalance, @glAccountCode, @subledgerDefinitionId, @metadata::jsonb, NOW())";
                cmd.Parameters.AddWithValue("@bankAccountId", defaultBankAccountCode);
                cmd.Parameters.AddWithValue("@legalEntity", "IMAGINEBC");
                cmd.Parameters.AddWithValue("@currency", "USD");
                cmd.Parameters.AddWithValue("@description", description);
                cmd.Parameters.AddWithValue("@debitAmt", debitAmt);
                cmd.Parameters.AddWithValue("@creditAmt", creditAmt);
                cmd.Parameters.AddWithValue("@runningBalance", runningBalance);
                cmd.Parameters.AddWithValue("@glAccountCode", glAccountCode);
                cmd.Parameters.AddWithValue("@subledgerDefinitionId", subledgerDefinitionId);
                cmd.Parameters.Add(new NpgsqlParameter("@metadata", NpgsqlTypes.NpgsqlDbType.Jsonb) { Value = new JObject { ["txId"] = txId, ["transactionType"] = transactionTypeLabel, ["source"] = "smart_contract" }.ToString(Newtonsoft.Json.Formatting.None) });
                cmd.ExecuteNonQuery();
            }
            CreateBankSubLedgerEntry(defs1100[0].Id, defs1100[0].Name, 0m, amount, subledgerGlAccountCode);
            if (imagineBcAmount > 0m) CreateBankSubLedgerEntry(defs1100[1].Id, defs1100[1].Name, imagineBcAmount, 0m, subledgerGlAccountCode);
            // No single credit (totalSocialCause) to SC; only the two GAAP debits (buyer and seller referrer shares)
            if (buyerReferrerToSocialCause > 0m) CreateBankSubLedgerEntry(defs1100[2].Id, defs1100[2].Name, buyerReferrerToSocialCause, 0m, subledgerGlAccountCode);
            if (sellerReferrerToSocialCause > 0m) CreateBankSubLedgerEntry(defs1100[2].Id, defs1100[2].Name, sellerReferrerToSocialCause, 0m, subledgerGlAccountCode);
            if (genesisPoolAmount > 0m) CreateBankSubLedgerEntry(defs1100[3].Id, defs1100[3].Name, genesisPoolAmount, 0m, subledgerGlAccountCode);
            if (sellerReferrerKeeps > 0m && !string.IsNullOrWhiteSpace(sellerReferrer)) CreateBankSubLedgerEntry(defs1100[0].Id, defs1100[0].Name, sellerReferrerKeeps, 0m, subledgerGlAccountCode);
            if (buyerReferrerAmount > 0m && !string.IsNullOrWhiteSpace(buyerReferrer)) CreateBankSubLedgerEntry(defs1100[0].Id, defs1100[0].Name, buyerReferrerAmount, 0m, subledgerGlAccountCode);
            if (sellerKeeps > 0m) CreateBankSubLedgerEntry(defs1100[0].Id, defs1100[0].Name, sellerKeeps, 0m, subledgerGlAccountCode);

            return (debit, credits);
        }

        // ============================================================
        // TRANSACTION TYPE 20: smart_contract_distribution
        // ============================================================
        private JObject ProcessSmartContractDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            mode = mode?.ToLower() == "production" ? "production" : "test";
            var isTest = !string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
            
            _debugTrace?.Write($"[ProcessSmartContractDistribution] 🔵 ENTRY: mode={mode}");
            
            if (metadata == null) metadata = new JObject();
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;
            metadata["originalTransactionType"] = "smart_contract_distribution";
            
            var amount = payload.Value<decimal?>("amount") ?? throw new InvalidOperationException("amount is required");
            if (amount <= 0m) throw new InvalidOperationException("amount must be greater than 0");
            var buyerReferral = payload.Value<string>("buyerReferral") ?? throw new InvalidOperationException("buyerReferral is required");
            var sellerReferral = payload.Value<string>("sellerReferral") ?? throw new InvalidOperationException("sellerReferral is required");
            var buyerPointType = payload.Value<string>("buyerPointType") ?? throw new InvalidOperationException("buyerPointType is required (transferable, community, special, etc.)");
            var validPointTypes = new[] { "transferable", "nontransferable", "community", "special", "subscription", "overflow" };
            if (!validPointTypes.Contains(buyerPointType.ToLower())) throw new InvalidOperationException($"buyerPointType must be one of: {string.Join(", ", validPointTypes)}");
            
            var ledgerTable = "ledger";
            using (var checkCmd = conn.CreateCommand())
            {
                checkCmd.Transaction = tx;
                checkCmd.CommandText = $@"SELECT COUNT(*) FROM {ledgerTable} WHERE tx_id = @txId";
                checkCmd.Parameters.AddWithValue("@txId", txId);
                if (Convert.ToInt64(checkCmd.ExecuteScalar()) > 0) throw new InvalidOperationException($"Transaction with txId {txId} already exists");
            }
            
            var walletTable = "memberwalletbalances";
            decimal buyerBalance = 0m;
            using (var balanceCmd = conn.CreateCommand())
            {
                balanceCmd.Transaction = tx;
                var balanceColumn = buyerPointType.ToLower() switch { "transferable" => "transferable", "nontransferable" => "nontransferable", "community" => "community", "special" => "special", "subscription" => "subscription", "overflow" => "overflow", _ => "transferable" };
                balanceCmd.CommandText = $"SELECT COALESCE({balanceColumn}, 0) FROM {walletTable} WHERE referral_code = @referral";
                balanceCmd.Parameters.AddWithValue("@referral", buyerReferral);
                var balanceResult = balanceCmd.ExecuteScalar();
                if (balanceResult != null && balanceResult != DBNull.Value) buyerBalance = Convert.ToDecimal(balanceResult);
            }
            if (buyerBalance < amount) throw new InvalidOperationException($"Buyer {buyerReferral} has insufficient {buyerPointType} balance. Required: {amount}, Available: {buyerBalance}");
            
            var buyerReferrer = metadata.Value<string>("buyerReferrer");
            var sellerReferrer = metadata.Value<string>("sellerReferrer");
            var sellerDonationPercent = metadata.Value<decimal?>("sellerDonatedatapercent") ?? 0m;
            var sellerReferrerDonationPercent = metadata.Value<decimal?>("sellerReferrerDonatedatapercent") ?? 0m;
            if (sellerDonationPercent < 0m || sellerDonationPercent > 100m) throw new InvalidOperationException("sellerDonatedatapercent must be between 0 and 100");
            if (sellerReferrerDonationPercent < 0m || sellerReferrerDonationPercent > 100m) throw new InvalidOperationException("sellerReferrerDonatedatapercent must be between 0 and 100");

            var (debit, credits) = ExecuteSmartContractStyleDistribution(conn, tx, txId, amount, buyerReferral, sellerReferral, buyerPointType, buyerReferrer, sellerReferrer, sellerDonationPercent, sellerReferrerDonationPercent, mode, isTest, payload, metadata, "smart_contract_distribution", "4100", "1100");

            AccountingHelpers.ValidateTransactionBalance(conn, tx, txId, "ledger");
            _debugTrace?.Write($"[ProcessSmartContractDistribution] 💾 Committing transaction");
            tx.Commit();
            
            // Response math must match ExecuteSmartContractStyleDistribution (Round6, GP last)
            decimal sellerAmount = AccountingHelpers.Round6(amount * 0.70m);
            decimal sellerReferrerAmount = AccountingHelpers.Round6(amount * 0.05m);
            decimal buyerReferrerAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal imagineBcAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal genesisPoolAmount = AccountingHelpers.Round6(amount - sellerAmount - sellerReferrerAmount - buyerReferrerAmount - imagineBcAmount);
            decimal sellerToSocialCause = AccountingHelpers.Round6(sellerAmount * (sellerDonationPercent / 100m));
            decimal sellerKeeps = sellerAmount - sellerToSocialCause;
            decimal sellerReferrerToSocialCause = string.IsNullOrWhiteSpace(sellerReferrer) ? sellerReferrerAmount : AccountingHelpers.Round6(sellerReferrerAmount * (sellerReferrerDonationPercent / 100m));
            decimal sellerReferrerKeeps = string.IsNullOrWhiteSpace(sellerReferrer) ? 0m : sellerReferrerAmount - sellerReferrerToSocialCause;
            decimal buyerReferrerToSocialCause = string.IsNullOrWhiteSpace(buyerReferrer) ? buyerReferrerAmount : 0m;
            if (!string.IsNullOrWhiteSpace(buyerReferrer)) buyerReferrerAmount = AccountingHelpers.Round6(amount * 0.10m);
            decimal totalSocialCause = AccountingHelpers.Round6(sellerToSocialCause + sellerReferrerToSocialCause + buyerReferrerToSocialCause);

            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, posting_code, tx_subtype, point_type, account_number, amount
                    FROM {ledgerTable}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);
                
                using (var reader = read.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ledgerRows.Add(new JObject
                        {
                            ["referral_code"] = reader["referral_code"]?.ToString() ?? "",
                            ["tx_type"] = reader["tx_type"]?.ToString() ?? "",
                            ["posting_code"] = reader["posting_code"]?.ToString(),
                            ["tx_subtype"] = reader["tx_subtype"]?.ToString() ?? "",
                            ["point_type"] = reader["point_type"]?.ToString() ?? "",
                            ["account_number"] = reader["account_number"]?.ToString() ?? "",
                            ["amount"] = reader["amount"] != DBNull.Value ? Convert.ToDecimal(reader["amount"]) : 0m
                        });
                    }
                }
            }
            
            var result = new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["txId"] = txId,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    pointType = buyerPointType,
                    amount = amount
                }),
                ["credits"] = new JArray(credits.Select(c => new JObject
                {
                    ["owner"] = c.Owner,
                    ["transferable"] = c.Transferable,
                    ["community"] = c.Community,
                    ["special"] = c.Special,
                    ["subscription"] = c.Subscription,
                    ["overflow"] = c.Overflow,
                    ["total"] = c.Total
                })),
                ["distribution"] = new JObject
                {
                    ["seller"] = sellerKeeps,
                    ["sellerToSocialCause"] = sellerToSocialCause,
                    ["sellerReferrer"] = sellerReferrerKeeps,
                    ["sellerReferrerToSocialCause"] = sellerReferrerToSocialCause,
                    ["buyerReferrer"] = buyerReferrerAmount,
                    ["buyerReferrerToSocialCause"] = buyerReferrerToSocialCause,
                    ["imagineBC"] = imagineBcAmount,
                    ["genesisPool"] = genesisPoolAmount,
                    ["totalSocialCause"] = totalSocialCause
                },
                ["ledger"] = ledgerRows
            };
            
            _debugTrace?.Write($"[ProcessSmartContractDistribution] ✅ COMPLETE: Result: {result.ToString(Newtonsoft.Json.Formatting.None)}");
            
            return result;
        }

        // ============================================================
        // TRANSACTION TYPE 7: member_points_purchase
        // ============================================================
        private JObject ProcessMemberPointsPurchase(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[ProcessMemberPointsPurchase] Starting, mode={mode}");
            _debugTrace?.Write($"[ProcessMemberPointsPurchase] Payload keys: {string.Join(", ", payload.Properties().Select(p => p.Name))}");

            // 1. Validate payload (HARD REQUIREMENTS)
            var memberReferral = payload.Value<string>("memberReferral")
                ?? payload.Value<string>("member")
                ?? throw new InvalidOperationException("memberReferral is required");

            var pointsRequestedNullable = payload.Value<decimal?>("pointsRequested")
                ?? payload.Value<decimal?>("points");
            
            if (!pointsRequestedNullable.HasValue || pointsRequestedNullable.Value <= 0)
                throw new InvalidOperationException("pointsRequested is required and must be greater than zero");

            var pointsRequested = pointsRequestedNullable.Value;

            var fundingSource = payload.Value<string>("fundingSource")
                ?? throw new InvalidOperationException("fundingSource is required");

            // Check if this is a resume (approval granted)
            var resumeToken = payload.Value<string>("resumeToken");
            var approved = payload.Value<bool?>("approved") ?? false;
            var fundingToken = payload.Value<string>("fundingToken");

            if (!string.IsNullOrWhiteSpace(resumeToken) && approved && !string.IsNullOrWhiteSpace(fundingToken))
            {
                // RESUME PATH: Execute after approval
                return ExecuteMemberPointsPurchaseResume(
                    resumeToken,
                    fundingToken,
                    memberReferral,
                    pointsRequested,
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    start);
            }

            // PREFLIGHT PATH: Validate funding source, create payment intent
            return ExecuteMemberPointsPurchasePreflight(
                memberReferral,
                pointsRequested,
                fundingSource,
                payload,
                metadata,
                mode,
                conn,
                tx);
        }

        private JObject ExecuteMemberPointsPurchasePreflight(
            string memberReferral,
            decimal pointsRequested,
            string fundingSource,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Member={memberReferral}, Points={pointsRequested}, FundingSource={fundingSource}");

            // 2. Funding Source Gate (only credit_card is implemented)
            if (fundingSource != "credit_card" && fundingSource != "creditCard")
            {
                _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Funding source {fundingSource} not implemented");
                return new JObject
                {
                    ["ok"] = false,
                    ["notImplemented"] = true,
                    ["fundingSource"] = fundingSource,
                    ["error"] = $"Funding source '{fundingSource}' is not implemented yet. Only credit_card is supported."
                };
            }

            // 3. Calculate purchase amount (conversion: $1 = 1 point, or configured rate)
            // For now: 1 point = $1 USD
            decimal purchaseAmount = pointsRequested;
            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Conversion: {pointsRequested} points = ${purchaseAmount} USD");

            // 4. Validate country allows credit card charges
            var countryIso2 = payload.Value<string>("countryIso2");
            if (string.IsNullOrWhiteSpace(countryIso2))
            {
                _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Missing countryIso2 in payload");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = "countryIso2 is required for credit card transactions"
                };
            }

            var countryAllowsCreditCard = CheckCountryAllowsCreditCard(conn, countryIso2);
            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Country={countryIso2}, AllowsCreditCard={countryAllowsCreditCard}");

            if (!countryAllowsCreditCard)
            {
                _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Country {countryIso2} does not allow credit card charges");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Credit card transactions are not allowed for country {countryIso2}"
                };
            }

            // 5. Calculate surcharge (if applicable)
            decimal surchargePercentage = GetCreditCardSurchargePercentage();
            decimal surcharge = Math.Round(purchaseAmount * surchargePercentage, 2);

            var totalCharge = purchaseAmount + surcharge;
            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] PurchaseAmount={purchaseAmount}, Surcharge={surcharge}, TotalCharge={totalCharge}");

            // 6. Create payment intent
            Guid intentId = Guid.NewGuid();
            Guid secureToken = Guid.NewGuid();

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO transaction_payment_intents (
                        id, secure_token, transaction_type, member_referral,
                        gross_amount, transferable_used, external_required,
                        external_amount, surcharge_amount, funding_method,
                        status, payload_snapshot, metadata_snapshot, mode
                    ) VALUES (
                        @id, @secureToken, @transactionType, @memberReferral,
                        @grossAmount, @transferableUsed, @externalRequired,
                        @externalAmount, @surchargeAmount, @fundingMethod,
                        @status, @payloadSnapshot::jsonb, @metadataSnapshot::jsonb, @mode
                    )";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@secureToken", secureToken);
                cmd.Parameters.AddWithValue("@transactionType", "member_points_purchase");
                cmd.Parameters.AddWithValue("@memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("@grossAmount", purchaseAmount);
                cmd.Parameters.AddWithValue("@transferableUsed", 0m); // No internal points used
                cmd.Parameters.AddWithValue("@externalRequired", true);
                cmd.Parameters.AddWithValue("@externalAmount", purchaseAmount);
                cmd.Parameters.AddWithValue("@surchargeAmount", surcharge);
                cmd.Parameters.AddWithValue("@fundingMethod", "credit_card");
                cmd.Parameters.AddWithValue("@status", "pending_approval");
                cmd.Parameters.AddWithValue("@payloadSnapshot", payload.ToString());
                cmd.Parameters.AddWithValue("@metadataSnapshot", metadata?.ToString() ?? "{}");
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.ExecuteNonQuery();
            }

            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_PREFLIGHT] Created payment intent: {intentId}, Token: {secureToken}");

            // Commit the transaction so the payment intent is persisted
            tx.Commit();

            // 7. Return approval-required response
            var response = new JObject
            {
                ["ok"] = false,
                ["requiresApproval"] = true,
                ["approvalType"] = "credit_card",
                ["transactionType"] = "member_points_purchase",
                ["points"] = pointsRequested,
                ["purchaseAmount"] = purchaseAmount,
                ["surcharge"] = surcharge,
                ["totalCharge"] = totalCharge,
                ["resumeToken"] = secureToken.ToString()
            };

            // Add country and currency info if available
            if (!string.IsNullOrWhiteSpace(countryIso2))
            {
                response["countryIso2"] = countryIso2;
            }

            return response;
        }

        private JObject ExecuteMemberPointsPurchaseResume(
            string resumeToken,
            string fundingToken,
            string memberReferral,
            decimal pointsRequested,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_RESUME] Starting, Token={resumeToken}, Member={memberReferral}, Points={pointsRequested}");

            // 1. Validate resume token and load payment intent
            Guid intentGuid;
            if (!Guid.TryParse(resumeToken, out intentGuid))
            {
                return new JObject { ["ok"] = false, ["error"] = "Invalid resume token format" };
            }

            Guid intentId;
            decimal purchaseAmount;
            decimal surchargeAmount;

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    SELECT id, gross_amount, surcharge_amount, status
                    FROM transaction_payment_intents
                    WHERE secure_token = @secureToken
                      AND transaction_type = 'member_points_purchase'
                      AND status = 'pending_approval'
                ";
                cmd.Parameters.AddWithValue("@secureToken", intentGuid);

                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return new JObject { ["ok"] = false, ["error"] = "Payment intent not found or already processed" };

                intentId = reader.GetGuid(0);
                purchaseAmount = reader.GetDecimal(1);
                surchargeAmount = reader.GetDecimal(2);
                var status = reader.GetString(3);

                if (status != "pending_approval")
                    return new JObject { ["ok"] = false, ["error"] = $"Payment intent status is {status}, expected pending_approval" };
            }

            // Validate amount matches
            if (Math.Abs(pointsRequested - purchaseAmount) > 0.01m)
            {
                _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_RESUME] WARNING: Points requested ({pointsRequested}) doesn't match intent amount ({purchaseAmount})");
            }

            // 2. Execute Stripe charge (via ExternalPaymentService)
            string? providerChargeId = null;
            decimal processingFee = 0m;
            decimal netFunded = 0m;

            var totalChargeToCustomer = purchaseAmount + surchargeAmount;

            if (_externalPayment != null && totalChargeToCustomer > 0)
            {
                var amountCents = (int)Math.Round(totalChargeToCustomer * 100);
                if (amountCents <= 0)
                {
                    _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_RESUME] Invalid amountCents: {amountCents}");
                    return new JObject { ["ok"] = false, ["error"] = $"Invalid charge amount: {totalChargeToCustomer}. Cannot process payment." };
                }

                var (success, chargeId, gross, fee, net, error) = _externalPayment.CreateAndCapturePayment(
                    memberReferral,
                    amountCents,
                    fundingToken
                ).GetAwaiter().GetResult();

                if (!success)
                    return new JObject { ["ok"] = false, ["error"] = error ?? "Payment failed" };

                providerChargeId = chargeId;
                processingFee = fee;
                netFunded = purchaseAmount; // Net funded equals purchase amount (points value)
            }
            else
            {
                // Mock for testing when ExternalPaymentService not available
                providerChargeId = $"ch_mock_{Guid.NewGuid():N}";
                processingFee = Math.Round(totalChargeToCustomer * 0.029m + 0.30m, 2);
                netFunded = purchaseAmount;
            }

            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_RESUME] Stripe charge: ChargeId={providerChargeId}, ProcessingFee={processingFee}, NetFunded={netFunded}");

            // 3. Persist external payment ledger
            Guid externalPaymentId = Guid.NewGuid();
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO external_payment_ledger (
                        id, intent_id, member_referral, provider,
                        provider_charge_id, gross_charge_amount,
                        processing_fee_amount, net_funded_amount,
                        currency, transaction_type, status, mode, metadata
                    ) VALUES (
                        @id, @intentId, @memberReferral, @provider,
                        @providerChargeId, @grossChargeAmount,
                        @processingFeeAmount, @netFundedAmount,
                        @currency, @transactionType, @status, @mode, @metadata::jsonb
                    )";
                cmd.Parameters.AddWithValue("@id", externalPaymentId);
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("@provider", "stripe");
                cmd.Parameters.AddWithValue("@providerChargeId", providerChargeId ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@grossChargeAmount", totalChargeToCustomer);
                cmd.Parameters.AddWithValue("@processingFeeAmount", processingFee);
                cmd.Parameters.AddWithValue("@netFundedAmount", netFunded);
                cmd.Parameters.AddWithValue("@currency", "USD");
                cmd.Parameters.AddWithValue("@transactionType", "member_points_purchase");
                cmd.Parameters.AddWithValue("@status", "captured");
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.Parameters.AddWithValue("@metadata", "{}");
                cmd.ExecuteNonQuery();
            }

            // 4. Update payment intent status
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    UPDATE transaction_payment_intents
                    SET status = 'executed',
                        funding_token = @fundingToken,
                        consumed_at = CURRENT_TIMESTAMP
                    WHERE id = @intentId
                ";
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@fundingToken", fundingToken);
                cmd.ExecuteNonQuery();
            }

            // 5. Execute the points purchase (credit non-transferable balance, write ledger)
            return ExecuteMemberPointsPurchaseExecution(
                memberReferral,
                pointsRequested,
                externalPaymentId,
                providerChargeId,
                purchaseAmount,
                processingFee,
                payload,
                metadata,
                mode,
                conn,
                tx,
                start);
        }

        private JObject ExecuteMemberPointsPurchaseExecution(
            string memberReferral,
            decimal pointsPurchased,
            Guid externalPaymentId,
            string? providerChargeId,
            decimal purchaseAmount,
            decimal processingFee,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[MEMBER_POINTS_PURCHASE_EXECUTION] Member={memberReferral}, Points={pointsPurchased}, ExternalPaymentId={externalPaymentId}");

            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // 1. Apply balance mutation (credit non-transferable only, NO DEBIT)
            // This is new point issuance, so we only credit, never debit
            var credit = BalanceVector.Credit(memberReferral);
            credit.NonTransferable = pointsPurchased;
            
            _balances.ApplyVectors(
                BalanceVector.ForSpend(memberReferral), // Empty debit vector (no internal debit)
                new List<BalanceVector> { credit },
                "member_points_purchase",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 2. Write ledger entries
            // Internal ledger: Credit non-transferable points (no offsetting debit)
            var ledgerTable = "ledger";
            var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "member_points_purchase", "nonTransferable");
            
            var ledgerMetadata = new JObject
            {
                ["transactionType"] = "member_points_purchase",
                ["memberReferral"] = memberReferral,
                ["pointsPurchased"] = pointsPurchased,
                ["purchaseAmount"] = purchaseAmount,
                ["processingFee"] = processingFee,
                ["externalPaymentId"] = externalPaymentId.ToString(),
                ["providerChargeId"] = providerChargeId ?? "",
                ["conversionRate"] = "1.0", // $1 = 1 point
                ["accountingNote"] = "External cash inflow → internal stored value issuance (non-transferable points)"
            };
            
            metadata.Merge(ledgerMetadata);

            // Write credit entry (points issued)
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = $@"
                    INSERT INTO {ledgerTable} (
                        tx_id, referral_code, tx_type, posting_code, point_type, account_code,
                        amount, transaction_date, metadata, source_system, created_at, entry_type
                    ) VALUES (
                        @txId, @referralCode, @txType, @postingCode, @pointType, @accountCode,
                        @amount, CURRENT_TIMESTAMP, @metadata::jsonb, @sourceSystem, CURRENT_TIMESTAMP, @entryType
                    )";
                cmd.Parameters.AddWithValue("@txId", txId);
                cmd.Parameters.AddWithValue("@referralCode", memberReferral);
                cmd.Parameters.AddWithValue("@txType", "member_points_purchase");
                cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                cmd.Parameters.AddWithValue("@pointType", "nonTransferable");
                cmd.Parameters.AddWithValue("@accountCode", accountCode);
                cmd.Parameters.AddWithValue("@amount", pointsPurchased); // CREDIT (positive)
                cmd.Parameters.AddWithValue("@metadata", ledgerMetadata.ToString());
                cmd.Parameters.AddWithValue("@sourceSystem", "accounting_service");
                cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                cmd.ExecuteNonQuery();
            }

            tx.Commit();

            // 3. Read back ledger rows
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {ledgerTable}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = ledgerTable,
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            // 4. Return result
            return new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["debit"] = JObject.FromObject(new
                {
                    owner = memberReferral,
                    transferable = 0m,
                    nonTransferable = 0m,
                    community = 0m,
                    special = 0m,
                    overflow = 0m,
                    subscription = 0m,
                    total = 0m,
                    accountCode = (string?)null
                }),
                ["credits"] = new JArray
                {
                    JObject.FromObject(new
                    {
                        owner = memberReferral,
                        transferable = 0m,
                        nonTransferable = pointsPurchased,
                        community = 0m,
                        special = 0m,
                        overflow = 0m,
                        subscription = 0m,
                        total = pointsPurchased,
                        accountCode = accountCode
                    })
                },
                ["ledger"] = ledgerRows,
                ["transactionType"] = "member_points_purchase",
                ["mode"] = mode,
                ["txId"] = txId,
                ["pointsPurchased"] = pointsPurchased,
                ["purchaseAmount"] = purchaseAmount,
                ["processingFee"] = processingFee,
                ["externalPaymentId"] = externalPaymentId.ToString()
            };
        }

        // ============================================================
        // TRANSACTION TYPE 5: subscription_purchase_distribution
        // ============================================================
        private JObject ProcessSubscriptionPurchaseDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[ProcessSubscriptionPurchaseDistribution] Starting, mode={mode}");
            _debugTrace?.Write($"[ProcessSubscriptionPurchaseDistribution] Payload keys: {string.Join(", ", payload.Properties().Select(p => p.Name))}");
            
            // 1. Validate payload (HARD REQUIREMENTS)
            var buyerReferral = payload.Value<string>("memberReferral")
                ?? payload.Value<string>("buyerReferral")
                ?? throw new InvalidOperationException("memberReferral is required");

            var channelReferral = payload.Value<string>("channelReferral")
                ?? throw new InvalidOperationException("channelReferral is required");

            var tierIdentifier = payload.Value<string>("tierIdentifier");
            var frequency = payload.Value<string>("frequency") ?? "monthly"; // Default to monthly

            _debugTrace?.Write($"[ProcessSubscriptionPurchaseDistribution] Buyer={buyerReferral}, Channel={channelReferral}, Tier={tierIdentifier}, Frequency={frequency}");

            // Check if this is a resume (approval granted)
            var resumeToken = payload.Value<string>("resumeToken");
            var approved = payload.Value<bool?>("approved") ?? false;
            var fundingToken = payload.Value<string>("fundingToken");

            if (!string.IsNullOrWhiteSpace(resumeToken) && approved && !string.IsNullOrWhiteSpace(fundingToken))
            {
                // RESUME PATH: Execute after approval
                return ExecuteSubscriptionPurchaseResume(
                    resumeToken,
                    fundingToken,
                    buyerReferral,
                    channelReferral,
                    tierIdentifier,
                    frequency,
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    start);
            }

            // PREFLIGHT PATH: Resolve tier, calculate funding needs, create payment intent
            return ExecuteSubscriptionPurchasePreflight(
                buyerReferral,
                channelReferral,
                tierIdentifier,
                frequency,
                payload,
                metadata,
                mode,
                conn,
                tx);
        }

        private JObject ExecuteSubscriptionPurchasePreflight(
            string buyerReferral,
            string channelReferral,
            string? tierIdentifier,
            string frequency,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // 1. Resolve tier and amount
            decimal subscriptionAmount;
            int resolvedTierIdentifier;

            if (mode == "production")
            {
                // PRODUCTION: Get tier from channel subscriptionmap
                if (string.IsNullOrWhiteSpace(tierIdentifier))
                {
                    _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Missing tierIdentifier in PRODUCTION mode");
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = "tierIdentifier is required in PRODUCTION mode"
                    };
                }

                if (!int.TryParse(tierIdentifier, out resolvedTierIdentifier))
                {
                    _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Invalid tierIdentifier: {tierIdentifier}");
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = $"Invalid tierIdentifier: {tierIdentifier}"
                    };
                }

                // Get subscription map from channel
                string? subscriptionMapJson = null;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        SELECT subscriptionmap
                        FROM channel
                        WHERE assignedreferral = @channelReferral
                        LIMIT 1
                    ";
                    cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                    var result = cmd.ExecuteScalar();
                    subscriptionMapJson = result?.ToString();
                }

                if (string.IsNullOrWhiteSpace(subscriptionMapJson) || subscriptionMapJson == "{}")
                {
                    _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Channel {channelReferral} has no subscription map");
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = $"Channel {channelReferral} does not have a subscription configuration"
                    };
                }

                // Parse subscription map and find tier
                try
                {
                    var subscriptionMap = JObject.Parse(subscriptionMapJson);
                    var tiers = subscriptionMap["tiers"] as JArray;
                    if (tiers == null)
                    {
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = "Subscription map has no tiers"
                        };
                    }

                    var tier = tiers.FirstOrDefault(t => t["rank"]?.Value<int?>() == resolvedTierIdentifier);
                    if (tier == null)
                    {
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = $"Tier {resolvedTierIdentifier} not found in channel subscription map"
                        };
                    }

                    var costs = tier["costs"] as JObject;
                    if (costs == null)
                    {
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = $"Tier {resolvedTierIdentifier} has no costs"
                        };
                    }

                    var cost = costs[frequency]?.Value<decimal?>();
                    if (!cost.HasValue || cost.Value <= 0)
                    {
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = $"Tier {resolvedTierIdentifier} has no cost for frequency {frequency}"
                        };
                    }

                    subscriptionAmount = cost.Value;
                    _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Resolved tier {resolvedTierIdentifier} amount: {subscriptionAmount} for frequency {frequency}");
                }
                catch (Exception ex)
                {
                    _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Error parsing subscription map: {ex.Message}");
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = $"Error parsing subscription map: {ex.Message}"
                    };
                }
            }
            else
            {
                // TEST: Check if tier already saved, otherwise use provided tierIdentifier and amount
                int? existingTierId = null;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    var tableName = "memberaccess";
                    cmd.CommandText = $@"
                        SELECT membersubscriptionid
                        FROM {tableName}
                        WHERE assignedreferral = @memberReferral
                          AND channelreferral = @channelReferral
                        LIMIT 1
                    ";
                    cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                    cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        existingTierId = Convert.ToInt32(result);
                    }
                }

                if (existingTierId.HasValue && existingTierId.Value > 0)
                {
                    // Reuse existing tier
                    resolvedTierIdentifier = existingTierId.Value;
                    _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Reusing existing tier {resolvedTierIdentifier} from memberaccess");
                }
                else
                {
                    // Use provided tierIdentifier
                    if (string.IsNullOrWhiteSpace(tierIdentifier))
                    {
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = "tierIdentifier is required in TEST mode when no existing subscription"
                        };
                    }

                    if (!int.TryParse(tierIdentifier, out resolvedTierIdentifier))
                    {
                        return new JObject
                        {
                            ["ok"] = false,
                            ["error"] = $"Invalid tierIdentifier: {tierIdentifier}"
                        };
                    }
                }

                // Get amount from payload (TEST mode allows override)
                subscriptionAmount = payload.Value<decimal?>("amount") ?? 0m;
                if (subscriptionAmount <= 0)
                {
                    return new JObject
                    {
                        ["ok"] = false,
                        ["error"] = "amount must be greater than zero in TEST mode"
                    };
                }

                _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] TEST mode: Using tier {resolvedTierIdentifier}, amount {subscriptionAmount}");
            }

            // 2. Load buyer wallet snapshot (READ ONLY, NO MUTATION)
            var wallet = _balances.LoadWalletSnapshot(buyerReferral, mode, conn, tx);
            
            // 3. Resolve usable channel subscription amount (contentId = NULL)
            decimal usableSubscriptionPoints = ResolveUsableChannelSubscriptionPoints(
                wallet.SubscriptionDetailsJson,
                channelReferral);

            _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] UsableSubscriptionPoints={usableSubscriptionPoints} for channel={channelReferral}");

            // 4. Calculate funding mix using LOCKED PRIORITY:
            // Subscription (channel-only) → Non-transferable → Community → Transferable → Overflow
            var debit = BalanceVector.ForSpend(buyerReferral);
            decimal remainingPrice = subscriptionAmount;
            decimal internalFundingTotal = 0m;

            // Priority 1: Subscription (channel-only, contentId = NULL)
            if (usableSubscriptionPoints > 0 && remainingPrice > 0)
            {
                var subscriptionUsed = Math.Min(usableSubscriptionPoints, remainingPrice);
                debit.Subscription = subscriptionUsed;
                remainingPrice -= subscriptionUsed;
                internalFundingTotal += subscriptionUsed;
            }

            // Priority 2: Non-transferable
            if (remainingPrice > 0 && wallet.NonTransferable > 0)
            {
                var nonTransferableUsed = Math.Min(wallet.NonTransferable, remainingPrice);
                debit.NonTransferable = nonTransferableUsed;
                remainingPrice -= nonTransferableUsed;
                internalFundingTotal += nonTransferableUsed;
            }

            // Priority 3: Community
            if (remainingPrice > 0 && wallet.Community > 0)
            {
                var communityUsed = Math.Min(wallet.Community, remainingPrice);
                debit.Community = communityUsed;
                remainingPrice -= communityUsed;
                internalFundingTotal += communityUsed;
            }

            // Priority 4: Transferable
            if (remainingPrice > 0 && wallet.Transferable > 0)
            {
                var transferableUsed = Math.Min(wallet.Transferable, remainingPrice);
                debit.Transferable = transferableUsed;
                remainingPrice -= transferableUsed;
                internalFundingTotal += transferableUsed;
            }

            // Priority 5: Overflow
            if (remainingPrice > 0 && wallet.Overflow > 0)
            {
                var overflowUsed = Math.Min(wallet.Overflow, remainingPrice);
                debit.Overflow = overflowUsed;
                remainingPrice -= overflowUsed;
                internalFundingTotal += overflowUsed;
            }

            var shortfall = remainingPrice;

            _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Buyer={buyerReferral}, Amount={subscriptionAmount}, InternalFunding={internalFundingTotal}, Shortfall={shortfall}, Mode={mode}");

            // 5. If no shortfall, proceed directly to execution
            if (shortfall <= 0)
            {
                _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] No shortfall detected, executing immediately");
                // No external funding needed - execute immediately
                return ExecuteSubscriptionPurchaseDistribution(
                    buyerReferral,
                    channelReferral,
                    resolvedTierIdentifier,
                    subscriptionAmount,
                    debit,
                    null, // no external payment
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    DateTime.UtcNow);
            }

            // 6. Validate country allows credit card charges (if shortfall requires credit card)
            var countryIso2 = payload.Value<string>("countryIso2");
            if (string.IsNullOrWhiteSpace(countryIso2))
            {
                _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Missing countryIso2 in payload");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = "countryIso2 is required for credit card transactions"
                };
            }

            var countryAllowsCreditCard = CheckCountryAllowsCreditCard(conn, countryIso2);
            _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Country={countryIso2}, AllowsCreditCard={countryAllowsCreditCard}");

            if (!countryAllowsCreditCard)
            {
                _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Country {countryIso2} does not allow credit card charges");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Credit card transactions are not allowed for country {countryIso2}"
                };
            }

            // 7. Calculate surcharge and total charge
            _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Shortfall detected: {shortfall}, creating payment intent");
            
            decimal surchargePercentage = GetCreditCardSurchargePercentage();
            var surcharge = Math.Round(shortfall * surchargePercentage, 2);
            var totalCharge = shortfall + surcharge;
            
            _debugTrace?.Write($"[SUBSCRIPTION_PURCHASE_PREFLIGHT] Surcharge={surcharge}, TotalCharge={totalCharge}");

            // 8. Create payment intent
            var secureToken = Guid.NewGuid();
            var intentId = Guid.NewGuid();

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO transaction_payment_intents (
                        id, secure_token, transaction_type, member_referral,
                        gross_amount, transferable_used, external_required,
                        external_amount, surcharge_amount, funding_method,
                        status, payload_snapshot, metadata_snapshot, mode
                    ) VALUES (
                        @id, @secureToken, @transactionType, @memberReferral,
                        @grossAmount, @transferableUsed, @externalRequired,
                        @externalAmount, @surchargeAmount, @fundingMethod,
                        @status, @payloadSnapshot::jsonb, @metadataSnapshot::jsonb, @mode
                    )";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@secureToken", secureToken);
                cmd.Parameters.AddWithValue("@transactionType", "subscription_purchase_distribution");
                cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                cmd.Parameters.AddWithValue("@grossAmount", subscriptionAmount);
                
                // Calculate total internal points used (all buckets)
                var totalInternalUsed = debit.Subscription + debit.NonTransferable + debit.Community + debit.Transferable + debit.Overflow;
                cmd.Parameters.AddWithValue("@transferableUsed", totalInternalUsed);
                cmd.Parameters.AddWithValue("@externalRequired", true);
                cmd.Parameters.AddWithValue("@externalAmount", shortfall);
                cmd.Parameters.AddWithValue("@surchargeAmount", surcharge);
                cmd.Parameters.AddWithValue("@fundingMethod", "credit_card");
                cmd.Parameters.AddWithValue("@status", "pending_approval");
                cmd.Parameters.AddWithValue("@payloadSnapshot", payload.ToString());
                cmd.Parameters.AddWithValue("@metadataSnapshot", metadata.ToString());
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();

            // 9. Get exchange rate and currency info for non-US countries
            string? memberCurrencyCode = null;
            decimal? memberExchangeRate = null;
            decimal? memberConvertedAmount = null;

            if (!string.IsNullOrWhiteSpace(countryIso2) && countryIso2.ToUpper() != "US" && _countriesService != null)
            {
                // Get exchange rate from cache (no database reads)
                memberExchangeRate = _countriesService.GetExchangeRateUsdToCountry(countryIso2);
                
                // Get currency code from cached countries
                var countries = _countriesService.GetAllCountriesForManagement();
                var country = countries.FirstOrDefault(c => 
                    (c.ContainsKey("iso2") ? c["iso2"]?.ToString() : null)?.ToUpper() == countryIso2.ToUpper());
                
                if (country != null)
                {
                    memberCurrencyCode = country.ContainsKey("currencyCode") ? country["currencyCode"]?.ToString() : null;
                    
                    // Calculate converted amount if we have exchange rate
                    if (memberExchangeRate.HasValue && memberExchangeRate.Value > 0)
                    {
                        memberConvertedAmount = Math.Round(totalCharge * memberExchangeRate.Value, 2);
                    }
                }
            }

            // 10. Return approval required response
            var response = new JObject
            {
                ["ok"] = false,
                ["requiresApproval"] = true,
                ["approvalType"] = "credit_card",
                ["transactionType"] = "subscription_purchase_distribution",
                ["subscriptionUsed"] = debit.Subscription,
                ["nonTransferableUsed"] = debit.NonTransferable,
                ["communityUsed"] = debit.Community,
                ["transferableUsed"] = debit.Transferable,
                ["overflowUsed"] = debit.Overflow,
                ["externalRequired"] = shortfall,
                ["surcharge"] = surcharge,
                ["totalCharge"] = totalCharge,
                ["resumeToken"] = secureToken.ToString(),
                ["tierIdentifier"] = resolvedTierIdentifier
            };

            // Add country and currency info if available
            if (!string.IsNullOrWhiteSpace(countryIso2))
            {
                response["countryIso2"] = countryIso2;
            }
            if (!string.IsNullOrWhiteSpace(memberCurrencyCode))
            {
                response["currencyCode"] = memberCurrencyCode;
            }
            if (memberExchangeRate.HasValue)
            {
                response["exchangeRate"] = memberExchangeRate.Value;
            }
            if (memberConvertedAmount.HasValue)
            {
                response["convertedAmount"] = memberConvertedAmount.Value;
            }

            return response;
        }

        private JObject ExecuteSubscriptionPurchaseResume(
            string resumeToken,
            string fundingToken,
            string buyerReferral,
            string channelReferral,
            string? tierIdentifier,
            string frequency,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            // 1. Resolve intent
            Guid intentGuid;
            if (!Guid.TryParse(resumeToken, out intentGuid))
                return new JObject { ["ok"] = false, ["error"] = "Invalid resumeToken" };

            Guid intentId;
            decimal totalInternalUsed;
            decimal externalAmount;
            decimal surchargeAmount;
            decimal subscriptionAmount;

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    SELECT id, transferable_used, external_amount, surcharge_amount, gross_amount, status
                    FROM transaction_payment_intents
                    WHERE secure_token = @secureToken
                      AND transaction_type = 'subscription_purchase_distribution'
                      AND status = 'pending_approval'
                ";
                cmd.Parameters.AddWithValue("@secureToken", intentGuid);

                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return new JObject { ["ok"] = false, ["error"] = "Payment intent not found or already processed" };

                intentId = reader.GetGuid(0);
                totalInternalUsed = reader.GetDecimal(1);
                externalAmount = reader.GetDecimal(2);
                surchargeAmount = reader.GetDecimal(3);
                subscriptionAmount = reader.GetDecimal(4);
                var status = reader.GetString(5);

                if (status != "pending_approval")
                    return new JObject { ["ok"] = false, ["error"] = $"Payment intent status is {status}, expected pending_approval" };
            }

            // 2. Execute Stripe charge (via ExternalPaymentService)
            string? providerChargeId = null;
            decimal processingFee = 0m;
            decimal netFunded = 0m;

            var totalChargeToCustomer = externalAmount + surchargeAmount;

            if (_externalPayment != null && totalChargeToCustomer > 0)
            {
                var amountCents = (int)Math.Round(totalChargeToCustomer * 100);
                var (success, chargeId, gross, fee, net, error) = _externalPayment.CreateAndCapturePayment(
                    buyerReferral,
                    amountCents,
                    fundingToken
                ).GetAwaiter().GetResult();

                if (!success)
                    return new JObject { ["ok"] = false, ["error"] = error ?? "Payment failed" };

                providerChargeId = chargeId;
                processingFee = fee;
                netFunded = externalAmount; // Fund the full shortfall amount
            }
            else
            {
                // Mock for testing when ExternalPaymentService not available
                providerChargeId = $"ch_mock_{Guid.NewGuid():N}";
                processingFee = Math.Round(totalChargeToCustomer * 0.029m + 0.30m, 2);
                netFunded = externalAmount;
            }

            // 3. Persist external payment ledger
            Guid externalPaymentId = Guid.NewGuid();
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO external_payment_ledger (
                        id, intent_id, member_referral, provider,
                        provider_charge_id, gross_charge_amount,
                        processing_fee_amount, net_funded_amount,
                        currency, transaction_type, status, mode, metadata
                    ) VALUES (
                        @id, @intentId, @memberReferral, @provider,
                        @providerChargeId, @grossChargeAmount,
                        @processingFeeAmount, @netFundedAmount,
                        @currency, @transactionType, @status, @mode, @metadata::jsonb
                    )";
                cmd.Parameters.AddWithValue("@id", externalPaymentId);
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@memberReferral", buyerReferral);
                cmd.Parameters.AddWithValue("@provider", "stripe");
                cmd.Parameters.AddWithValue("@providerChargeId", providerChargeId ?? "");
                cmd.Parameters.AddWithValue("@grossChargeAmount", totalChargeToCustomer);
                cmd.Parameters.AddWithValue("@processingFeeAmount", processingFee);
                cmd.Parameters.AddWithValue("@netFundedAmount", netFunded);
                cmd.Parameters.AddWithValue("@currency", "USD");
                cmd.Parameters.AddWithValue("@transactionType", "subscription_purchase_distribution");
                cmd.Parameters.AddWithValue("@status", "captured");
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.Parameters.AddWithValue("@metadata", metadata.ToString());
                cmd.ExecuteNonQuery();
            }

            // 4. Update payment intent status
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    UPDATE transaction_payment_intents
                    SET status = 'approved',
                        funding_token = @fundingToken,
                        consumed_at = CURRENT_TIMESTAMP
                    WHERE id = @id
                ";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@fundingToken", fundingToken);
                cmd.ExecuteNonQuery();
            }

            // 5. Reconstruct debit vector from payment intent (we need to reload wallet to get subscription details)
            var wallet = _balances.LoadWalletSnapshot(buyerReferral, mode, conn, tx);
            var usableSubscriptionPoints = ResolveUsableChannelSubscriptionPoints(
                wallet.SubscriptionDetailsJson,
                channelReferral);

            var debit = BalanceVector.ForSpend(buyerReferral);
            decimal remainingPrice = subscriptionAmount;

            // Reconstruct debit using same priority order
            if (usableSubscriptionPoints > 0 && remainingPrice > 0)
            {
                var subscriptionUsed = Math.Min(usableSubscriptionPoints, remainingPrice);
                debit.Subscription = subscriptionUsed;
                remainingPrice -= subscriptionUsed;
            }
            if (remainingPrice > 0 && wallet.NonTransferable > 0)
            {
                var nonTransferableUsed = Math.Min(wallet.NonTransferable, remainingPrice);
                debit.NonTransferable = nonTransferableUsed;
                remainingPrice -= nonTransferableUsed;
            }
            if (remainingPrice > 0 && wallet.Community > 0)
            {
                var communityUsed = Math.Min(wallet.Community, remainingPrice);
                debit.Community = communityUsed;
                remainingPrice -= communityUsed;
            }
            if (remainingPrice > 0 && wallet.Transferable > 0)
            {
                var transferableUsed = Math.Min(wallet.Transferable, remainingPrice);
                debit.Transferable = transferableUsed;
                remainingPrice -= transferableUsed;
            }
            if (remainingPrice > 0 && wallet.Overflow > 0)
            {
                var overflowUsed = Math.Min(wallet.Overflow, remainingPrice);
                debit.Overflow = overflowUsed;
                remainingPrice -= overflowUsed;
            }

            // Add external funding
            debit.Transferable += netFunded;

            // 6. Resolve tier identifier from payload or payment intent metadata
            int resolvedTierIdentifier;
            if (!string.IsNullOrWhiteSpace(tierIdentifier) && int.TryParse(tierIdentifier, out resolvedTierIdentifier))
            {
                // Use from payload
            }
            else
            {
                // Try to get from payment intent metadata
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        SELECT metadata_snapshot->>'tierIdentifier'
                        FROM transaction_payment_intents
                        WHERE id = @id
                    ";
                    cmd.Parameters.AddWithValue("@id", intentId);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value && int.TryParse(result.ToString(), out resolvedTierIdentifier))
                    {
                        // Got from metadata
                    }
                    else
                    {
                        return new JObject { ["ok"] = false, ["error"] = "Unable to resolve tierIdentifier" };
                    }
                }
            }

            // 7. Execute the distribution
            return ExecuteSubscriptionPurchaseDistribution(
                buyerReferral,
                channelReferral,
                resolvedTierIdentifier,
                subscriptionAmount,
                debit,
                externalPaymentId,
                payload,
                metadata,
                mode,
                conn,
                tx,
                start);
        }

        private JObject ExecuteSubscriptionPurchaseDistribution(
            string buyerReferral,
            string channelReferral,
            int tierIdentifier,
            decimal subscriptionAmount,
            BalanceVector debit,
            Guid? externalPaymentId,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // 1. Update channel subscription details if subscription points were used
            if (debit.Subscription > 0)
            {
                UpdateChannelSubscriptionDetailsAfterPurchase(
                    buyerReferral,
                    channelReferral,
                    debit.Subscription,
                    mode,
                    conn,
                    tx);
            }

            // 2. Smart contract distribution
            var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
            var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
            var donationPoolReferral = ResolveSystemReferral("DONATION-POOL-REFERRAL", conn, tx);
            var buyerReferrer = ResolveMemberReferrer(buyerReferral, conn, tx, mode);
            var sellerReferrer = ResolveChannelReferrer(channelReferral, conn, tx, mode);

            var creditVectors = _distribution.Distribute(
                "subscription_purchase_distribution",
                debit,
                channelReferral,
                imagineBcReferral,
                genesisPoolReferral,
                donationPoolReferral,
                buyerReferrer,
                sellerReferrer).ToList();

            // 3. Apply voluntary donation split (Transaction Type 8) if enabled
            creditVectors = ApplyVoluntaryDonationSplit(
                creditVectors,
                channelReferral, // seller is the channel
                payload,
                metadata,
                conn,
                tx);

            // 4. Apply vectors
            _balances.ApplyVectors(
                debit,
                creditVectors,
                "subscription_purchase_distribution",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 4. Write ledger entries
            // Add subscription-specific metadata
            var ledgerMetadata = new JObject
            {
                ["channelReferral"] = channelReferral,
                ["tierIdentifier"] = tierIdentifier,
                ["subscriptionAmount"] = subscriptionAmount,
                ["externalFunding"] = externalPaymentId.HasValue,
                ["stripeChargeId"] = externalPaymentId?.ToString()
            };
            metadata.Merge(ledgerMetadata);

            WriteLedger(
                txId,
                "subscription_purchase_distribution",
                debit,
                creditVectors,
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 5. Update memberaccess with tierIdentifier (MANDATORY - only after successful transaction)
            UpdateMemberAccessAfterSubscriptionPurchase(
                buyerReferral,
                channelReferral,
                tierIdentifier,
                mode,
                conn,
                tx);

            // 6. Write CC processing fee to ledger (if external payment exists)
            decimal surchargeAmount = 0m;
            if (externalPaymentId.HasValue)
            {
                // Get surcharge from payment intent
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        SELECT surcharge_amount
                        FROM transaction_payment_intents
                        WHERE id = (SELECT intent_id FROM external_payment_ledger WHERE id = @externalPaymentId)
                    ";
                    cmd.Parameters.AddWithValue("@externalPaymentId", externalPaymentId.Value);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        surchargeAmount = Convert.ToDecimal(result);
                    }
                }

                if (surchargeAmount > 0)
                {
                    var feeMetadata = new JObject
                    {
                        ["externalPaymentId"] = externalPaymentId.Value.ToString(),
                        ["fundingSource"] = "credit_card",
                        ["surchargeAmount"] = surchargeAmount,
                        ["accountingNote"] = "Cash debit recorded in external_payment_ledger via Stripe"
                    };

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        var ledgerTable = "ledger";
                        var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "subscription_purchase_distribution", "transferable");
                        
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (
                                tx_id, referral_code, tx_type, posting_code, point_type, account_code,
                                amount, transaction_date, metadata, source_system, created_at, entry_type
                            ) VALUES (
                                @txId, @referralCode, @txType, @postingCode, @pointType, @accountCode,
                                @amount, CURRENT_TIMESTAMP, @metadata::jsonb, @sourceSystem, CURRENT_TIMESTAMP, @entryType
                            )";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referralCode", imagineBcReferral);
                        cmd.Parameters.AddWithValue("@txType", "subscription_purchase_distribution");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "transferable");
                        cmd.Parameters.AddWithValue("@accountCode", "CC_PROC_FEE_REV");
                        cmd.Parameters.AddWithValue("@amount", surchargeAmount);
                        cmd.Parameters.AddWithValue("@metadata", feeMetadata.ToString());
                        cmd.Parameters.AddWithValue("@sourceSystem", "accounting_service");
                        cmd.Parameters.AddWithValue("@entryType", "CREDIT");
                        cmd.ExecuteNonQuery();
                    }
                }
            }

            tx.Commit();

            // 7. Read back ledger rows
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            // 8. Return result
            var debitTotal = debit.Transferable + debit.NonTransferable + debit.Community + debit.Special + debit.Overflow + debit.Subscription;
            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "subscription_purchase_distribution", "transferable");
            
            var creditsArray = new JArray(creditVectors.Select(c => 
            {
                var creditTotal = c.Transferable + c.NonTransferable + c.Community + c.Special + c.Overflow + c.Subscription;
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "subscription_purchase_distribution", "transferable");
                return JObject.FromObject(new
                {
                    owner = c.Owner,
                    transferable = c.Transferable,
                    nonTransferable = c.NonTransferable,
                    community = c.Community,
                    special = c.Special,
                    overflow = c.Overflow,
                    subscription = c.Subscription,
                    total = creditTotal,
                    accountCode = accountCode
                });
            }));
            
            return new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    nonTransferable = debit.NonTransferable,
                    community = debit.Community,
                    special = debit.Special,
                    overflow = debit.Overflow,
                    subscription = debit.Subscription,
                    total = debitTotal,
                    accountCode = debitAccountCode
                }),
                ["credits"] = creditsArray,
                ["ledger"] = ledgerRows,
                ["transactionType"] = "subscription_purchase_distribution",
                ["mode"] = mode,
                ["txId"] = txId,
                ["tierIdentifier"] = tierIdentifier,
                ["systemReferrals"] = new JObject
                {
                    ["imaginebc"] = imagineBcReferral,
                    ["genesisPool"] = genesisPoolReferral,
                    ["donationPool"] = donationPoolReferral
                }
            };
        }

        // Helper: Update channel subscription details after purchase (decrement balance and recalculate subscription balance)
        private void UpdateChannelSubscriptionDetailsAfterPurchase(
            string buyerReferral,
            string channelReferral,
            decimal subscriptionUsed,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            try
            {
                var tableName = "memberwalletbalances";

                // Load current subscription details
                string currentDetailsJson;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        SELECT subscription_details
                        FROM {tableName}
                        WHERE referral_code = @referral
                        FOR UPDATE
                    ";
                    cmd.Parameters.AddWithValue("@referral", buyerReferral);
                    var result = cmd.ExecuteScalar();
                    currentDetailsJson = result?.ToString() ?? "[]";
                }

                // Parse as array (channel subscriptions are stored as array)
                JArray details;
                try
                {
                    details = string.IsNullOrWhiteSpace(currentDetailsJson) || currentDetailsJson == "[]" || currentDetailsJson == "{}"
                        ? new JArray()
                        : JArray.Parse(currentDetailsJson);
                }
                catch
                {
                    // If parsing as array fails, start fresh
                    details = new JArray();
                }

                // Find or create subscription entry for this channel
                JObject? channelSub = null;
                for (int i = 0; i < details.Count; i++)
                {
                    if (details[i] is JObject obj && obj["channelReferral"]?.ToString() == channelReferral)
                    {
                        channelSub = obj;
                        break;
                    }
                }

                if (channelSub == null)
                {
                    channelSub = new JObject
                    {
                        ["type"] = "Primary",
                        ["aliasName"] = "",
                        ["channelReferral"] = channelReferral,
                        ["balance"] = 0m
                    };
                    details.Add(channelSub);
                }

                // Decrement balance
                var currentBalance = channelSub["balance"]?.Value<decimal?>() ?? 0m;
                var newBalance = Math.Max(0m, currentBalance - subscriptionUsed);
                channelSub["balance"] = newBalance;

                // Recalculate total subscription balance (sum of all balances in array)
                decimal totalSubscription = 0m;
                foreach (var item in details)
                {
                    if (item is JObject subObj)
                    {
                        var balance = subObj["balance"]?.Value<decimal?>() ?? 0m;
                        totalSubscription += balance;
                    }
                }

                // Update database
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        UPDATE {tableName}
                        SET subscription = @subscription,
                            subscription_details = @subscriptionDetails::jsonb,
                            totalpoints = transferable + nontransferable + community + special + overflow + @subscription,
                            last_updated = NOW()
                        WHERE referral_code = @referral
                    ";
                    cmd.Parameters.AddWithValue("@referral", buyerReferral);
                    cmd.Parameters.AddWithValue("@subscription", totalSubscription);
                    cmd.Parameters.AddWithValue("@subscriptionDetails", details.ToString());
                    cmd.ExecuteNonQuery();
                }

                _debugTrace?.Write($"[UpdateChannelSubscriptionDetailsAfterPurchase] Updated subscription balance to {totalSubscription} for {buyerReferral}");
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[UpdateChannelSubscriptionDetailsAfterPurchase] Error: {ex.Message}");
                throw;
            }
        }

        // Helper: Update memberaccess with tierIdentifier after successful subscription purchase
        private void UpdateMemberAccessAfterSubscriptionPurchase(
            string memberReferral,
            string channelReferral,
            int tierIdentifier,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            try
            {
                var tableName = "memberaccess";

                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        INSERT INTO {tableName} (
                            assignedreferral, channelreferral, membersubscriptionid
                        ) VALUES (
                            @memberReferral, @channelReferral, @tierIdentifier
                        )
                        ON CONFLICT (assignedreferral, channelreferral)
                        DO UPDATE SET
                            membersubscriptionid = @tierIdentifier
                    ";
                    cmd.Parameters.AddWithValue("@memberReferral", memberReferral);
                    cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                    cmd.Parameters.AddWithValue("@tierIdentifier", tierIdentifier);
                    cmd.ExecuteNonQuery();
                }

                _debugTrace?.Write($"[UpdateMemberAccessAfterSubscriptionPurchase] Updated memberaccess: member={memberReferral}, channel={channelReferral}, tier={tierIdentifier}");
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[UpdateMemberAccessAfterSubscriptionPurchase] Error: {ex.Message}");
                throw;
            }
        }

        // ============================================================
        // TRANSACTION TYPE 6: donation_distribution
        // ============================================================
        private JObject ProcessDonationDistribution(
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            _debugTrace?.Write($"[ProcessDonationDistribution] Starting, mode={mode}");
            _debugTrace?.Write($"[ProcessDonationDistribution] Payload keys: {string.Join(", ", payload.Properties().Select(p => p.Name))}");

            // 1. Validate payload (HARD REQUIREMENTS)
            var memberReferral = payload.Value<string>("memberReferral")
                ?? payload.Value<string>("donator")
                ?? throw new InvalidOperationException("memberReferral is required");

            var channelReferral = payload.Value<string>("channelReferral")
                ?? payload.Value<string>("nonProfitChannel")
                ?? throw new InvalidOperationException("channelReferral is required");

            // Check if this is a resume (approval granted) - MUST check FIRST before any validation
            var resumeToken = payload.Value<string>("resumeToken");
            var approved = payload.Value<bool?>("approved") ?? false;
            var fundingToken = payload.Value<string>("fundingToken");

            if (!string.IsNullOrWhiteSpace(resumeToken) && approved && !string.IsNullOrWhiteSpace(fundingToken))
            {
                // RESUME PATH: Execute after approval (same pattern as transaction types 1-5)
                // Get amount from payload - ExecuteDonationResume will validate it
                var resumeAmount = payload.Value<decimal?>("amount")
                    ?? throw new InvalidOperationException("amount is required in resume payload");

                _debugTrace?.Write($"[ProcessDonationDistribution] RESUME PATH: Donator={memberReferral}, Channel={channelReferral}, Amount={resumeAmount}");
                
                return ExecuteDonationResume(
                    resumeToken,
                    fundingToken,
                    memberReferral,
                    channelReferral,
                    resumeAmount,
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    start);
            }

            // PREFLIGHT PATH: Validate amount normally
            var amount = payload.Value<decimal?>("amount")
                ?? throw new InvalidOperationException("amount is required");

            if (amount <= 0)
                throw new InvalidOperationException("amount must be greater than zero");

            _debugTrace?.Write($"[ProcessDonationDistribution] PREFLIGHT PATH: Donator={memberReferral}, Channel={channelReferral}, Amount={amount}");

            // PREFLIGHT PATH: Calculate funding needs, create payment intent if needed
            return ExecuteDonationPreflight(
                memberReferral,
                channelReferral,
                amount,
                payload,
                metadata,
                mode,
                conn,
                tx);
        }

        private JObject ExecuteDonationPreflight(
            string memberReferral,
            string channelReferral,
            decimal amount,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // 1. Validate Channel Category (MANDATORY - must be nonprofit)
            var channelTable = "channel";
            string? channelCategory = null;
            
            // Get category from payload (for testing different categories) or query database
            string? requestedCategory = payload.Value<string>("channelCategory");
            
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = $@"
                    SELECT category
                    FROM {channelTable}
                    WHERE assignedreferral = @channelReferral
                    LIMIT 1
                ";
                cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                var result = cmd.ExecuteScalar();
                channelCategory = result?.ToString();
            }

            // Auto-create channel if it doesn't exist (TEST mode only)
            if (string.IsNullOrWhiteSpace(channelCategory) && (mode == "TEST" || mode == "test"))
            {
                _debugTrace?.Write($"[DONATION_PREFLIGHT] Channel {channelReferral} not found, auto-creating in TEST mode");
                
                // Use requested category from payload, or default to "Nonprofit"
                string categoryToCreate = !string.IsNullOrWhiteSpace(requestedCategory) 
                    ? requestedCategory 
                    : "Nonprofit";
                
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        INSERT INTO {channelTable} (
                            assignedreferral, 
                            shortname, 
                            category,
                            status,
                            createdon
                        )
                        VALUES (
                            @channelReferral,
                            @channelReferral,
                            @category,
                            'REVIEW',
                            NOW()
                        )
                        ON CONFLICT (assignedreferral) DO NOTHING
                    ";
                    cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                    cmd.Parameters.AddWithValue("@category", categoryToCreate);
                    cmd.ExecuteNonQuery();
                }
                
                // Re-query to get the category
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        SELECT category
                        FROM {channelTable}
                        WHERE assignedreferral = @channelReferral
                        LIMIT 1
                    ";
                    cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                    var result = cmd.ExecuteScalar();
                    channelCategory = result?.ToString();
                }
                
                _debugTrace?.Write($"[DONATION_PREFLIGHT] Auto-created channel {channelReferral} with category {categoryToCreate}");
            }

            if (string.IsNullOrWhiteSpace(channelCategory))
            {
                _debugTrace?.Write($"[DONATION_PREFLIGHT] Channel {channelReferral} not found and could not be created");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Channel {channelReferral} not found"
                };
            }

            // Normalize category: trim, case-insensitive comparison
            var normalizedCategory = channelCategory.Trim();
            if (!string.Equals(normalizedCategory, "nonprofit", StringComparison.OrdinalIgnoreCase))
            {
                _debugTrace?.Write($"[DONATION_PREFLIGHT] Channel {channelReferral} category '{channelCategory}' is not 'nonprofit'");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Channel category must be 'nonprofit'. Found: '{channelCategory}'"
                };
            }

            _debugTrace?.Write($"[DONATION_PREFLIGHT] Channel category validated: {normalizedCategory}");

            // 2. Load Donator Wallet Snapshot (only transferable + non-transferable)
            var wallet = _balances.LoadWalletSnapshot(memberReferral, mode, conn, tx);

            // 3. Calculate Debit Vector (transferable + non-transferable only)
            var debit = BalanceVector.ForSpend(memberReferral);
            decimal remainingAmount = amount;

            // Priority 1: Transferable
            if (remainingAmount > 0 && wallet.Transferable > 0)
            {
                var transferableUsed = Math.Min(wallet.Transferable, remainingAmount);
                debit.Transferable = transferableUsed;
                remainingAmount -= transferableUsed;
            }

            // Priority 2: Non-transferable
            if (remainingAmount > 0 && wallet.NonTransferable > 0)
            {
                var nonTransferableUsed = Math.Min(wallet.NonTransferable, remainingAmount);
                debit.NonTransferable = nonTransferableUsed;
                remainingAmount -= nonTransferableUsed;
            }

            var shortfall = remainingAmount;
            var internalFundingTotal = debit.Transferable + debit.NonTransferable;

            _debugTrace?.Write($"[DONATION_PREFLIGHT] Donator={memberReferral}, Amount={amount}, InternalFunding={internalFundingTotal}, Shortfall={shortfall}, Mode={mode}");

            // 4. If no shortfall, proceed directly to execution
            if (shortfall <= 0)
            {
                _debugTrace?.Write($"[DONATION_PREFLIGHT] No shortfall detected, executing immediately");
                // No external funding needed - execute immediately
                return ExecuteDonationDistribution(
                    memberReferral,
                    channelReferral,
                    amount,
                    debit,
                    null, // no external payment
                    payload,
                    metadata,
                    mode,
                    conn,
                    tx,
                    DateTime.UtcNow);
            }

            // 5. Validate country allows credit card charges (if shortfall requires credit card)
            var countryIso2 = payload.Value<string>("countryIso2");
            if (string.IsNullOrWhiteSpace(countryIso2))
            {
                _debugTrace?.Write($"[DONATION_PREFLIGHT] Missing countryIso2 in payload");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = "countryIso2 is required for credit card transactions"
                };
            }

            var countryAllowsCreditCard = CheckCountryAllowsCreditCard(conn, countryIso2);
            _debugTrace?.Write($"[DONATION_PREFLIGHT] Country={countryIso2}, AllowsCreditCard={countryAllowsCreditCard}");

            if (!countryAllowsCreditCard)
            {
                _debugTrace?.Write($"[DONATION_PREFLIGHT] Country {countryIso2} does not allow credit card charges");
                return new JObject
                {
                    ["ok"] = false,
                    ["error"] = $"Credit card transactions are not allowed for country {countryIso2}"
                };
            }

            // 6. Calculate surcharge and total charge
            _debugTrace?.Write($"[DONATION_PREFLIGHT] Shortfall detected: {shortfall}, creating payment intent");
            
            decimal surchargePercentage = GetCreditCardSurchargePercentage();
            var surcharge = Math.Round(shortfall * surchargePercentage, 2);
            var totalCharge = shortfall + surcharge;
            
            _debugTrace?.Write($"[DONATION_PREFLIGHT] Surcharge={surcharge}, TotalCharge={totalCharge}");

            // 7. Create payment intent
            var secureToken = Guid.NewGuid();
            var intentId = Guid.NewGuid();

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO transaction_payment_intents (
                        id, secure_token, transaction_type, member_referral,
                        gross_amount, transferable_used, external_required,
                        external_amount, surcharge_amount, funding_method,
                        status, payload_snapshot, metadata_snapshot, mode
                    ) VALUES (
                        @id, @secureToken, @transactionType, @memberReferral,
                        @grossAmount, @transferableUsed, @externalRequired,
                        @externalAmount, @surchargeAmount, @fundingMethod,
                        @status, @payloadSnapshot::jsonb, @metadataSnapshot::jsonb, @mode
                    )";
                cmd.Parameters.AddWithValue("@id", intentId);
                cmd.Parameters.AddWithValue("@secureToken", secureToken);
                cmd.Parameters.AddWithValue("@transactionType", "donation_distribution");
                cmd.Parameters.AddWithValue("@memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("@grossAmount", amount);
                
                var totalInternalUsed = debit.Transferable + debit.NonTransferable;
                cmd.Parameters.AddWithValue("@transferableUsed", totalInternalUsed);
                cmd.Parameters.AddWithValue("@externalRequired", true);
                cmd.Parameters.AddWithValue("@externalAmount", shortfall);
                cmd.Parameters.AddWithValue("@surchargeAmount", surcharge);
                cmd.Parameters.AddWithValue("@fundingMethod", "credit_card");
                cmd.Parameters.AddWithValue("@status", "pending_approval");
                cmd.Parameters.AddWithValue("@payloadSnapshot", payload.ToString());
                cmd.Parameters.AddWithValue("@metadataSnapshot", metadata.ToString());
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.ExecuteNonQuery();
            }

            tx.Commit();

            // 8. Get exchange rate and currency info for non-US countries
            string? memberCurrencyCode = null;
            decimal? memberExchangeRate = null;
            decimal? memberConvertedAmount = null;

            if (!string.IsNullOrWhiteSpace(countryIso2) && countryIso2.ToUpper() != "US" && _countriesService != null)
            {
                // Get exchange rate from cache (no database reads)
                memberExchangeRate = _countriesService.GetExchangeRateUsdToCountry(countryIso2);
                
                // Get currency code from cached countries
                var countries = _countriesService.GetAllCountriesForManagement();
                var country = countries.FirstOrDefault(c => 
                    (c.ContainsKey("iso2") ? c["iso2"]?.ToString() : null)?.ToUpper() == countryIso2.ToUpper());
                
                if (country != null)
                {
                    memberCurrencyCode = country.ContainsKey("currencyCode") ? country["currencyCode"]?.ToString() : null;
                    
                    // Calculate converted amount if we have exchange rate
                    if (memberExchangeRate.HasValue && memberExchangeRate.Value > 0)
                    {
                        memberConvertedAmount = Math.Round(totalCharge * memberExchangeRate.Value, 2);
                    }
                }
            }

            // 9. Return approval required response
            var response = new JObject
            {
                ["ok"] = false,
                ["requiresApproval"] = true,
                ["approvalType"] = "credit_card",
                ["transactionType"] = "donation_distribution",
                ["transferableUsed"] = debit.Transferable,
                ["nonTransferableUsed"] = debit.NonTransferable,
                ["externalRequired"] = shortfall,
                ["surcharge"] = surcharge,
                ["totalCharge"] = totalCharge,
                ["resumeToken"] = secureToken.ToString()
            };

            // Add country and currency info if available
            if (!string.IsNullOrWhiteSpace(countryIso2))
            {
                response["countryIso2"] = countryIso2;
            }
            if (!string.IsNullOrWhiteSpace(memberCurrencyCode))
            {
                response["currencyCode"] = memberCurrencyCode;
            }
            if (memberExchangeRate.HasValue)
            {
                response["exchangeRate"] = memberExchangeRate.Value;
            }
            if (memberConvertedAmount.HasValue)
            {
                response["convertedAmount"] = memberConvertedAmount.Value;
            }

            return response;
        }

        private JObject ExecuteDonationResume(
            string resumeToken,
            string fundingToken,
            string memberReferral,
            string channelReferral,
            decimal amount,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            // 1. Resolve intent
            Guid intentGuid;
            if (!Guid.TryParse(resumeToken, out intentGuid))
                return new JObject { ["ok"] = false, ["error"] = "Invalid resumeToken" };

            Guid intentId;
            decimal totalInternalUsed;
            decimal externalAmount;
            decimal surchargeAmount;

            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    SELECT id, transferable_used, external_amount, surcharge_amount, status
                    FROM transaction_payment_intents
                    WHERE secure_token = @secureToken
                      AND transaction_type = 'donation_distribution'
                      AND status = 'pending_approval'
                ";
                cmd.Parameters.AddWithValue("@secureToken", intentGuid);

                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return new JObject { ["ok"] = false, ["error"] = "Payment intent not found or already processed" };

                intentId = reader.GetGuid(0);
                totalInternalUsed = reader.GetDecimal(1);
                externalAmount = reader.GetDecimal(2);
                surchargeAmount = reader.GetDecimal(3);
                var status = reader.GetString(4);

                if (status != "pending_approval")
                    return new JObject { ["ok"] = false, ["error"] = $"Payment intent status is {status}, expected pending_approval" };
            }

            // Validate amount - must be positive (same simple validation as transaction types 1-5)
            if (amount <= 0)
            {
                _debugTrace?.Write($"[ExecuteDonationResume] Invalid amount: {amount}");
                return new JObject { ["ok"] = false, ["error"] = $"Invalid amount: {amount}. Amount must be greater than zero." };
            }

            // 2. Execute Stripe charge (via ExternalPaymentService)
            string? providerChargeId = null;
            decimal processingFee = 0m;
            decimal netFunded = 0m;

            var totalChargeToCustomer = externalAmount + surchargeAmount;

            if (_externalPayment != null && totalChargeToCustomer > 0)
            {
                var amountCents = (int)Math.Round(totalChargeToCustomer * 100);
                var (success, chargeId, gross, fee, net, error) = _externalPayment.CreateAndCapturePayment(
                    memberReferral,
                    amountCents,
                    fundingToken
                ).GetAwaiter().GetResult();

                if (!success)
                    return new JObject { ["ok"] = false, ["error"] = error ?? "Payment failed" };

                providerChargeId = chargeId;
                processingFee = fee;
                netFunded = externalAmount; // Fund the full shortfall amount
            }
            else
            {
                // Mock for testing when ExternalPaymentService not available
                providerChargeId = $"ch_mock_{Guid.NewGuid():N}";
                processingFee = Math.Round(totalChargeToCustomer * 0.029m + 0.30m, 2);
                netFunded = externalAmount;
            }

            // 3. Persist external payment ledger
            Guid externalPaymentId = Guid.NewGuid();
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    INSERT INTO external_payment_ledger (
                        id, intent_id, member_referral, provider,
                        provider_charge_id, gross_charge_amount,
                        processing_fee_amount, net_funded_amount,
                        currency, transaction_type, status, mode, metadata
                    ) VALUES (
                        @id, @intentId, @memberReferral, @provider,
                        @providerChargeId, @grossChargeAmount,
                        @processingFeeAmount, @netFundedAmount,
                        @currency, @transactionType, @status, @mode, @metadata::jsonb
                    )";
                cmd.Parameters.AddWithValue("@id", externalPaymentId);
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("@provider", "stripe");
                cmd.Parameters.AddWithValue("@providerChargeId", providerChargeId ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@grossChargeAmount", totalChargeToCustomer);
                cmd.Parameters.AddWithValue("@processingFeeAmount", processingFee);
                cmd.Parameters.AddWithValue("@netFundedAmount", netFunded);
                cmd.Parameters.AddWithValue("@currency", "USD");
                cmd.Parameters.AddWithValue("@transactionType", "donation_distribution");
                cmd.Parameters.AddWithValue("@status", "captured"); // Must be one of: authorized, captured, failed, refunded
                cmd.Parameters.AddWithValue("@mode", mode);
                cmd.Parameters.AddWithValue("@metadata", "{}");
                cmd.ExecuteNonQuery();
            }

            // 4. Update payment intent status (same pattern as other transaction types)
            using (var cmd = conn.CreateCommand())
            {
                cmd.Transaction = tx;
                cmd.CommandText = @"
                    UPDATE transaction_payment_intents
                    SET status = 'approved',
                        funding_token = @fundingToken,
                        consumed_at = CURRENT_TIMESTAMP
                    WHERE id = @intentId
                ";
                cmd.Parameters.AddWithValue("@intentId", intentId);
                cmd.Parameters.AddWithValue("@fundingToken", fundingToken);
                cmd.ExecuteNonQuery();
            }

            // 5. Reconstruct debit vector from payment intent
            var debit = BalanceVector.ForSpend(memberReferral);
            // The payment intent stores totalInternalUsed, but we need to reconstruct the breakdown
            // For donation_distribution, we use transferable + non-transferable only
            // If totalInternalUsed is 0 (credit card only), debit will be empty which is fine
            if (totalInternalUsed > 0)
            {
                var wallet = _balances.LoadWalletSnapshot(memberReferral, mode, conn, tx);
                var remainingForDebit = totalInternalUsed;
                
                if (remainingForDebit > 0 && wallet.Transferable > 0)
                {
                    var transferableUsed = Math.Min(wallet.Transferable, remainingForDebit);
                    debit.Transferable = transferableUsed;
                    remainingForDebit -= transferableUsed;
                }
                
                if (remainingForDebit > 0 && wallet.NonTransferable > 0)
                {
                    var nonTransferableUsed = Math.Min(wallet.NonTransferable, remainingForDebit);
                    debit.NonTransferable = nonTransferableUsed;
                    remainingForDebit -= nonTransferableUsed;
                }
            }

            // 6. Execute distribution
            return ExecuteDonationDistribution(
                memberReferral,
                channelReferral,
                amount,
                debit,
                externalPaymentId,
                payload,
                metadata,
                mode,
                conn,
                tx,
                start);
        }

        private JObject ExecuteDonationDistribution(
            string memberReferral,
            string channelReferral,
            decimal amount,
            BalanceVector debit,
            Guid? externalPaymentId,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            DateTime start)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // 1. Custom Distribution Logic (100% to channel, NO SMART CONTRACT)
            // Calculate total credit amount: points debited + external funding
            // For credit card only, debit will be 0, so use the full amount
            var totalDebited = debit.Transferable + debit.NonTransferable;
            var totalCreditAmount = totalDebited > 0 ? totalDebited : amount; // Use amount if no points debited (CC only)
            
            // Only create credit vector if there's an amount to credit (should always be > 0 at this point)
            if (totalCreditAmount <= 0)
            {
                _debugTrace?.Write($"[ExecuteDonationDistribution] WARNING: totalCreditAmount is {totalCreditAmount}, using amount {amount}");
                totalCreditAmount = amount;
            }
            
            var creditVectors = new List<BalanceVector>
            {
                BalanceVector.CreditTransferable(channelReferral, totalCreditAmount)
            };

            // 2. Apply Balance Vectors
            _balances.ApplyVectors(
                debit,
                creditVectors,
                "donation_distribution",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // 3. Write Ledger Entries
            var ledgerMetadata = new JObject
            {
                ["transactionType"] = "donation_distribution",
                ["donator"] = memberReferral,
                ["nonProfitChannel"] = channelReferral,
                ["amount"] = amount,
                ["debit"] = new JObject
                {
                    ["transferable"] = debit.Transferable,
                    ["nonTransferable"] = debit.NonTransferable
                },
                ["categoryValidated"] = true
            };
            
            if (externalPaymentId.HasValue)
            {
                ledgerMetadata["externalPaymentId"] = externalPaymentId.Value.ToString();
            }
            
            metadata.Merge(ledgerMetadata);

            // For credit card only donations, we need to write a DEBIT entry for external payment
            // BEFORE calling WriteLedger, to ensure it's included in the transaction
            // This balances the CREDIT entry for points issued to the channel
            if (externalPaymentId.HasValue)
            {
                var pointsDebited = debit.Transferable + debit.NonTransferable;
                if (pointsDebited <= 0)
                {
                    // Credit card only - write DEBIT for external payment (cash)
                    // This balances the CREDIT for points issued to the channel
                    var ledgerTable = "ledger";
                    var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
                    
                    // Get external payment details
                    decimal externalAmount = 0m;
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = @"
                            SELECT net_funded_amount
                            FROM external_payment_ledger
                            WHERE id = @externalPaymentId
                        ";
                        cmd.Parameters.AddWithValue("@externalPaymentId", externalPaymentId.Value);
                        var result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            externalAmount = Convert.ToDecimal(result);
                        }
                    }
                    
                    // Use the amount parameter if external amount is 0 or not found
                    if (externalAmount <= 0)
                    {
                        externalAmount = amount;
                    }
                    
                    // Write DEBIT entry for external payment (cash)
                    // For GAAP: Cash inflow (debit cash account) balances points issuance (credit points account)
                    // Use the member's referral for the debit (they paid the cash), but this is a cash account, not points
                    // The account code should reflect this is cash/external, not points
                    var externalDebitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "donation_distribution", "transferable");
                    
                    // IMPORTANT: For credit card only donations, the member pays cash, so we debit the member's cash account
                    // This balances the credit of points to the channel
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = $@"
                            INSERT INTO {ledgerTable} (
                                tx_id, referral_code, tx_type, posting_code, point_type, account_code,
                                amount, transaction_date, metadata, source_system, created_at, entry_type
                            ) VALUES (
                                @txId, @referralCode, @txType, @postingCode, @pointType, @accountCode,
                                @amount, CURRENT_TIMESTAMP, @metadata::jsonb, @sourceSystem, CURRENT_TIMESTAMP, @entryType
                            )";
                        cmd.Parameters.AddWithValue("@txId", txId);
                        cmd.Parameters.AddWithValue("@referralCode", memberReferral); // Member paid the cash
                        cmd.Parameters.AddWithValue("@txType", "donation_distribution");
                        cmd.Parameters.AddWithValue("@postingCode", DBNull.Value);
                        cmd.Parameters.AddWithValue("@pointType", "transferable"); // Using transferable as point type for external payment
                        cmd.Parameters.AddWithValue("@accountCode", externalDebitAccountCode);
                        cmd.Parameters.AddWithValue("@amount", Math.Abs(externalAmount)); // Store absolute value
                        cmd.Parameters.AddWithValue("@metadata", new JObject
                        {
                            ["externalPaymentId"] = externalPaymentId.Value.ToString(),
                            ["fundingSource"] = "credit_card",
                            ["accountingNote"] = "External payment debit (cash) to balance points credit for donation",
                            ["isExternalPayment"] = true
                        }.ToString());
                        cmd.Parameters.AddWithValue("@sourceSystem", "accounting_service");
                        cmd.Parameters.AddWithValue("@entryType", "DEBIT");
                        cmd.ExecuteNonQuery();
                    }
                    
                    _debugTrace?.Write($"[ExecuteDonationDistribution] Wrote external payment DEBIT: {externalAmount} for credit card only donation");
                }
            }

            WriteLedger(
                txId,
                "donation_distribution",
                debit,
                creditVectors,
                payload,
                metadata,
                mode,
                conn,
                tx);

            tx.Commit();

            // 4. Read back ledger rows
            var ledgerRows = new JArray();
            using (var read = conn.CreateCommand())
            {
                read.CommandText = $@"
                    SELECT referral_code, tx_type, point_type, account_number, amount
                    FROM {("ledger")}
                    WHERE tx_id = @txId
                    ORDER BY created_at
                ";
                read.Parameters.AddWithValue("@txId", txId);

                using var r = read.ExecuteReader();
                while (r.Read())
                {
                    ledgerRows.Add(new JObject
                    {
                        ["ledgerName"] = "ledger",
                        ["referralCode"] = r.GetString(0),
                        ["txType"] = r.GetString(1),
                        ["pointType"] = r.GetString(2),
                        ["accountCode"] = r.IsDBNull(3) ? null : r.GetString(3),
                        ["amount"] = r.GetDecimal(4)
                    });
                }
            }

            // 5. Return result
            // For credit card only, if there's an external payment, the debit total should reflect the external payment, not points
            var debitTotal = debit.Transferable + debit.NonTransferable;
            if (externalPaymentId.HasValue && debitTotal <= 0)
            {
                // Credit card only - use external amount for debit total in response
                decimal externalAmount = 0m;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        SELECT net_funded_amount
                        FROM external_payment_ledger
                        WHERE id = @externalPaymentId
                    ";
                    cmd.Parameters.AddWithValue("@externalPaymentId", externalPaymentId.Value);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        externalAmount = Convert.ToDecimal(result);
                    }
                }
                if (externalAmount <= 0)
                {
                    externalAmount = amount;
                }
                debitTotal = externalAmount; // Show external amount as debit total for credit card only
            }
            var debitAccountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "donation_distribution", "transferable");

            var creditsArray = new JArray(creditVectors.Select(c =>
            {
                var creditTotal = c.Transferable + c.NonTransferable;
                var accountCode = AccountingHelpers.ResolveAccountCode(conn, tx, "donation_distribution", "transferable");
                return JObject.FromObject(new
                {
                    owner = c.Owner,
                    transferable = c.Transferable,
                    nonTransferable = 0m, // Credits go to transferable bucket
                    community = 0m,
                    special = 0m,
                    overflow = 0m,
                    subscription = 0m,
                    total = creditTotal,
                    accountCode = accountCode
                });
            }));

            return new JObject
            {
                ["ok"] = true,
                ["executionMs"] = (int)(DateTime.UtcNow - start).TotalMilliseconds,
                ["debit"] = JObject.FromObject(new
                {
                    owner = debit.Owner,
                    transferable = debit.Transferable,
                    nonTransferable = debit.NonTransferable,
                    community = 0m,
                    special = 0m,
                    overflow = 0m,
                    subscription = 0m,
                    total = debitTotal,
                    accountCode = debitAccountCode
                }),
                ["credits"] = creditsArray,
                ["ledger"] = ledgerRows,
                ["transactionType"] = "donation_distribution",
                ["mode"] = mode,
                ["txId"] = txId
            };
        }

        // Helper: Insert into memberpurchases table
        private void InsertMemberPurchase(
            string memberReferral,
            string channelReferral,
            long contentId,
            decimal amount,
            string currency,
            string? transactionRef,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            try
            {
                // Determine which table to use based on mode
                var isTest = !string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
                var tableName = "memberpurchases";
                
                _debugTrace?.Write($"[InsertMemberPurchase] Using table: {tableName}, mode: {mode}");

                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = $@"
                        INSERT INTO {tableName} (
                            memberreferral, channelreferral, contentid,
                            purchasetype, amount, currency,
                            purchasesource, status, transactionref,
                            metadata, createdon, updatedon
                        ) VALUES (
                            @memberReferral, @channelReferral, @contentId,
                            @purchaseType, @amount, @currency,
                            @purchaseSource, @status, @transactionRef,
                            @metadata::jsonb, NOW(), NOW()
                        )
                        RETURNING purchaseid
                    ";
                    cmd.Parameters.AddWithValue("@memberReferral", memberReferral);
                    cmd.Parameters.AddWithValue("@channelReferral", channelReferral);
                    cmd.Parameters.AddWithValue("@contentId", contentId);
                    cmd.Parameters.AddWithValue("@purchaseType", "PURCHASE"); // Default as per schema
                    cmd.Parameters.AddWithValue("@amount", amount);
                    cmd.Parameters.AddWithValue("@currency", currency);
                    cmd.Parameters.AddWithValue("@purchaseSource", "WEB"); // Default, could be enhanced
                    cmd.Parameters.AddWithValue("@status", "ACTIVE");
                    cmd.Parameters.AddWithValue("@transactionRef", transactionRef ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@metadata", "{}");
                    
                    var purchaseId = cmd.ExecuteScalar();
                    _debugTrace?.Write($"[InsertMemberPurchase] Inserted purchase ID: {purchaseId} into {tableName}");
                }
            }
            catch (Exception ex)
            {
                _debugTrace?.Write($"[InsertMemberPurchase] Error: {ex.Message}");
                throw;
            }
        }

        //--ensure ledger partition exists
        // Creates the partition for the current date if it doesn't exist
        // This prevents "23514: no partition found" errors when inserting into partitioned ledger table
        private void EnsureLedgerPartition(
            bool isTest,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            // Test table is not partitioned, no need to ensure partition
            if (isTest)
                return;

            var partitionDate = DateTime.UtcNow.Date;
            var partitionName = $"ledger_{partitionDate:yyyy_MM_dd}";
            var partitionStart = partitionDate.ToString("yyyy-MM-dd HH:mm:ss.ffffffZ");
            var partitionEnd = partitionDate.AddDays(1).ToString("yyyy-MM-dd HH:mm:ss.ffffffZ");

            _debugTrace?.Write($"[EnsureLedgerPartition] Checking partition: {partitionName} for date {partitionDate:yyyy-MM-dd}");

            // Check if partition exists
            using (var checkCmd = conn.CreateCommand())
            {
                checkCmd.Transaction = tx;
                checkCmd.CommandText = @"
                    SELECT 1 FROM pg_class c
                    JOIN pg_namespace n ON n.oid = c.relnamespace
                    WHERE n.nspname = 'public' 
                      AND c.relname = @partitionName;";
                checkCmd.Parameters.AddWithValue("partitionName", partitionName);

                var exists = checkCmd.ExecuteScalar() != null;

                if (!exists)
                {
                    _debugTrace?.Write($"[EnsureLedgerPartition] Partition {partitionName} does not exist. Creating...");
                    try
                    {
                        using var createCmd = conn.CreateCommand();
                        createCmd.Transaction = tx;
                        createCmd.CommandText = $@"
                            CREATE TABLE IF NOT EXISTS public.{partitionName} PARTITION OF public.ledger
                            FOR VALUES FROM ('{partitionStart}') TO ('{partitionEnd}');";
                        createCmd.ExecuteNonQuery();
                        _debugTrace?.Write($"[EnsureLedgerPartition] ✅ Created partition: {partitionName} for range '{partitionStart}' to '{partitionEnd}'");
                    }
                    catch (Npgsql.PostgresException pex) when (pex.SqlState == "42P07") // duplicate_table
                    {
                        // This can happen in a race condition if another concurrent transaction
                        // created the partition just before this one. It's safe to ignore.
                        _debugTrace?.Write($"[EnsureLedgerPartition] ℹ️ Partition {partitionName} already exists (race condition), continuing.");
                    }
                    catch (Exception ex)
                    {
                        _debugTrace?.Write($"[EnsureLedgerPartition] ❌ Error creating partition {partitionName}: {ex.Message}, StackTrace: {ex.StackTrace}");
                        throw; // Re-throw if it's another type of error
                    }
                }
                else
                {
                    _debugTrace?.Write($"[EnsureLedgerPartition] ℹ️ Partition {partitionName} for {partitionDate:yyyy-MM-dd} already exists.");
                }
            }
        }

        public void WriteLedger(
            string txId,
            string transactionType,
            BalanceVector debit,
            IReadOnlyList<BalanceVector> credits,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            var isTest = !string.Equals(mode, "production", StringComparison.OrdinalIgnoreCase);
            var ledgerTable = "ledger";
            
            // Extract transaction description from metadata (if provided)
            var txDescription = metadata?.Value<string>("txDescription");
            
            _debugTrace?.Write($"[WRITE_LEDGER] 🔵 ENTRY: TxId={txId}, Table={ledgerTable}, Type={transactionType}, Mode={mode}, DebitOwner={debit.Owner}, CreditsCount={credits.Count}");

            // CRITICAL: Ensure partition exists before inserting (only for production table)
            // This prevents "23514: no partition found" errors
            EnsureLedgerPartition(isTest, conn, tx);

            // Chart of Accounts Governance: Initialize governance service once for all validations
            var governanceService = new ChartOfAccountsGovernanceService(_connectionString);

            int totalRowsInserted = 0;
            int skippedZeroAmount = 0;

            // Helper function to determine sub-code based on point type
            string GetSubCode(string pointType)
            {
                return pointType.ToLower() switch
                {
                    "transferable" => "WD", // Withdrawable
                    "overflow" => "DO",      // Digital overflow
                    "community" => "CD",      // Community
                    "special" => "UD",        // Unencumbered
                    "subscription" => "UD",   // Unencumbered
                    "nontransferable" => "UD", // Unencumbered
                    "encumbered" => "ED",     // Encumbered
                    _ => "WD" // Default to withdrawable
                };
            }

            void Insert(string owner, string pointType, decimal amount)
            {
                if (amount == 0m)
                {
                    skippedZeroAmount++;
                    _debugTrace?.Write($"[WRITE_LEDGER] ⏭️ Skipping zero amount: Owner={owner}, PointType={pointType}");
                    return;
                }

                var accountCode =
                    AccountingHelpers.ResolveAccountCode(conn, tx, transactionType, pointType);
                
                // Chart of Accounts Governance: Intercompany transaction detection and enforcement
                var counterpartyCode = metadata?.Value<string>("counterpartyCode") ?? payload?.Value<string>("counterpartyCode");
                if (!string.IsNullOrWhiteSpace(counterpartyCode))
                {
                    var intercompanyValidation = governanceService.ValidateIntercompanyTransaction(
                        owner, counterpartyCode, accountCode, conn, tx);
                    
                    if (!intercompanyValidation.IsValid)
                    {
                        _debugTrace?.Write($"[WRITE_LEDGER] ❌ Intercompany validation failed: {string.Join("; ", intercompanyValidation.Errors)}");
                        throw new InvalidOperationException($"Chart of Accounts Governance violation: {string.Join("; ", intercompanyValidation.Errors)}");
                    }
                    
                    // Auto-resolve to account 1400 for intercompany transactions
                    accountCode = governanceService.ResolveIntercompanyAccountCode(owner, counterpartyCode, accountCode);
                    if (accountCode == "1400")
                    {
                        _debugTrace?.Write($"[WRITE_LEDGER] 🔄 Auto-resolved to intercompany account 1400 for intercompany transaction");
                    }
                }
                
                // Chart of Accounts Governance: Control account posting restrictions
                var isManualPosting = metadata?.Value<bool>("isManualPosting") ?? false;
                var controlValidation = governanceService.ValidateControlAccountPosting(
                    accountCode, isManualPosting, metadata ?? new JObject());
                
                if (!controlValidation.IsValid)
                {
                    _debugTrace?.Write($"[WRITE_LEDGER] ❌ Control account validation failed: {string.Join("; ", controlValidation.Errors)}");
                    throw new InvalidOperationException($"Chart of Accounts Governance violation: {string.Join("; ", controlValidation.Errors)}");
                }
                
                if (controlValidation.Warnings.Any())
                {
                    _debugTrace?.Write($"[WRITE_LEDGER] ⚠️ Control account warnings: {string.Join("; ", controlValidation.Warnings)}");
                }
                
                // Ledger stores positive amounts only (direction is implicit via account code)
                var absoluteAmount = Math.Abs(amount);
                
                // Determine entry_type: CREDIT for positive amounts, DEBIT for negative amounts
                var entryType = amount >= 0 ? "CREDIT" : "DEBIT";
                
                // Calculate tx_subtype based on point type
                // Allow metadata to override tx_subtype (e.g., 'ARED' for GPS question rewards)
                var txSubtype = metadata?.Value<string>("txSubtype") ?? metadata?.Value<string>("tx_subtype") ?? GetSubCode(pointType);
                
                _debugTrace?.Write($"[WRITE_LEDGER] 💾 Inserting: Owner={owner}, PointType={pointType}, Amount={absoluteAmount}, AccountCode={accountCode}, TxSubtype={txSubtype}, EntryType={entryType}, OriginalAmount={amount}");

                using var cmd = conn.CreateCommand();
                cmd.Transaction = tx;

                cmd.CommandText = $@"
                    INSERT INTO {ledgerTable} (
                        tx_id,
                        referral_code,
                        tx_type,
                        posting_code,
                        tx_subtype,
                        point_type,
                        account_number,
                        amount,
                        transaction_date,
                        metadata,
                        source_system,
                        is_test,
                        tx_description,
                        entry_type
                    )
                    VALUES (
                        @tx_id,
                        @referral_code,
                        @tx_type,
                        @posting_code,
                        @tx_subtype,
                        @point_type,
                        @account_number,
                        @amount,
                        NOW(),
                        @metadata::jsonb,
                        'v3',
                        @is_test,
                        @tx_description,
                        @entry_type
                    );
                ";

                cmd.Parameters.AddWithValue("@tx_id", txId);
                cmd.Parameters.AddWithValue("@referral_code", owner);
                cmd.Parameters.AddWithValue("@tx_type", transactionType);
                cmd.Parameters.AddWithValue("@posting_code", DBNull.Value);
                cmd.Parameters.AddWithValue("@tx_subtype", txSubtype);
                cmd.Parameters.AddWithValue("@point_type", pointType);
                cmd.Parameters.AddWithValue("@account_number", accountCode);
                cmd.Parameters.AddWithValue("@amount", absoluteAmount);
                cmd.Parameters.AddWithValue("@metadata", metadata?.ToString() ?? "{}");
                cmd.Parameters.AddWithValue("@is_test", isTest);
                cmd.Parameters.AddWithValue("@tx_description", (object?)txDescription ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@entry_type", entryType);

                var rowsAffected = cmd.ExecuteNonQuery();
                totalRowsInserted += rowsAffected;
                _debugTrace?.Write($"[WRITE_LEDGER] ✅ Inserted {rowsAffected} row(s) for {owner}/{pointType} (Total: {totalRowsInserted})");
            }

            // ---------------- DEBIT ----------------
            _debugTrace?.Write($"[WRITE_LEDGER] 📝 Writing debit entries for {debit.Owner}: T={debit.Transferable}, NT={debit.NonTransferable}, C={debit.Community}, S={debit.Subscription}, O={debit.Overflow}");
            Insert(debit.Owner, "transferable", -debit.Transferable);
            Insert(debit.Owner, "nonTransferable", -debit.NonTransferable);
            Insert(debit.Owner, "community", -debit.Community);
            Insert(debit.Owner, "special", -debit.Special);
            Insert(debit.Owner, "subscription", -debit.Subscription);
            Insert(debit.Owner, "overflow", -debit.Overflow);

            // ---------------- CREDITS ----------------
            _debugTrace?.Write($"[WRITE_LEDGER] 📝 Writing credit entries (count={credits.Count})");
            int creditIndex = 0;
            foreach (var c in credits)
            {
                creditIndex++;
                _debugTrace?.Write($"[WRITE_LEDGER] 📝 Credit #{creditIndex} for {c.Owner}: T={c.Transferable}, NT={c.NonTransferable}, C={c.Community}, S={c.Subscription}, O={c.Overflow}");
                Insert(c.Owner, "transferable", c.Transferable);
                Insert(c.Owner, "nonTransferable", c.NonTransferable);
                Insert(c.Owner, "community", c.Community);
                Insert(c.Owner, "special", c.Special);
                Insert(c.Owner, "subscription", c.Subscription);
                Insert(c.Owner, "overflow", c.Overflow);
            }
            
            _debugTrace?.Write($"[WRITE_LEDGER] ✅ COMPLETE: Total rows inserted={totalRowsInserted}, Skipped zero amounts={skippedZeroAmount}, Table={ledgerTable}");
        }

    }


    //--------------------------------------------------------------------------------------------------------
    //--balace vector extensions
    internal static class BalanceVectorExtensions
    {
        public static BalanceVector WithTransferable(
            this BalanceVector vector,
            decimal amount)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            vector.Transferable = amount;
            return vector;
        }

        public static BalanceVector WithNonTransferable(
            this BalanceVector vector,
            decimal amount)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            vector.NonTransferable = amount;
            return vector;
        }

        public static BalanceVector WithCommunity(
            this BalanceVector vector,
            decimal amount)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            vector.Community = amount;
            return vector;
        }

        public static BalanceVector WithSpecial(
            this BalanceVector vector,
            decimal amount)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            vector.Special = amount;
            return vector;
        }

        public static BalanceVector WithOverflow(
            this BalanceVector vector,
            decimal amount)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            vector.Overflow = amount;
            return vector;
        }

        public static BalanceVector WithSubscription(
            this BalanceVector vector,
            decimal amount)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));

            vector.Subscription = amount;
            return vector;
        }

        public static BalanceVector Also(
            this BalanceVector vector,
            Action<BalanceVector> apply)
        {
            if (vector == null)
                throw new ArgumentNullException(nameof(vector));
            if (apply == null)
                throw new ArgumentNullException(nameof(apply));

            apply(vector);
            return vector;
        }
    }

    // ============================================================================
    // SHARED ACCOUNTING HELPERS
    // ============================================================================
    internal static class AccountingHelpers
    {
        /// <summary>
        /// FinanceBase rounding standard: 6 decimals, MidpointRounding.AwayFromZero.
        /// Use for all ledger/subledger amount computations.
        /// </summary>
        internal static decimal Round6(decimal x) =>
            Math.Round(x, 6, MidpointRounding.AwayFromZero);

        /// <summary>
        /// Returns account_name from the chart of accounts (finance_account_code) for the given account_number.
        /// Returns empty string if not found.
        /// </summary>
        internal static string GetAccountName(NpgsqlConnection conn, NpgsqlTransaction tx, string accountNumber)
        {
            if (string.IsNullOrWhiteSpace(accountNumber)) return "";
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = "SELECT account_name FROM finance_account_code WHERE account_number = @accountNumber AND is_active = true LIMIT 1";
            cmd.Parameters.AddWithValue("@accountNumber", accountNumber);
            var result = cmd.ExecuteScalar();
            return result != null && result != DBNull.Value ? result.ToString() ?? "" : "";
        }

        /// <summary>
        /// Returns the 2-letter point type abbreviation for display (WD, CD, UD, DO, ED).
        /// Used in ledger row responses so UI can show e.g. "Point Type" column.
        /// </summary>
        internal static string GetPointTypeAbbrev(string? pointType)
        {
            if (string.IsNullOrWhiteSpace(pointType)) return "WD";
            return pointType.Trim().ToLowerInvariant() switch
            {
                "transferable" => "WD",
                "overflow" => "DO",
                "community" => "CD",
                "special" => "UD",
                "subscription" => "UD",
                "nontransferable" => "UD",
                "encumbered" => "ED",
                _ => "WD"
            };
        }

        /// <summary>
        /// Derives transaction code for display when not stored (e.g. reward_distribution read-back).
        /// Based on account_number: 2300=SCO, 4000=IBCI, 4100=GPI, 2310/5000=GPA. Others return empty.
        /// </summary>
        internal static string DeriveTransactionCodeFromAccount(string txType, string accountNumber)
        {
            if (string.IsNullOrWhiteSpace(accountNumber)) return "";
            var n = accountNumber.Trim();
            if (string.Equals(txType, "reward_distribution", StringComparison.OrdinalIgnoreCase))
            {
                if (n == "2300") return "SCO";
                if (n == "4000") return "IBCI";
                if (n == "4100") return "GPI";
                if (n == "2310" || n == "5000") return "GPA";
            }
            return "";
        }

        /// <summary>
        /// Resolves a system referral code from the tokens table.
        /// </summary>
        internal static string ResolveSystemReferral(
            string tokenKey,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
                SELECT stringvalue
                FROM tokens
                WHERE key = @key
            ";
            cmd.Parameters.AddWithValue("@key", tokenKey);

            var result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new InvalidOperationException($"Missing system referral token: {tokenKey}");

            return result.ToString()!;
        }

        /// <summary>
        /// Loads the four 1100 subledger definitions (MEMBER_CASH_POSTING, IMBC_CASH_PENDING, SC_CASH_PENDING, GP_CASH_PENDING) in sort_order.
        /// Name is the display name: COALESCE(account_name, name) so Manage Subledgers edits to account_name appear in preview and production.
        /// Used by BankSubLedgerRowBuilder and CreateBankSubLedgerEntry to resolve descriptions and subledger_definition_id from the catalog.
        /// </summary>
        internal static List<(long Id, string Name)> Get1100SubledgerDefinitions(NpgsqlConnection conn, NpgsqlTransaction tx)
        {
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
                SELECT id, COALESCE(NULLIF(TRIM(account_name), ''), name) AS display_name
                FROM subledger_definition
                WHERE control_account_code = '1100' AND is_active = true
                ORDER BY sort_order";
            var list = new List<(long, string)>();
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    var id = r.GetInt64(0);
                    var displayName = r.GetString(1);
                    list.Add((id, displayName));
                }
            }
            if (list.Count < 4)
                throw new InvalidOperationException($"subledger_definition must have at least 4 active rows for control_account_code 1100; found {list.Count}. Run migration 196.");
            return list;
        }

        /// <summary>
        /// Double-entry guardrail: validates that total debits equal total credits for the given tx_id before commit.
        /// Tolerance 1e-6 (6-decimal ledger precision). Throws LedgerOutOfBalanceException if unbalanced; caller must not commit and should return 400.
        /// </summary>
        internal static void ValidateTransactionBalance(NpgsqlConnection conn, NpgsqlTransaction tx, string txId, string ledgerTable)
        {
            const decimal tolerance = 0.000001m;
            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = $@"
                SELECT
                    COALESCE(SUM(CASE WHEN entry_type = 'DEBIT' THEN amount ELSE 0 END), 0),
                    COALESCE(SUM(CASE WHEN entry_type = 'CREDIT' THEN amount ELSE 0 END), 0)
                FROM {ledgerTable}
                WHERE tx_id = @txId";
            cmd.Parameters.AddWithValue("@txId", txId);
            decimal sumDebit = 0m, sumCredit = 0m;
            using (var r = cmd.ExecuteReader())
            {
                if (r.Read())
                {
                    sumDebit = r.GetDecimal(0);
                    sumCredit = r.GetDecimal(1);
                }
            }
            var diff = Math.Abs(sumDebit - sumCredit);
            if (diff >= tolerance)
                throw new LedgerOutOfBalanceException("LEDGER_OUT_OF_BALANCE: Total debits must equal total credits (double-entry bookkeeping).", sumDebit, sumCredit);
        }

        /// <summary>
        /// Resolves the GAAP account number for a given transaction type and point type.
        /// Uses GAAP-aligned Chart of Accounts (1000-5600).
        /// Returns account_number (VARCHAR) from finance_account_code table.
        /// </summary>
        internal static string ResolveAccountCode(
            NpgsqlConnection conn,
            NpgsqlTransaction tx,
            string transactionType,
            string pointType,
            string? referralCode = null)
        {
            // GAAP Mapping Logic:
            // - All member balance transactions (transferable, nonTransferable, community, subscription, special, overflow)
            //   map to 2100 - Due to Members (Liability) since we owe these points to members
            // - Platform fees map to 4100 - Transaction Fees Revenue
            // - Cash receipts map to 1000 - Cash and Cash Equivalents
            // - Vendor payables map to 2000 - Accounts Payable
            // - Tax liabilities map to 2400 - Indirect Tax Liabilities
            // - Donations to social causes map to 2300 - Due to Social Causes
            // - Intercompany transactions map to 1400 - Intercompany Clearing Account
            // - Genesis Pool allocations map to 2310 - Due to Genesis Pool
            
            // For reward_distribution, check if referral code is a system code (ImagineBC or Genesis Pool)
            if (transactionType?.ToUpper() == "REWARD_DISTRIBUTION" && !string.IsNullOrWhiteSpace(referralCode))
            {
                // Resolve system referral codes to check if this is ImagineBC or Genesis Pool
                var imagineBcReferral = ResolveSystemReferral("IMAGINEBC-ASSIGNED-REFERRAL", conn, tx);
                var genesisPoolReferral = ResolveSystemReferral("GENESIS-POOL-REFERRAL", conn, tx);
                
                if (referralCode == imagineBcReferral)
                {
                    // ImagineBC share → 4100 (Transaction Fees Revenue) - same as IBCI
                    return "4100";
                }
                
                if (referralCode == genesisPoolReferral)
                {
                    // Genesis Pool share → 2310 (Due to Genesis Pool) - same as GPA
                    return "2310";
                }
            }
            
            var accountNumber = (transactionType?.ToUpper(), pointType?.ToLower()) switch
            {
                // ============================================================
                // MEMBER BALANCE TRANSACTIONS → 2100 - Due to Members
                // ============================================================
                // All point balance types (transferable, nonTransferable, community, subscription, special, overflow)
                // represent liabilities we owe to members, so they all map to 2100
                
                // Reward distribution - all balance types
                ("REWARD_DISTRIBUTION", "transferable") => "2100",
                ("REWARD_DISTRIBUTION", "nontransferable") => "2100",
                ("REWARD_DISTRIBUTION", "community") => "2100",
                ("REWARD_DISTRIBUTION", "subscription") => "2100",
                ("REWARD_DISTRIBUTION", "special") => "2100",
                ("REWARD_DISTRIBUTION", "overflow") => "2100",
                
                // Offer purchase distribution - all balance types
                ("OFFER_PURCHASE_DISTRIBUTION", "transferable") => "2100",
                ("OFFER_PURCHASE_DISTRIBUTION", "nontransferable") => "2100",
                ("OFFER_PURCHASE_DISTRIBUTION", "community") => "2100",
                ("OFFER_PURCHASE_DISTRIBUTION", "subscription") => "2100",
                ("OFFER_PURCHASE_DISTRIBUTION", "special") => "2100",
                ("OFFER_PURCHASE_DISTRIBUTION", "overflow") => "2100",
                
                // Content purchase distribution - all balance types
                ("CONTENT_PURCHASE_DISTRIBUTION", "transferable") => "2100",
                ("CONTENT_PURCHASE_DISTRIBUTION", "nontransferable") => "2100",
                ("CONTENT_PURCHASE_DISTRIBUTION", "community") => "2100",
                ("CONTENT_PURCHASE_DISTRIBUTION", "subscription") => "2100",
                ("CONTENT_PURCHASE_DISTRIBUTION", "special") => "2100",
                ("CONTENT_PURCHASE_DISTRIBUTION", "overflow") => "2100",
                
                // Comment payment distribution
                ("COMMENT_PAYMENT_DISTRIBUTION", "transferable") => "2100",
                ("COMMENT_PAYMENT_DISTRIBUTION", "community") => "2100",
                ("COMMENT_PAYMENT_DISTRIBUTION", "overflow") => "2100",
                
                // Subscription purchase distribution - all balance types
                ("SUBSCRIPTION_PURCHASE_DISTRIBUTION", "transferable") => "2100",
                ("SUBSCRIPTION_PURCHASE_DISTRIBUTION", "nontransferable") => "2100",
                ("SUBSCRIPTION_PURCHASE_DISTRIBUTION", "community") => "2100",
                ("SUBSCRIPTION_PURCHASE_DISTRIBUTION", "subscription") => "2100",
                ("SUBSCRIPTION_PURCHASE_DISTRIBUTION", "overflow") => "2100",
                
                // Subscription renewal distribution - all balance types
                ("SUBSCRIPTION_RENEWAL_DISTRIBUTION", "transferable") => "2100",
                ("SUBSCRIPTION_RENEWAL_DISTRIBUTION", "nontransferable") => "2100",
                ("SUBSCRIPTION_RENEWAL_DISTRIBUTION", "community") => "2100",
                ("SUBSCRIPTION_RENEWAL_DISTRIBUTION", "subscription") => "2100",
                ("SUBSCRIPTION_RENEWAL_DISTRIBUTION", "overflow") => "2100",
                
                // Donation distribution - member balances
                ("DONATION_DISTRIBUTION", "transferable") => "2100",
                ("DONATION_DISTRIBUTION", "nontransferable") => "2100",
                
                // Campaign donation - community balance
                ("CAMPAIGN_DONATION", "community") => "2100",
                
                // Member to member transfer
                ("MEMBER_TO_MEMBER_TRANSFER", "transferable") => "2100",
                ("MEMBER_TO_MEMBER_TRANSFER", "community") => "2100",
                
                // Member points purchase - new points issued (creates liability)
                ("MEMBER_POINTS_PURCHASE", "transferable") => "2100",
                ("MEMBER_POINTS_PURCHASE", "nontransferable") => "2100",
                
                // Game/giveaway winnings
                ("GAME_OR_GIVEAWAY_WINNINGS", "transferable") => "2100",
                ("GAME_OR_GIVEAWAY_WINNINGS", "community") => "2100",
                
                // Genesis Pool distribution - distribution to members
                ("GENESIS_POOL_DISTRIBUTION", "transferable") => "2100",
                
                // Member withdrawal
                ("MEMBER_WITHDRAWAL", "transferable") => "2100",
                
                // Legacy revenue split
                ("LEGACY_REVENUE_SPLIT", "transferable") => "2100",
                
                // Referral reward
                ("REFERRAL_REWARD", "transferable") => "2100",
                
                // ID verification fee - deduction from member balance
                ("ID_VERIFICATION_FEE", "transferable") => "2100",
                
                // Buy now pay later
                ("BUY_NOW_PAY_LATER_CONTRACT", "transferable") => "2100",
                
                // Campaign balance credit
                ("CAMPAIGN_BALANCE_CREDIT", "transferable") => "2100",
                ("CAMPAIGN_BALANCE_CREDIT", "community") => "2100",
                
                // Brand to campaign transfer
                ("BRAND_TO_CAMPAIGN_TRANSFER", "transferable") => "2100",
                
                // Campaign to brand transfer
                ("CAMPAIGN_TO_BRAND_TRANSFER", "transferable") => "2100",
                
                // Brand balance return
                ("BRAND_BALANCE_RETURN", "transferable") => "2100",
                
                // Point type conversion - all balance types
                ("POINT_TYPE_CONVERSION", "transferable") => "2100",
                ("POINT_TYPE_CONVERSION", "nontransferable") => "2100",
                ("POINT_TYPE_CONVERSION", "community") => "2100",
                ("POINT_TYPE_CONVERSION", "subscription") => "2100",
                ("POINT_TYPE_CONVERSION", "special") => "2100",
                ("POINT_TYPE_CONVERSION", "overflow") => "2100",
                
                // Manual finance adjustment - default to member balance
                ("MANUAL_FINANCE_ADJUSTMENT", "transferable") => "2100",
                ("MANUAL_FINANCE_ADJUSTMENT", "nontransferable") => "2100",
                ("MANUAL_FINANCE_ADJUSTMENT", "community") => "2100",
                ("MANUAL_FINANCE_ADJUSTMENT", "subscription") => "2100",
                ("MANUAL_FINANCE_ADJUSTMENT", "special") => "2100",
                ("MANUAL_FINANCE_ADJUSTMENT", "overflow") => "2100",
                
                // Member voluntary donation - uses source transaction type's balance
                ("MEMBER_VOLUNTARY_DONATION", "transferable") => "2100",
                ("MEMBER_VOLUNTARY_DONATION", "nontransferable") => "2100",
                ("MEMBER_VOLUNTARY_DONATION", "community") => "2100",
                ("MEMBER_VOLUNTARY_DONATION", "subscription") => "2100",
                ("MEMBER_VOLUNTARY_DONATION", "overflow") => "2100",
                
                // ============================================================
                // SMART CONTRACT TRANSACTION CODES
                // ============================================================
                // BO - Smart contract buyer expense out (debit from buyer); reward_distribution uses encumbered/ED
                ("BO", "transferable") => "2100",
                ("BO", "nontransferable") => "2100",
                ("BO", "community") => "2100",
                ("BO", "special") => "2100",
                ("BO", "subscription") => "2100",
                ("BO", "overflow") => "2100",
                ("BO", "encumbered") => "2100",
                
                // PI - Smart contract provider income (seller credit)
                ("PI", "transferable") => "2100",
                ("PI", "nontransferable") => "2100",
                ("PI", "community") => "2100",
                ("PI", "special") => "2100",
                ("PI", "subscription") => "2100",
                ("PI", "overflow") => "2100",
                
                // SCO - Smart contract Social Cause share of transaction
                ("SCO", "community") => "2300", // Due to Social Causes
                ("SCO", "transferable") => "2300",
                ("SCO", "nontransferable") => "2300",
                ("SCO", "special") => "2300",
                ("SCO", "subscription") => "2300",
                ("SCO", "overflow") => "2300",
                
                // IBCI - Smart contract Imagine share of income
                ("IBCI", "transferable") => "4100", // Transaction Fees Revenue
                ("IBCI", "nontransferable") => "4100",
                ("IBCI", "community") => "4100",
                ("IBCI", "special") => "4100",
                ("IBCI", "subscription") => "4100",
                ("IBCI", "overflow") => "4100",
                
                // BRI - Smart contract buyer referral source income
                ("BRI", "transferable") => "2100",
                ("BRI", "nontransferable") => "2100",
                ("BRI", "community") => "2100",
                ("BRI", "special") => "2100",
                ("BRI", "subscription") => "2100",
                ("BRI", "overflow") => "2100",
                
                // PRI - Smart contract provider referrer income
                ("PRI", "transferable") => "2100",
                ("PRI", "nontransferable") => "2100",
                ("PRI", "community") => "2100",
                ("PRI", "special") => "2100",
                ("PRI", "subscription") => "2100",
                ("PRI", "overflow") => "2100",
                
                // GPA - Allocation of revenue to the Genesis Pool
                ("GPA", "transferable") => "2310", // Due to Genesis Pool
                ("GPA", "nontransferable") => "2310",
                ("GPA", "community") => "2310",
                ("GPA", "special") => "2310",
                ("GPA", "subscription") => "2310",
                ("GPA", "overflow") => "2310",
                
                // Encumbrance - encumbered point type (member liability reserve)
                ("ENCUMBRANCE", "encumbered") => "2100", // Due to Members (Liability)
                
                // Default fallback - member balance liability
                _ => "2100" // Default to 2100 - Due to Members (Liability)
            };
            
            return accountNumber;
        }
        
        /// <summary>
        /// Resolves account number for platform fee revenue transactions.
        /// Maps to 4100 - Transaction Fees Revenue.
        /// </summary>
        internal static string ResolvePlatformFeeAccount()
        {
            return "4100"; // Transaction Fees Revenue
        }
        
        /// <summary>
        /// Resolves account number for vendor payables.
        /// Maps to 2000 - Accounts Payable.
        /// </summary>
        internal static string ResolveVendorPayableAccount()
        {
            return "2000"; // Accounts Payable
        }
        
        /// <summary>
        /// Resolves account number for tax liabilities.
        /// Maps to 2400 - Indirect Tax Liabilities.
        /// </summary>
        internal static string ResolveTaxLiabilityAccount()
        {
            return "2400"; // Indirect Tax Liabilities
        }
        
        /// <summary>
        /// Resolves account number for donations to social causes.
        /// Maps to 2300 - Due to Social Causes.
        /// </summary>
        internal static string ResolveSocialCauseAccount()
        {
            return "2300"; // Due to Social Causes
        }
        
        /// <summary>
        /// Resolves account number for cash receipts.
        /// Maps to 1000 - Cash and Cash Equivalents.
        /// </summary>
        internal static string ResolveCashAccount()
        {
            return "1000"; // Cash and Cash Equivalents
        }
        
        /// <summary>
        /// Resolves account number for intercompany transactions.
        /// Maps to 1400 - Intercompany Clearing Account.
        /// </summary>
        internal static string ResolveIntercompanyAccount()
        {
            return "1400"; // Intercompany Clearing Account
        }
        
        /// <summary>
        /// Resolves account number for payment processing fees (expenses).
        /// Maps to 5100 - Payment Processing Fees.
        /// </summary>
        internal static string ResolvePaymentProcessingFeeAccount()
        {
            return "5100"; // Payment Processing Fees
        }

    }

    //--------------------------------------------------------------------------------------------------------
    //--Accounting Service (wrapper for HealthBase methods)
    public sealed class AccountingService
    {
        private readonly TransactionProcessingService _transactionProcessing;
        private readonly BalanceService _balances;
        private readonly string _connectionString;

        public AccountingService(
            string connectionString,
            BalanceService balances,
            TransactionProcessingService transactionProcessing)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _balances = balances ?? throw new ArgumentNullException(nameof(balances));
            _transactionProcessing = transactionProcessing ?? throw new ArgumentNullException(nameof(transactionProcessing));
        }

        // ============================================================
        // HEALTHBASE DISTRIBUTION METHODS
        // Custom distribution: 70% provider, 0.3pts flat + 6% platform, 3% genesis, remainder TKD
        // ============================================================

        /// <summary>
        /// Process HealthBase distribution with custom split
        /// Distribution: 70% provider, 0.3pts flat + 6% platform, 3% genesis, remainder TKD
        /// </summary>
        public JObject ProcessHealthBaseDistribution(
            string buyerReferral,
            string providerChannelReferral,
            decimal transactionAmount,
            decimal providerAmount,
            decimal platformAmount,
            string imagineBcReferral,
            decimal genesisAmount,
            string genesisPoolReferral,
            decimal tkdAmount,
            string tkdReferralCode,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // Build debit vector from buyer
            var debit = BalanceVector.Debit(buyerReferral);
            debit.Transferable = transactionAmount;

            // Build credit vectors
            var credits = new List<BalanceVector>
            {
                BalanceVector.CreditTransferable(providerChannelReferral, providerAmount),
                BalanceVector.CreditTransferable(imagineBcReferral, platformAmount),
                BalanceVector.CreditTransferable(genesisPoolReferral, genesisAmount),
                BalanceVector.CreditTransferable(tkdReferralCode, tkdAmount)
            };

            // Apply vectors
            _balances.ApplyVectors(
                debit,
                credits,
                "healthbase_appointment_payment",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // Write ledger entries using TransactionProcessingService's WriteLedger
            _transactionProcessing.WriteLedger(
                txId,
                "healthbase_appointment_payment",
                debit,
                credits,
                payload,
                metadata,
                mode,
                conn,
                tx);

            return new JObject
            {
                ["ok"] = true,
                ["txId"] = txId,
                ["distribution"] = new JObject
                {
                    ["provider"] = providerAmount,
                    ["platform"] = platformAmount,
                    ["genesis"] = genesisAmount,
                    ["tkd"] = tkdAmount
                }
            };
        }

        /// <summary>
        /// Process direct credit (for rewards, bonuses - no distribution)
        /// </summary>
        public JObject ProcessDirectCredit(
            string memberReferral,
            decimal amount,
            string balanceType,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // Build credit vector
            var credit = BalanceVector.Credit(memberReferral);
            
            // Set balance type
            switch (balanceType.ToUpper())
            {
                case "TRANSFERABLE":
                    credit.Transferable = amount;
                    break;
                case "NONTRANSFERABLE":
                case "NON-TRANSFERABLE":
                    credit.NonTransferable = amount;
                    break;
                case "COMMUNITY":
                    credit.Community = amount;
                    break;
                case "SPECIAL":
                    credit.Special = amount;
                    break;
                case "SUBSCRIPTION":
                    credit.Subscription = amount;
                    break;
                default:
                    credit.Transferable = amount;
                    break;
            }

            // Apply vector (no debit - this is a platform credit)
            // Create empty debit vector for platform credits (no actual debit, but required by ApplyVectors)
            var emptyDebit = BalanceVector.Debit(memberReferral);
            
            _balances.ApplyVectors(
                emptyDebit, // Empty debit for platform credits
                new List<BalanceVector> { credit },
                metadata.Value<string>("transactionType") ?? "healthbase_health_reward",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // Write ledger entry using TransactionProcessingService's WriteLedger
            _transactionProcessing.WriteLedger(
                txId,
                metadata.Value<string>("transactionType") ?? "healthbase_health_reward",
                emptyDebit, // Empty debit
                new List<BalanceVector> { credit },
                payload,
                metadata,
                mode,
                conn,
                tx);

            return new JObject
            {
                ["ok"] = true,
                ["txId"] = txId,
                ["amount"] = amount,
                ["balanceType"] = balanceType
            };
        }

        /// <summary>
        /// Process direct debit (similar to ProcessDirectCredit but for debits)
        /// </summary>
        public JObject ProcessDirectDebit(
            string memberReferral,
            decimal amount,
            string balanceType,
            JObject payload,
            JObject metadata,
            string mode,
            NpgsqlConnection conn,
            NpgsqlTransaction tx)
        {
            var txId = metadata.Value<string>("txId") ?? Guid.NewGuid().ToString("N");
            metadata["txId"] = txId;

            // Build debit vector
            var debit = BalanceVector.Debit(memberReferral);
            
            // Set balance type
            switch (balanceType.ToUpper())
            {
                case "TRANSFERABLE":
                    debit.Transferable = amount;
                    break;
                case "NONTRANSFERABLE":
                case "NON-TRANSFERABLE":
                    debit.NonTransferable = amount;
                    break;
                case "COMMUNITY":
                    debit.Community = amount;
                    break;
                case "SPECIAL":
                    debit.Special = amount;
                    break;
                case "SUBSCRIPTION":
                    debit.Subscription = amount;
                    break;
                default:
                    debit.Transferable = amount;
                    break;
            }

            // Apply vector (no credit - this is a platform debit)
            // Create empty credit vector for platform debits (no actual credit, but required by ApplyVectors)
            var emptyCredit = BalanceVector.Credit(memberReferral);
            
            _balances.ApplyVectors(
                debit,
                new List<BalanceVector> { emptyCredit }, // Empty credit for platform debits
                metadata.Value<string>("transactionType") ?? "hellokenya_payout",
                payload,
                metadata,
                mode,
                conn,
                tx);

            // Write ledger entry using TransactionProcessingService's WriteLedger
            _transactionProcessing.WriteLedger(
                txId,
                metadata.Value<string>("transactionType") ?? "hellokenya_payout",
                debit,
                new List<BalanceVector> { emptyCredit }, // Empty credit
                payload,
                metadata,
                mode,
                conn,
                tx);

            return new JObject
            {
                ["ok"] = true,
                ["txId"] = txId,
                ["amount"] = amount,
                ["balanceType"] = balanceType
            };
        }
    }

}


