using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ImagineBC.MainService.Services;

namespace ImagineBC.MainService.Controllers
{
    [ApiController]
    [Route("api/gamification")]
    public class GamificationController : ControllerBase
    {
        private readonly string _connectionString;
        private readonly ILogger<GamificationController> _logger;
        private readonly ILoggerFactory _loggerFactory;
        private readonly ServiceActivityService? _activityService;

        public GamificationController(IConfiguration config, ILogger<GamificationController> logger, ILoggerFactory loggerFactory, ServiceActivityService? activityService = null)
        {
            _connectionString = config.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Missing connection string.");
            _logger = logger;
            _loggerFactory = loggerFactory;
            _activityService = activityService;
        }

        // ============================================================================
        // PILLARS CRUD
        // ============================================================================

        [HttpGet("pillars")]
        public IActionResult GetPillars([FromQuery] bool? activeOnly = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = @"SELECT id, code, name, description, is_active, created_at, updated_at 
                              FROM pillars";
                
                if (activeOnly == true)
                {
                    sql += " WHERE is_active = true";
                }
                
                sql += " ORDER BY code";

                var pillars = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = cmd.ExecuteReader();
                
                while (reader.Read())
                {
                    pillars.Add(new
                    {
                        id = reader.GetGuid(0).ToString(),
                        code = reader.GetString(1),
                        name = reader.GetString(2),
                        description = reader.IsDBNull(3) ? null : reader.GetString(3),
                        isActive = reader.GetBoolean(4),
                        createdAt = reader.GetDateTime(5).ToString("O"),
                        updatedAt = reader.GetDateTime(6).ToString("O")
                    });
                }

                _activityService?.Record("GamificationController", "INFO", "Fetched pillars list");
                return Ok(new { success = true, pillars });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching pillars");
                return StatusCode(500, new { success = false, message = "Failed to fetch pillars", error = ex.Message });
            }
        }

        [HttpGet("pillars/{id}")]
        public IActionResult GetPillar(string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var pillarId))
                {
                    return BadRequest(new { success = false, message = "Invalid pillar ID format" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = @"SELECT id, code, name, description, is_active, created_at, updated_at 
                              FROM pillars WHERE id = @id";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", pillarId);
                
                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                {
                    return NotFound(new { success = false, message = "Pillar not found" });
                }

                var pillar = new
                {
                    id = reader.GetGuid(0).ToString(),
                    code = reader.GetString(1),
                    name = reader.GetString(2),
                    description = reader.IsDBNull(3) ? null : reader.GetString(3),
                    isActive = reader.GetBoolean(4),
                    createdAt = reader.GetDateTime(5).ToString("O"),
                    updatedAt = reader.GetDateTime(6).ToString("O")
                };

                return Ok(new { success = true, pillar });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching pillar {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to fetch pillar", error = ex.Message });
            }
        }

        [HttpPost("pillars")]
        public IActionResult CreatePillar([FromBody] JObject payload)
        {
            try
            {
                if (payload == null)
                {
                    return BadRequest(new { success = false, message = "Payload is required" });
                }

                var code = payload.Value<string>("code")?.Trim();
                var name = payload.Value<string>("name")?.Trim();
                var description = payload.Value<string>("description")?.Trim();
                var isActive = payload.Value<bool?>("isActive") ?? true;

                if (string.IsNullOrWhiteSpace(code))
                {
                    return BadRequest(new { success = false, message = "code is required" });
                }

                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { success = false, message = "name is required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = @"INSERT INTO pillars (code, name, description, is_active) 
                              VALUES (@code, @name, @description, @isActive) 
                              RETURNING id";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("code", code);
                cmd.Parameters.AddWithValue("name", name);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                var id = cmd.ExecuteScalar();
                _activityService?.Record("GamificationController", "INFO", $"Created pillar: {code}");

                return Ok(new { success = true, id = id?.ToString() });
            }
            catch (PostgresException ex) when (ex.SqlState == "23505") // Unique violation
            {
                return Conflict(new { success = false, message = "Pillar with this code already exists" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error creating pillar");
                return StatusCode(500, new { success = false, message = "Failed to create pillar", error = ex.Message });
            }
        }

        [HttpPut("pillars/{id}")]
        public IActionResult UpdatePillar(string id, [FromBody] JObject payload)
        {
            try
            {
                if (!Guid.TryParse(id, out var pillarId))
                {
                    return BadRequest(new { success = false, message = "Invalid pillar ID format" });
                }

                if (payload == null)
                {
                    return BadRequest(new { success = false, message = "Payload is required" });
                }

                var updates = new List<string>();
                var parameters = new List<NpgsqlParameter> { new NpgsqlParameter("id", pillarId) };

                if (payload["name"] != null)
                {
                    var name = payload.Value<string>("name")?.Trim();
                    if (!string.IsNullOrWhiteSpace(name))
                    {
                        updates.Add("name = @name");
                        parameters.Add(new NpgsqlParameter("name", name));
                    }
                }

                if (payload["description"] != null)
                {
                    updates.Add("description = @description");
                    parameters.Add(new NpgsqlParameter("description", (object?)payload.Value<string>("description")?.Trim() ?? DBNull.Value));
                }

                if (payload["isActive"] != null)
                {
                    updates.Add("is_active = @isActive");
                    parameters.Add(new NpgsqlParameter("isActive", payload.Value<bool>("isActive")));
                }

                if (updates.Count == 0)
                {
                    return BadRequest(new { success = false, message = "No fields to update" });
                }

                updates.Add("updated_at = NOW()");

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = $"UPDATE pillars SET {string.Join(", ", updates)} WHERE id = @id";

                using var cmd = new NpgsqlCommand(sql, connection);
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                int affected = cmd.ExecuteNonQuery();
                if (affected == 0)
                {
                    return NotFound(new { success = false, message = "Pillar not found" });
                }

                _activityService?.Record("GamificationController", "INFO", $"Updated pillar: {id}");
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error updating pillar {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to update pillar", error = ex.Message });
            }
        }

        [HttpDelete("pillars/{id}")]
        public IActionResult DeletePillar(string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var pillarId))
                {
                    return BadRequest(new { success = false, message = "Invalid pillar ID format" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = "DELETE FROM pillars WHERE id = @id";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", pillarId);

                int affected = cmd.ExecuteNonQuery();
                if (affected == 0)
                {
                    return NotFound(new { success = false, message = "Pillar not found" });
                }

                _activityService?.Record("GamificationController", "INFO", $"Deleted pillar: {id}");
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error deleting pillar {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to delete pillar", error = ex.Message });
            }
        }

        // ============================================================================
        // ACHIEVEMENTS CRUD
        // ============================================================================

        [HttpGet("achievements")]
        public IActionResult GetAchievements(
            [FromQuery] string? pillarId = null,
            [FromQuery] string? achievementType = null,
            [FromQuery] bool? activeOnly = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                var whereConditions = new List<string>();
                var parameters = new List<NpgsqlParameter>();

                if (!string.IsNullOrWhiteSpace(pillarId) && Guid.TryParse(pillarId, out var pId))
                {
                    whereConditions.Add("a.pillar_id = @pillarId");
                    parameters.Add(new NpgsqlParameter("pillarId", pId));
                }

                if (!string.IsNullOrWhiteSpace(achievementType) && 
                    new[] { "BINARY", "PROGRESSIVE", "META" }.Contains(achievementType.ToUpper()))
                {
                    whereConditions.Add("a.achievement_type = @type");
                    parameters.Add(new NpgsqlParameter("type", achievementType.ToUpper()));
                }

                if (activeOnly == true)
                {
                    whereConditions.Add("a.is_active = true");
                }

                string whereClause = whereConditions.Count > 0 ? "WHERE " + string.Join(" AND ", whereConditions) : "";

                string sql = $@"SELECT a.id, a.pillar_id, p.code as pillar_code, a.code, a.name, a.description, 
                               a.achievement_type, a.progress_required, a.is_repeatable, a.is_seasonal, 
                               a.is_active, a.reputation_reward, a.title, a.created_at, a.updated_at
                               FROM achievements a
                               JOIN pillars p ON a.pillar_id = p.id
                               {whereClause}
                               ORDER BY p.code, a.code";

                var achievements = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    achievements.Add(new
                    {
                        id = reader.GetGuid(0).ToString(),
                        pillarId = reader.GetGuid(1).ToString(),
                        pillarCode = reader.GetString(2),
                        code = reader.GetString(3),
                        name = reader.GetString(4),
                        description = reader.IsDBNull(5) ? null : reader.GetString(5),
                        achievementType = reader.GetString(6),
                        progressRequired = reader.IsDBNull(7) ? (int?)null : reader.GetInt32(7),
                        isRepeatable = reader.GetBoolean(8),
                        isSeasonal = reader.GetBoolean(9),
                        isActive = reader.GetBoolean(10),
                        reputationReward = reader.GetInt32(11),
                        title = reader.IsDBNull(12) ? null : reader.GetString(12),
                        createdAt = reader.GetDateTime(13).ToString("O"),
                        updatedAt = reader.GetDateTime(14).ToString("O")
                    });
                }

                _activityService?.Record("GamificationController", "INFO", "Fetched achievements list");
                return Ok(new { success = true, achievements });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching achievements");
                return StatusCode(500, new { success = false, message = "Failed to fetch achievements", error = ex.Message });
            }
        }

        [HttpGet("achievements/{id}")]
        public IActionResult GetAchievement(string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var achievementId))
                {
                    return BadRequest(new { success = false, message = "Invalid achievement ID format" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = @"SELECT a.id, a.pillar_id, p.code as pillar_code, a.code, a.name, a.description,
                              a.achievement_type, a.progress_required, a.is_repeatable, a.is_seasonal,
                              a.is_active, a.reputation_reward, a.title, a.created_at, a.updated_at
                              FROM achievements a
                              JOIN pillars p ON a.pillar_id = p.id
                              WHERE a.id = @id";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", achievementId);
                
                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                {
                    return NotFound(new { success = false, message = "Achievement not found" });
                }

                var achievement = new
                {
                    id = reader.GetGuid(0).ToString(),
                    pillarId = reader.GetGuid(1).ToString(),
                    pillarCode = reader.GetString(2),
                    code = reader.GetString(3),
                    name = reader.GetString(4),
                    description = reader.IsDBNull(5) ? null : reader.GetString(5),
                    achievementType = reader.GetString(6),
                    progressRequired = reader.IsDBNull(7) ? (int?)null : reader.GetInt32(7),
                    isRepeatable = reader.GetBoolean(8),
                    isSeasonal = reader.GetBoolean(9),
                    isActive = reader.GetBoolean(10),
                    reputationReward = reader.GetInt32(11),
                    title = reader.IsDBNull(12) ? null : reader.GetString(12),
                    createdAt = reader.GetDateTime(13).ToString("O"),
                    updatedAt = reader.GetDateTime(14).ToString("O")
                };

                reader.Close();

                // Fetch dependencies for META achievements
                var dependencies = new List<string>();
                string depSql = @"SELECT required_achievement_id FROM achievement_dependencies WHERE meta_achievement_id = @achId ORDER BY id";
                using var depCmd = new NpgsqlCommand(depSql, connection);
                depCmd.Parameters.AddWithValue("achId", achievementId);
                using var depReader = depCmd.ExecuteReader();
                while (depReader.Read())
                {
                    dependencies.Add(depReader.GetGuid(0).ToString());
                }

                return Ok(new { success = true, achievement, dependencies });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching achievement {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to fetch achievement", error = ex.Message });
            }
        }

        [HttpPost("achievements")]
        public IActionResult CreateAchievement([FromBody] JObject payload)
        {
            try
            {
                if (payload == null)
                {
                    return BadRequest(new { success = false, message = "Payload is required" });
                }

                var pillarId = payload.Value<string>("pillarId")?.Trim();
                var code = payload.Value<string>("code")?.Trim();
                var name = payload.Value<string>("name")?.Trim();
                var description = payload.Value<string>("description")?.Trim();
                var achievementType = payload.Value<string>("achievementType")?.Trim().ToUpper();
                var progressRequired = payload.Value<int?>("progressRequired");
                var isRepeatable = payload.Value<bool?>("isRepeatable") ?? false;
                var isSeasonal = payload.Value<bool?>("isSeasonal") ?? false;
                var isActive = payload.Value<bool?>("isActive") ?? true;
                var reputationReward = payload.Value<int?>("reputationReward") ?? 0;
                var title = payload.Value<string>("title")?.Trim();

                if (string.IsNullOrWhiteSpace(pillarId) || !Guid.TryParse(pillarId, out var pId))
                {
                    return BadRequest(new { success = false, message = "Valid pillarId is required" });
                }

                if (string.IsNullOrWhiteSpace(code))
                {
                    return BadRequest(new { success = false, message = "code is required" });
                }

                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { success = false, message = "name is required" });
                }

                if (string.IsNullOrWhiteSpace(achievementType) || 
                    !new[] { "BINARY", "PROGRESSIVE", "META" }.Contains(achievementType))
                {
                    return BadRequest(new { success = false, message = "achievementType must be BINARY, PROGRESSIVE, or META" });
                }

                if (achievementType == "PROGRESSIVE" && (!progressRequired.HasValue || progressRequired.Value <= 0))
                {
                    return BadRequest(new { success = false, message = "progressRequired must be > 0 for PROGRESSIVE achievements" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = @"INSERT INTO achievements (pillar_id, code, name, description, achievement_type, 
                              progress_required, is_repeatable, is_seasonal, is_active, reputation_reward, title) 
                              VALUES (@pillarId, @code, @name, @description, @type, @progress, @repeatable, 
                              @seasonal, @active, @reputation, @title) 
                              RETURNING id";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("pillarId", pId);
                cmd.Parameters.AddWithValue("code", code);
                cmd.Parameters.AddWithValue("name", name);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("type", achievementType);
                cmd.Parameters.AddWithValue("progress", (object?)progressRequired ?? DBNull.Value);
                cmd.Parameters.AddWithValue("repeatable", isRepeatable);
                cmd.Parameters.AddWithValue("seasonal", isSeasonal);
                cmd.Parameters.AddWithValue("active", isActive);
                cmd.Parameters.AddWithValue("reputation", reputationReward);
                cmd.Parameters.AddWithValue("title", (object?)title ?? DBNull.Value);

                var id = cmd.ExecuteScalar();
                _activityService?.Record("GamificationController", "INFO", $"Created achievement: {code}");

                return Ok(new { success = true, id = id?.ToString() });
            }
            catch (PostgresException ex) when (ex.SqlState == "23505")
            {
                return Conflict(new { success = false, message = "Achievement with this code already exists" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error creating achievement");
                return StatusCode(500, new { success = false, message = "Failed to create achievement", error = ex.Message });
            }
        }

        [HttpPut("achievements/{id}")]
        public IActionResult UpdateAchievement(string id, [FromBody] JObject payload)
        {
            try
            {
                if (!Guid.TryParse(id, out var achievementId))
                {
                    return BadRequest(new { success = false, message = "Invalid achievement ID format" });
                }

                if (payload == null)
                {
                    return BadRequest(new { success = false, message = "Payload is required" });
                }

                var updates = new List<string>();
                var parameters = new List<NpgsqlParameter> { new NpgsqlParameter("id", achievementId) };

                if (payload["name"] != null)
                {
                    var name = payload.Value<string>("name")?.Trim();
                    if (!string.IsNullOrWhiteSpace(name))
                    {
                        updates.Add("name = @name");
                        parameters.Add(new NpgsqlParameter("name", name));
                    }
                }

                if (payload["description"] != null)
                {
                    updates.Add("description = @description");
                    parameters.Add(new NpgsqlParameter("description", (object?)payload.Value<string>("description")?.Trim() ?? DBNull.Value));
                }

                if (payload["progressRequired"] != null)
                {
                    updates.Add("progress_required = @progress");
                    parameters.Add(new NpgsqlParameter("progress", (object?)payload.Value<int?>("progressRequired") ?? DBNull.Value));
                }

                if (payload["isRepeatable"] != null)
                {
                    updates.Add("is_repeatable = @repeatable");
                    parameters.Add(new NpgsqlParameter("repeatable", payload.Value<bool>("isRepeatable")));
                }

                if (payload["isSeasonal"] != null)
                {
                    updates.Add("is_seasonal = @seasonal");
                    parameters.Add(new NpgsqlParameter("seasonal", payload.Value<bool>("isSeasonal")));
                }

                if (payload["isActive"] != null)
                {
                    updates.Add("is_active = @active");
                    parameters.Add(new NpgsqlParameter("active", payload.Value<bool>("isActive")));
                }

                if (payload["reputationReward"] != null)
                {
                    updates.Add("reputation_reward = @reputation");
                    parameters.Add(new NpgsqlParameter("reputation", payload.Value<int>("reputationReward")));
                }

                if (payload["title"] != null)
                {
                    updates.Add("title = @title");
                    var title = payload.Value<string>("title")?.Trim();
                    parameters.Add(new NpgsqlParameter("title", (object?)title ?? DBNull.Value));
                }

                if (updates.Count == 0)
                {
                    return BadRequest(new { success = false, message = "No fields to update" });
                }

                updates.Add("updated_at = NOW()");

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = $"UPDATE achievements SET {string.Join(", ", updates)} WHERE id = @id";

                using var cmd = new NpgsqlCommand(sql, connection);
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                int affected = cmd.ExecuteNonQuery();
                if (affected == 0)
                {
                    return NotFound(new { success = false, message = "Achievement not found" });
                }

                _activityService?.Record("GamificationController", "INFO", $"Updated achievement: {id}");
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error updating achievement {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to update achievement", error = ex.Message });
            }
        }

        [HttpDelete("achievements/{id}")]
        public IActionResult DeleteAchievement(string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var achievementId))
                {
                    return BadRequest(new { success = false, message = "Invalid achievement ID format" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = "DELETE FROM achievements WHERE id = @id";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", achievementId);

                int affected = cmd.ExecuteNonQuery();
                if (affected == 0)
                {
                    return NotFound(new { success = false, message = "Achievement not found" });
                }

                _activityService?.Record("GamificationController", "INFO", $"Deleted achievement: {id}");
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error deleting achievement {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to delete achievement", error = ex.Message });
            }
        }

        // ============================================================================
        // MEMBER ACHIEVEMENT PROGRESS CRUD
        // ============================================================================

        [HttpGet("member-progress")]
        public IActionResult GetMemberProgress(
            [FromQuery] string? memberReferral = null,
            [FromQuery] string? achievementId = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                var whereConditions = new List<string>();
                var parameters = new List<NpgsqlParameter>();

                if (!string.IsNullOrWhiteSpace(memberReferral))
                {
                    whereConditions.Add("map.member_referral = @memberRef");
                    parameters.Add(new NpgsqlParameter("memberRef", memberReferral));
                }

                if (!string.IsNullOrWhiteSpace(achievementId) && Guid.TryParse(achievementId, out var aId))
                {
                    whereConditions.Add("map.achievement_id = @achievementId");
                    parameters.Add(new NpgsqlParameter("achievementId", aId));
                }

                string whereClause = whereConditions.Count > 0 ? "WHERE " + string.Join(" AND ", whereConditions) : "";

                string sql = $@"SELECT map.member_referral, map.achievement_id, a.code as achievement_code, 
                               a.name as achievement_name, map.progress, map.is_completed, map.completed_at,
                               map.created_at, map.updated_at
                               FROM member_achievement_progress map
                               JOIN achievements a ON map.achievement_id = a.id
                               {whereClause}
                               ORDER BY map.member_referral, a.code";

                var progress = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    progress.Add(new
                    {
                        memberReferral = reader.GetString(0),
                        achievementId = reader.GetGuid(1).ToString(),
                        achievementCode = reader.GetString(2),
                        achievementName = reader.GetString(3),
                        progress = reader.GetInt32(4),
                        isCompleted = reader.GetBoolean(5),
                        completedAt = reader.IsDBNull(6) ? null : reader.GetDateTime(6).ToString("O"),
                        createdAt = reader.GetDateTime(7).ToString("O"),
                        updatedAt = reader.GetDateTime(8).ToString("O")
                    });
                }

                _activityService?.Record("GamificationController", "INFO", "Fetched member achievement progress");
                return Ok(new { success = true, progress });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching member progress");
                return StatusCode(500, new { success = false, message = "Failed to fetch member progress", error = ex.Message });
            }
        }

        // Note: Member progress is typically managed by the GamificationService, not directly via CRUD
        // But we provide read-only access here for admin review

        // ============================================================================
        // MEMBER TITLES CRUD
        // ============================================================================

        [HttpGet("member-titles")]
        public IActionResult GetMemberTitles([FromQuery] string? memberReferral = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                var whereConditions = new List<string>();
                var parameters = new List<NpgsqlParameter>();

                if (!string.IsNullOrWhiteSpace(memberReferral))
                {
                    whereConditions.Add("mt.member_referral = @memberRef");
                    parameters.Add(new NpgsqlParameter("memberRef", memberReferral));
                }

                string whereClause = whereConditions.Count > 0 ? "WHERE " + string.Join(" AND ", whereConditions) : "";

                string sql = $@"SELECT mt.id, mt.member_referral, mt.achievement_id, a.code as achievement_code,
                               a.name as achievement_name, mt.title, mt.is_active, mt.unlocked_at, mt.created_at
                               FROM member_titles mt
                               JOIN achievements a ON mt.achievement_id = a.id
                               {whereClause}
                               ORDER BY mt.member_referral, mt.unlocked_at DESC";

                var titles = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    titles.Add(new
                    {
                        id = reader.GetGuid(0).ToString(),
                        memberReferral = reader.GetString(1),
                        achievementId = reader.GetGuid(2).ToString(),
                        achievementCode = reader.GetString(3),
                        achievementName = reader.GetString(4),
                        title = reader.GetString(5),
                        isActive = reader.GetBoolean(6),
                        unlockedAt = reader.GetDateTime(7).ToString("O"),
                        createdAt = reader.GetDateTime(8).ToString("O")
                    });
                }

                _activityService?.Record("GamificationController", "INFO", "Fetched member titles");
                return Ok(new { success = true, titles });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching member titles");
                return StatusCode(500, new { success = false, message = "Failed to fetch member titles", error = ex.Message });
            }
        }

        [HttpPut("member-titles/{id}/activate")]
        public IActionResult ActivateTitle(string id)
        {
            try
            {
                if (!Guid.TryParse(id, out var titleId))
                {
                    return BadRequest(new { success = false, message = "Invalid title ID format" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                // First get member_referral for this title
                string getMemberSql = "SELECT member_referral FROM member_titles WHERE id = @id";
                string? memberReferral = null;
                
                using (var cmd = new NpgsqlCommand(getMemberSql, connection))
                {
                    cmd.Parameters.AddWithValue("id", titleId);
                    var result = cmd.ExecuteScalar();
                    if (result == null)
                    {
                        return NotFound(new { success = false, message = "Title not found" });
                    }
                    memberReferral = result.ToString();
                }

                // Deactivate all other titles for this member
                string deactivateSql = @"UPDATE member_titles SET is_active = false 
                                        WHERE member_referral = @memberRef AND id != @id";
                using (var cmd = new NpgsqlCommand(deactivateSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberRef", memberReferral ?? string.Empty);
                    cmd.Parameters.AddWithValue("id", titleId);
                    cmd.ExecuteNonQuery();
                }

                // Activate this title
                string activateSql = "UPDATE member_titles SET is_active = true WHERE id = @id";
                using (var cmd = new NpgsqlCommand(activateSql, connection))
                {
                    cmd.Parameters.AddWithValue("id", titleId);
                    int affected = cmd.ExecuteNonQuery();
                    if (affected == 0)
                    {
                        return NotFound(new { success = false, message = "Title not found" });
                    }
                }

                _activityService?.Record("GamificationController", "INFO", $"Activated title: {id}");
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error activating title {Id}", id);
                return StatusCode(500, new { success = false, message = "Failed to activate title", error = ex.Message });
            }
        }

        [HttpPost("member-titles/create")]
        public IActionResult CreateTitle([FromBody] Dictionary<string, object?> payload)
        {
            try
            {
                var memberReferral = payload.GetValueOrDefault("memberReferral")?.ToString();
                var achievementIdStr = payload.GetValueOrDefault("achievementId")?.ToString();

                if (string.IsNullOrWhiteSpace(memberReferral) || string.IsNullOrWhiteSpace(achievementIdStr))
                {
                    return BadRequest(new { success = false, message = "memberReferral and achievementId are required" });
                }

                if (!Guid.TryParse(achievementIdStr, out var achievementId))
                {
                    return BadRequest(new { success = false, message = "Invalid achievementId format" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                // Get title from achievement
                string getTitleSql = "SELECT title FROM achievements WHERE id = @achievementId";
                string? titleText = null;
                using (var cmd = new NpgsqlCommand(getTitleSql, connection))
                {
                    cmd.Parameters.AddWithValue("achievementId", achievementId);
                    var result = cmd.ExecuteScalar();
                    if (result == null || result == DBNull.Value)
                    {
                        return NotFound(new { success = false, message = "Achievement not found" });
                    }
                    titleText = result.ToString();
                    if (string.IsNullOrWhiteSpace(titleText))
                    {
                        return BadRequest(new { success = false, message = "Achievement does not have a title" });
                    }
                }

                // Check if title already exists
                string checkExistsSql = "SELECT id FROM member_titles WHERE member_referral = @memberRef AND achievement_id = @achievementId";
                Guid? existingTitleId = null;
                using (var cmd = new NpgsqlCommand(checkExistsSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberRef", memberReferral);
                    cmd.Parameters.AddWithValue("achievementId", achievementId);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        existingTitleId = (Guid)result;
                    }
                }

                Guid titleId;
                if (existingTitleId.HasValue)
                {
                    // Title already exists, return existing ID
                    titleId = existingTitleId.Value;
                }
                else
                {
                    // Create new title
                    string createSql = @"INSERT INTO member_titles (member_referral, achievement_id, title, is_active, unlocked_at, created_at)
                                       VALUES (@memberRef, @achievementId, @title, false, NOW(), NOW())
                                       RETURNING id";
                    using (var cmd = new NpgsqlCommand(createSql, connection))
                    {
                        cmd.Parameters.AddWithValue("memberRef", memberReferral);
                        cmd.Parameters.AddWithValue("achievementId", achievementId);
                        cmd.Parameters.AddWithValue("title", titleText);
                        var result = cmd.ExecuteScalar();
                        if (result == null || result == DBNull.Value)
                        {
                            return StatusCode(500, new { success = false, message = "Failed to create title - no ID returned" });
                        }
                        titleId = (Guid)result;
                    }
                }

                _activityService?.Record("GamificationController", "INFO", $"Created title: {titleId} for member: {memberReferral}");
                return Ok(new { success = true, titleId = titleId.ToString() });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error creating title");
                return StatusCode(500, new { success = false, message = "Failed to create title", error = ex.Message });
            }
        }

        [HttpPut("member-titles/deactivate-all")]
        public IActionResult DeactivateAllTitles([FromQuery] string memberReferral)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(memberReferral))
                {
                    return BadRequest(new { success = false, message = "memberReferral is required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                // Deactivate all titles for this member
                string deactivateSql = @"UPDATE member_titles SET is_active = false 
                                        WHERE member_referral = @memberRef";
                using (var cmd = new NpgsqlCommand(deactivateSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberRef", memberReferral);
                    cmd.ExecuteNonQuery();
                }

                _activityService?.Record("GamificationController", "INFO", $"Deactivated all titles for member: {memberReferral}");
                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error deactivating all titles for member {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = "Failed to deactivate titles", error = ex.Message });
            }
        }

        // ============================================================================
        // PROGRESS TOKENS CRUD (Read-only for admin review)
        // ============================================================================

        [HttpGet("progress-tokens")]
        public IActionResult GetProgressTokens([FromQuery] string? memberReferral = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                var whereConditions = new List<string>();
                var parameters = new List<NpgsqlParameter>();

                if (!string.IsNullOrWhiteSpace(memberReferral))
                {
                    whereConditions.Add("pt.member_referral = @memberRef");
                    parameters.Add(new NpgsqlParameter("memberRef", memberReferral));
                }

                string whereClause = whereConditions.Count > 0 ? "WHERE " + string.Join(" AND ", whereConditions) : "";

                string sql = $@"SELECT pt.member_referral, pt.pillar_code, p.name as pillar_name,
                               pt.token_count, pt.updated_at
                               FROM progress_tokens pt
                               JOIN pillars p ON pt.pillar_code = p.code
                               {whereClause}
                               ORDER BY pt.member_referral, pt.pillar_code";

                var tokens = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                foreach (var param in parameters)
                {
                    cmd.Parameters.Add(param);
                }

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    tokens.Add(new
                    {
                        memberReferral = reader.GetString(0),
                        pillarCode = reader.GetString(1),
                        pillarName = reader.GetString(2),
                        tokenCount = reader.GetInt32(3),
                        updatedAt = reader.GetDateTime(4).ToString("O")
                    });
                }

                _activityService?.Record("GamificationController", "INFO", "Fetched progress tokens");
                return Ok(new { success = true, tokens });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error fetching progress tokens");
                return StatusCode(500, new { success = false, message = "Failed to fetch progress tokens", error = ex.Message });
            }
        }

        // ============================================================================
        // EVENT PROCESSING ENDPOINTS
        // ============================================================================

        /// <summary>
        /// Process a gamification event (called by other controllers after actions)
        /// </summary>
        [HttpPost("events/process")]
        public async Task<IActionResult> ProcessEvent([FromBody] JObject payload)
        {
            try
            {
                if (payload == null)
                {
                    return BadRequest(new { success = false, message = "Payload is required" });
                }

                var eventType = payload.Value<string>("eventType")?.Trim();
                var memberReferral = payload.Value<string>("memberReferral")?.Trim();
                var metadata = payload["metadata"]?.ToObject<Dictionary<string, object>>();

                if (string.IsNullOrWhiteSpace(eventType) || string.IsNullOrWhiteSpace(memberReferral))
                {
                    return BadRequest(new { success = false, message = "eventType and memberReferral are required" });
                }

                var service = new GamificationService(_connectionString, 
                    _loggerFactory.CreateLogger<GamificationService>(), _activityService);
                var result = await service.ProcessEventAsync(eventType, memberReferral, metadata);

                return Ok(new
                {
                    success = true,
                    eventType = result.EventType,
                    memberReferral = result.MemberReferral,
                    unlockedAchievements = result.UnlockedAchievements.Select(a => new
                    {
                        achievementId = a.AchievementId.ToString(),
                        code = a.Code,
                        name = a.Name,
                        pillarId = a.PillarId.ToString()
                    })
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error processing gamification event");
                return StatusCode(500, new { success = false, message = "Failed to process event", error = ex.Message });
            }
        }

        /// <summary>
        /// Check for recently unlocked achievements (for immediate notification after actions)
        /// </summary>
        [HttpGet("check-recent-unlocks")]
        public IActionResult CheckRecentUnlocks([FromQuery] string memberReferral, [FromQuery] int secondsAgo = 30)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(memberReferral))
                {
                    return BadRequest(new { success = false, message = "memberReferral is required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                string sql = $@"
                    SELECT map.achievement_id, a.code, a.name, a.pillar_id, p.code as pillar_code,
                           map.completed_at, a.title, a.description, a.achievement_type
                    FROM member_achievement_progress map
                    JOIN achievements a ON map.achievement_id = a.id
                    JOIN pillars p ON a.pillar_id = p.id
                    WHERE map.member_referral = @memberRef
                      AND map.is_completed = true
                      AND map.completed_at >= NOW() - INTERVAL '{secondsAgo} seconds'
                    ORDER BY map.completed_at DESC";

                var unlocks = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberRef", memberReferral);

                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    unlocks.Add(new
                    {
                        achievementId = reader.GetGuid(0).ToString(),
                        code = reader.GetString(1),
                        name = reader.GetString(2),
                        pillarId = reader.GetGuid(3).ToString(),
                        pillarCode = reader.GetString(4),
                        completedAt = reader.GetDateTime(5).ToString("O"),
                        title = reader.IsDBNull(6) ? null : reader.GetString(6),
                        description = reader.IsDBNull(7) ? null : reader.GetString(7),
                        achievementType = reader.IsDBNull(8) ? null : reader.GetString(8)
                    });
                }

                return Ok(new { success = true, unlocks });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error checking recent unlocks");
                return StatusCode(500, new { success = false, message = "Failed to check recent unlocks", error = ex.Message });
            }
        }
    }
}
