using Npgsql;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace ImagineBC.MainService.Services
{
    /// <summary>
    /// Service for processing gamification events and managing achievement progression
    /// </summary>
    public class GamificationService
    {
        private readonly string _connectionString;
        private readonly ILogger<GamificationService>? _logger;
        private readonly ServiceActivityService? _activityService;

        public GamificationService(
            string connectionString,
            ILogger<GamificationService>? logger = null,
            ServiceActivityService? activityService = null)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _logger = logger;
            _activityService = activityService;
        }

        /// <summary>
        /// Process a gamification event and evaluate achievements
        /// </summary>
        public async Task<ProcessEventResult> ProcessEventAsync(string eventType, string memberReferral, Dictionary<string, object>? metadata = null)
        {
            if (string.IsNullOrWhiteSpace(eventType) || string.IsNullOrWhiteSpace(memberReferral))
            {
                throw new ArgumentException("eventType and memberReferral are required");
            }

            try
            {
                await using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                await using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    var result = new ProcessEventResult
                    {
                        EventType = eventType,
                        MemberReferral = memberReferral,
                        UnlockedAchievements = new List<UnlockedAchievement>()
                    };

                    // Step 1: Update progress tokens based on event type
                    var pillarCode = GetPillarForEvent(eventType, metadata);
                    if (!string.IsNullOrWhiteSpace(pillarCode))
                    {
                        await IncrementProgressTokenAsync(connection, transaction, memberReferral, pillarCode);
                    }

                    // Step 2: Get eligible achievements for this event type
                    var eligibleAchievements = await GetEligibleAchievementsAsync(connection, transaction, eventType, pillarCode);

                    // Step 3: Process each eligible achievement
                    foreach (var achievement in eligibleAchievements)
                    {
                        var unlocked = await ProcessAchievementAsync(connection, transaction, memberReferral, achievement.Id, eventType, metadata);
                        if (unlocked != null)
                        {
                            result.UnlockedAchievements.Add(unlocked);
                            
                            // Step 4: Check meta-achievements when an achievement unlocks
                            var metaUnlocks = await EvaluateMetaAchievementsAsync(connection, transaction, memberReferral);
                            result.UnlockedAchievements.AddRange(metaUnlocks);
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("GamificationService", "SUCCESS", 
                        $"Processed event {eventType} for member {memberReferral}", 
                        new { eventType, memberReferral, unlockedCount = result.UnlockedAchievements.Count });

                    return result;
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "❌ Error processing gamification event {EventType} for member {MemberReferral}", eventType, memberReferral);
                _activityService?.Record("GamificationService", "ERROR", 
                    $"Failed to process event {eventType} for member {memberReferral}", 
                    new { exception = ex.Message });
                throw;
            }
        }

        /// <summary>
        /// Get pillar code for an event type
        /// </summary>
        private string? GetPillarForEvent(string eventType, Dictionary<string, object>? metadata)
        {
            return eventType switch
            {
                "MAP_LOCATION_ENTERED" => "EXPLORER",
                "SCRATCHER_REDEEMED" => null, // Scratchers don't contribute to achievements
                "DAILY_LOGIN_COMPLETED" => "CITIZEN",
                "PUZZLE_COMPLETED" => "GAMER",
                "TIP_SENT" => "PATRON",
                "LEDGER_OPENED" => "PATRON",
                "POLL_VOTE_CAST" => "CITIZEN",
                "GUARDIANS_PATROL_COMPLETED" => "GAMER",
                // HealthBase events - all map to CITIZEN pillar
                "HEALTHBASE_VITALS_RECORDED" => "CITIZEN",
                "HEALTHBASE_APPOINTMENT_COMPLETED" => "CITIZEN",
                "HEALTHBASE_HEALTH_REWARD_EARNED" => "CITIZEN",
                "HEALTHBASE_INSURANCE_ENROLLED" => "CITIZEN",
                "HEALTHBASE_UTILITY_PAID" => "CITIZEN",
                "CONTENT_PURCHASED" => "PATRON",
                _ => null
            };
        }

        /// <summary>
        /// Increment progress token for a pillar
        /// </summary>
        private async Task IncrementProgressTokenAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, string memberReferral, string pillarCode)
        {
            const string sql = @"
                INSERT INTO progress_tokens (member_referral, pillar_code, token_count, updated_at)
                VALUES (@memberRef, @pillarCode, 1, NOW())
                ON CONFLICT (member_referral, pillar_code)
                DO UPDATE SET 
                    token_count = progress_tokens.token_count + 1,
                    updated_at = NOW()";

            await using var cmd = new NpgsqlCommand(sql, connection, transaction);
            cmd.Parameters.AddWithValue("memberRef", memberReferral);
            cmd.Parameters.AddWithValue("pillarCode", pillarCode);
            await cmd.ExecuteNonQueryAsync();
        }

        /// <summary>
        /// Get eligible achievements for an event type
        /// </summary>
        private async Task<List<AchievementInfo>> GetEligibleAchievementsAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, string eventType, string? pillarCode)
        {
            var achievements = new List<AchievementInfo>();

            // Build query based on event type
            string sql = @"
                SELECT id, pillar_id, code, name, description, achievement_type, progress_required, 
                       is_repeatable, reputation_reward
                FROM achievements
                WHERE is_active = true
                  AND achievement_type != 'META'";

            var parameters = new List<NpgsqlParameter>();

            // Map event types to achievement conditions
            if (eventType == "MAP_LOCATION_ENTERED" && !string.IsNullOrWhiteSpace(pillarCode))
            {
                sql += " AND pillar_id = (SELECT id FROM pillars WHERE code = @pillarCode)";
                sql += " AND (code LIKE 'EXPLORER_%')";
                parameters.Add(new NpgsqlParameter("pillarCode", pillarCode));
            }
            else if (eventType == "DAILY_LOGIN_COMPLETED")
            {
                sql += " AND (code LIKE 'CITIZEN_DAILY_%' OR code LIKE 'CITIZEN_FIRST_%')";
            }
            else if (eventType == "POLL_VOTE_CAST")
            {
                sql += " AND (code LIKE 'CITIZEN_%VOTE%' OR code LIKE 'CITIZEN_%HELPER%')";
            }
            else if (eventType == "TIP_SENT" || eventType == "PATRON_FIRST_TIP")
            {
                sql += " AND (code LIKE 'PATRON_%')";
            }
            else if (eventType == "PUZZLE_COMPLETED" || eventType == "GUARDIANS_PATROL_COMPLETED")
            {
                sql += " AND (code LIKE 'GAMER_%')";
            }
            else if (eventType == "CONTENT_PURCHASED")
            {
                sql += " AND (code LIKE 'PATRON_%')";
            }
            // ── HealthBase event filters ──
            else if (eventType == "HEALTHBASE_VITALS_RECORDED")
            {
                sql += " AND (code LIKE 'CITIZEN_HEALTH_VITALS_%')";
            }
            else if (eventType == "HEALTHBASE_APPOINTMENT_COMPLETED")
            {
                sql += " AND (code LIKE 'CITIZEN_HEALTH_APPOINTMENTS_%')";
            }
            else if (eventType == "HEALTHBASE_HEALTH_REWARD_EARNED")
            {
                sql += " AND (code LIKE 'CITIZEN_HEALTH_REWARDS_%')";
            }
            else if (eventType == "HEALTHBASE_INSURANCE_ENROLLED")
            {
                sql += " AND (code = 'CITIZEN_HEALTH_INSURANCE')";
            }
            else if (eventType == "HEALTHBASE_UTILITY_PAID")
            {
                sql += " AND (code LIKE 'CITIZEN_HEALTH_UTILITIES_%')";
            }
            // ── Patron ledger filter ──
            else if (eventType == "LEDGER_OPENED")
            {
                sql += " AND (code LIKE 'PATRON_KEEPER_%')";
            }
            else
            {
                // Safety: unknown event types should not match any achievements
                sql += " AND 1=0";
            }

            await using var cmd = new NpgsqlCommand(sql, connection, transaction);
            foreach (var param in parameters)
            {
                cmd.Parameters.Add(param);
            }

            await using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                achievements.Add(new AchievementInfo
                {
                    Id = reader.GetGuid(0),
                    PillarId = reader.GetGuid(1),
                    Code = reader.GetString(2),
                    Name = reader.GetString(3),
                    Description = reader.IsDBNull(4) ? null : reader.GetString(4),
                    AchievementType = reader.GetString(5),
                    ProgressRequired = reader.IsDBNull(6) ? null : reader.GetInt32(6),
                    IsRepeatable = reader.GetBoolean(7),
                    ReputationReward = reader.GetInt32(8)
                });
            }

            return achievements;
        }

        /// <summary>
        /// Process an individual achievement (increment progress, check for unlock)
        /// </summary>
        private async Task<UnlockedAchievement?> ProcessAchievementAsync(
            NpgsqlConnection connection, 
            NpgsqlTransaction transaction, 
            string memberReferral, 
            Guid achievementId, 
            string eventType,
            Dictionary<string, object>? metadata)
        {
            // Get achievement details
            const string getAchievementSql = @"
                SELECT achievement_type, progress_required, is_repeatable, code, name, pillar_id
                FROM achievements
                WHERE id = @achievementId";

            await using var getCmd = new NpgsqlCommand(getAchievementSql, connection, transaction);
            getCmd.Parameters.AddWithValue("achievementId", achievementId);
            
            await using var reader = await getCmd.ExecuteReaderAsync();
            if (!await reader.ReadAsync())
            {
                return null;
            }

            var achievementType = reader.GetString(0);
            var progressRequired = reader.IsDBNull(1) ? null : (int?)reader.GetInt32(1);
            var isRepeatable = reader.GetBoolean(2);
            var code = reader.GetString(3);
            var name = reader.GetString(4);
            var pillarId = reader.GetGuid(5);
            reader.Close();

            // Special handling for EXPLORER_FIRST_STEP: Exclude clubhouse, personal channel, and original referral channel
            bool shouldIncrementProgress = true;
            if (code == "EXPLORER_FIRST_STEP" && eventType == "MAP_LOCATION_ENTERED" && metadata != null)
            {
                // Extract location information from metadata
                var locationType = metadata.ContainsKey("locationType") ? metadata["locationType"]?.ToString() : null;
                var locationId = metadata.ContainsKey("locationId") ? metadata["locationId"]?.ToString() : null;
                var centerKey = metadata.ContainsKey("centerKey") ? metadata["centerKey"]?.ToString() : null;
                var entityReferral = metadata.ContainsKey("entityReferral") ? metadata["entityReferral"]?.ToString() : null;
                
                // Use entityReferral or locationId as the channel referral to check
                var channelReferral = !string.IsNullOrWhiteSpace(entityReferral) ? entityReferral : locationId;
                
                // Check if this is clubhouse (centerKey = "clubhouse")
                if (!string.IsNullOrWhiteSpace(centerKey) && centerKey.Equals("clubhouse", StringComparison.OrdinalIgnoreCase))
                {
                    shouldIncrementProgress = false;
                }
                else if (!string.IsNullOrWhiteSpace(channelReferral) && 
                         !string.IsNullOrWhiteSpace(locationType) && 
                         (locationType.Equals("channel", StringComparison.OrdinalIgnoreCase) || 
                          locationType.Equals("channelStorefront", StringComparison.OrdinalIgnoreCase)))
                {
                    // Check if this channel is the user's personal channel or original referral channel
                    const string checkChannelSql = @"
                        SELECT 
                            CASE 
                                WHEN c.assignedreferral = m.assignedreferral THEN 1  -- Personal channel
                                WHEN c.assignedreferral = m.originalreferrer THEN 2  -- Original referral channel
                                ELSE 0
                            END as channel_type
                        FROM members m
                        LEFT JOIN channel c ON c.assignedreferral = @channelRef
                        WHERE m.assignedreferral = @memberRef
                          AND c.assignedreferral IS NOT NULL
                        LIMIT 1";
                    
                    await using var channelCheckCmd = new NpgsqlCommand(checkChannelSql, connection, transaction);
                    channelCheckCmd.Parameters.AddWithValue("memberRef", memberReferral);
                    channelCheckCmd.Parameters.AddWithValue("channelRef", channelReferral);
                    
                    var channelTypeResult = await channelCheckCmd.ExecuteScalarAsync();
                    if (channelTypeResult != null && channelTypeResult != DBNull.Value)
                    {
                        var channelType = Convert.ToInt32(channelTypeResult);
                        if (channelType == 1 || channelType == 2)  // Personal channel or original referral channel
                        {
                            shouldIncrementProgress = false;
                        }
                    }
                }
            }

            // Special handling for CITIZEN_DAILY_VISITOR: Only count unique login days (not consecutive, just 7 total unique days)
            // The event fires on every bootstrap, so we need to check if we've already counted today
            if (code == "CITIZEN_DAILY_VISITOR" && eventType == "DAILY_LOGIN_COMPLETED")
            {
                // Check if we've already processed this achievement today
                // We use updated_at to track when we last counted a day
                const string checkAlreadyCountedSql = @"
                    SELECT 
                        DATE(updated_at) as last_counted_date,
                        u.lastlogindate
                    FROM member_achievement_progress map
                    INNER JOIN members m ON m.assignedreferral = map.member_referral
                    INNER JOIN users u ON u.memberreferral = m.assignedreferral
                    WHERE map.member_referral = @memberRef 
                        AND map.achievement_id = @achievementId
                    LIMIT 1";
                
                await using var checkCmd = new NpgsqlCommand(checkAlreadyCountedSql, connection, transaction);
                checkCmd.Parameters.AddWithValue("memberRef", memberReferral);
                checkCmd.Parameters.AddWithValue("achievementId", achievementId);
                
                await using var checkReader = await checkCmd.ExecuteReaderAsync();
                if (await checkReader.ReadAsync())
                {
                    // Progress record exists - check if we've already counted today
                    var lastCountedDate = checkReader.IsDBNull(0) ? (DateTime?)null : checkReader.GetDateTime(0);
                    var lastLoginDate = checkReader.IsDBNull(1) ? (DateTime?)null : checkReader.GetDateTime(1);
                    checkReader.Close();
                    
                    var today = DateTime.UtcNow.Date;
                    var lastCountedDateOnly = lastCountedDate?.Date;
                    var lastLoginDateOnly = lastLoginDate?.Date;
                    
                    // Only increment if:
                    // 1. lastlogindate is today (member logged in today)
                    // 2. We haven't already counted today (lastCountedDate is not today)
                    if (lastLoginDateOnly != today || lastCountedDateOnly == today)
                    {
                        // Either member hasn't logged in today, or we already counted today - don't increment
                        shouldIncrementProgress = false;
                    }
                }
                else
                {
                    checkReader.Close();
                    // No progress record exists yet - check if member logged in today before creating
                    const string checkLoginDateSql = @"
                        SELECT u.lastlogindate
                        FROM users u
                        INNER JOIN members m ON m.assignedreferral = u.memberreferral
                        WHERE m.assignedreferral = @memberRef
                        LIMIT 1";
                    
                    await using var loginCheckCmd = new NpgsqlCommand(checkLoginDateSql, connection, transaction);
                    loginCheckCmd.Parameters.AddWithValue("memberRef", memberReferral);
                    
                    var loginDateResult = await loginCheckCmd.ExecuteScalarAsync();
                    if (loginDateResult != null && loginDateResult != DBNull.Value)
                    {
                        var lastLoginDate = ((DateTime)loginDateResult).Date;
                        var today = DateTime.UtcNow.Date;
                        
                        // Only create record if member logged in today
                        if (lastLoginDate != today)
                        {
                            shouldIncrementProgress = false;
                        }
                    }
                    else
                    {
                        // Can't determine login date - don't increment
                        shouldIncrementProgress = false;
                    }
                }
            }

            // Upsert progress record (only increment if shouldIncrementProgress is true)
            string upsertProgressSql;
            if (shouldIncrementProgress)
            {
                upsertProgressSql = @"
                    INSERT INTO member_achievement_progress 
                        (member_referral, achievement_id, progress, is_completed, updated_at)
                    VALUES (@memberRef, @achievementId, 1, false, NOW())
                    ON CONFLICT (member_referral, achievement_id)
                    DO UPDATE SET 
                        progress = member_achievement_progress.progress + 1,
                        updated_at = NOW()
                    RETURNING progress, is_completed";
            }
            else
            {
                // Don't increment, just return current progress (or create record with 0 if it doesn't exist)
                upsertProgressSql = @"
                    INSERT INTO member_achievement_progress 
                        (member_referral, achievement_id, progress, is_completed, updated_at)
                    VALUES (@memberRef, @achievementId, 0, false, NOW())
                    ON CONFLICT (member_referral, achievement_id)
                    DO UPDATE SET updated_at = NOW()
                    RETURNING progress, is_completed";
            }

            await using var progressCmd = new NpgsqlCommand(upsertProgressSql, connection, transaction);
            progressCmd.Parameters.AddWithValue("memberRef", memberReferral);
            progressCmd.Parameters.AddWithValue("achievementId", achievementId);
            
            await using var progressReader = await progressCmd.ExecuteReaderAsync();
            if (!await progressReader.ReadAsync())
            {
                return null;
            }

            var currentProgress = progressReader.GetInt32(0);
            var isCompleted = progressReader.GetBoolean(1);
            progressReader.Close();

            // Check if achievement should be unlocked
            bool shouldUnlock = false;
            if (achievementType == "BINARY")
            {
                shouldUnlock = currentProgress >= 1 && !isCompleted;
            }
            else if (achievementType == "PROGRESSIVE" && progressRequired.HasValue)
            {
                shouldUnlock = currentProgress >= progressRequired.Value && !isCompleted;
            }

            if (shouldUnlock)
            {
                // Mark achievement as completed
                const string completeSql = @"
                    UPDATE member_achievement_progress
                    SET is_completed = true, completed_at = NOW(), updated_at = NOW()
                    WHERE member_referral = @memberRef AND achievement_id = @achievementId";

                await using var completeCmd = new NpgsqlCommand(completeSql, connection, transaction);
                completeCmd.Parameters.AddWithValue("memberRef", memberReferral);
                completeCmd.Parameters.AddWithValue("achievementId", achievementId);
                await completeCmd.ExecuteNonQueryAsync();

                // Grant title if this achievement grants one
                await GrantTitleAsync(connection, transaction, memberReferral, achievementId, name);

                // Update reputation score
                const string getReputationRewardSql = "SELECT reputation_reward FROM achievements WHERE id = @achievementId";
                await using var repCmd = new NpgsqlCommand(getReputationRewardSql, connection, transaction);
                repCmd.Parameters.AddWithValue("achievementId", achievementId);
                var repReward = await repCmd.ExecuteScalarAsync();
                if (repReward != null && repReward != DBNull.Value)
                {
                    await UpdateReputationAsync(connection, transaction, memberReferral, Convert.ToInt32(repReward));
                }

                return new UnlockedAchievement
                {
                    AchievementId = achievementId,
                    Code = code,
                    Name = name,
                    PillarId = pillarId
                };
            }

            return null;
        }

        /// <summary>
        /// Grant a title to a member
        /// </summary>
        private async Task GrantTitleAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, string memberReferral, Guid achievementId, string achievementName)
        {
            // Check if this achievement grants a title (for now, assume all achievements grant titles with achievement name)
            const string insertTitleSql = @"
                INSERT INTO member_titles (member_referral, achievement_id, title, is_active, unlocked_at)
                VALUES (@memberRef, @achievementId, @title, false, NOW())
                ON CONFLICT (member_referral, achievement_id) DO NOTHING";

            await using var cmd = new NpgsqlCommand(insertTitleSql, connection, transaction);
            cmd.Parameters.AddWithValue("memberRef", memberReferral);
            cmd.Parameters.AddWithValue("achievementId", achievementId);
            cmd.Parameters.AddWithValue("title", achievementName);
            await cmd.ExecuteNonQueryAsync();
        }

        /// <summary>
        /// Update member reputation score
        /// </summary>
        private async Task UpdateReputationAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, string memberReferral, int reputationIncrease)
        {
            // Get current reputation token value
            const string getTokenSql = "SELECT decimalvalue FROM tokens WHERE key = 'REPUTATION-ACHIEVEMENT-MATCH' LIMIT 1";
            await using var tokenCmd = new NpgsqlCommand(getTokenSql, connection, transaction);
            var tokenValue = await tokenCmd.ExecuteScalarAsync();
            var multiplier = tokenValue != null && tokenValue != DBNull.Value ? Convert.ToDecimal(tokenValue) : 1.0m;

            var totalReputationIncrease = (int)(reputationIncrease * multiplier);

            // Update member reputation (assuming there's a reputation column or separate table)
            // For now, we'll log this - the actual reputation update may be in a different table
            _logger?.LogInformation("Reputation increase: {Amount} for member {MemberRef}", totalReputationIncrease, memberReferral);
        }

        /// <summary>
        /// Evaluate meta-achievements when a regular achievement unlocks
        /// </summary>
        private async Task<List<UnlockedAchievement>> EvaluateMetaAchievementsAsync(NpgsqlConnection connection, NpgsqlTransaction transaction, string memberReferral)
        {
            var unlocked = new List<UnlockedAchievement>();

            // Get all meta-achievements
            const string getMetaSql = @"
                SELECT a.id, a.code, a.name, a.pillar_id, a.reputation_reward
                FROM achievements a
                WHERE a.achievement_type = 'META'
                  AND a.is_active = true";

            await using var metaCmd = new NpgsqlCommand(getMetaSql, connection, transaction);
            await using var metaReader = await metaCmd.ExecuteReaderAsync();

            var metaAchievements = new List<MetaAchievementInfo>();
            while (await metaReader.ReadAsync())
            {
                metaAchievements.Add(new MetaAchievementInfo
                {
                    Id = metaReader.GetGuid(0),
                    Code = metaReader.GetString(1),
                    Name = metaReader.GetString(2),
                    PillarId = metaReader.GetGuid(3),
                    ReputationReward = metaReader.GetInt32(4)
                });
            }
            metaReader.Close();

            // Check each meta-achievement's dependencies
            foreach (var meta in metaAchievements)
            {
                const string getDepsSql = @"
                    SELECT required_achievement_id, required_pillar_code
                    FROM achievement_dependencies
                    WHERE meta_achievement_id = @metaId";

                await using var depsCmd = new NpgsqlCommand(getDepsSql, connection, transaction);
                depsCmd.Parameters.AddWithValue("metaId", meta.Id);
                await using var depsReader = await depsCmd.ExecuteReaderAsync();

                var dependencies = new List<(Guid? achievementId, string? pillarCode)>();
                while (await depsReader.ReadAsync())
                {
                    var reqAchievementId = depsReader.IsDBNull(0) ? (Guid?)null : depsReader.GetGuid(0);
                    var reqPillarCode = depsReader.IsDBNull(1) ? null : depsReader.GetString(1);
                    dependencies.Add((reqAchievementId, reqPillarCode));
                }
                depsReader.Close();

                // Check if all dependencies are met
                bool allDependenciesMet = true;
                foreach (var (achievementId, pillarCode) in dependencies)
                {
                    if (achievementId.HasValue)
                    {
                        // Check if specific achievement is completed
                        const string checkAchievementSql = @"
                            SELECT COUNT(*) FROM member_achievement_progress
                            WHERE member_referral = @memberRef 
                              AND achievement_id = @achievementId 
                              AND is_completed = true";

                        await using var checkCmd = new NpgsqlCommand(checkAchievementSql, connection, transaction);
                        checkCmd.Parameters.AddWithValue("memberRef", memberReferral);
                        checkCmd.Parameters.AddWithValue("achievementId", achievementId.Value);
                        var count = await checkCmd.ExecuteScalarAsync();
                        if (Convert.ToInt32(count) == 0)
                        {
                            allDependenciesMet = false;
                            break;
                        }
                    }
                    else if (!string.IsNullOrWhiteSpace(pillarCode))
                    {
                        // Check if member has any completed achievement from this pillar
                        const string checkPillarSql = @"
                            SELECT COUNT(*) 
                            FROM member_achievement_progress map
                            JOIN achievements a ON map.achievement_id = a.id
                            JOIN pillars p ON a.pillar_id = p.id
                            WHERE map.member_referral = @memberRef
                              AND p.code = @pillarCode
                              AND map.is_completed = true";

                        await using var checkCmd = new NpgsqlCommand(checkPillarSql, connection, transaction);
                        checkCmd.Parameters.AddWithValue("memberRef", memberReferral);
                        checkCmd.Parameters.AddWithValue("pillarCode", pillarCode);
                        var count = await checkCmd.ExecuteScalarAsync();
                        if (Convert.ToInt32(count) == 0)
                        {
                            allDependenciesMet = false;
                            break;
                        }
                    }
                }

                // If all dependencies met, unlock meta-achievement
                if (allDependenciesMet)
                {
                    // Check if already unlocked
                    const string checkUnlockedSql = @"
                        SELECT COUNT(*) FROM member_achievement_progress
                        WHERE member_referral = @memberRef AND achievement_id = @metaId AND is_completed = true";

                    await using var checkUnlockedCmd = new NpgsqlCommand(checkUnlockedSql, connection, transaction);
                    checkUnlockedCmd.Parameters.AddWithValue("memberRef", memberReferral);
                    checkUnlockedCmd.Parameters.AddWithValue("metaId", meta.Id);
                    var alreadyUnlocked = Convert.ToInt32(await checkUnlockedCmd.ExecuteScalarAsync()) > 0;

                    if (!alreadyUnlocked)
                    {
                        // Insert progress and mark as completed
                        const string unlockMetaSql = @"
                            INSERT INTO member_achievement_progress 
                                (member_referral, achievement_id, progress, is_completed, completed_at)
                            VALUES (@memberRef, @metaId, 1, true, NOW())
                            ON CONFLICT (member_referral, achievement_id)
                            DO UPDATE SET is_completed = true, completed_at = NOW()";

                        await using var unlockCmd = new NpgsqlCommand(unlockMetaSql, connection, transaction);
                        unlockCmd.Parameters.AddWithValue("memberRef", memberReferral);
                        unlockCmd.Parameters.AddWithValue("metaId", meta.Id);
                        await unlockCmd.ExecuteNonQueryAsync();

                        // Grant title
                        await GrantTitleAsync(connection, transaction, memberReferral, meta.Id, meta.Name);

                        // Update reputation
                        await UpdateReputationAsync(connection, transaction, memberReferral, meta.ReputationReward);

                        unlocked.Add(new UnlockedAchievement
                        {
                            AchievementId = meta.Id,
                            Code = meta.Code,
                            Name = meta.Name,
                            PillarId = meta.PillarId
                        });
                    }
                }
            }

            return unlocked;
        }

        // Helper classes
        private class AchievementInfo
        {
            public Guid Id { get; set; }
            public Guid PillarId { get; set; }
            public string Code { get; set; } = "";
            public string Name { get; set; } = "";
            public string? Description { get; set; }
            public string AchievementType { get; set; } = "";
            public int? ProgressRequired { get; set; }
            public bool IsRepeatable { get; set; }
            public int ReputationReward { get; set; }
        }

        private class MetaAchievementInfo
        {
            public Guid Id { get; set; }
            public string Code { get; set; } = "";
            public string Name { get; set; } = "";
            public Guid PillarId { get; set; }
            public int ReputationReward { get; set; }
        }
    }

    // Result classes
    public class ProcessEventResult
    {
        public string EventType { get; set; } = "";
        public string MemberReferral { get; set; } = "";
        public List<UnlockedAchievement> UnlockedAchievements { get; set; } = new();
    }

    public class UnlockedAchievement
    {
        public Guid AchievementId { get; set; }
        public string Code { get; set; } = "";
        public string Name { get; set; } = "";
        public Guid PillarId { get; set; }
    }
}
