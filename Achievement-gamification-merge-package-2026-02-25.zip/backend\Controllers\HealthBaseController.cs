using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using ImagineBC.MainService.Services;
using ImagineBC.MainService.Services.Accounting;
using ImagineBC.MainService.Services.VideoConference;

namespace ImagineBC.MainService.Controllers
{
    [ApiController]
    [Route("api/healthbase")]
    public class HealthBaseController : ControllerBase
    {
        private readonly string _connectionString;
        private readonly ILogger<HealthBaseController> _logger;
        private readonly ServiceActivityService? _activityService;
        private readonly TokenService? _tokenService;
        private readonly AccountingService? _accountingService;
        private readonly HealthBaseService? _healthBaseService;

        public HealthBaseController(
            IConfiguration config,
            ILogger<HealthBaseController> logger,
            ILoggerFactory? loggerFactory = null,
            ServiceActivityService? activityService = null,
            TokenService? tokenService = null,
            AccountingService? accountingService = null,
            HealthBaseService? healthBaseService = null)
        {
            _connectionString = config.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Missing connection string.");
            _logger = logger;
            _activityService = activityService;
            _tokenService = tokenService;
            _accountingService = accountingService;
            ILogger<HealthBaseService> healthBaseLogger;
            if (loggerFactory != null)
            {
                healthBaseLogger = loggerFactory.CreateLogger<HealthBaseService>();
            }
            else
            {
                // Fallback: create a logger factory if not provided
                var factory = LoggerFactory.Create(builder => builder.AddConsole());
                healthBaseLogger = factory.CreateLogger<HealthBaseService>();
            }
            _healthBaseService = healthBaseService ?? new HealthBaseService(
                _connectionString,
                healthBaseLogger,
                activityService,
                accountingService,
                null);
        }

        /// <summary>
        /// Sync HealthBase appointment to Pia calendar
        /// </summary>
        private async Task SyncAppointmentToPiaCalendarAsync(NpgsqlConnection connection, int appointmentId, string patientReferral, int providerId, DateTime appointmentDate, string? reason, bool isTelemedicine, int? appointmentTypeId)
        {
            try
            {
                // Get provider name and appointment type name
                string? providerName = null;
                string? appointmentTypeName = null;
                
                const string providerSql = @"
                    SELECT first_name, last_name
                    FROM healthbase_providers
                    WHERE id = @providerId
                    LIMIT 1;
                ";
                using (var cmd = new NpgsqlCommand(providerSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId);
                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        var firstName = reader.IsDBNull(0) ? null : reader.GetString(0);
                        var lastName = reader.IsDBNull(1) ? null : reader.GetString(1);
                        providerName = $"{firstName} {lastName}".Trim();
                        if (string.IsNullOrWhiteSpace(providerName))
                        {
                            providerName = "Provider";
                        }
                    }
                }
                
                if (appointmentTypeId.HasValue)
                {
                    const string typeSql = @"
                        SELECT type_name
                        FROM healthbase_appointment_types
                        WHERE id = @typeId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(typeSql, connection))
                    {
                        cmd.Parameters.AddWithValue("typeId", appointmentTypeId.Value);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            appointmentTypeName = result.ToString();
                        }
                    }
                }
                
                // Build event title
                string eventTitle;
                if (!string.IsNullOrWhiteSpace(appointmentTypeName))
                {
                    eventTitle = $"{appointmentTypeName} with {providerName}";
                }
                else
                {
                    eventTitle = $"Health Appointment with {providerName}";
                }
                
                // Build event description
                var descriptionParts = new List<string>();
                if (!string.IsNullOrWhiteSpace(reason))
                {
                    descriptionParts.Add($"Reason: {reason}");
                }
                if (isTelemedicine)
                {
                    descriptionParts.Add("Telemedicine appointment");
                }
                descriptionParts.Add($"Appointment ID: {appointmentId}");
                var eventDescription = string.Join(". ", descriptionParts);
                
                // Set reminder to 1 day before appointment
                var reminderDate = appointmentDate.AddDays(-1);
                
                // Check if calendar event already exists for this appointment
                const string checkSql = @"
                    SELECT id
                    FROM member_pia_calendar
                    WHERE memberreferral = @memberReferral
                      AND event_description LIKE @appointmentIdPattern
                    LIMIT 1;
                ";
                string? existingEventId = null;
                using (var checkCmd = new NpgsqlCommand(checkSql, connection))
                {
                    checkCmd.Parameters.AddWithValue("memberReferral", patientReferral);
                    checkCmd.Parameters.AddWithValue("appointmentIdPattern", $"%Appointment ID: {appointmentId}%");
                    var result = await checkCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        existingEventId = result.ToString();
                    }
                }
                
                if (!string.IsNullOrWhiteSpace(existingEventId))
                {
                    // Update existing calendar event
                    const string updateSql = @"
                        UPDATE member_pia_calendar
                        SET event_title = @title,
                            event_description = @desc,
                            event_date = @date,
                            reminder_datetime = @reminder,
                            updated_at = NOW()
                        WHERE id = @eventId;
                    ";
                    using (var updateCmd = new NpgsqlCommand(updateSql, connection))
                    {
                        updateCmd.Parameters.AddWithValue("eventId", Guid.Parse(existingEventId));
                        updateCmd.Parameters.AddWithValue("title", eventTitle);
                        updateCmd.Parameters.AddWithValue("desc", eventDescription);
                        updateCmd.Parameters.AddWithValue("date", appointmentDate);
                        updateCmd.Parameters.AddWithValue("reminder", reminderDate);
                        await updateCmd.ExecuteNonQueryAsync();
                    }
                }
                else
                {
                    // Create new calendar event
                    const string insertSql = @"
                        INSERT INTO member_pia_calendar (memberreferral, event_title, event_description, event_date, reminder_datetime, is_recurring, recurrence_pattern, created_at, updated_at)
                        VALUES (@ref, @title, @desc, @date, @reminder, false, NULL, NOW(), NOW());
                    ";
                    using (var insertCmd = new NpgsqlCommand(insertSql, connection))
                    {
                        insertCmd.Parameters.AddWithValue("ref", patientReferral);
                        insertCmd.Parameters.AddWithValue("title", eventTitle);
                        insertCmd.Parameters.AddWithValue("desc", eventDescription);
                        insertCmd.Parameters.AddWithValue("date", appointmentDate);
                        insertCmd.Parameters.AddWithValue("reminder", reminderDate);
                        await insertCmd.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to sync appointment {AppointmentId} to Pia calendar", appointmentId);
                // Don't throw - calendar sync failure shouldn't break appointment creation
            }
        }
        
        /// <summary>
        /// Remove HealthBase appointment from Pia calendar (when cancelled)
        /// </summary>
        private async Task RemoveAppointmentFromPiaCalendarAsync(NpgsqlConnection connection, int appointmentId, string patientReferral)
        {
            try
            {
                const string deleteSql = @"
                    DELETE FROM member_pia_calendar
                    WHERE memberreferral = @memberReferral
                      AND event_description LIKE @appointmentIdPattern;
                ";
                using (var cmd = new NpgsqlCommand(deleteSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberReferral", patientReferral);
                    cmd.Parameters.AddWithValue("appointmentIdPattern", $"%Appointment ID: {appointmentId}%");
                    await cmd.ExecuteNonQueryAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to remove appointment {AppointmentId} from Pia calendar", appointmentId);
                // Don't throw - calendar sync failure shouldn't break appointment cancellation
            }
        }

        /// <summary>
        /// Check if member is eligible to access HealthBase based on originalreferrer
        /// </summary>
        private async Task<bool> IsEligibleMemberAsync(string memberReferral)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get member's originalreferrer
                string? originalReferrer = null;
                const string memberSql = @"
                    SELECT originalreferrer
                    FROM members
                    WHERE assignedreferral = @memberReferral
                    LIMIT 1;
                ";
                using (var cmd = new NpgsqlCommand(memberSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await cmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        originalReferrer = result.ToString()?.ToUpper();
                    }
                }

                if (string.IsNullOrWhiteSpace(originalReferrer))
                {
                    return false;
                }

                // Get eligible referrers from tokens table
                var eligibleReferrers = new List<string>();
                const string tokenSql = @"
                    SELECT stringvalue
                    FROM tokens
                    WHERE key = 'HEALTHBASE_ELIGIBLE_REFERRERS'
                    LIMIT 1;
                ";
                using (var cmd = new NpgsqlCommand(tokenSql, connection))
                {
                    var tokenValue = await cmd.ExecuteScalarAsync();
                    if (tokenValue != null && tokenValue != DBNull.Value)
                    {
                        var referrersStr = tokenValue.ToString();
                        if (!string.IsNullOrWhiteSpace(referrersStr))
                        {
                            eligibleReferrers = referrersStr.Split(',', StringSplitOptions.RemoveEmptyEntries)
                                .Select(r => r.Trim().ToUpper())
                                .ToList();
                        }
                    }
                }

                // If no eligible referrers configured, allow all (for testing)
                if (eligibleReferrers.Count == 0)
                {
                    return true;
                }

                return eligibleReferrers.Contains(originalReferrer);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking HealthBase eligibility for {MemberReferral}", memberReferral);
                return false;
            }
        }

        // ============================================================
        // HEALTH CHECK
        // ============================================================
        [HttpGet("health")]
        public IActionResult Health()
        {
            return Ok(new { ok = true, module = "healthbase" });
        }

        // ============================================================
        // PATIENT ENDPOINTS
        // ============================================================

        [HttpGet("patient/profile")]
        public async Task<IActionResult> GetPatientProfile([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        p.id,
                        p.member_referral,
                        p.patient_id,
                        p.date_of_birth,
                        p.gender,
                        p.blood_type,
                        p.emergency_contact_name,
                        p.emergency_contact_phone,
                        p.emergency_contact_relationship,
                        p.created_at,
                        p.updated_at
                    FROM healthbase_patients p
                    WHERE p.member_referral = @memberReferral
                    LIMIT 1;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var profile = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        profile[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    return Ok(new { success = true, profile });
                }

                return Ok(new { success = true, profile = (object?)null });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching patient profile for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("patient/profile")]
        public async Task<IActionResult> CreateOrUpdatePatientProfile([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
                {
                    return BadRequest(new { success = false, error = "memberReferral is required" });
                }

                var memberReferral = memberRefObj.ToString() ?? "";

                if (!await IsEligibleMemberAsync(memberReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                // Extract fields
                var patientId = request.TryGetValue("patientId", out var pidObj) ? pidObj?.ToString() : null;
                var dateOfBirth = request.TryGetValue("dateOfBirth", out var dobObj) && dobObj != null 
                    ? DateTime.Parse(dobObj.ToString() ?? "") 
                    : (DateTime?)null;
                var gender = request.TryGetValue("gender", out var genderObj) ? genderObj?.ToString() : null;
                var bloodType = request.TryGetValue("bloodType", out var btObj) ? btObj?.ToString() : null;
                var emergencyContactName = request.TryGetValue("emergencyContactName", out var ecnObj) ? ecnObj?.ToString() : null;
                var emergencyContactPhone = request.TryGetValue("emergencyContactPhone", out var ecpObj) ? ecpObj?.ToString() : null;
                var emergencyContactRelationship = request.TryGetValue("emergencyContactRelationship", out var ecrObj) ? ecrObj?.ToString() : null;

                if (dateOfBirth == null)
                {
                    return BadRequest(new { success = false, error = "dateOfBirth is required" });
                }

                // Generate patient ID if not provided
                if (string.IsNullOrWhiteSpace(patientId))
                {
                    patientId = $"HB-{memberReferral}-{DateTime.UtcNow:yyyyMMdd}";
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Check if profile exists
                const string checkSql = @"
                    SELECT id FROM healthbase_patients
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                int? existingId = null;
                using (var checkCmd = new NpgsqlCommand(checkSql, connection))
                {
                    checkCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await checkCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        existingId = Convert.ToInt32(result);
                    }
                }

                Dictionary<string, object?> profile;
                if (existingId.HasValue)
                {
                    // Update existing profile
                    const string updateSql = @"
                        UPDATE healthbase_patients
                        SET patient_id = @patientId,
                            date_of_birth = @dateOfBirth,
                            gender = @gender,
                            blood_type = @bloodType,
                            emergency_contact_name = @emergencyContactName,
                            emergency_contact_phone = @emergencyContactPhone,
                            emergency_contact_relationship = @emergencyContactRelationship,
                            updated_at = NOW()
                        WHERE id = @id
                        RETURNING id, member_referral, patient_id, date_of_birth, gender, blood_type,
                                  emergency_contact_name, emergency_contact_phone, emergency_contact_relationship,
                                  created_at, updated_at;
                    ";
                    using var updateCmd = new NpgsqlCommand(updateSql, connection);
                    updateCmd.Parameters.AddWithValue("id", existingId.Value);
                    updateCmd.Parameters.AddWithValue("patientId", patientId);
                    updateCmd.Parameters.AddWithValue("dateOfBirth", dateOfBirth.Value);
                    updateCmd.Parameters.AddWithValue("gender", (object?)gender ?? DBNull.Value);
                    updateCmd.Parameters.AddWithValue("bloodType", (object?)bloodType ?? DBNull.Value);
                    updateCmd.Parameters.AddWithValue("emergencyContactName", (object?)emergencyContactName ?? DBNull.Value);
                    updateCmd.Parameters.AddWithValue("emergencyContactPhone", (object?)emergencyContactPhone ?? DBNull.Value);
                    updateCmd.Parameters.AddWithValue("emergencyContactRelationship", (object?)emergencyContactRelationship ?? DBNull.Value);

                    using var reader = await updateCmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        profile = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            profile[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                    }
                    else
                    {
                        return StatusCode(500, new { success = false, error = "Failed to update patient profile" });
                    }
                }
                else
                {
                    // Create new profile
                    const string insertSql = @"
                        INSERT INTO healthbase_patients (
                            member_referral, patient_id, date_of_birth, gender, blood_type,
                            emergency_contact_name, emergency_contact_phone, emergency_contact_relationship
                        )
                        VALUES (
                            @memberReferral, @patientId, @dateOfBirth, @gender, @bloodType,
                            @emergencyContactName, @emergencyContactPhone, @emergencyContactRelationship
                        )
                        RETURNING id, member_referral, patient_id, date_of_birth, gender, blood_type,
                                  emergency_contact_name, emergency_contact_phone, emergency_contact_relationship,
                                  created_at, updated_at;
                    ";
                    using var insertCmd = new NpgsqlCommand(insertSql, connection);
                    insertCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    insertCmd.Parameters.AddWithValue("patientId", patientId);
                    insertCmd.Parameters.AddWithValue("dateOfBirth", dateOfBirth.Value);
                    insertCmd.Parameters.AddWithValue("gender", (object?)gender ?? DBNull.Value);
                    insertCmd.Parameters.AddWithValue("bloodType", (object?)bloodType ?? DBNull.Value);
                    insertCmd.Parameters.AddWithValue("emergencyContactName", (object?)emergencyContactName ?? DBNull.Value);
                    insertCmd.Parameters.AddWithValue("emergencyContactPhone", (object?)emergencyContactPhone ?? DBNull.Value);
                    insertCmd.Parameters.AddWithValue("emergencyContactRelationship", (object?)emergencyContactRelationship ?? DBNull.Value);

                    using var reader = await insertCmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        profile = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            profile[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                    }
                    else
                    {
                        return StatusCode(500, new { success = false, error = "Failed to create patient profile" });
                    }
                }

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"Patient profile {(existingId.HasValue ? "updated" : "created")}: {memberReferral}",
                    new { memberReferral, patientId });

                return Ok(new { success = true, profile });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating/updating patient profile");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpGet("patient/vitals")]
        public async Task<IActionResult> GetPatientVitals([FromQuery] string memberReferral, [FromQuery] int limit = 50, [FromQuery] int offset = 0)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        v.id,
                        v.patient_member_referral,
                        v.recorded_by_member_referral,
                        v.provider_id,
                        v.appointment_id,
                        v.systolic,
                        v.diastolic,
                        v.bp_status,
                        v.weight_kg,
                        v.height_cm,
                        v.bmi,
                        v.bmi_category,
                        v.temperature_celsius,
                        v.temperature_status,
                        v.heart_rate,
                        v.heart_rate_status,
                        v.respiratory_rate,
                        v.respiratory_status,
                        v.oxygen_saturation,
                        v.oxygen_status,
                        v.blood_glucose,
                        v.glucose_status,
                        v.pain_level,
                        v.notes,
                        v.recorded_at
                    FROM healthbase_patient_vitals v
                    WHERE v.patient_member_referral = @memberReferral
                    ORDER BY v.recorded_at DESC
                    LIMIT @limit OFFSET @offset;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("limit", limit);
                cmd.Parameters.AddWithValue("offset", offset);

                var vitals = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var vital = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        vital[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    vitals.Add(vital);
                }

                return Ok(new { success = true, vitals, count = vitals.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching patient vitals for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("patient/vitals")]
        public async Task<IActionResult> RecordVitals([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("patientMemberReferral", out var patientRefObj) || patientRefObj == null)
                {
                    return BadRequest(new { success = false, error = "patientMemberReferral is required" });
                }

                var patientReferral = patientRefObj.ToString() ?? "";
                var recordedByReferral = request.TryGetValue("recordedByMemberReferral", out var recordedByObj) 
                    ? recordedByObj?.ToString() ?? patientReferral 
                    : patientReferral;
                var providerId = request.TryGetValue("providerId", out var provIdObj) && provIdObj != null
                    ? (int?)Convert.ToInt32(provIdObj)
                    : null;
                var appointmentId = request.TryGetValue("appointmentId", out var apptIdObj) && apptIdObj != null
                    ? (int?)Convert.ToInt32(apptIdObj)
                    : null;

                // Extract vital signs
                var systolic = request.TryGetValue("systolic", out var sysObj) && sysObj != null ? (int?)Convert.ToInt32(sysObj) : null;
                var diastolic = request.TryGetValue("diastolic", out var diaObj) && diaObj != null ? (int?)Convert.ToInt32(diaObj) : null;
                var weightKg = request.TryGetValue("weightKg", out var wtObj) && wtObj != null ? (float?)Convert.ToSingle(wtObj) : null;
                var heightCm = request.TryGetValue("heightCm", out var htObj) && htObj != null ? (float?)Convert.ToSingle(htObj) : null;
                var temperatureCelsius = request.TryGetValue("temperatureCelsius", out var tempObj) && tempObj != null ? (float?)Convert.ToSingle(tempObj) : null;
                var heartRate = request.TryGetValue("heartRate", out var hrObj) && hrObj != null ? (int?)Convert.ToInt32(hrObj) : null;
                var respiratoryRate = request.TryGetValue("respiratoryRate", out var rrObj) && rrObj != null ? (int?)Convert.ToInt32(rrObj) : null;
                var oxygenSaturation = request.TryGetValue("oxygenSaturation", out var o2Obj) && o2Obj != null ? (int?)Convert.ToInt32(o2Obj) : null;
                var bloodGlucose = request.TryGetValue("bloodGlucose", out var bgObj) && bgObj != null ? (float?)Convert.ToSingle(bgObj) : null;
                var painLevel = request.TryGetValue("painLevel", out var painObj) && painObj != null ? (int?)Convert.ToInt32(painObj) : null;
                var notes = request.TryGetValue("notes", out var notesObj) ? notesObj?.ToString() : null;

                // Validate pain level
                if (painLevel.HasValue && (painLevel < 0 || painLevel > 10))
                {
                    return BadRequest(new { success = false, error = "painLevel must be between 0 and 10" });
                }

                // Calculate BMI if weight and height provided
                float? bmi = null;
                string? bmiCategory = null;
                if (weightKg.HasValue && heightCm.HasValue && heightCm > 0)
                {
                    var heightM = heightCm.Value / 100f;
                    bmi = weightKg.Value / (heightM * heightM);
                    
                    if (bmi < 18.5f)
                        bmiCategory = "underweight";
                    else if (bmi < 25f)
                        bmiCategory = "normal";
                    else if (bmi < 30f)
                        bmiCategory = "overweight";
                    else
                        bmiCategory = "obese";
                }

                // Determine BP status
                string? bpStatus = null;
                if (systolic.HasValue && diastolic.HasValue)
                {
                    if (systolic < 90 || diastolic < 60)
                        bpStatus = "low";
                    else if (systolic < 120 && diastolic < 80)
                        bpStatus = "normal";
                    else if (systolic < 130 && diastolic < 80)
                        bpStatus = "elevated";
                    else if (systolic < 140 || diastolic < 90)
                        bpStatus = "high";
                    else
                        bpStatus = "very_high";
                }

                // Determine temperature status
                string? temperatureStatus = null;
                if (temperatureCelsius.HasValue)
                {
                    if (temperatureCelsius < 35f)
                        temperatureStatus = "low";
                    else if (temperatureCelsius <= 37.5f)
                        temperatureStatus = "normal";
                    else if (temperatureCelsius <= 38.5f)
                        temperatureStatus = "fever";
                    else
                        temperatureStatus = "high_fever";
                }

                // Determine heart rate status
                string? heartRateStatus = null;
                if (heartRate.HasValue)
                {
                    if (heartRate < 60)
                        heartRateStatus = "low";
                    else if (heartRate <= 100)
                        heartRateStatus = "normal";
                    else if (heartRate <= 120)
                        heartRateStatus = "elevated";
                    else
                        heartRateStatus = "high";
                }

                // Determine respiratory rate status
                string? respiratoryStatus = null;
                if (respiratoryRate.HasValue)
                {
                    if (respiratoryRate < 12)
                        respiratoryStatus = "low";
                    else if (respiratoryRate <= 20)
                        respiratoryStatus = "normal";
                    else if (respiratoryRate <= 24)
                        respiratoryStatus = "elevated";
                    else
                        respiratoryStatus = "high";
                }

                // Determine oxygen saturation status
                string? oxygenStatus = null;
                if (oxygenSaturation.HasValue)
                {
                    if (oxygenSaturation < 90)
                        oxygenStatus = "critical";
                    else if (oxygenSaturation < 95)
                        oxygenStatus = "low";
                    else
                        oxygenStatus = "normal";
                }

                // Determine glucose status
                string? glucoseStatus = null;
                if (bloodGlucose.HasValue)
                {
                    if (bloodGlucose < 70f)
                        glucoseStatus = "low";
                    else if (bloodGlucose < 100f)
                        glucoseStatus = "normal";
                    else if (bloodGlucose < 126f)
                        glucoseStatus = "prediabetic";
                    else
                        glucoseStatus = "diabetic";
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string insertSql = @"
                    INSERT INTO healthbase_patient_vitals (
                        patient_member_referral, recorded_by_member_referral, provider_id, appointment_id,
                        systolic, diastolic, bp_status, weight_kg, height_cm, bmi, bmi_category,
                        temperature_celsius, temperature_status, heart_rate, heart_rate_status,
                        respiratory_rate, respiratory_status, oxygen_saturation, oxygen_status,
                        blood_glucose, glucose_status, pain_level, notes
                    )
                    VALUES (
                        @patientReferral, @recordedByReferral, @providerId, @appointmentId,
                        @systolic, @diastolic, @bpStatus, @weightKg, @heightCm, @bmi, @bmiCategory,
                        @temperatureCelsius, @temperatureStatus, @heartRate, @heartRateStatus,
                        @respiratoryRate, @respiratoryStatus, @oxygenSaturation, @oxygenStatus,
                        @bloodGlucose, @glucoseStatus, @painLevel, @notes
                    )
                    RETURNING id, patient_member_referral, recorded_by_member_referral, provider_id, appointment_id,
                              systolic, diastolic, bp_status, weight_kg, height_cm, bmi, bmi_category,
                              temperature_celsius, temperature_status, heart_rate, heart_rate_status,
                              respiratory_rate, respiratory_status, oxygen_saturation, oxygen_status,
                              blood_glucose, glucose_status, pain_level, notes, recorded_at;
                ";

                using var cmd = new NpgsqlCommand(insertSql, connection);
                cmd.Parameters.AddWithValue("patientReferral", patientReferral);
                cmd.Parameters.AddWithValue("recordedByReferral", recordedByReferral);
                cmd.Parameters.AddWithValue("providerId", (object?)providerId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("appointmentId", (object?)appointmentId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("systolic", (object?)systolic ?? DBNull.Value);
                cmd.Parameters.AddWithValue("diastolic", (object?)diastolic ?? DBNull.Value);
                cmd.Parameters.AddWithValue("bpStatus", (object?)bpStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("weightKg", (object?)weightKg ?? DBNull.Value);
                cmd.Parameters.AddWithValue("heightCm", (object?)heightCm ?? DBNull.Value);
                cmd.Parameters.AddWithValue("bmi", (object?)bmi ?? DBNull.Value);
                cmd.Parameters.AddWithValue("bmiCategory", (object?)bmiCategory ?? DBNull.Value);
                cmd.Parameters.AddWithValue("temperatureCelsius", (object?)temperatureCelsius ?? DBNull.Value);
                cmd.Parameters.AddWithValue("temperatureStatus", (object?)temperatureStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("heartRate", (object?)heartRate ?? DBNull.Value);
                cmd.Parameters.AddWithValue("heartRateStatus", (object?)heartRateStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("respiratoryRate", (object?)respiratoryRate ?? DBNull.Value);
                cmd.Parameters.AddWithValue("respiratoryStatus", (object?)respiratoryStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("oxygenSaturation", (object?)oxygenSaturation ?? DBNull.Value);
                cmd.Parameters.AddWithValue("oxygenStatus", (object?)oxygenStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("bloodGlucose", (object?)bloodGlucose ?? DBNull.Value);
                cmd.Parameters.AddWithValue("glucoseStatus", (object?)glucoseStatus ?? DBNull.Value);
                cmd.Parameters.AddWithValue("painLevel", (object?)painLevel ?? DBNull.Value);
                cmd.Parameters.AddWithValue("notes", (object?)notes ?? DBNull.Value);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var vital = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        vital[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Vitals recorded for {patientReferral}",
                        new { patientReferral, vitalId = vital["id"] });

                    // Emit gamification event for vitals recorded (fire and forget)
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var gamificationService = new GamificationService(_connectionString, null, null);
                            await gamificationService.ProcessEventAsync("HEALTHBASE_VITALS_RECORDED", patientReferral);
                        }
                        catch { /* Gamification should never block health operations */ }
                    });

                    return Ok(new { success = true, vital });
                }

                return StatusCode(500, new { success = false, error = "Failed to record vitals" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error recording vitals");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpGet("patient/health-passport")]
        public async Task<IActionResult> GetHealthPassport([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        hp.id,
                        hp.patient_member_referral,
                        hp.passport_number,
                        hp.qr_code,
                        hp.qr_code_access_level,
                        hp.blood_type,
                        hp.allergies,
                        hp.chronic_conditions,
                        hp.emergency_contact_name,
                        hp.emergency_contact_phone,
                        hp.emergency_contact_relationship,
                        hp.vaccination_records,
                        hp.current_medications,
                        hp.last_checkup_date,
                        hp.next_checkup_date,
                        hp.health_status,
                        hp.verified,
                        hp.issued_date,
                        hp.expiry_date,
                        hp.is_active,
                        hp.created_at,
                        hp.updated_at
                    FROM healthbase_health_passports hp
                    WHERE hp.patient_member_referral = @memberReferral
                      AND hp.is_active = true
                    LIMIT 1;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var passport = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        passport[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    return Ok(new { success = true, passport });
                }

                return Ok(new { success = true, passport = (object?)null });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching health passport for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("patient/health-passport")]
        public async Task<IActionResult> CreateHealthPassport([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            var memberReferral = memberRefObj.ToString() ?? "";

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Check if passport already exists
                    const string checkSql = @"
                        SELECT id FROM healthbase_health_passports
                        WHERE patient_member_referral = @memberReferral AND is_active = true
                        LIMIT 1;
                    ";
                    using (var checkCmd = new NpgsqlCommand(checkSql, connection, transaction))
                    {
                        checkCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var existingId = await checkCmd.ExecuteScalarAsync();
                        if (existingId != null && existingId != DBNull.Value)
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, message = "Health passport already exists for this member" });
                        }
                    }

                    // Generate passport number
                    var passportNumber = $"HP-{memberReferral}-{DateTime.UtcNow:yyyyMMddHHmmss}";

                    // Generate QR code (placeholder - in production, use a QR code library)
                    var qrCodeData = $"HEALTHPASSPORT:{passportNumber}:{memberReferral}";
                    var qrCodeUrl = $"https://api.qrserver.com/v1/create-qr-code/?size=250x250&data={Uri.EscapeDataString(qrCodeData)}";

                    // Extract optional fields
                    var bloodType = request.TryGetValue("bloodType", out var btObj) ? btObj?.ToString() : null;
                    var allergies = request.TryGetValue("allergies", out var allObj) ? allObj?.ToString() : null;
                    var chronicConditions = request.TryGetValue("chronicConditions", out var ccObj) ? ccObj?.ToString() : null;
                    var emergencyContactName = request.TryGetValue("emergencyContactName", out var ecnObj) ? ecnObj?.ToString() : null;
                    var emergencyContactPhone = request.TryGetValue("emergencyContactPhone", out var ecpObj) ? ecpObj?.ToString() : null;
                    var emergencyContactRelationship = request.TryGetValue("emergencyContactRelationship", out var ecrObj) ? ecrObj?.ToString() : null;

                    // Create passport
                    long passportId;
                    const string insertSql = @"
                        INSERT INTO healthbase_health_passports
                            (patient_member_referral, passport_number, qr_code, qr_code_access_level,
                             blood_type, allergies, chronic_conditions, emergency_contact_name,
                             emergency_contact_phone, emergency_contact_relationship, health_status,
                             verified, issued_date, expiry_date, is_active, created_at, updated_at)
                        VALUES
                            (@memberReferral, @passportNumber, @qrCode, 'private',
                             @bloodType, @allergies, @chronicConditions, @emergencyContactName,
                             @emergencyContactPhone, @emergencyContactRelationship, 'good',
                             true, CURRENT_DATE, CURRENT_DATE + INTERVAL '5 years', true, NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        cmd.Parameters.AddWithValue("passportNumber", passportNumber);
                        cmd.Parameters.AddWithValue("qrCode", qrCodeUrl);
                        cmd.Parameters.AddWithValue("bloodType", (object?)bloodType ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("allergies", (object?)allergies ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("chronicConditions", (object?)chronicConditions ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("emergencyContactName", (object?)emergencyContactName ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("emergencyContactPhone", (object?)emergencyContactPhone ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("emergencyContactRelationship", (object?)emergencyContactRelationship ?? DBNull.Value);
                        passportId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Health passport created: {passportNumber} for member {memberReferral}",
                        new { memberReferral, passportId, passportNumber });

                    return Ok(new { success = true, passportId, passportNumber, message = "Health passport created successfully" });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating health passport for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("patient/appointments")]
        public async Task<IActionResult> GetAppointments([FromQuery] string memberReferral, [FromQuery] string? status = null, [FromQuery] int limit = 50, [FromQuery] int offset = 0)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var sql = @"
                    SELECT 
                        a.id,
                        a.patient_member_referral,
                        a.provider_id,
                        a.appointment_type_id,
                        a.appointment_date,
                        a.duration_minutes,
                        a.status,
                        a.reason,
                        a.notes,
                        a.cancellation_reason,
                        a.cancelled_at,
                        a.is_telemedicine,
                        a.telemedicine_content_id,
                        a.price,
                        a.created_at,
                        a.updated_at,
                        p.member_referral as provider_member_referral,
                        p.license_number,
                        s.name as specialization_name,
                        at.name as appointment_type_name
                    FROM healthbase_appointments a
                    LEFT JOIN healthbase_providers p ON a.provider_id = p.id
                    LEFT JOIN healthbase_specializations s ON p.specialization_id = s.id
                    LEFT JOIN healthbase_appointment_types at ON a.appointment_type_id = at.id
                    WHERE a.patient_member_referral = @memberReferral
                ";

                if (!string.IsNullOrWhiteSpace(status))
                {
                    sql += " AND a.status = @status";
                }

                sql += " ORDER BY a.appointment_date DESC LIMIT @limit OFFSET @offset;";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                if (!string.IsNullOrWhiteSpace(status))
                {
                    cmd.Parameters.AddWithValue("status", status);
                }
                cmd.Parameters.AddWithValue("limit", limit);
                cmd.Parameters.AddWithValue("offset", offset);

                var appointments = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var appointment = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        appointment[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    appointments.Add(appointment);
                }

                return Ok(new { success = true, appointments, count = appointments.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching appointments for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================
        // PROVIDER ENDPOINTS
        // ============================================================

        [HttpGet("provider/profile")]
        public async Task<IActionResult> GetProviderProfile([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        p.id,
                        p.member_referral,
                        p.channel_referral,
                        p.specialization_id,
                        p.license_number,
                        p.license_expiry_date,
                        p.years_experience,
                        p.bio,
                        p.education,
                        p.rating,
                        p.total_ratings,
                        p.total_appointments,
                        p.total_earnings,
                        p.consultation_fee,
                        p.status,
                        p.approved_by,
                        p.approved_at,
                        p.created_at,
                        p.updated_at,
                        s.name as specialization_name,
                        s.code as specialization_code
                    FROM healthbase_providers p
                    LEFT JOIN healthbase_specializations s ON p.specialization_id = s.id
                    WHERE p.member_referral = @memberReferral
                    LIMIT 1;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var profile = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        profile[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    return Ok(new { success = true, profile });
                }

                return Ok(new { success = true, profile = (object?)null });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching provider profile for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/register")]
        public async Task<IActionResult> RegisterProvider([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
                {
                    return BadRequest(new { success = false, error = "memberReferral is required" });
                }

                var memberReferral = memberRefObj.ToString() ?? "";
                var licenseNumber = request.TryGetValue("licenseNumber", out var licObj) ? licObj?.ToString() : null;
                var specializationId = request.TryGetValue("specializationId", out var specObj) && specObj != null
                    ? (int?)Convert.ToInt32(specObj)
                    : null;
                var yearsExperience = request.TryGetValue("yearsExperience", out var expObj) && expObj != null
                    ? (int?)Convert.ToInt32(expObj)
                    : null;
                var consultationFee = request.TryGetValue("consultationFee", out var feeObj) && feeObj != null
                    ? Convert.ToDecimal(feeObj)
                    : 0m;
                var bio = request.TryGetValue("bio", out var bioObj) ? bioObj?.ToString() : null;
                var education = request.TryGetValue("education", out var eduObj) ? eduObj?.ToString() : null;
                var licenseExpiryDate = request.TryGetValue("licenseExpiryDate", out var expDateObj) && expDateObj != null
                    ? (DateTime?)DateTime.Parse(expDateObj.ToString() ?? "")
                    : null;

                if (string.IsNullOrWhiteSpace(licenseNumber))
                {
                    return BadRequest(new { success = false, error = "licenseNumber is required" });
                }

                if (!await IsEligibleMemberAsync(memberReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Check if provider already exists
                    const string checkSql = @"
                        SELECT id FROM healthbase_providers
                        WHERE member_referral = @memberReferral
                        LIMIT 1;
                    ";
                    int? existingProviderId = null;
                    using (var checkCmd = new NpgsqlCommand(checkSql, connection, transaction))
                    {
                        checkCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await checkCmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            existingProviderId = Convert.ToInt32(result);
                        }
                    }

                    if (existingProviderId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider already registered for this member" });
                    }

                    // Generate unique channel referral
                    string channelReferral;
                    const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                    var random = new Random();
                    bool exists;
                    do
                    {
                        channelReferral = new string(Enumerable.Repeat(chars, 8)
                            .Select(s => s[random.Next(s.Length)]).ToArray());
                        const string channelCheckSql = "SELECT COUNT(1) FROM channel WHERE LOWER(assignedreferral) = LOWER(@r)";
                        using (var cmd = new NpgsqlCommand(channelCheckSql, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("r", channelReferral);
                            exists = Convert.ToInt32(await cmd.ExecuteScalarAsync()) > 0;
                        }
                    } while (exists);

                    // Get member's full name for channel
                    string? memberFullName = null;
                    const string memberSql = @"
                        SELECT firstname FROM members
                        WHERE assignedreferral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(memberSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            memberFullName = result.ToString();
                        }
                    }

                    // Create channel for provider
                    const string insertChannelSql = @"
                        INSERT INTO channel (
                            assignedreferral, fullname, shortname, handle, description,
                            type, category, status, createdon, monetizationcurrency
                        )
                        VALUES (
                            @assignedreferral, @fullname, @shortname, @handle, @description,
                            'Provider', 'Healthcare', 'REVIEW', NOW(), 'KES'
                        )
                        ON CONFLICT (assignedreferral) DO NOTHING;
                    ";
                    using (var cmd = new NpgsqlCommand(insertChannelSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("assignedreferral", channelReferral);
                        cmd.Parameters.AddWithValue("fullname", memberFullName ?? $"Provider {memberReferral}");
                        cmd.Parameters.AddWithValue("shortname", memberFullName ?? $"Provider {memberReferral}");
                        cmd.Parameters.AddWithValue("handle", $"provider-{memberReferral}");
                        cmd.Parameters.AddWithValue("description", bio ?? "Healthcare provider");
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Create provider record
                    const string insertProviderSql = @"
                        INSERT INTO healthbase_providers (
                            member_referral, channel_referral, specialization_id, license_number,
                            license_expiry_date, years_experience, bio, education, consultation_fee, status
                        )
                        VALUES (
                            @memberReferral, @channelReferral, @specializationId, @licenseNumber,
                            @licenseExpiryDate, @yearsExperience, @bio, @education, @consultationFee, 'pending'
                        )
                        RETURNING id, member_referral, channel_referral, specialization_id, license_number,
                                  license_expiry_date, years_experience, bio, education, consultation_fee,
                                  status, created_at;
                    ";
                    using var providerCmd = new NpgsqlCommand(insertProviderSql, connection, transaction);
                    providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    providerCmd.Parameters.AddWithValue("channelReferral", channelReferral);
                    providerCmd.Parameters.AddWithValue("specializationId", (object?)specializationId ?? DBNull.Value);
                    providerCmd.Parameters.AddWithValue("licenseNumber", licenseNumber);
                    providerCmd.Parameters.AddWithValue("licenseExpiryDate", (object?)licenseExpiryDate ?? DBNull.Value);
                    providerCmd.Parameters.AddWithValue("yearsExperience", (object?)yearsExperience ?? DBNull.Value);
                    providerCmd.Parameters.AddWithValue("bio", (object?)bio ?? DBNull.Value);
                    providerCmd.Parameters.AddWithValue("education", (object?)education ?? DBNull.Value);
                    providerCmd.Parameters.AddWithValue("consultationFee", consultationFee);

                    using var reader = await providerCmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        var provider = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }

                        await transaction.CommitAsync();

                        _activityService?.Record("HealthBaseController", "SUCCESS",
                            $"Provider registered: {memberReferral}, Channel: {channelReferral}",
                            new { memberReferral, channelReferral, providerId = provider["id"] });

                        return Ok(new
                        {
                            success = true,
                            provider,
                            channelReferral,
                            message = "Provider registration submitted for approval"
                        });
                    }

                    await transaction.RollbackAsync();
                    return StatusCode(500, new { success = false, error = "Failed to create provider record" });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error registering provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================================
        // PROVIDER DASHBOARD & GIG ECONOMY ENDPOINTS
        // ============================================================================

        [HttpGet("provider/dashboard")]
        public async Task<IActionResult> GetProviderDashboard([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get provider ID
                int? providerId = null;
                const string providerSql = @"
                    SELECT id FROM healthbase_providers
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                using (var providerCmd = new NpgsqlCommand(providerSql, connection))
                {
                    providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await providerCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        providerId = Convert.ToInt32(result);
                    }
                }

                if (!providerId.HasValue)
                {
                    return Ok(new { success = true, dashboard = (object?)null });
                }

                // Get wallet balance from HelloKenya
                decimal walletBalance = 0m;
                decimal totalEarned = 0m;
                try
                {
                    // Query wallet balance directly from memberwalletbalances
                    using (var balanceCmd = connection.CreateCommand())
                    {
                        balanceCmd.CommandText = @"
                            SELECT transferable
                            FROM memberwalletbalances
                            WHERE referral_code = @referral";
                        balanceCmd.Parameters.AddWithValue("referral", memberReferral);
                        var balanceResult = balanceCmd.ExecuteScalar();
                        if (balanceResult != null && balanceResult != DBNull.Value)
                        {
                            walletBalance = Convert.ToDecimal(balanceResult);
                        }
                    }

                    // Get total earned from metadata
                    const string metadataSql = @"
                        SELECT total_earned_kes FROM hellokenya_wallet_metadata
                        WHERE member_id = @memberId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(metadataSql, connection))
                    {
                        cmd.Parameters.AddWithValue("memberId", memberReferral);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            totalEarned = Convert.ToDecimal(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error fetching wallet balance for provider dashboard");
                }

                // Get this month's earnings
                var monthStart = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
                decimal thisMonthEarnings = 0m;
                const string earningsSql = @"
                    SELECT COALESCE(SUM(amount_kes), 0)
                    FROM healthbase_provider_earnings
                    WHERE provider_id = @providerId
                      AND created_at >= @monthStart;
                ";
                using (var cmd = new NpgsqlCommand(earningsSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    cmd.Parameters.AddWithValue("monthStart", monthStart);
                    var result = await cmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        thisMonthEarnings = Convert.ToDecimal(result);
                    }
                }

                // Get performance metrics
                var metrics = new Dictionary<string, object?>();
                const string metricsSql = @"
                    SELECT 
                        punctuality_percentage,
                        completion_rate,
                        patient_retention_rate,
                        quality_score,
                        patient_satisfaction,
                        avg_response_time_minutes,
                        this_month_consultations,
                        this_month_vitals,
                        this_month_prescriptions,
                        this_month_follow_ups
                    FROM healthbase_provider_performance_metrics
                    WHERE provider_id = @providerId
                    LIMIT 1;
                ";
                using (var cmd = new NpgsqlCommand(metricsSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        metrics["punctuality"] = reader.IsDBNull(0) ? 0 : reader.GetDecimal(0);
                        metrics["completionRate"] = reader.IsDBNull(1) ? 0 : reader.GetDecimal(1);
                        metrics["patientRetention"] = reader.IsDBNull(2) ? 0 : reader.GetDecimal(2);
                        metrics["qualityScore"] = reader.IsDBNull(3) ? 0 : reader.GetDecimal(3);
                        metrics["patientSatisfaction"] = reader.IsDBNull(4) ? 0 : reader.GetDecimal(4);
                        metrics["avgResponseTime"] = reader.IsDBNull(5) ? 0 : reader.GetInt32(5);
                        metrics["thisMonthConsultations"] = reader.IsDBNull(6) ? 0 : reader.GetInt32(6);
                        metrics["thisMonthVitals"] = reader.IsDBNull(7) ? 0 : reader.GetInt32(7);
                        metrics["thisMonthPrescriptions"] = reader.IsDBNull(8) ? 0 : reader.GetInt32(8);
                        metrics["thisMonthFollowUps"] = reader.IsDBNull(9) ? 0 : reader.GetInt32(9);
                    }
                    else
                    {
                        // Initialize with defaults
                        metrics["punctuality"] = 0m;
                        metrics["completionRate"] = 0m;
                        metrics["patientRetention"] = 0m;
                        metrics["qualityScore"] = 0m;
                        metrics["patientSatisfaction"] = 0m;
                        metrics["avgResponseTime"] = 0;
                        metrics["thisMonthConsultations"] = 0;
                        metrics["thisMonthVitals"] = 0;
                        metrics["thisMonthPrescriptions"] = 0;
                        metrics["thisMonthFollowUps"] = 0;
                    }
                }

                // Get gig stats
                var gigStats = new Dictionary<string, object>();
                const string gigStatsSql = @"
                    SELECT 
                        COUNT(*) FILTER (WHERE status = 'completed') as completed,
                        COUNT(*) FILTER (WHERE status IN ('assigned', 'in_progress')) as active,
                        COALESCE(AVG(pay_amount_kes), 0) as avg_pay,
                        COUNT(*) FILTER (WHERE status = 'completed' AND completed_at >= @monthStart) as this_month_completed
                    FROM healthbase_provider_gigs
                    WHERE provider_id = @providerId;
                ";
                using (var cmd = new NpgsqlCommand(gigStatsSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    cmd.Parameters.AddWithValue("monthStart", monthStart);
                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        gigStats["completed"] = reader.IsDBNull(0) ? 0 : reader.GetInt64(0);
                        gigStats["active"] = reader.IsDBNull(1) ? 0 : reader.GetInt64(1);
                        gigStats["avgPay"] = reader.IsDBNull(2) ? 0m : reader.GetDecimal(2);
                        gigStats["thisMonthCompleted"] = reader.IsDBNull(3) ? 0 : reader.GetInt64(3);
                    }
                }

                // Get referral stats
                var referralStats = new Dictionary<string, object>();
                const string referralSql = @"
                    SELECT 
                        COUNT(*) as total_referred,
                        COUNT(*) FILTER (WHERE status = 'active') as active_referrals,
                        COALESCE(SUM(earnings_kes), 0) as total_earnings,
                        COUNT(*) FILTER (WHERE status = 'active' AND created_at >= @monthStart) as this_month_referrals,
                        COALESCE(SUM(earnings_kes) FILTER (WHERE created_at >= @monthStart), 0) as this_month_earnings
                    FROM healthbase_provider_referrals
                    WHERE provider_id = @providerId;
                ";
                using (var cmd = new NpgsqlCommand(referralSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    cmd.Parameters.AddWithValue("monthStart", monthStart);
                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        referralStats["totalReferred"] = reader.IsDBNull(0) ? 0 : reader.GetInt64(0);
                        referralStats["activeReferrals"] = reader.IsDBNull(1) ? 0 : reader.GetInt64(1);
                        referralStats["totalEarnings"] = reader.IsDBNull(2) ? 0m : reader.GetDecimal(2);
                        referralStats["thisMonthReferrals"] = reader.IsDBNull(3) ? 0 : reader.GetInt64(3);
                        referralStats["thisMonthEarnings"] = reader.IsDBNull(4) ? 0m : reader.GetDecimal(4);
                    }
                }

                return Ok(new
                {
                    success = true,
                    dashboard = new
                    {
                        wallet = new
                        {
                            balance = walletBalance,
                            totalEarned = totalEarned,
                            thisMonthEarnings = thisMonthEarnings
                        },
                        metrics = metrics,
                        gigStats = gigStats,
                        referralStats = referralStats
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching provider dashboard for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("provider/appointments")]
        public async Task<IActionResult> GetProviderAppointments([FromQuery] string memberReferral, [FromQuery] string? status = null)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get provider ID from member referral
                int? providerId = null;
                const string providerSql = @"
                    SELECT id FROM healthbase_providers
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                using (var providerCmd = new NpgsqlCommand(providerSql, connection))
                {
                    providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await providerCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        providerId = Convert.ToInt32(result);
                    }
                }

                if (!providerId.HasValue)
                {
                    return Ok(new { success = true, appointments = new List<object>(), count = 0 });
                }

                var sql = @"
                    SELECT 
                        a.id,
                        a.patient_member_referral,
                        a.provider_id,
                        a.appointment_type_id,
                        a.appointment_date,
                        a.duration_minutes,
                        a.status,
                        a.reason,
                        a.notes,
                        a.cancellation_reason,
                        a.cancelled_at,
                        a.is_telemedicine,
                        a.telemedicine_content_id,
                        a.price,
                        a.created_at,
                        a.updated_at,
                        at.name as appointment_type_name
                    FROM healthbase_appointments a
                    LEFT JOIN healthbase_appointment_types at ON a.appointment_type_id = at.id
                    WHERE a.provider_id = @providerId
                ";

                if (!string.IsNullOrWhiteSpace(status))
                {
                    sql += " AND a.status = @status";
                }

                sql += " ORDER BY a.appointment_date DESC;";

                using var appointmentsCmd = new NpgsqlCommand(sql, connection);
                appointmentsCmd.Parameters.AddWithValue("providerId", providerId.Value);
                if (!string.IsNullOrWhiteSpace(status))
                {
                    appointmentsCmd.Parameters.AddWithValue("status", status);
                }

                var appointments = new List<Dictionary<string, object?>>();
                using var appointmentsReader = await appointmentsCmd.ExecuteReaderAsync();
                while (await appointmentsReader.ReadAsync())
                {
                    var appointment = new Dictionary<string, object?>();
                    for (int i = 0; i < appointmentsReader.FieldCount; i++)
                    {
                        appointment[appointmentsReader.GetName(i)] = appointmentsReader.IsDBNull(i) ? null : appointmentsReader.GetValue(i);
                    }
                    appointments.Add(appointment);
                }

                return Ok(new { success = true, appointments, count = appointments.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching provider appointments for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("provider/gigs/available")]
        public async Task<IActionResult> GetAvailableGigs([FromQuery] string? memberReferral = null, [FromQuery] string? gigType = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var sql = @"
                    SELECT 
                        g.id,
                        g.provider_id,
                        g.gig_type,
                        g.title,
                        g.description,
                        g.patient_member_referral,
                        g.appointment_id,
                        g.status,
                        g.pay_amount_kes,
                        g.urgency_level,
                        g.required_response_time_minutes,
                        g.location_address,
                        g.location_latitude,
                        g.location_longitude,
                        g.scheduled_start_time,
                        g.scheduled_end_time,
                        g.created_at,
                        a.patient_member_referral as appointment_patient_referral
                    FROM healthbase_provider_gigs g
                    LEFT JOIN healthbase_appointments a ON g.appointment_id = a.id
                    WHERE g.status = 'available'
                ";

                if (!string.IsNullOrWhiteSpace(gigType))
                {
                    sql += " AND g.gig_type = @gigType";
                }

                sql += " ORDER BY g.urgency_level DESC, g.created_at ASC LIMIT 50;";

                using var cmd = new NpgsqlCommand(sql, connection);
                if (!string.IsNullOrWhiteSpace(gigType))
                {
                    cmd.Parameters.AddWithValue("gigType", gigType);
                }

                var gigs = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var gig = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        gig[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    gigs.Add(gig);
                }

                return Ok(new { success = true, gigs, count = gigs.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching available gigs");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/gigs/{gigId}/accept")]
        public async Task<IActionResult> AcceptGig([FromRoute] int gigId, [FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
            {
                return BadRequest(new { success = false, error = "memberReferral is required" });
            }

            var memberReferral = memberRefObj.ToString() ?? "";

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get provider ID
                    int? providerId = null;
                    const string providerSql = @"
                        SELECT id FROM healthbase_providers
                        WHERE member_referral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var providerCmd = new NpgsqlCommand(providerSql, connection, transaction))
                    {
                        providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await providerCmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            providerId = Convert.ToInt32(result);
                        }
                    }

                    if (!providerId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider not found" });
                    }

                    // Check if gig is available and update
                    const string updateSql = @"
                        UPDATE healthbase_provider_gigs
                        SET provider_id = @providerId,
                            status = 'assigned',
                            assigned_at = NOW(),
                            updated_at = NOW()
                        WHERE id = @gigId
                          AND status = 'available'
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(updateSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        cmd.Parameters.AddWithValue("gigId", gigId);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result == null || result == DBNull.Value)
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Gig not available or already assigned" });
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Provider {memberReferral} accepted gig {gigId}",
                        new { memberReferral, gigId, providerId });

                    return Ok(new { success = true, message = "Gig accepted successfully" });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error accepting gig {GigId} for {MemberReferral}", gigId, memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/gigs/{gigId}/complete")]
        public async Task<IActionResult> CompleteGig([FromRoute] int gigId, [FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
            {
                return BadRequest(new { success = false, error = "memberReferral is required" });
            }

            var memberReferral = memberRefObj.ToString() ?? "";

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get provider ID
                    int? providerId = null;
                    const string providerSql = @"
                        SELECT id FROM healthbase_providers
                        WHERE member_referral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var providerCmd = new NpgsqlCommand(providerSql, connection, transaction))
                    {
                        providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await providerCmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            providerId = Convert.ToInt32(result);
                        }
                    }

                    if (!providerId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider not found" });
                    }

                    // Get gig details
                    decimal payAmount = 0m;
                    const string gigSql = @"
                        SELECT pay_amount_kes, provider_id, status
                        FROM healthbase_provider_gigs
                        WHERE id = @gigId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(gigSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("gigId", gigId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (!await reader.ReadAsync())
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Gig not found" });
                        }

                        payAmount = reader.GetDecimal(0);
                        var gigProviderId = reader.GetInt32(1);
                        var status = reader.GetString(2);

                        if (gigProviderId != providerId.Value)
                        {
                            await transaction.RollbackAsync();
                            return Unauthorized(new { success = false, message = "Gig is not assigned to this provider" });
                        }

                        if (status != "assigned" && status != "in_progress")
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = $"Gig cannot be completed from status: {status}" });
                        }
                    }

                    // Update gig status
                    const string updateSql = @"
                        UPDATE healthbase_provider_gigs
                        SET status = 'completed',
                            completed_at = NOW(),
                            updated_at = NOW()
                        WHERE id = @gigId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("gigId", gigId);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Record earnings
                    const string earningsSql = @"
                        INSERT INTO healthbase_provider_earnings
                            (provider_id, earnings_type, amount_kes, points_awarded, period_type, reference_id, reference_type, description, created_at)
                        VALUES
                            (@providerId, 'gig_completion', @amount, 10, 'one_time', @gigId, 'gig', 'Gig completion payment', NOW());
                    ";
                    using (var cmd = new NpgsqlCommand(earningsSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        cmd.Parameters.AddWithValue("amount", payAmount);
                        cmd.Parameters.AddWithValue("gigId", gigId);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Credit wallet
                    if (payAmount > 0 && _accountingService != null)
                    {
                        var payload = new Newtonsoft.Json.Linq.JObject
                        {
                            ["memberReferral"] = memberReferral,
                            ["payAmount"] = payAmount,
                            ["gigId"] = gigId
                        };
                        var metadata = new Newtonsoft.Json.Linq.JObject
                        {
                            ["source"] = "healthbase_gig",
                            ["gigId"] = gigId,
                            ["transactionType"] = "gig_completion"
                        };
                        var creditResult = await Task.Run(() => _accountingService.ProcessDirectCredit(
                            memberReferral,
                            payAmount,
                            "Transferable",
                            payload,
                            metadata,
                            "production",
                            connection,
                            transaction
                        ));

                        if (creditResult["ok"]?.ToObject<bool>() != true)
                        {
                            _logger.LogWarning("Failed to credit wallet for gig completion, but gig marked as completed");
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Provider {memberReferral} completed gig {gigId} for {payAmount} KES",
                        new { memberReferral, gigId, payAmount, providerId });

                    return Ok(new { success = true, message = "Gig completed successfully", payAmount });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error completing gig {GigId} for {MemberReferral}", gigId, memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================================
        // PROVIDER LOAN SYSTEM & CREDIT SCORING ENDPOINTS
        // ============================================================================

        [HttpGet("provider/credit-score")]
        public async Task<IActionResult> GetProviderCreditScore([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get provider ID
                int? providerId = null;
                const string providerSql = @"
                    SELECT id FROM healthbase_providers
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                using (var providerCmd = new NpgsqlCommand(providerSql, connection))
                {
                    providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await providerCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        providerId = Convert.ToInt32(result);
                    }
                }

                if (!providerId.HasValue)
                {
                    return Ok(new { success = true, creditScore = (object?)null });
                }

                // Get or calculate credit score
                var creditScore = await CalculateOrGetCreditScoreAsync(connection, providerId.Value, memberReferral);

                return Ok(new { success = true, creditScore });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching credit score for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/loans/apply")]
        public async Task<IActionResult> ApplyForLoan([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
            {
                return BadRequest(new { success = false, error = "memberReferral is required" });
            }

            var memberReferral = memberRefObj.ToString() ?? "";

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            if (!request.TryGetValue("loanAmountKes", out var amountObj) || amountObj == null)
            {
                return BadRequest(new { success = false, error = "loanAmountKes is required" });
            }

            if (!request.TryGetValue("termMonths", out var termObj) || termObj == null)
            {
                return BadRequest(new { success = false, error = "termMonths is required" });
            }

            var loanAmountKes = Convert.ToDecimal(amountObj);
            var termMonths = Convert.ToInt32(termObj);
            var purpose = request.TryGetValue("purpose", out var purposeObj) ? purposeObj?.ToString() : null;
            var purposeDescription = request.TryGetValue("purposeDescription", out var descObj) ? descObj?.ToString() : null;

            if (termMonths != 3 && termMonths != 6 && termMonths != 12)
            {
                return BadRequest(new { success = false, error = "termMonths must be 3, 6, or 12" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get provider ID
                    int? providerId = null;
                    const string providerSql = @"
                        SELECT id FROM healthbase_providers
                        WHERE member_referral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var providerCmd = new NpgsqlCommand(providerSql, connection, transaction))
                    {
                        providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await providerCmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            providerId = Convert.ToInt32(result);
                        }
                    }

                    if (!providerId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider not found" });
                    }

                    // Get credit score
                    var creditScore = await CalculateOrGetCreditScoreAsync(connection, providerId.Value, memberReferral, transaction);
                    if (creditScore == null || !(creditScore.ContainsKey("eligible_for_loan") && Convert.ToBoolean(creditScore["eligible_for_loan"])))
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Not eligible for loan", creditScore });
                    }

                    decimal maxLoanAmount = creditScore.ContainsKey("max_loan_amount_kes") ? Convert.ToDecimal(creditScore["max_loan_amount_kes"]) : 0m;
                    if (loanAmountKes > maxLoanAmount)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = $"Loan amount exceeds maximum of {maxLoanAmount} KES" });
                    }

                    // Check for active loans
                    const string activeLoanSql = @"
                        SELECT COUNT(*) FROM healthbase_provider_loans
                        WHERE provider_id = @providerId AND status = 'active';
                    ";
                    int activeLoanCount = 0;
                    using (var cmd = new NpgsqlCommand(activeLoanSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        activeLoanCount = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                    }

                    if (activeLoanCount > 0)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider already has an active loan" });
                    }

                    // Calculate interest rate based on credit score
                    decimal creditScoreValue = creditScore.ContainsKey("credit_score") ? Convert.ToDecimal(creditScore["credit_score"]) : 0m;
                    decimal interestRate = creditScoreValue >= 750 ? 6.5m : creditScoreValue >= 700 ? 7.5m : 8.5m;

                    // Calculate monthly payment and total amount due
                    decimal monthlyRate = interestRate / 100 / 12;
                    decimal monthlyPayment = loanAmountKes * (monthlyRate * (decimal)Math.Pow((double)(1 + monthlyRate), termMonths)) / ((decimal)Math.Pow((double)(1 + monthlyRate), termMonths) - 1);
                    decimal totalAmountDue = monthlyPayment * termMonths;

                    // Create loan application
                    long loanId;
                    var firstPaymentDate = DateTime.UtcNow.AddMonths(1).Date;
                    var maturityDate = DateTime.UtcNow.AddMonths(termMonths).Date;
                    const string insertLoanSql = @"
                        INSERT INTO healthbase_provider_loans
                            (provider_id, loan_amount_kes, interest_rate, term_months, monthly_payment_kes, 
                             total_amount_due_kes, status, purpose, purpose_description, application_date,
                             first_payment_date, maturity_date, remaining_balance_kes, credit_score_at_application,
                             credit_limit_at_application, created_at, updated_at)
                        VALUES
                            (@providerId, @amount, @rate, @term, @monthly, @total, 'approved', @purpose, @purposeDesc,
                             NOW(), @firstPayment, @maturity, @amount, @creditScore, @creditLimit, NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertLoanSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        cmd.Parameters.AddWithValue("amount", loanAmountKes);
                        cmd.Parameters.AddWithValue("rate", interestRate);
                        cmd.Parameters.AddWithValue("term", termMonths);
                        cmd.Parameters.AddWithValue("monthly", monthlyPayment);
                        cmd.Parameters.AddWithValue("total", totalAmountDue);
                        cmd.Parameters.AddWithValue("purpose", (object?)purpose ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("purposeDesc", (object?)purposeDescription ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("firstPayment", firstPaymentDate);
                        cmd.Parameters.AddWithValue("maturity", maturityDate);
                        decimal creditScoreForInsert = creditScore.ContainsKey("credit_score") ? Convert.ToDecimal(creditScore["credit_score"]) : 0m;
                        decimal creditLimitForInsert = creditScore.ContainsKey("credit_limit_kes") ? Convert.ToDecimal(creditScore["credit_limit_kes"]) : 0m;
                        cmd.Parameters.AddWithValue("creditScore", creditScoreForInsert);
                        cmd.Parameters.AddWithValue("creditLimit", creditLimitForInsert);
                        loanId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    // Create payment schedule
                    var paymentDate = firstPaymentDate;
                    for (int i = 0; i < termMonths; i++)
                    {
                        const string insertPaymentSql = @"
                            INSERT INTO healthbase_loan_payments
                                (loan_id, provider_id, payment_amount_kes, principal_amount_kes, interest_amount_kes,
                                 status, due_date, created_at, updated_at)
                            VALUES
                                (@loanId, @providerId, @amount, @principal, @interest, 'pending', @dueDate, NOW(), NOW());
                        ";
                        using (var cmd = new NpgsqlCommand(insertPaymentSql, connection, transaction))
                        {
                            // Simplified: equal principal + interest per payment
                            decimal principalPerPayment = loanAmountKes / termMonths;
                            decimal interestPerPayment = monthlyPayment - principalPerPayment;
                            cmd.Parameters.AddWithValue("loanId", loanId);
                            cmd.Parameters.AddWithValue("providerId", providerId.Value);
                            cmd.Parameters.AddWithValue("amount", monthlyPayment);
                            cmd.Parameters.AddWithValue("principal", principalPerPayment);
                            cmd.Parameters.AddWithValue("interest", interestPerPayment);
                            cmd.Parameters.AddWithValue("dueDate", paymentDate);
                            await cmd.ExecuteNonQueryAsync();
                        }
                        paymentDate = paymentDate.AddMonths(1);
                    }

                    // Update loan status to active and set disbursement date
                    const string updateLoanSql = @"
                        UPDATE healthbase_provider_loans
                        SET status = 'active',
                            approved_date = NOW(),
                            disbursement_date = NOW(),
                            next_payment_date = @firstPayment,
                            updated_at = NOW()
                        WHERE id = @loanId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateLoanSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("loanId", loanId);
                        cmd.Parameters.AddWithValue("firstPayment", firstPaymentDate);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Credit wallet with loan amount
                    if (_accountingService != null)
                    {
                        var payload = new Newtonsoft.Json.Linq.JObject
                        {
                            ["memberReferral"] = memberReferral,
                            ["loanAmountKes"] = loanAmountKes,
                            ["loanId"] = loanId
                        };
                        var metadata = new Newtonsoft.Json.Linq.JObject
                        {
                            ["source"] = "healthbase_loan",
                            ["loanId"] = loanId,
                            ["transactionType"] = "loan_disbursement"
                        };
                        var creditResult = await Task.Run(() => _accountingService.ProcessDirectCredit(
                            memberReferral,
                            loanAmountKes,
                            "Transferable",
                            payload,
                            metadata,
                            "production",
                            connection,
                            transaction
                        ));

                        if (creditResult["ok"]?.ToObject<bool>() != true)
                        {
                            _logger.LogWarning("Failed to credit wallet for loan, but loan created");
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Loan application approved: {loanAmountKes} KES for provider {memberReferral}",
                        new { memberReferral, loanId, loanAmountKes, termMonths, interestRate });

                    return Ok(new
                    {
                        success = true,
                        loanId = loanId,
                        message = "Loan approved and disbursed",
                        loan = new
                        {
                            loanAmountKes,
                            interestRate,
                            termMonths,
                            monthlyPaymentKes = monthlyPayment,
                            totalAmountDueKes = totalAmountDue,
                            firstPaymentDate,
                            maturityDate
                        }
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing loan application for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("provider/loans")]
        public async Task<IActionResult> GetProviderLoans([FromQuery] string memberReferral, [FromQuery] string? status = null)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get provider ID
                int? providerId = null;
                const string providerSql = @"
                    SELECT id FROM healthbase_providers
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                using (var providerCmd = new NpgsqlCommand(providerSql, connection))
                {
                    providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await providerCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        providerId = Convert.ToInt32(result);
                    }
                }

                if (!providerId.HasValue)
                {
                    return Ok(new { success = true, loans = new List<object>(), activeLoan = (object?)null });
                }

                var sql = @"
                    SELECT 
                        id, loan_amount_kes, interest_rate, term_months, monthly_payment_kes,
                        total_amount_due_kes, status, purpose, purpose_description,
                        application_date, approved_date, disbursement_date, first_payment_date,
                        last_payment_date, next_payment_date, maturity_date, paid_off_date,
                        principal_paid_kes, interest_paid_kes, total_paid_kes, remaining_balance_kes,
                        payments_made, payments_on_time, payments_late, credit_score_at_application,
                        created_at, updated_at
                    FROM healthbase_provider_loans
                    WHERE provider_id = @providerId
                ";

                if (!string.IsNullOrWhiteSpace(status))
                {
                    sql += " AND status = @status";
                }

                sql += " ORDER BY created_at DESC;";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("providerId", providerId.Value);
                if (!string.IsNullOrWhiteSpace(status))
                {
                    cmd.Parameters.AddWithValue("status", status);
                }

                var loans = new List<Dictionary<string, object?>>();
                Dictionary<string, object?>? activeLoan = null;
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var loan = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        loan[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    loans.Add(loan);
                    if (loan["status"]?.ToString() == "active")
                    {
                        activeLoan = loan;
                    }
                }

                return Ok(new { success = true, loans, activeLoan });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching loans for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/loans/{loanId}/pay")]
        public async Task<IActionResult> MakeLoanPayment([FromRoute] long loanId, [FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
            {
                return BadRequest(new { success = false, error = "memberReferral is required" });
            }

            var memberReferral = memberRefObj.ToString() ?? "";

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get provider ID
                    int? providerId = null;
                    const string providerSql = @"
                        SELECT id FROM healthbase_providers
                        WHERE member_referral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var providerCmd = new NpgsqlCommand(providerSql, connection, transaction))
                    {
                        providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await providerCmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            providerId = Convert.ToInt32(result);
                        }
                    }

                    if (!providerId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider not found" });
                    }

                    // Get loan
                    const string loanSql = @"
                        SELECT provider_id, remaining_balance_kes, monthly_payment_kes, next_payment_date, status
                        FROM healthbase_provider_loans
                        WHERE id = @loanId
                        LIMIT 1;
                    ";
                    int? loanProviderId = null;
                    decimal? remainingBalance = null;
                    decimal? monthlyPayment = null;
                    DateTime? nextPaymentDate = null;
                    string? loanStatus = null;
                    using (var cmd = new NpgsqlCommand(loanSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("loanId", loanId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            loanProviderId = reader.GetInt32(0);
                            remainingBalance = reader.GetDecimal(1);
                            monthlyPayment = reader.GetDecimal(2);
                            nextPaymentDate = reader.IsDBNull(3) ? null : reader.GetDateTime(3);
                            loanStatus = reader.GetString(4);
                        }
                    }

                    if (loanProviderId == null || loanProviderId.Value != providerId.Value)
                    {
                        await transaction.RollbackAsync();
                        return Unauthorized(new { success = false, message = "Loan does not belong to this provider" });
                    }

                    if (loanStatus != "active")
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = $"Loan is not active (status: {loanStatus})" });
                    }

                    // Get next pending payment
                    const string paymentSql = @"
                        SELECT id, payment_amount_kes, principal_amount_kes, interest_amount_kes, due_date
                        FROM healthbase_loan_payments
                        WHERE loan_id = @loanId AND status = 'pending'
                        ORDER BY due_date ASC
                        LIMIT 1;
                    ";
                    long? paymentId = null;
                    decimal? paymentAmount = null;
                    decimal? principalAmount = null;
                    decimal? interestAmount = null;
                    DateTime? dueDate = null;
                    using (var cmd = new NpgsqlCommand(paymentSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("loanId", loanId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            paymentId = reader.GetInt64(0);
                            paymentAmount = reader.GetDecimal(1);
                            principalAmount = reader.GetDecimal(2);
                            interestAmount = reader.GetDecimal(3);
                            dueDate = reader.GetDateTime(4);
                        }
                    }

                    if (!paymentId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "No pending payments found" });
                    }

                    // Check wallet balance
                    decimal walletBalance = 0m;
                    using (var balanceCmd = connection.CreateCommand())
                    {
                        balanceCmd.Transaction = transaction;
                        balanceCmd.CommandText = @"
                            SELECT transferable
                            FROM memberwalletbalances
                            WHERE referral_code = @referral";
                        balanceCmd.Parameters.AddWithValue("referral", memberReferral);
                        var balanceResult = await balanceCmd.ExecuteScalarAsync();
                        if (balanceResult != null && balanceResult != DBNull.Value)
                        {
                            walletBalance = Convert.ToDecimal(balanceResult);
                        }
                    }

                    if (!paymentAmount.HasValue || walletBalance < paymentAmount.Value)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = $"Insufficient wallet balance. Required: {paymentAmount?.ToString() ?? "0"} KES, Available: {walletBalance} KES" });
                    }

                    // Extract values for use throughout this method
                    decimal paymentAmountValue = paymentAmount.Value;
                    decimal principalAmountValue = principalAmount ?? 0m;
                    decimal interestAmountValue = interestAmount ?? 0m;
                    bool isOnTime = dueDate.HasValue && paymentAmount.HasValue && DateTime.UtcNow.Date <= dueDate.Value.Date;

                    // Debit wallet
                    if (_accountingService != null)
                    {
                        var payload = new Newtonsoft.Json.Linq.JObject
                        {
                            ["memberReferral"] = memberReferral,
                            ["paymentAmount"] = paymentAmountValue,
                            ["loanId"] = loanId,
                            ["paymentId"] = paymentId ?? 0L
                        };
                        var metadata = new Newtonsoft.Json.Linq.JObject
                        {
                            ["source"] = "healthbase_loan_payment",
                            ["loanId"] = loanId,
                            ["paymentId"] = paymentId ?? 0L,
                            ["transactionType"] = "loan_payment"
                        };
                        var debitResult = await Task.Run(() => _accountingService.ProcessDirectDebit(
                            memberReferral,
                            paymentAmountValue,
                            "Transferable",
                            payload,
                            metadata,
                            "production",
                            connection,
                            transaction
                        ));

                        if (debitResult["ok"]?.ToObject<bool>() != true)
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Failed to debit wallet" });
                        }
                    }

                    // Update payment
                    
                    const string updatePaymentSql = @"
                        UPDATE healthbase_loan_payments
                        SET status = 'completed',
                            paid_date = NOW(),
                            is_on_time = @isOnTime,
                            updated_at = NOW()
                        WHERE id = @paymentId;
                    ";
                    using (var cmd = new NpgsqlCommand(updatePaymentSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("paymentId", paymentId ?? 0L);
                        cmd.Parameters.AddWithValue("isOnTime", isOnTime);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Update loan
                    decimal newRemainingBalance = (remainingBalance ?? 0m) - principalAmountValue;
                    int paymentsMade = 0;
                    int paymentsOnTime = 0;
                    int paymentsLate = 0;
                    const string getPaymentStatsSql = @"
                        SELECT 
                            COUNT(*) FILTER (WHERE status = 'completed') as payments_made,
                            COUNT(*) FILTER (WHERE status = 'completed' AND is_on_time = true) as payments_on_time,
                            COUNT(*) FILTER (WHERE status = 'completed' AND is_on_time = false) as payments_late
                        FROM healthbase_loan_payments
                        WHERE loan_id = @loanId;
                    ";
                    using (var cmd = new NpgsqlCommand(getPaymentStatsSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("loanId", loanId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            paymentsMade = reader.GetInt32(0);
                            paymentsOnTime = reader.GetInt32(1);
                            paymentsLate = reader.GetInt32(2);
                        }
                    }

                    DateTime? nextPayment = null;
                    if (newRemainingBalance > 0)
                    {
                        const string nextPaymentSql = @"
                            SELECT due_date FROM healthbase_loan_payments
                            WHERE loan_id = @loanId AND status = 'pending'
                            ORDER BY due_date ASC
                            LIMIT 1;
                        ";
                        using (var cmd = new NpgsqlCommand(nextPaymentSql, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("loanId", loanId);
                            var result = await cmd.ExecuteScalarAsync();
                            if (result != null && result != DBNull.Value)
                            {
                                nextPayment = Convert.ToDateTime(result);
                            }
                        }
                    }

                    string newStatus = newRemainingBalance <= 0 ? "paid_off" : "active";
                    const string updateLoanSql = @"
                        UPDATE healthbase_provider_loans
                        SET remaining_balance_kes = @remaining,
                            principal_paid_kes = principal_paid_kes + @principal,
                            interest_paid_kes = interest_paid_kes + @interest,
                            total_paid_kes = total_paid_kes + @payment,
                            payments_made = @paymentsMade,
                            payments_on_time = @paymentsOnTime,
                            payments_late = @paymentsLate,
                            next_payment_date = @nextPayment,
                            last_payment_date = NOW(),
                            status = @status,
                            paid_off_date = CASE WHEN @status = 'paid_off' THEN NOW() ELSE paid_off_date END,
                            updated_at = NOW()
                        WHERE id = @loanId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateLoanSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("remaining", newRemainingBalance);
                        cmd.Parameters.AddWithValue("principal", principalAmountValue);
                        cmd.Parameters.AddWithValue("interest", interestAmountValue);
                        cmd.Parameters.AddWithValue("payment", paymentAmountValue);
                        cmd.Parameters.AddWithValue("paymentsMade", paymentsMade);
                        cmd.Parameters.AddWithValue("paymentsOnTime", paymentsOnTime);
                        cmd.Parameters.AddWithValue("paymentsLate", paymentsLate);
                        cmd.Parameters.AddWithValue("nextPayment", (object?)nextPayment ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("status", newStatus);
                        cmd.Parameters.AddWithValue("loanId", loanId);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Loan payment made: {paymentAmountValue} KES for loan {loanId}",
                        new { memberReferral, loanId, paymentId, paymentAmount = paymentAmountValue, isOnTime });

                    return Ok(new
                    {
                        success = true,
                        message = "Payment processed successfully",
                        payment = new
                        {
                            paymentId = paymentId ?? 0L,
                            paymentAmount = paymentAmountValue,
                            principalAmount = principalAmountValue,
                            interestAmount = interestAmountValue,
                            isOnTime,
                            remainingBalance = newRemainingBalance,
                            loanStatus = newStatus
                        }
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing loan payment for loan {LoanId}", loanId);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================================
        // HELPER: Calculate or Get Credit Score
        // ============================================================================
        private async Task<Dictionary<string, object?>> CalculateOrGetCreditScoreAsync(
            NpgsqlConnection connection,
            int providerId,
            string memberReferral,
            NpgsqlTransaction? transaction = null)
        {
            // Get provider creation date for account age
            DateTime? providerCreatedAt = null;
            const string providerDateSql = @"
                SELECT created_at FROM healthbase_providers
                WHERE id = @providerId
                LIMIT 1;
            ";
            using (var cmd = new NpgsqlCommand(providerDateSql, connection))
            {
                if (transaction != null) cmd.Transaction = transaction;
                cmd.Parameters.AddWithValue("providerId", providerId);
                var result = await cmd.ExecuteScalarAsync();
                if (result != null && result != DBNull.Value)
                {
                    providerCreatedAt = Convert.ToDateTime(result);
                }
            }

            // Get performance metrics
            var metrics = new Dictionary<string, object?>();
            const string metricsSql = @"
                SELECT 
                    punctuality_percentage, completion_rate, patient_retention_rate,
                    quality_score, patient_satisfaction, this_month_consultations,
                    total_consultations, total_gigs_completed, total_gigs_successful
                FROM healthbase_provider_performance_metrics
                WHERE provider_id = @providerId
                LIMIT 1;
            ";
            using (var cmd = new NpgsqlCommand(metricsSql, connection))
            {
                if (transaction != null) cmd.Transaction = transaction;
                cmd.Parameters.AddWithValue("providerId", providerId);
                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    metrics["punctuality"] = reader.IsDBNull(0) ? 0m : reader.GetDecimal(0);
                    metrics["completionRate"] = reader.IsDBNull(1) ? 0m : reader.GetDecimal(1);
                    metrics["patientRetention"] = reader.IsDBNull(2) ? 0m : reader.GetDecimal(2);
                    metrics["qualityScore"] = reader.IsDBNull(3) ? 0m : reader.GetDecimal(3);
                    metrics["patientSatisfaction"] = reader.IsDBNull(4) ? 0m : reader.GetDecimal(4);
                    metrics["thisMonthConsultations"] = reader.IsDBNull(5) ? 0 : reader.GetInt32(5);
                    metrics["totalConsultations"] = reader.IsDBNull(6) ? 0 : reader.GetInt32(6);
                    metrics["totalGigsCompleted"] = reader.IsDBNull(7) ? 0 : reader.GetInt32(7);
                    metrics["totalGigsSuccessful"] = reader.IsDBNull(8) ? 0 : reader.GetInt32(8);
                }
            }

            // Get payment history (loan payments)
            int onTimePayments = 0;
            int totalPayments = 0;
            const string paymentHistorySql = @"
                SELECT 
                    COUNT(*) FILTER (WHERE is_on_time = true) as on_time,
                    COUNT(*) FILTER (WHERE status = 'completed') as total
                FROM healthbase_loan_payments
                WHERE provider_id = @providerId AND status = 'completed';
            ";
            using (var cmd = new NpgsqlCommand(paymentHistorySql, connection))
            {
                if (transaction != null) cmd.Transaction = transaction;
                cmd.Parameters.AddWithValue("providerId", providerId);
                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    onTimePayments = reader.GetInt32(0);
                    totalPayments = reader.GetInt32(1);
                }
            }

            // Calculate score components (0-100 each)
            int totalConsultations = Convert.ToInt32(metrics.GetValueOrDefault("totalConsultations", 0));
            int thisMonthConsultations = Convert.ToInt32(metrics.GetValueOrDefault("thisMonthConsultations", 0));
            int totalGigsCompleted = Convert.ToInt32(metrics.GetValueOrDefault("totalGigsCompleted", 0));
            int totalGigsSuccessful = Convert.ToInt32(metrics.GetValueOrDefault("totalGigsSuccessful", 0));
            decimal patientSatisfaction = Convert.ToDecimal(metrics.GetValueOrDefault("patientSatisfaction", 0m));
            
            int platformActivityScore = Math.Min(100, (int)((totalConsultations * 2 + 
                                                             thisMonthConsultations * 5 +
                                                             totalGigsCompleted * 3) / 10));
            int paymentHistoryScore = totalPayments > 0 ? (int)((onTimePayments * 100.0 / totalPayments)) : 100; // Perfect if no payments yet
            int gigCompletionScore = totalGigsCompleted > 0
                ? (int)((totalGigsSuccessful * 100.0 / totalGigsCompleted))
                : 100;
            int patientSatisfactionScore = (int)(patientSatisfaction * 20); // 5.0 = 100
            int accountAgeScore = providerCreatedAt.HasValue
                ? Math.Min(100, (int)((DateTime.UtcNow - providerCreatedAt.Value).TotalDays / 365.0 * 20)) // 5 years = 100
                : 0;

            // Calculate overall credit score (weighted average, max 850)
            int creditScore = (int)((platformActivityScore * 0.25 + paymentHistoryScore * 0.25 + gigCompletionScore * 0.15 +
                                    patientSatisfactionScore * 0.20 + accountAgeScore * 0.15) * 8.5); // Scale to 850

            // Calculate credit limit (based on score)
            decimal creditLimit = creditScore >= 750 ? 50000m : creditScore >= 700 ? 30000m : creditScore >= 650 ? 20000m : 10000m;
            bool eligibleForLoan = creditScore >= 600;
            decimal maxLoanAmount = creditLimit;

            // Update or insert credit score
            const string upsertSql = @"
                INSERT INTO healthbase_provider_credit_scores
                    (provider_id, credit_score, platform_activity_score, payment_history_score,
                     gig_completion_score, patient_satisfaction_score, account_age_score,
                     credit_limit_kes, eligible_for_loan, max_loan_amount_kes,
                     last_calculated_at, calculation_period_start, calculation_period_end,
                     created_at, updated_at)
                VALUES
                    (@providerId, @score, @platform, @payment, @gig, @satisfaction, @age,
                     @limit, @eligible, @max, NOW(), NOW() - INTERVAL '30 days', NOW(), NOW(), NOW())
                ON CONFLICT (provider_id) 
                DO UPDATE SET
                    credit_score = EXCLUDED.credit_score,
                    platform_activity_score = EXCLUDED.platform_activity_score,
                    payment_history_score = EXCLUDED.payment_history_score,
                    gig_completion_score = EXCLUDED.gig_completion_score,
                    patient_satisfaction_score = EXCLUDED.patient_satisfaction_score,
                    account_age_score = EXCLUDED.account_age_score,
                    credit_limit_kes = EXCLUDED.credit_limit_kes,
                    eligible_for_loan = EXCLUDED.eligible_for_loan,
                    max_loan_amount_kes = EXCLUDED.max_loan_amount_kes,
                    last_calculated_at = EXCLUDED.last_calculated_at,
                    calculation_period_start = EXCLUDED.calculation_period_start,
                    calculation_period_end = EXCLUDED.calculation_period_end,
                    updated_at = NOW()
                RETURNING *;
            ";
            using (var cmd = new NpgsqlCommand(upsertSql, connection))
            {
                if (transaction != null) cmd.Transaction = transaction;
                cmd.Parameters.AddWithValue("providerId", providerId);
                cmd.Parameters.AddWithValue("score", creditScore);
                cmd.Parameters.AddWithValue("platform", platformActivityScore);
                cmd.Parameters.AddWithValue("payment", paymentHistoryScore);
                cmd.Parameters.AddWithValue("gig", gigCompletionScore);
                cmd.Parameters.AddWithValue("satisfaction", patientSatisfactionScore);
                cmd.Parameters.AddWithValue("age", accountAgeScore);
                cmd.Parameters.AddWithValue("limit", creditLimit);
                cmd.Parameters.AddWithValue("eligible", eligibleForLoan);
                cmd.Parameters.AddWithValue("max", maxLoanAmount);
                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return result;
                }
            }

            // Fallback return
            return new Dictionary<string, object?>
            {
                ["credit_score"] = creditScore,
                ["platform_activity_score"] = platformActivityScore,
                ["payment_history_score"] = paymentHistoryScore,
                ["gig_completion_score"] = gigCompletionScore,
                ["patient_satisfaction_score"] = patientSatisfactionScore,
                ["account_age_score"] = accountAgeScore,
                ["credit_limit_kes"] = creditLimit,
                ["eligible_for_loan"] = eligibleForLoan,
                ["max_loan_amount_kes"] = maxLoanAmount
            };
        }

        // ============================================================================
        // PROVIDER REFERRAL PROGRAM ENDPOINTS
        // ============================================================================

        [HttpGet("provider/referral-code")]
        public async Task<IActionResult> GetProviderReferralCode([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get provider ID
                int? providerId = null;
                const string providerSql = @"
                    SELECT id FROM healthbase_providers
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                using (var providerCmd = new NpgsqlCommand(providerSql, connection))
                {
                    providerCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await providerCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        providerId = Convert.ToInt32(result);
                    }
                }

                if (!providerId.HasValue)
                {
                    return Ok(new { success = true, referralCode = (object?)null });
                }

                // Get or generate referral code
                string? referralCode = null;
                const string referralSql = @"
                    SELECT referral_code FROM healthbase_provider_referrals
                    WHERE provider_id = @providerId AND referral_code IS NOT NULL
                    LIMIT 1;
                ";
                using (var cmd = new NpgsqlCommand(referralSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    var result = await cmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        referralCode = result.ToString();
                    }
                }

                // Generate referral code if not exists
                if (string.IsNullOrWhiteSpace(referralCode))
                {
                    // Get provider name for code generation
                    string? providerName = null;
                    const string nameSql = @"
                        SELECT firstname FROM members
                        WHERE assignedreferral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(nameSql, connection))
                    {
                        cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                            providerName = result.ToString()?.Trim();
                    }

                    // Generate code: HELEXIA-{FIRST_NAME}-{LAST_NAME} or HELEXIA-{MEMBER_REFERRAL}
                    if (!string.IsNullOrWhiteSpace(providerName))
                    {
                        var nameParts = providerName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                        if (nameParts.Length >= 2)
                        {
                            referralCode = $"HELEXIA-{nameParts[0].ToUpper()}-{nameParts[1].ToUpper()}";
                        }
                        else
                        {
                            referralCode = $"HELEXIA-{nameParts[0].ToUpper()}";
                        }
                    }
                    else
                    {
                        referralCode = $"HELEXIA-{memberReferral}";
                    }

                    // Ensure uniqueness
                    int suffix = 1;
                    string originalCode = referralCode;
                    while (true)
                    {
                        const string checkSql = @"
                            SELECT COUNT(*) FROM healthbase_provider_referrals
                            WHERE referral_code = @code;
                        ";
                        using (var cmd = new NpgsqlCommand(checkSql, connection))
                        {
                            cmd.Parameters.AddWithValue("code", referralCode);
                            var count = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                            if (count == 0) break;
                            referralCode = $"{originalCode}-{suffix}";
                            suffix++;
                        }
                    }
                }

                // Get referral stats
                var stats = new Dictionary<string, object>();
                const string statsSql = @"
                    SELECT 
                        COUNT(*) as total_referred,
                        COUNT(*) FILTER (WHERE status = 'active') as active_referrals,
                        COALESCE(SUM(earnings_kes), 0) as total_earnings,
                        COUNT(*) FILTER (WHERE created_at >= DATE_TRUNC('month', CURRENT_DATE)) as this_month_referrals,
                        COALESCE(SUM(earnings_kes) FILTER (WHERE created_at >= DATE_TRUNC('month', CURRENT_DATE)), 0) as this_month_earnings
                    FROM healthbase_provider_referrals
                    WHERE provider_id = @providerId;
                ";
                using (var cmd = new NpgsqlCommand(statsSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        stats["totalReferred"] = reader.GetInt64(0);
                        stats["activeReferrals"] = reader.GetInt64(1);
                        stats["totalEarnings"] = reader.GetDecimal(2);
                        stats["thisMonthReferrals"] = reader.GetInt64(3);
                        stats["thisMonthEarnings"] = reader.GetDecimal(4);
                    }
                }

                // Get recent referrals
                var recentReferrals = new List<Dictionary<string, object?>>();
                const string recentSql = @"
                    SELECT 
                        id, referred_member_referral, referral_type, status,
                        earnings_kes, first_transaction_bonus, active_referral_bonus,
                        first_transaction_at, became_active_at, created_at
                    FROM healthbase_provider_referrals
                    WHERE provider_id = @providerId
                    ORDER BY created_at DESC
                    LIMIT 10;
                ";
                using (var cmd = new NpgsqlCommand(recentSql, connection))
                {
                    cmd.Parameters.AddWithValue("providerId", providerId.Value);
                    using var reader = await cmd.ExecuteReaderAsync();
                    while (await reader.ReadAsync())
                    {
                        var referral = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            referral[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                        recentReferrals.Add(referral);
                    }
                }

                return Ok(new
                {
                    success = true,
                    referralCode,
                    referralLink = $"{Request.Scheme}://{Request.Host}/healthbase?ref={referralCode}",
                    stats,
                    recentReferrals
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching referral code for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/referral/track")]
        public async Task<IActionResult> TrackReferral([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("referralCode", out var codeObj) || codeObj == null)
            {
                return BadRequest(new { success = false, error = "referralCode is required" });
            }

            if (!request.TryGetValue("referredMemberReferral", out var memberObj) || memberObj == null)
            {
                return BadRequest(new { success = false, error = "referredMemberReferral is required" });
            }

            var referralCode = codeObj.ToString() ?? "";
            var referredMemberReferral = memberObj.ToString() ?? "";
            var referralType = request.TryGetValue("referralType", out var typeObj) ? typeObj?.ToString() ?? "patient" : "patient";

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Find provider by referral code
                    int? providerId = null;
                    string? providerMemberReferral = null;
                    const string providerSql = @"
                        SELECT pr.provider_id, p.member_referral
                        FROM healthbase_provider_referrals pr
                        JOIN healthbase_providers p ON pr.provider_id = p.id
                        WHERE pr.referral_code = @code
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(providerSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("code", referralCode);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            providerId = reader.GetInt32(0);
                            providerMemberReferral = reader.GetString(1);
                        }
                    }

                    if (!providerId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Invalid referral code" });
                    }

                    // Check if referral already exists
                    bool referralExists = false;
                    const string checkSql = @"
                        SELECT COUNT(*) FROM healthbase_provider_referrals
                        WHERE provider_id = @providerId AND referred_member_referral = @referred;
                    ";
                    using (var cmd = new NpgsqlCommand(checkSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        cmd.Parameters.AddWithValue("referred", referredMemberReferral);
                        referralExists = Convert.ToInt32(await cmd.ExecuteScalarAsync()) > 0;
                    }

                    if (referralExists)
                    {
                        await transaction.RollbackAsync();
                        return Ok(new { success = true, message = "Referral already tracked" });
                    }

                    // Determine earnings based on referral type
                    decimal referralEarnings = referralType == "provider" ? 200m : 100m;
                    decimal firstTransactionBonus = 50m;

                    // Create referral record
                    long referralId;
                    const string insertSql = @"
                        INSERT INTO healthbase_provider_referrals
                            (provider_id, referred_member_referral, referral_type, referral_code,
                             earnings_kes, status, created_at, updated_at)
                        VALUES
                            (@providerId, @referred, @type, @code, 0, 'pending', NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        cmd.Parameters.AddWithValue("referred", referredMemberReferral);
                        cmd.Parameters.AddWithValue("type", referralType);
                        cmd.Parameters.AddWithValue("code", referralCode);
                        referralId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    // Award first transaction bonus immediately
                    if (_accountingService != null && providerMemberReferral != null)
                    {
                        var payload = new Newtonsoft.Json.Linq.JObject
                        {
                            ["providerMemberReferral"] = providerMemberReferral,
                            ["firstTransactionBonus"] = firstTransactionBonus,
                            ["referralId"] = referralId,
                            ["referralType"] = referralType
                        };
                        var metadata = new Newtonsoft.Json.Linq.JObject
                        {
                            ["source"] = "healthbase_referral",
                            ["referralId"] = referralId,
                            ["referralType"] = referralType,
                            ["transactionType"] = "referral_first_transaction_bonus"
                        };
                        var creditResult = await Task.Run(() => _accountingService.ProcessDirectCredit(
                            providerMemberReferral,
                            firstTransactionBonus,
                            "Transferable",
                            payload,
                            metadata,
                            "production",
                            connection,
                            transaction
                        ));

                        if (creditResult["ok"]?.ToObject<bool>() == true)
                        {
                            // Update referral with first transaction bonus
                            const string updateSql = @"
                                UPDATE healthbase_provider_referrals
                                SET first_transaction_bonus = @bonus,
                                    first_transaction_at = NOW(),
                                    earnings_kes = @bonus,
                                    updated_at = NOW()
                                WHERE id = @referralId;
                            ";
                            using (var cmd = new NpgsqlCommand(updateSql, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("referralId", referralId);
                                cmd.Parameters.AddWithValue("bonus", firstTransactionBonus);
                                await cmd.ExecuteNonQueryAsync();
                            }

                            // Record earnings
                            const string earningsSql = @"
                                INSERT INTO healthbase_provider_earnings
                                    (provider_id, earnings_type, amount_kes, points_awarded, period_type, reference_id, reference_type, description, created_at)
                                VALUES
                                    (@providerId, 'referral_bonus', @amount, 25, 'one_time', @referralId, 'referral', 'First transaction referral bonus', NOW());
                            ";
                            using (var cmd = new NpgsqlCommand(earningsSql, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("providerId", providerId.Value);
                                cmd.Parameters.AddWithValue("amount", firstTransactionBonus);
                                cmd.Parameters.AddWithValue("referralId", referralId);
                                await cmd.ExecuteNonQueryAsync();
                            }
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Referral tracked: {referredMemberReferral} referred by {referralCode}",
                        new { referralCode, referredMemberReferral, referralType, referralId });

                    return Ok(new
                    {
                        success = true,
                        message = "Referral tracked successfully",
                        referralId,
                        firstTransactionBonus
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error tracking referral");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("provider/referral/activate")]
        public async Task<IActionResult> ActivateReferral([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("referralId", out var idObj) || idObj == null)
            {
                return BadRequest(new { success = false, error = "referralId is required" });
            }

            var referralId = Convert.ToInt64(idObj);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get referral details
                    int? providerId = null;
                    string? providerMemberReferral = null;
                    string? referralType = null;
                    string? currentStatus = null;
                    decimal activeReferralBonus = 0m;
                    const string referralSql = @"
                        SELECT pr.provider_id, p.member_referral, pr.referral_type, pr.status
                        FROM healthbase_provider_referrals pr
                        JOIN healthbase_providers p ON pr.provider_id = p.id
                        WHERE pr.id = @referralId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(referralSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("referralId", referralId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            providerId = reader.GetInt32(0);
                            providerMemberReferral = reader.GetString(1);
                            referralType = reader.GetString(2);
                            currentStatus = reader.GetString(3);
                        }
                    }

                    if (!providerId.HasValue || currentStatus == "active")
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Referral not found or already active" });
                    }

                    // Determine active referral bonus
                    activeReferralBonus = referralType == "provider" ? 200m : 100m;

                    // Update referral status
                    const string updateSql = @"
                        UPDATE healthbase_provider_referrals
                        SET status = 'active',
                            became_active_at = NOW(),
                            active_referral_bonus = @bonus,
                            earnings_kes = earnings_kes + @bonus,
                            updated_at = NOW()
                        WHERE id = @referralId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("referralId", referralId);
                        cmd.Parameters.AddWithValue("bonus", activeReferralBonus);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Credit wallet
                    if (_accountingService != null && providerMemberReferral != null)
                    {
                        var payload = new Newtonsoft.Json.Linq.JObject
                        {
                            ["providerMemberReferral"] = providerMemberReferral,
                            ["activeReferralBonus"] = activeReferralBonus,
                            ["referralId"] = referralId,
                            ["referralType"] = referralType
                        };
                        var metadata = new Newtonsoft.Json.Linq.JObject
                        {
                            ["source"] = "healthbase_referral",
                            ["referralId"] = referralId,
                            ["referralType"] = referralType,
                            ["transactionType"] = "referral_active_bonus"
                        };
                        var creditResult = await Task.Run(() => _accountingService.ProcessDirectCredit(
                            providerMemberReferral,
                            activeReferralBonus,
                            "Transferable",
                            payload,
                            metadata,
                            "production",
                            connection,
                            transaction
                        ));

                        if (creditResult["ok"]?.ToObject<bool>() == true)
                        {
                            // Record earnings
                            const string earningsSql = @"
                                INSERT INTO healthbase_provider_earnings
                                    (provider_id, earnings_type, amount_kes, points_awarded, period_type, reference_id, reference_type, description, created_at)
                                VALUES
                                    (@providerId, 'referral_bonus', @amount, 25, 'one_time', @referralId, 'referral', 'Active referral bonus', NOW());
                            ";
                            using (var cmd = new NpgsqlCommand(earningsSql, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("providerId", providerId.Value);
                                cmd.Parameters.AddWithValue("amount", activeReferralBonus);
                                cmd.Parameters.AddWithValue("referralId", referralId);
                                await cmd.ExecuteNonQueryAsync();
                            }
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Referral activated: {referralId}",
                        new { referralId, activeReferralBonus });

                    return Ok(new
                    {
                        success = true,
                        message = "Referral activated successfully",
                        activeReferralBonus
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error activating referral {ReferralId}", referralId);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================================
        // GEO-LOCATION SERVICES DIRECTORY ENDPOINTS
        // ============================================================================

        [HttpGet("nearby-services")]
        public async Task<IActionResult> GetNearbyServices(
            [FromQuery] double? lat = null,
            [FromQuery] double? lng = null,
            [FromQuery] string? type = null,
            [FromQuery] double? radiusKm = 5.0)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Default to Nairobi if no coordinates provided
                if (!lat.HasValue || !lng.HasValue)
                {
                    lat = -1.2921;  // Nairobi coordinates
                    lng = 36.8219;
                }

                var sql = @"
                    SELECT 
                        id, service_name, service_type, category, address, city, country,
                        latitude, longitude, phone, email, website,
                        discount_rate, min_purchase_kes, max_discount_kes,
                        description, hours_of_operation, rating, total_reviews,
                        is_verified, is_active,
                        calculate_distance_km(@lat, @lng, latitude, longitude) as distance_km
                    FROM healthbase_nearby_services
                    WHERE is_active = true
                ";

                if (!string.IsNullOrWhiteSpace(type) && type != "all")
                {
                    sql += " AND service_type = @type";
                }

                sql += @"
                    AND calculate_distance_km(@lat, @lng, latitude, longitude) <= @radius
                    ORDER BY distance_km ASC
                    LIMIT 50;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("lat", (decimal)lat.Value);
                cmd.Parameters.AddWithValue("lng", (decimal)lng.Value);
                cmd.Parameters.AddWithValue("radius", (decimal)(radiusKm ?? 5.0));
                if (!string.IsNullOrWhiteSpace(type) && type != "all")
                {
                    cmd.Parameters.AddWithValue("type", type);
                }

                var services = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var service = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        service[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    services.Add(service);
                }

                return Ok(new { success = true, services, count = services.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching nearby services");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("nearby-services/visit")]
        public async Task<IActionResult> TrackServiceVisit([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
            {
                return BadRequest(new { success = false, error = "memberReferral is required" });
            }

            if (!request.TryGetValue("serviceId", out var serviceIdObj) || serviceIdObj == null)
            {
                return BadRequest(new { success = false, error = "serviceId is required" });
            }

            if (!request.TryGetValue("amount", out var amountObj) || amountObj == null)
            {
                return BadRequest(new { success = false, error = "amount is required" });
            }

            var memberReferral = memberRefObj.ToString() ?? "";
            var serviceId = Convert.ToInt64(serviceIdObj);
            var purchaseAmount = Convert.ToDecimal(amountObj);
            var paymentMethod = request.TryGetValue("paymentMethod", out var methodObj) ? methodObj?.ToString() ?? "mpesa" : "mpesa";
            var paymentReference = request.TryGetValue("paymentReference", out var refObj) ? refObj?.ToString() : null;

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get service details
                    decimal discountRate = 0m;
                    decimal minPurchase = 0m;
                    decimal? maxDiscount = null;
                    const string serviceSql = @"
                        SELECT discount_rate, min_purchase_kes, max_discount_kes
                        FROM healthbase_nearby_services
                        WHERE id = @serviceId AND is_active = true
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(serviceSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("serviceId", serviceId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            discountRate = reader.GetDecimal(0);
                            minPurchase = reader.GetDecimal(1);
                            maxDiscount = reader.IsDBNull(2) ? null : (decimal?)reader.GetDecimal(2);
                        }
                        else
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Service not found or inactive" });
                        }
                    }

                    // Calculate discount
                    decimal discountAmount = 0m;
                    if (purchaseAmount >= minPurchase && discountRate > 0)
                    {
                        discountAmount = purchaseAmount * discountRate / 100;
                        if (maxDiscount.HasValue && discountAmount > maxDiscount.Value)
                        {
                            discountAmount = maxDiscount.Value;
                        }
                    }

                    decimal finalAmount = purchaseAmount - discountAmount;

                    // Create visit record
                    long visitId;
                    const string insertVisitSql = @"
                        INSERT INTO healthbase_service_visits
                            (member_referral, service_id, visit_date, purchase_amount_kes,
                             discount_amount_kes, final_amount_kes, payment_method, payment_reference,
                             discount_rate_applied, status, created_at, updated_at)
                        VALUES
                            (@memberReferral, @serviceId, NOW(), @purchase, @discount, @final,
                             @paymentMethod, @paymentRef, @discountRate, 'completed', NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertVisitSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        cmd.Parameters.AddWithValue("serviceId", serviceId);
                        cmd.Parameters.AddWithValue("purchase", purchaseAmount);
                        cmd.Parameters.AddWithValue("discount", discountAmount);
                        cmd.Parameters.AddWithValue("final", finalAmount);
                        cmd.Parameters.AddWithValue("paymentMethod", paymentMethod);
                        cmd.Parameters.AddWithValue("paymentRef", (object?)paymentReference ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("discountRate", discountRate);
                        visitId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    // Record discount history
                    if (discountAmount > 0)
                    {
                        const string insertHistorySql = @"
                            INSERT INTO healthbase_service_discount_history
                                (member_referral, service_id, visit_id, original_amount_kes,
                                 discount_amount_kes, final_amount_kes, discount_rate, visit_date, created_at)
                            VALUES
                                (@memberReferral, @serviceId, @visitId, @original, @discount, @final,
                                 @discountRate, NOW(), NOW());
                        ";
                        using (var cmd = new NpgsqlCommand(insertHistorySql, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                            cmd.Parameters.AddWithValue("serviceId", serviceId);
                            cmd.Parameters.AddWithValue("visitId", visitId);
                            cmd.Parameters.AddWithValue("original", purchaseAmount);
                            cmd.Parameters.AddWithValue("discount", discountAmount);
                            cmd.Parameters.AddWithValue("final", finalAmount);
                            cmd.Parameters.AddWithValue("discountRate", discountRate);
                            await cmd.ExecuteNonQueryAsync();
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Service visit tracked: {memberReferral} visited service {serviceId}, saved {discountAmount} KES",
                        new { memberReferral, serviceId, purchaseAmount, discountAmount, finalAmount });

                    return Ok(new
                    {
                        success = true,
                        message = "Visit tracked successfully",
                        visit = new
                        {
                            visitId,
                            purchaseAmountKes = purchaseAmount,
                            discountAmountKes = discountAmount,
                            finalAmountKes = finalAmount,
                            discountRate = discountRate,
                            savings = discountAmount
                        }
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error tracking service visit");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("nearby-services/discounts")]
        public async Task<IActionResult> GetDiscountHistory([FromQuery] string memberReferral, [FromQuery] int? limit = 50)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        h.id, h.member_referral, h.service_id, h.visit_id,
                        h.original_amount_kes, h.discount_amount_kes, h.final_amount_kes,
                        h.discount_rate, h.visit_date, h.created_at,
                        s.service_name, s.service_type, s.address
                    FROM healthbase_service_discount_history h
                    JOIN healthbase_nearby_services s ON h.service_id = s.id
                    WHERE h.member_referral = @memberReferral
                    ORDER BY h.visit_date DESC
                    LIMIT @limit;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("limit", limit ?? 50);

                var discounts = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var discount = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        discount[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    discounts.Add(discount);
                }

                // Calculate total savings
                decimal totalSavings = discounts.Sum(d => Convert.ToDecimal(d["discount_amount_kes"] ?? 0m));

                return Ok(new
                {
                    success = true,
                    discounts,
                    totalSavings,
                    count = discounts.Count
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching discount history for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================================
        // AI SMART SCAN TECHNOLOGY ENDPOINTS
        // ============================================================================

        [HttpPost("ai-scan/initiate")]
        public async Task<IActionResult> InitiateAiScan([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("patientMemberReferral", out var patientObj) || patientObj == null)
            {
                return BadRequest(new { success = false, error = "patientMemberReferral is required" });
            }

            var patientMemberReferral = patientObj.ToString() ?? "";
            var providerMemberReferral = request.TryGetValue("providerMemberReferral", out var providerObj) ? providerObj?.ToString() : null;
            var scanType = !string.IsNullOrWhiteSpace(providerMemberReferral) ? "remote_scan" : "self_scan";

            if (!await IsEligibleMemberAsync(patientMemberReferral))
            {
                return Forbid("Member is not eligible to access HealthBase");
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Generate secure session token
                    var sessionToken = $"SCAN-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper()}";

                    // Create scan session
                    long sessionId;
                    const string insertSql = @"
                        INSERT INTO healthbase_ai_scan_sessions
                            (patient_member_referral, provider_member_referral, scan_type, session_token,
                             status, initiated_at, created_at, updated_at)
                        VALUES
                            (@patient, @provider, @type, @token, 'initiated', NOW(), NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("patient", patientMemberReferral);
                        cmd.Parameters.AddWithValue("provider", (object?)providerMemberReferral ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("type", scanType);
                        cmd.Parameters.AddWithValue("token", sessionToken);
                        sessionId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"AI scan session initiated: {sessionId} for patient {patientMemberReferral}",
                        new { sessionId, patientMemberReferral, providerMemberReferral, scanType });

                    return Ok(new
                    {
                        success = true,
                        sessionId,
                        sessionToken,
                        scanType,
                        message = "Scan session initiated. Start camera to begin scan."
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initiating AI scan");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("ai-scan/{sessionId}/start")]
        public async Task<IActionResult> StartAiScan([FromRoute] long sessionId, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Update session status
                    const string updateSql = @"
                        UPDATE healthbase_ai_scan_sessions
                        SET status = 'in_progress',
                            started_at = NOW(),
                            updated_at = NOW()
                        WHERE id = @sessionId AND status = 'initiated'
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(updateSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("sessionId", sessionId);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result == null || result == DBNull.Value)
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Session not found or already started" });
                        }
                    }

                    await transaction.CommitAsync();

                    return Ok(new { success = true, message = "Scan started" });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error starting AI scan {SessionId}", sessionId);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("ai-scan/{sessionId}/complete")]
        public async Task<IActionResult> CompleteAiScan([FromRoute] long sessionId, [FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("vitals", out var vitalsObj) || vitalsObj == null)
            {
                return BadRequest(new { success = false, error = "vitals data is required" });
            }

            var vitals = vitalsObj as Dictionary<string, object> ?? new Dictionary<string, object>();

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get session details
                    string? patientReferral = null;
                    string? providerReferral = null;
                    const string sessionSql = @"
                        SELECT patient_member_referral, provider_member_referral, status
                        FROM healthbase_ai_scan_sessions
                        WHERE id = @sessionId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(sessionSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("sessionId", sessionId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            patientReferral = reader.GetString(0);
                            providerReferral = reader.IsDBNull(1) ? null : reader.GetString(1);
                            var status = reader.GetString(2);
                            if (status != "in_progress")
                            {
                                await transaction.RollbackAsync();
                                return BadRequest(new { success = false, error = $"Session is not in progress (status: {status})" });
                            }
                        }
                        else
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Session not found" });
                        }
                    }

                    if (string.IsNullOrWhiteSpace(patientReferral))
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Patient referral not found" });
                    }

                    // Extract vitals from request
                    int? heartRate = vitals.TryGetValue("heartRate", out var hrObj) && hrObj != null ? Convert.ToInt32(hrObj) : null;
                    int? systolic = vitals.TryGetValue("systolic", out var sysObj) && sysObj != null ? Convert.ToInt32(sysObj) : null;
                    int? diastolic = vitals.TryGetValue("diastolic", out var diaObj) && diaObj != null ? Convert.ToInt32(diaObj) : null;
                    int? respiratoryRate = vitals.TryGetValue("respiratoryRate", out var rrObj) && rrObj != null ? Convert.ToInt32(rrObj) : null;
                    int? oxygenSaturation = vitals.TryGetValue("oxygenSaturation", out var o2Obj) && o2Obj != null ? Convert.ToInt32(o2Obj) : null;
                    string? stressLevel = vitals.TryGetValue("stressLevel", out var stressObj) ? stressObj?.ToString() : null;
                    decimal confidenceScore = vitals.TryGetValue("confidenceScore", out var confObj) && confObj != null ? Convert.ToDecimal(confObj) : 0m;
                    int? processingTimeMs = vitals.TryGetValue("processingTimeMs", out var timeObj) && timeObj != null ? Convert.ToInt32(timeObj) : null;

                    // Save scan results
                    long resultId;
                    const string insertResultSql = @"
                        INSERT INTO healthbase_ai_scan_results
                            (scan_session_id, heart_rate_bpm, systolic_bp, diastolic_bp,
                             respiratory_rate, oxygen_saturation, stress_level, confidence_score,
                             processing_time_ms, algorithm_version, status, created_at, updated_at)
                        VALUES
                            (@sessionId, @hr, @systolic, @diastolic, @rr, @o2, @stress, @confidence,
                             @processingTime, 'v1.0', 'completed', NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertResultSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("sessionId", sessionId);
                        cmd.Parameters.AddWithValue("hr", (object?)heartRate ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("systolic", (object?)systolic ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("diastolic", (object?)diastolic ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("rr", (object?)respiratoryRate ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("o2", (object?)oxygenSaturation ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("stress", (object?)stressLevel ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("confidence", confidenceScore);
                        cmd.Parameters.AddWithValue("processingTime", (object?)processingTimeMs ?? DBNull.Value);
                        resultId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    // Save to patient_vitals table
                    int? providerId = null;
                    if (!string.IsNullOrWhiteSpace(providerReferral))
                    {
                        const string providerSql = @"
                            SELECT id FROM healthbase_providers
                            WHERE member_referral = @providerReferral
                            LIMIT 1;
                        ";
                        using (var cmd = new NpgsqlCommand(providerSql, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("providerReferral", providerReferral);
                            var result = await cmd.ExecuteScalarAsync();
                            if (result != null && result != DBNull.Value)
                            {
                                providerId = Convert.ToInt32(result);
                            }
                        }
                    }

                    long? vitalsRecordId = null;
                    if (heartRate.HasValue || systolic.HasValue || diastolic.HasValue || respiratoryRate.HasValue || oxygenSaturation.HasValue)
                    {
                        const string insertVitalsSql = @"
                            INSERT INTO healthbase_patient_vitals
                                (patient_member_referral, recorded_by_member_referral, provider_id,
                                 heart_rate, systolic, diastolic, respiratory_rate, oxygen_saturation,
                                 recorded_at)
                            VALUES
                                (@patient, @recordedBy, @providerId, @hr, @systolic, @diastolic, @rr, @o2, NOW())
                            RETURNING id;
                        ";
                        using (var cmd = new NpgsqlCommand(insertVitalsSql, connection, transaction))
                        {
                            cmd.Parameters.AddWithValue("patient", patientReferral);
                            cmd.Parameters.AddWithValue("recordedBy", providerReferral ?? patientReferral);
                            cmd.Parameters.AddWithValue("providerId", (object?)providerId ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("hr", (object?)heartRate ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("systolic", (object?)systolic ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("diastolic", (object?)diastolic ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("rr", (object?)respiratoryRate ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("o2", (object?)oxygenSaturation ?? DBNull.Value);
                            var result = await cmd.ExecuteScalarAsync();
                            if (result != null && result != DBNull.Value)
                            {
                                vitalsRecordId = Convert.ToInt64(result);
                            }
                        }
                    }

                    // Update session
                    int? durationSeconds = null;
                    if (processingTimeMs.HasValue)
                    {
                        durationSeconds = processingTimeMs.Value / 1000;
                    }

                    const string updateSessionSql = @"
                        UPDATE healthbase_ai_scan_sessions
                        SET status = 'completed',
                            completed_at = NOW(),
                            duration_seconds = @duration,
                            results_saved = true,
                            vitals_record_id = @vitalsId,
                            updated_at = NOW()
                        WHERE id = @sessionId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateSessionSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("sessionId", sessionId);
                        cmd.Parameters.AddWithValue("duration", (object?)durationSeconds ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("vitalsId", (object?)vitalsRecordId ?? DBNull.Value);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Award reward for completing scan (if patient self-scan)
                    if (string.IsNullOrWhiteSpace(providerReferral) && _accountingService != null)
                    {
                        // Get reward activity for "AI Scan Completed"
                        decimal rewardKesAmount = 25m; // Default: 25 KES
                        int? rewardActivityId = null;
                        const string rewardSql = @"
                            SELECT id, kes_amount
                            FROM healthbase_reward_activities
                            WHERE activity_name ILIKE '%scan%' OR activity_name ILIKE '%vitals%'
                              AND is_active = true
                            LIMIT 1;
                        ";
                        using (var cmd = new NpgsqlCommand(rewardSql, connection, transaction))
                        {
                            using var reader = await cmd.ExecuteReaderAsync();
                            if (await reader.ReadAsync())
                            {
                                rewardActivityId = reader.GetInt32(0);
                                rewardKesAmount = reader.GetDecimal(1);
                            }
                        }

                        if (rewardKesAmount > 0)
                        {
                            await CreditWalletForRewardAsync(
                                patientReferral,
                                rewardKesAmount,
                                "AI Smart Scan Completed",
                                rewardActivityId,
                                connection,
                                transaction
                            );
                        }
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"AI scan completed: {sessionId}, vitals saved to record {vitalsRecordId}",
                        new { sessionId, resultId, vitalsRecordId, patientReferral });

                    return Ok(new
                    {
                        success = true,
                        message = "Scan completed and vitals saved",
                        resultId,
                        vitalsRecordId,
                        vitals = new
                        {
                            heartRate,
                            systolic,
                            diastolic,
                            respiratoryRate,
                            oxygenSaturation,
                            stressLevel,
                            confidenceScore
                        }
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error completing AI scan {SessionId}", sessionId);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("provider/patients")]
        public async Task<IActionResult> GetProviderPatients([FromQuery] string memberReferral, [FromQuery] int? limit = 50)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get provider ID
                int? providerId = null;
                const string providerSql = @"
                    SELECT id FROM healthbase_providers
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";
                using (var providerIdCmd = new NpgsqlCommand(providerSql, connection))
                {
                    providerIdCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await providerIdCmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        providerId = Convert.ToInt32(result);
                    }
                }

                if (!providerId.HasValue)
                {
                    return BadRequest(new { success = false, message = "Provider profile not found" });
                }

                // Get patients from appointments
                const string patientsSql = @"
                    SELECT DISTINCT
                        a.patient_member_referral,
                        m.primaryalias,
                        m.username,
                        COUNT(DISTINCT a.id) as appointment_count,
                        MAX(a.appointment_date) as last_appointment_date
                    FROM healthbase_appointments a
                    JOIN members m ON a.patient_member_referral = m.assignedreferral
                    WHERE a.provider_id = @providerId
                    GROUP BY a.patient_member_referral, m.primaryalias, m.username
                    ORDER BY MAX(a.appointment_date) DESC
                    LIMIT @limit;
                ";

                using var cmd = new NpgsqlCommand(patientsSql, connection);
                cmd.Parameters.AddWithValue("providerId", providerId.Value);
                cmd.Parameters.AddWithValue("limit", limit ?? 50);

                var patients = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var patient = new Dictionary<string, object?>();
                    patient["memberReferral"] = reader.GetString(0);
                    patient["name"] = reader.IsDBNull(1) ? reader.GetString(2) : reader.GetString(1);
                    patient["appointmentCount"] = reader.GetInt64(3);
                    patient["lastAppointmentDate"] = reader.IsDBNull(4) ? null : reader.GetDateTime(4).ToString("yyyy-MM-dd");
                    patients.Add(patient);
                }

                return Ok(new { success = true, patients, count = patients.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching provider patients for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("ai-scan/initiate-remote")]
        public async Task<IActionResult> InitiateRemoteScan([FromBody] Dictionary<string, object> request)
        {
            if (!request.TryGetValue("patientMemberReferral", out var patientObj) || patientObj == null)
            {
                return BadRequest(new { success = false, error = "patientMemberReferral is required" });
            }

            if (!request.TryGetValue("providerMemberReferral", out var providerObj) || providerObj == null)
            {
                return BadRequest(new { success = false, error = "providerMemberReferral is required" });
            }

            var patientMemberReferral = patientObj.ToString() ?? "";
            var providerMemberReferral = providerObj.ToString() ?? "";

            if (!await IsEligibleMemberAsync(patientMemberReferral))
            {
                return Forbid("Patient is not eligible to access HealthBase");
            }

            if (!await IsEligibleMemberAsync(providerMemberReferral))
            {
                return Forbid("Provider is not eligible to access HealthBase");
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Generate secure session token
                    var sessionToken = $"SCAN-REMOTE-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper()}";

                    // Create scan session (remote_scan type)
                    long sessionId;
                    const string insertSql = @"
                        INSERT INTO healthbase_ai_scan_sessions
                            (patient_member_referral, provider_member_referral, scan_type, session_token,
                             status, initiated_at, created_at, updated_at)
                        VALUES
                            (@patient, @provider, 'remote_scan', @token, 'initiated', NOW(), NOW(), NOW())
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("patient", patientMemberReferral);
                        cmd.Parameters.AddWithValue("provider", providerMemberReferral);
                        cmd.Parameters.AddWithValue("token", sessionToken);
                        sessionId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Remote AI scan session initiated: {sessionId} for patient {patientMemberReferral} by provider {providerMemberReferral}",
                        new { sessionId, patientMemberReferral, providerMemberReferral });

                    return Ok(new
                    {
                        success = true,
                        sessionId,
                        sessionToken,
                        scanType = "remote_scan",
                        message = "Remote scan session initiated. Patient can now start the scan."
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initiating remote AI scan");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("ai-scan/{sessionId}")]
        public async Task<IActionResult> GetAiScanSession([FromRoute] long sessionId)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        s.id, s.patient_member_referral, s.provider_member_referral, s.scan_type,
                        s.session_token, s.status, s.initiated_at, s.started_at, s.completed_at,
                        s.duration_seconds, s.results_saved, s.vitals_record_id, s.created_at,
                        r.heart_rate_bpm, r.systolic_bp, r.diastolic_bp, r.respiratory_rate,
                        r.oxygen_saturation, r.stress_level, r.confidence_score, r.status as result_status
                    FROM healthbase_ai_scan_sessions s
                    LEFT JOIN healthbase_ai_scan_results r ON s.id = r.scan_session_id
                    WHERE s.id = @sessionId
                    LIMIT 1;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("sessionId", sessionId);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var session = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        session[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    return Ok(new { success = true, session });
                }

                return Ok(new { success = true, session = (object?)null });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching AI scan session {SessionId}", sessionId);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("providers/search")]
        public async Task<IActionResult> SearchProviders(
            [FromQuery] string? specialization = null,
            [FromQuery] string? location = null,
            [FromQuery] int? minRating = null,
            [FromQuery] bool? hasAvailability = null)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var sql = @"
                    SELECT 
                        p.id,
                        p.member_referral,
                        p.channel_referral,
                        p.specialization_id,
                        p.license_number,
                        p.years_experience,
                        p.bio,
                        p.education,
                        p.rating,
                        p.total_ratings,
                        p.total_appointments,
                        p.consultation_fee,
                        p.status,
                        s.name as specialization_name,
                        s.code as specialization_code
                    FROM healthbase_providers p
                    LEFT JOIN healthbase_specializations s ON p.specialization_id = s.id
                    WHERE p.status = 'approved'
                ";

                if (!string.IsNullOrWhiteSpace(specialization))
                {
                    sql += " AND (LOWER(s.name) LIKE LOWER(@specialization) OR LOWER(s.code) LIKE LOWER(@specialization))";
                }

                if (minRating.HasValue)
                {
                    sql += " AND p.rating >= @minRating";
                }

                sql += " ORDER BY p.rating DESC, p.total_appointments DESC;";

                using var cmd = new NpgsqlCommand(sql, connection);
                if (!string.IsNullOrWhiteSpace(specialization))
                {
                    cmd.Parameters.AddWithValue("specialization", $"%{specialization}%");
                }
                if (minRating.HasValue)
                {
                    cmd.Parameters.AddWithValue("minRating", minRating.Value);
                }

                var providers = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var provider = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    providers.Add(provider);
                }

                return Ok(new { success = true, providers, count = providers.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching providers");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================
        // APPOINTMENT ENDPOINTS
        // ============================================================

        [HttpPost("appointments/create")]
        public async Task<IActionResult> CreateAppointment([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("patientMemberReferral", out var patientRefObj) || patientRefObj == null)
                {
                    return BadRequest(new { success = false, error = "patientMemberReferral is required" });
                }

                if (!request.TryGetValue("providerId", out var providerIdObj) || providerIdObj == null)
                {
                    return BadRequest(new { success = false, error = "providerId is required" });
                }

                if (!request.TryGetValue("appointmentDate", out var dateObj) || dateObj == null)
                {
                    return BadRequest(new { success = false, error = "appointmentDate is required" });
                }

                var patientReferral = patientRefObj.ToString() ?? "";
                var providerId = Convert.ToInt32(providerIdObj);
                var appointmentDate = DateTime.Parse(dateObj.ToString() ?? "");
                var isTelemedicine = request.TryGetValue("isTelemedicine", out var telemedObj) && 
                                    telemedObj != null && Convert.ToBoolean(telemedObj);
                var reason = request.TryGetValue("reason", out var reasonObj) ? reasonObj.ToString() : "";
                var appointmentTypeId = request.TryGetValue("appointmentTypeId", out var typeObj) ? 
                                       (int?)Convert.ToInt32(typeObj) : null;

                if (!await IsEligibleMemberAsync(patientReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get provider channel referral
                    string? providerChannelReferral = null;
                    decimal appointmentPrice = 0m;
                    const string providerSql = @"
                        SELECT channel_referral, consultation_fee
                        FROM healthbase_providers
                        WHERE id = @providerId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(providerSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId);
                        using var reader = await cmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            providerChannelReferral = reader.IsDBNull(0) ? null : reader.GetString(0);
                            appointmentPrice = reader.IsDBNull(1) ? 0m : reader.GetDecimal(1);
                        }
                    }

                    if (string.IsNullOrWhiteSpace(providerChannelReferral))
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Provider channel not found" });
                    }

                    // Create appointment record
                    int appointmentId;
                    const string insertAppointmentSql = @"
                        INSERT INTO healthbase_appointments (
                            patient_member_referral,
                            provider_id,
                            appointment_date,
                            appointment_type_id,
                            reason,
                            status,
                            is_telemedicine,
                            price,
                            created_at
                        )
                        VALUES (
                            @patientReferral,
                            @providerId,
                            @appointmentDate,
                            @appointmentTypeId,
                            @reason,
                            'scheduled',
                            @isTelemedicine,
                            @price,
                            NOW()
                        )
                        RETURNING id;
                    ";
                    using (var cmd = new NpgsqlCommand(insertAppointmentSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("patientReferral", patientReferral);
                        cmd.Parameters.AddWithValue("providerId", providerId);
                        cmd.Parameters.AddWithValue("appointmentDate", appointmentDate);
                        cmd.Parameters.AddWithValue("appointmentTypeId", appointmentTypeId ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("reason", reason ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("isTelemedicine", isTelemedicine);
                        cmd.Parameters.AddWithValue("price", appointmentPrice);
                        appointmentId = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                    }

                    // If telemedicine, create private BROADCAST content
                    long? broadcastContentId = null;
                    if (isTelemedicine && !string.IsNullOrWhiteSpace(providerChannelReferral))
                    {
                        // Get system manager referral for content ownership
                        string? systemManagerReferral = null;
                        const string systemManagerSql = @"
                            SELECT stringvalue
                            FROM tokens
                            WHERE key = 'SYSMANAGER-ASSIGNED-REFERRAL'
                            LIMIT 1;
                        ";
                        using (var cmd = new NpgsqlCommand(systemManagerSql, connection, transaction))
                        {
                            var result = await cmd.ExecuteScalarAsync();
                            if (result != null && result != DBNull.Value)
                            {
                                systemManagerReferral = result.ToString();
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(systemManagerReferral))
                        {
                            // Create private BROADCAST content for telemedicine
                            var titleSlug = $"telemedicine-{appointmentId}-{DateTime.UtcNow:yyyyMMddHHmmss}";
                            const string insertContentSql = @"
                                INSERT INTO channelcontent (
                                    channelreferral,
                                    contenttypeid,
                                    title,
                                    mediapathname,
                                    status,
                                    publishedat,
                                    createdby,
                                    includeinimaginarium,
                                    monetization_jsonb,
                                    textcontent
                                )
                                SELECT 
                                    @channelReferral,
                                    ct.id,
                                    @title,
                                    @mediapathname,
                                    'PUBLISHED',
                                    NOW(),
                                    0,
                                    false,
                                    '{""type"":""PRIVATE"",""isFree"":true}'::jsonb,
                                    @description
                                FROM contenttype ct
                                WHERE ct.typekey = 'BROADCAST'
                                LIMIT 1
                                RETURNING id;
                            ";
                            using (var cmd = new NpgsqlCommand(insertContentSql, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("channelReferral", systemManagerReferral);
                                cmd.Parameters.AddWithValue("title", $"Telemedicine Appointment #{appointmentId}");
                                cmd.Parameters.AddWithValue("mediapathname", titleSlug);
                                cmd.Parameters.AddWithValue("description", $"Private telemedicine session for appointment {appointmentId}");
                                var contentId = await cmd.ExecuteScalarAsync();
                                if (contentId != null && contentId != DBNull.Value)
                                {
                                    broadcastContentId = Convert.ToInt64(contentId);
                                }
                            }

                            // Link broadcast to appointment
                            if (broadcastContentId.HasValue)
                            {
                                const string updateAppointmentSql = @"
                                    UPDATE healthbase_appointments
                                    SET telemedicine_content_id = @contentId
                                    WHERE id = @appointmentId;
                                ";
                                using (var cmd = new NpgsqlCommand(updateAppointmentSql, connection, transaction))
                                {
                                    cmd.Parameters.AddWithValue("contentId", broadcastContentId.Value);
                                    cmd.Parameters.AddWithValue("appointmentId", appointmentId);
                                    await cmd.ExecuteNonQueryAsync();
                                }
                            }
                        }
                    }

                    // Process payment if price > 0
                    if (appointmentPrice > 0 && _accountingService != null && _healthBaseService != null)
                    {
                        var paymentResult = await _healthBaseService.ProcessAppointmentPaymentAsync(
                            patientReferral,
                            providerChannelReferral,
                            appointmentPrice,
                            appointmentId,
                            "production"
                        );

                        if (paymentResult?["ok"]?.ToObject<bool>() != true)
                        {
                            await transaction.RollbackAsync();
                            return StatusCode(500, new { success = false, error = paymentResult?["error"]?.ToString() ?? "Payment processing failed" });
                        }
                    }

                    await transaction.CommitAsync();

                    // Sync appointment to Pia calendar (use a new connection since transaction is committed)
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            using var syncConnection = new NpgsqlConnection(_connectionString);
                            await syncConnection.OpenAsync();
                            await SyncAppointmentToPiaCalendarAsync(syncConnection, appointmentId, patientReferral, providerId, appointmentDate, reason, isTelemedicine, appointmentTypeId);
                        }
                        catch (Exception syncEx)
                        {
                            // Log but don't fail the appointment creation if calendar sync fails
                            _logger.LogWarning(syncEx, "Failed to sync appointment {AppointmentId} to Pia calendar", appointmentId);
                        }
                    });

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Appointment created: {appointmentId}, Telemedicine: {isTelemedicine}",
                        new { appointmentId, patientReferral, providerId, isTelemedicine, broadcastContentId });

                    return Ok(new
                    {
                        success = true,
                        appointmentId,
                        broadcastContentId,
                        message = isTelemedicine ? "Telemedicine appointment created with private broadcast" : "Appointment created"
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ CreateAppointment failed");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("appointments/{id}/update")]
        public async Task<IActionResult> UpdateAppointment(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Check if appointment exists and get current status
                const string checkSql = @"
                    SELECT patient_member_referral, status
                    FROM healthbase_appointments
                    WHERE id = @id
                    LIMIT 1;
                ";
                string? patientReferral = null;
                string? currentStatus = null;
                using (var checkCmd = new NpgsqlCommand(checkSql, connection))
                {
                    checkCmd.Parameters.AddWithValue("id", id);
                    using var reader = await checkCmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        patientReferral = reader.IsDBNull(0) ? null : reader.GetString(0);
                        currentStatus = reader.IsDBNull(1) ? null : reader.GetString(1);
                    }
                }

                if (patientReferral == null)
                {
                    return NotFound(new { success = false, error = "Appointment not found" });
                }

                if (!await IsEligibleMemberAsync(patientReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                // Don't allow updates to completed or cancelled appointments
                if (currentStatus == "completed" || currentStatus == "cancelled")
                {
                    return BadRequest(new { success = false, error = $"Cannot update appointment with status '{currentStatus}'" });
                }

                // Extract updatable fields
                var appointmentDate = request.TryGetValue("appointmentDate", out var dateObj) && dateObj != null
                    ? (DateTime?)DateTime.Parse(dateObj.ToString() ?? "")
                    : null;
                var durationMinutes = request.TryGetValue("durationMinutes", out var durObj) && durObj != null
                    ? (int?)Convert.ToInt32(durObj)
                    : null;
                var reason = request.TryGetValue("reason", out var reasonObj) ? reasonObj?.ToString() : null;
                var notes = request.TryGetValue("notes", out var notesObj) ? notesObj?.ToString() : null;
                var status = request.TryGetValue("status", out var statusObj) ? statusObj?.ToString() : null;

                // Build update query dynamically
                var updateFields = new List<string>();
                var parameters = new List<NpgsqlParameter>();

                if (appointmentDate.HasValue)
                {
                    updateFields.Add("appointment_date = @appointmentDate");
                    parameters.Add(new NpgsqlParameter("appointmentDate", appointmentDate.Value));
                }
                if (durationMinutes.HasValue)
                {
                    updateFields.Add("duration_minutes = @durationMinutes");
                    parameters.Add(new NpgsqlParameter("durationMinutes", durationMinutes.Value));
                }
                if (reason != null)
                {
                    updateFields.Add("reason = @reason");
                    parameters.Add(new NpgsqlParameter("reason", (object?)reason ?? DBNull.Value));
                }
                if (notes != null)
                {
                    updateFields.Add("notes = @notes");
                    parameters.Add(new NpgsqlParameter("notes", (object?)notes ?? DBNull.Value));
                }
                if (status != null)
                {
                    updateFields.Add("status = @status");
                    parameters.Add(new NpgsqlParameter("status", status));
                }

                if (updateFields.Count == 0)
                {
                    return BadRequest(new { success = false, error = "No fields to update" });
                }

                updateFields.Add("updated_at = NOW()");

                var updateSql = $@"
                    UPDATE healthbase_appointments
                    SET {string.Join(", ", updateFields)}
                    WHERE id = @id
                    RETURNING id, patient_member_referral, provider_id, appointment_type_id, appointment_date,
                              duration_minutes, status, reason, notes, cancellation_reason, cancelled_at,
                              is_telemedicine, telemedicine_content_id, price, created_at, updated_at;
                ";

                using var updateCmd = new NpgsqlCommand(updateSql, connection);
                updateCmd.Parameters.AddWithValue("id", id);
                foreach (var param in parameters)
                {
                    updateCmd.Parameters.Add(param);
                }

                using var updateReader = await updateCmd.ExecuteReaderAsync();
                if (await updateReader.ReadAsync())
                {
                    var appointment = new Dictionary<string, object?>();
                    for (int i = 0; i < updateReader.FieldCount; i++)
                    {
                        appointment[updateReader.GetName(i)] = updateReader.IsDBNull(i) ? null : updateReader.GetValue(i);
                    }
                    
                    // Award reward if appointment was just marked as completed
                    if (status == "completed" && currentStatus != "completed")
                    {
                        var patientRef = appointment.ContainsKey("patient_member_referral") 
                            ? appointment["patient_member_referral"]?.ToString() 
                            : null;
                        
                        if (!string.IsNullOrWhiteSpace(patientRef))
                        {
                            // Get reward activity for "Appointment Completed"
                            int? rewardActivityId = null;
                            decimal rewardKesAmount = 50m; // Default: 50 KES
                            const string rewardActivitySql = @"
                                SELECT id, kes_amount
                                FROM healthbase_reward_activities
                                WHERE activity_name ILIKE '%appointment%complete%'
                                  AND is_active = true
                                LIMIT 1;
                            ";
                            using (var rewardCmd = new NpgsqlCommand(rewardActivitySql, connection))
                            {
                                using var rewardReader = await rewardCmd.ExecuteReaderAsync();
                                if (await rewardReader.ReadAsync())
                                {
                                    rewardActivityId = rewardReader.GetInt32(0);
                                    rewardKesAmount = rewardReader.GetDecimal(1);
                                }
                            }

                            // Credit wallet for reward (async, don't block appointment update)
                            _ = Task.Run(async () =>
                            {
                                try
                                {
                                    await CreditWalletForRewardAsync(
                                        patientRef!,
                                        rewardKesAmount,
                                        "Appointment Completed",
                                        rewardActivityId
                                    );
                                }
                                catch (Exception ex)
                                {
                                    _logger.LogError(ex, "Failed to credit wallet for appointment completion reward");
                                }
                            });

                            // Emit gamification events for appointment completion + health reward (fire and forget)
                            _ = Task.Run(async () =>
                            {
                                try
                                {
                                    var gamificationService = new GamificationService(_connectionString, null, null);
                                    await gamificationService.ProcessEventAsync("HEALTHBASE_APPOINTMENT_COMPLETED", patientRef!);
                                    await gamificationService.ProcessEventAsync("HEALTHBASE_HEALTH_REWARD_EARNED", patientRef!);
                                }
                                catch { /* Gamification should never block health operations */ }
                            });
                        }
                    }
                    
                    // Sync updated appointment to Pia calendar
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            using var syncConnection = new NpgsqlConnection(_connectionString);
                            await syncConnection.OpenAsync();
                            var updatedProviderId = appointment.ContainsKey("provider_id") ? Convert.ToInt32(appointment["provider_id"]) : 0;
                            var updatedDate = appointment.ContainsKey("appointment_date") ? Convert.ToDateTime(appointment["appointment_date"]) : DateTime.Now;
                            var updatedReason = appointment.ContainsKey("reason") ? appointment["reason"]?.ToString() : null;
                            var updatedIsTelemedicine = appointment.ContainsKey("is_telemedicine") && Convert.ToBoolean(appointment["is_telemedicine"]);
                            var updatedTypeId = appointment.ContainsKey("appointment_type_id") && appointment["appointment_type_id"] != null 
                                ? (int?)Convert.ToInt32(appointment["appointment_type_id"]) 
                                : null;
                            await SyncAppointmentToPiaCalendarAsync(syncConnection, id, patientReferral, updatedProviderId, updatedDate, updatedReason, updatedIsTelemedicine, updatedTypeId);
                        }
                        catch (Exception syncEx)
                        {
                            _logger.LogWarning(syncEx, "Failed to sync updated appointment {AppointmentId} to Pia calendar", id);
                        }
                    });

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Appointment {id} updated",
                        new { appointmentId = id, patientReferral });

                    return Ok(new { success = true, appointment });
                }

                return StatusCode(500, new { success = false, error = "Failed to update appointment" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating appointment {AppointmentId}", id);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPost("appointments/{id}/cancel")]
        public async Task<IActionResult> CancelAppointment(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                var cancellationReason = request.TryGetValue("cancellationReason", out var reasonObj) ? reasonObj?.ToString() : null;
                var cancelledBy = request.TryGetValue("cancelledBy", out var byObj) ? byObj?.ToString() : null;

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get appointment details
                    const string getSql = @"
                        SELECT patient_member_referral, provider_id, appointment_date, status, price, is_telemedicine
                        FROM healthbase_appointments
                        WHERE id = @id
                        FOR UPDATE;
                    ";
                    string? patientReferral = null;
                    int? providerId = null;
                    DateTime? appointmentDate = null;
                    string? currentStatus = null;
                    decimal price = 0m;
                    bool isTelemedicine = false;

                    using (var getCmd = new NpgsqlCommand(getSql, connection, transaction))
                    {
                        getCmd.Parameters.AddWithValue("id", id);
                        using var reader = await getCmd.ExecuteReaderAsync();
                        if (await reader.ReadAsync())
                        {
                            patientReferral = reader.IsDBNull(0) ? null : reader.GetString(0);
                            providerId = reader.IsDBNull(1) ? null : reader.GetInt32(1);
                            appointmentDate = reader.IsDBNull(2) ? null : reader.GetDateTime(2);
                            currentStatus = reader.IsDBNull(3) ? null : reader.GetString(3);
                            price = reader.IsDBNull(4) ? 0m : reader.GetDecimal(4);
                            isTelemedicine = !reader.IsDBNull(5) && reader.GetBoolean(5);
                        }
                    }

                    if (patientReferral == null)
                    {
                        await transaction.RollbackAsync();
                        return NotFound(new { success = false, error = "Appointment not found" });
                    }

                    if (!await IsEligibleMemberAsync(patientReferral))
                    {
                        await transaction.RollbackAsync();
                        return Forbid("Member is not eligible to access HealthBase");
                    }

                    if (currentStatus == "cancelled" || currentStatus == "completed")
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = $"Appointment is already {currentStatus}" });
                    }

                    // Check cancellation policy (24 hours before appointment)
                    decimal refundAmount = 0m;
                    bool fullRefund = false;
                    if (appointmentDate.HasValue)
                    {
                        var hoursUntilAppointment = (appointmentDate.Value - DateTime.UtcNow).TotalHours;
                        if (hoursUntilAppointment >= 24)
                        {
                            // Full refund if cancelled 24+ hours before
                            fullRefund = true;
                            refundAmount = price;
                        }
                        else if (hoursUntilAppointment >= 12)
                        {
                            // 50% refund if cancelled 12-24 hours before
                            refundAmount = price * 0.5m;
                        }
                        // No refund if cancelled less than 12 hours before
                    }

                    // Update appointment status
                    const string updateSql = @"
                        UPDATE healthbase_appointments
                        SET status = 'cancelled',
                            cancellation_reason = @cancellationReason,
                            cancelled_at = NOW(),
                            updated_at = NOW()
                        WHERE id = @id
                        RETURNING id, patient_member_referral, provider_id, appointment_date, status,
                                  cancellation_reason, cancelled_at, updated_at;
                    ";

                    using var updateCmd = new NpgsqlCommand(updateSql, connection, transaction);
                    updateCmd.Parameters.AddWithValue("id", id);
                    updateCmd.Parameters.AddWithValue("cancellationReason", 
                        (object?)(cancellationReason ?? "Cancelled by patient") ?? DBNull.Value);

                    Dictionary<string, object?> appointment;
                    using (var reader = await updateCmd.ExecuteReaderAsync())
                    {
                        if (!await reader.ReadAsync())
                        {
                            await transaction.RollbackAsync();
                            return StatusCode(500, new { success = false, error = "Failed to cancel appointment" });
                        }

                        appointment = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            appointment[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                    }

                    // Process refund if applicable
                    if (refundAmount > 0 && _accountingService != null)
                    {
                        // Get provider channel referral for refund processing
                        string? providerChannelReferral = null;
                        if (providerId.HasValue)
                        {
                            const string providerSql = @"
                                SELECT channel_referral
                                FROM healthbase_providers
                                WHERE id = @providerId
                                LIMIT 1;
                            ";
                            using (var provCmd = new NpgsqlCommand(providerSql, connection, transaction))
                            {
                                provCmd.Parameters.AddWithValue("providerId", providerId.Value);
                                var provResult = await provCmd.ExecuteScalarAsync();
                                if (provResult != null && provResult != DBNull.Value)
                                {
                                    providerChannelReferral = provResult.ToString();
                                }
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(providerChannelReferral))
                        {
                            // Process refund: credit patient, debit provider
                            var refundPayload = new Newtonsoft.Json.Linq.JObject
                            {
                                ["patientReferral"] = patientReferral,
                                ["providerChannelReferral"] = providerChannelReferral,
                                ["appointmentId"] = id,
                                ["refundAmount"] = refundAmount,
                                ["originalPrice"] = price
                            };

                            var refundMetadata = new Newtonsoft.Json.Linq.JObject
                            {
                                ["transactionType"] = "healthbase_appointment_refund",
                                ["module"] = "healthbase",
                                ["appointmentId"] = id
                            };

                            var refundResult = await Task.Run(() => _accountingService.ProcessHealthBaseDistribution(
                                patientReferral, // buyer (patient) - will be credited
                                providerChannelReferral, // provider - will be debited
                                refundAmount, // transaction amount
                                0m, // provider gets 0 (refund)
                                0m, // platform gets 0
                                "", // imagineBcReferral not needed for refund
                                0m, // genesis gets 0
                                "", // genesisPoolReferral not needed
                                refundAmount, // TKD gets full refund amount (goes back to patient)
                                patientReferral, // TKD referral is the patient
                                refundPayload,
                                refundMetadata,
                                "production",
                                connection,
                                transaction
                            ));

                            if (refundResult?["ok"]?.ToObject<bool>() != true)
                            {
                                _logger.LogWarning("Failed to process refund for appointment {AppointmentId}, but appointment was cancelled", id);
                            }
                        }
                    }

                    await transaction.CommitAsync();

                    // Remove appointment from Pia calendar
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            using var syncConnection = new NpgsqlConnection(_connectionString);
                            await syncConnection.OpenAsync();
                            await RemoveAppointmentFromPiaCalendarAsync(syncConnection, id, patientReferral);
                        }
                        catch (Exception syncEx)
                        {
                            _logger.LogWarning(syncEx, "Failed to remove cancelled appointment {AppointmentId} from Pia calendar", id);
                        }
                    });

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Appointment {id} cancelled. Refund: {refundAmount}",
                        new { appointmentId = id, patientReferral, refundAmount });

                    return Ok(new
                    {
                        success = true,
                        appointment,
                        refundAmount,
                        fullRefund,
                        message = refundAmount > 0 
                            ? $"Appointment cancelled. Refund of {refundAmount} processed."
                            : "Appointment cancelled. No refund applicable (cancelled less than 12 hours before appointment)."
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error cancelling appointment {AppointmentId}", id);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================
        // WALLET ENDPOINTS
        // ============================================================

        [HttpGet("wallet")]
        public async Task<IActionResult> GetWallet([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Get or create wallet
                const string walletSql = @"
                    SELECT id, member_referral, balance, total_earned, total_spent, currency,
                           mpesa_phone, mpesa_verified, created_at, updated_at
                    FROM healthbase_wallets
                    WHERE member_referral = @memberReferral
                    LIMIT 1;
                ";

                Dictionary<string, object?>? wallet = null;
                using (var cmd = new NpgsqlCommand(walletSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        wallet = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            wallet[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                    }
                }

                // If wallet doesn't exist, create it
                if (wallet == null)
                {
                    const string createWalletSql = @"
                        INSERT INTO healthbase_wallets (member_referral, balance, currency)
                        VALUES (@memberReferral, 0.00, 'KES')
                        RETURNING id, member_referral, balance, total_earned, total_spent, currency,
                                  mpesa_phone, mpesa_verified, created_at, updated_at;
                    ";
                    using var createCmd = new NpgsqlCommand(createWalletSql, connection);
                    createCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    using var reader = await createCmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        wallet = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            wallet[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                    }
                }

                // Get Transferable balance from memberwalletbalances
                decimal transferableBalance = 0m;
                const string balanceSql = @"
                    SELECT transferable
                    FROM memberwalletbalances
                    WHERE referral_code = @memberReferral
                    LIMIT 1;
                ";
                using (var cmd = new NpgsqlCommand(balanceSql, connection))
                {
                    cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    var result = await cmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        transferableBalance = Convert.ToDecimal(result);
                    }
                }

                if (wallet != null)
                {
                    wallet["transferableBalance"] = transferableBalance;
                }

                return Ok(new { success = true, wallet });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching wallet for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("wallet/mpesa/deposit")]
        public async Task<IActionResult> MpesaDeposit([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
                {
                    return BadRequest(new { success = false, error = "memberReferral is required" });
                }

                if (!request.TryGetValue("amount", out var amountObj) || amountObj == null)
                {
                    return BadRequest(new { success = false, error = "amount is required" });
                }

                if (!request.TryGetValue("phoneNumber", out var phoneObj) || phoneObj == null)
                {
                    return BadRequest(new { success = false, error = "phoneNumber is required" });
                }

                var memberReferral = memberRefObj.ToString() ?? "";
                var kesAmount = Convert.ToDecimal(amountObj);
                var phoneNumber = phoneObj.ToString() ?? "";

                if (kesAmount <= 0)
                {
                    return BadRequest(new { success = false, error = "amount must be greater than 0" });
                }

                // Get conversion rate from tokens (default 1.0)
                decimal conversionRate = 1.0m;
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    const string tokenSql = @"
                        SELECT decimalvalue
                        FROM tokens
                        WHERE key = 'HEALTHBASE-KES-TO-POINTS-RATE'
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(tokenSql, connection))
                    {
                        var tokenResult = await cmd.ExecuteScalarAsync();
                        if (tokenResult != null && tokenResult != DBNull.Value)
                        {
                            conversionRate = Convert.ToDecimal(tokenResult);
                        }
                    }
                }

                var pointsAmount = Math.Round(kesAmount * conversionRate, 2);

                // TODO: Call M-Pesa API to initiate payment
                // For now, simulate successful payment
                var mpesaReceipt = $"MPESA-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper()}";

                // Credit points to member using AccountingService
                if (_accountingService == null)
                {
                    return StatusCode(500, new { success = false, error = "AccountingService not available" });
                }

                using var conn = new NpgsqlConnection(_connectionString);
                await conn.OpenAsync();
                using var tx = await conn.BeginTransactionAsync();

                var payload = new Newtonsoft.Json.Linq.JObject
                {
                    ["memberReferral"] = memberReferral,
                    ["kesAmount"] = kesAmount,
                    ["pointsAmount"] = pointsAmount,
                    ["conversionRate"] = conversionRate,
                    ["phoneNumber"] = phoneNumber,
                    ["mpesaReceipt"] = mpesaReceipt
                };

                var metadata = new Newtonsoft.Json.Linq.JObject
                {
                    ["transactionType"] = "healthbase_mpesa_deposit",
                    ["module"] = "healthbase"
                };

                var result = await Task.Run(() => _accountingService.ProcessDirectCredit(
                    memberReferral,
                    pointsAmount,
                    "Transferable",
                    payload,
                    metadata,
                    "production",
                    conn,
                    tx
                ));

                if (result["ok"]?.ToObject<bool>() == true)
                {
                    await tx.CommitAsync();
                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"M-Pesa deposit: {kesAmount} KES = {pointsAmount} points",
                        new { memberReferral, kesAmount, pointsAmount, mpesaReceipt });

                    return Ok(new
                    {
                        success = true,
                        pointsAmount,
                        kesAmount,
                        conversionRate,
                        mpesaReceipt,
                        transactionId = result["txId"]?.ToString()
                    });
                }
                else
                {
                    await tx.RollbackAsync();
                    return StatusCode(500, new { success = false, error = result["error"]?.ToString() ?? "Failed to credit points" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ MpesaDeposit failed");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPost("wallet/mpesa/withdraw")]
        public async Task<IActionResult> MpesaWithdraw([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
                {
                    return BadRequest(new { success = false, error = "memberReferral is required" });
                }

                if (!request.TryGetValue("pointsAmount", out var pointsObj) || pointsObj == null)
                {
                    return BadRequest(new { success = false, error = "pointsAmount is required" });
                }

                if (!request.TryGetValue("phoneNumber", out var phoneObj) || phoneObj == null)
                {
                    return BadRequest(new { success = false, error = "phoneNumber is required" });
                }

                var memberReferral = memberRefObj.ToString() ?? "";
                var pointsAmount = Convert.ToDecimal(pointsObj);
                var phoneNumber = phoneObj.ToString() ?? "";

                if (pointsAmount <= 0)
                {
                    return BadRequest(new { success = false, error = "pointsAmount must be greater than 0" });
                }

                // Get conversion rate from tokens (default 1.0)
                decimal conversionRate = 1.0m;
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    const string tokenSql = @"
                        SELECT decimalvalue
                        FROM tokens
                        WHERE key = 'HEALTHBASE-POINTS-TO-KES-RATE'
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(tokenSql, connection))
                    {
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            conversionRate = Convert.ToDecimal(result);
                        }
                    }
                }

                var kesAmount = Math.Round(pointsAmount * conversionRate, 2);

                // Check balance
                if (_accountingService == null)
                {
                    return StatusCode(500, new { success = false, error = "AccountingService not available" });
                }

                using var conn = new NpgsqlConnection(_connectionString);
                await conn.OpenAsync();
                using var tx = await conn.BeginTransactionAsync();

                // Check Transferable balance
                decimal currentBalance = 0m;
                const string balanceSql = @"
                    SELECT transferable
                    FROM memberwalletbalances
                    WHERE referral_code = @referral
                    FOR UPDATE;
                ";
                using (var cmd = new NpgsqlCommand(balanceSql, conn, tx))
                {
                    cmd.Parameters.AddWithValue("referral", memberReferral);
                    var result = await cmd.ExecuteScalarAsync();
                    if (result != null && result != DBNull.Value)
                    {
                        currentBalance = Convert.ToDecimal(result);
                    }
                }

                if (currentBalance < pointsAmount)
                {
                    await tx.RollbackAsync();
                    return BadRequest(new { success = false, error = $"Insufficient balance. Required: {pointsAmount}, Available: {currentBalance}" });
                }

                // Debit points
                var debit = ImagineBC.MainService.Services.Accounting.BalanceVector.Debit(memberReferral);
                debit.Transferable = pointsAmount;

                var credits = new List<ImagineBC.MainService.Services.Accounting.BalanceVector>();

                // Apply debit
                var balanceService = new ImagineBC.MainService.Services.Accounting.BalanceService(
                    _connectionString,
                    new ImagineBC.MainService.Services.Accounting.LedgerWriteService(_connectionString)
                );

                balanceService.ApplyVectors(
                    debit,
                    credits,
                    "healthbase_mpesa_withdrawal",
                    new Newtonsoft.Json.Linq.JObject
                    {
                        ["memberReferral"] = memberReferral,
                        ["pointsAmount"] = pointsAmount,
                        ["kesAmount"] = kesAmount,
                        ["conversionRate"] = conversionRate,
                        ["phoneNumber"] = phoneNumber
                    },
                    new Newtonsoft.Json.Linq.JObject
                    {
                        ["transactionType"] = "healthbase_mpesa_withdrawal",
                        ["module"] = "healthbase"
                    },
                    "production",
                    conn,
                    tx
                );

                // TODO: Call M-Pesa API to send money
                // For now, simulate successful withdrawal
                var mpesaReceipt = $"MPESA-{DateTime.UtcNow:yyyyMMddHHmmss}-{Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper()}";

                await tx.CommitAsync();

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"M-Pesa withdrawal: {pointsAmount} points = {kesAmount} KES",
                    new { memberReferral, pointsAmount, kesAmount, mpesaReceipt });

                return Ok(new
                {
                    success = true,
                    pointsAmount,
                    kesAmount,
                    conversionRate,
                    mpesaReceipt,
                    balanceAfter = currentBalance - pointsAmount
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ MpesaWithdraw failed");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPost("wallet/utility/pay")]
        public async Task<IActionResult> PayUtilityBill([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
                {
                    return BadRequest(new { success = false, error = "memberReferral is required" });
                }

                if (!request.TryGetValue("utilityProviderId", out var providerIdObj) || providerIdObj == null)
                {
                    return BadRequest(new { success = false, error = "utilityProviderId is required" });
                }

                if (!request.TryGetValue("accountNumber", out var accountObj) || accountObj == null)
                {
                    return BadRequest(new { success = false, error = "accountNumber is required" });
                }

                if (!request.TryGetValue("amount", out var amountObj) || amountObj == null)
                {
                    return BadRequest(new { success = false, error = "amount is required" });
                }

                var memberReferral = memberRefObj.ToString() ?? "";
                var utilityProviderId = Convert.ToInt32(providerIdObj);
                var accountNumber = accountObj.ToString() ?? "";
                var amount = Convert.ToDecimal(amountObj);

                if (amount <= 0)
                {
                    return BadRequest(new { success = false, error = "amount must be greater than 0" });
                }

                if (!await IsEligibleMemberAsync(memberReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Get wallet ID
                    int? walletId = null;
                    const string walletSql = @"
                        SELECT id FROM healthbase_wallets
                        WHERE member_referral = @memberReferral
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(walletSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            walletId = Convert.ToInt32(result);
                        }
                    }

                    if (!walletId.HasValue)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = "Wallet not found" });
                    }

                    // Check balance
                    decimal currentBalance = 0m;
                    const string balanceSql = @"
                        SELECT transferable
                        FROM memberwalletbalances
                        WHERE referral_code = @memberReferral
                        FOR UPDATE;
                    ";
                    using (var cmd = new NpgsqlCommand(balanceSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        var result = await cmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            currentBalance = Convert.ToDecimal(result);
                        }
                    }

                    if (currentBalance < amount)
                    {
                        await transaction.RollbackAsync();
                        return BadRequest(new { success = false, error = $"Insufficient balance. Required: {amount}, Available: {currentBalance}" });
                    }

                    // Debit amount from wallet
                    if (_accountingService != null)
                    {
                        var debit = ImagineBC.MainService.Services.Accounting.BalanceVector.Debit(memberReferral);
                        debit.Transferable = amount;

                        var payload = new Newtonsoft.Json.Linq.JObject
                        {
                            ["memberReferral"] = memberReferral,
                            ["utilityProviderId"] = utilityProviderId,
                            ["accountNumber"] = accountNumber,
                            ["amount"] = amount
                        };

                        var metadata = new Newtonsoft.Json.Linq.JObject
                        {
                            ["transactionType"] = "healthbase_utility_payment",
                            ["module"] = "healthbase"
                        };

                        var balanceService = new ImagineBC.MainService.Services.Accounting.BalanceService(
                            _connectionString,
                            new ImagineBC.MainService.Services.Accounting.LedgerWriteService(_connectionString)
                        );

                        balanceService.ApplyVectors(
                            debit,
                            new List<ImagineBC.MainService.Services.Accounting.BalanceVector>(),
                            "healthbase_utility_payment",
                            payload,
                            metadata,
                            "production",
                            connection,
                            transaction
                        );
                    }

                    // Create utility payment record
                    const string insertPaymentSql = @"
                        INSERT INTO healthbase_utility_payments (
                            wallet_id, utility_provider_id, account_number, amount, status
                        )
                        VALUES (
                            @walletId, @utilityProviderId, @accountNumber, @amount, 'completed'
                        )
                        RETURNING id, wallet_id, utility_provider_id, account_number, amount,
                                  status, receipt_number, created_at, completed_at;
                    ";
                    using var paymentCmd = new NpgsqlCommand(insertPaymentSql, connection, transaction);
                    paymentCmd.Parameters.AddWithValue("walletId", walletId.Value);
                    paymentCmd.Parameters.AddWithValue("utilityProviderId", utilityProviderId);
                    paymentCmd.Parameters.AddWithValue("accountNumber", accountNumber);
                    paymentCmd.Parameters.AddWithValue("amount", amount);

                    Dictionary<string, object?> payment;
                    using (var reader = await paymentCmd.ExecuteReaderAsync())
                    {
                        if (!await reader.ReadAsync())
                        {
                            await transaction.RollbackAsync();
                            return StatusCode(500, new { success = false, error = "Failed to create payment record" });
                        }

                        payment = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            payment[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }
                    }

                    // Update wallet totals
                    const string updateWalletSql = @"
                        UPDATE healthbase_wallets
                        SET total_spent = total_spent + @amount,
                            updated_at = NOW()
                        WHERE id = @walletId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateWalletSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("amount", amount);
                        cmd.Parameters.AddWithValue("walletId", walletId.Value);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    await transaction.CommitAsync();

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Utility payment: {amount} for account {accountNumber}",
                        new { memberReferral, utilityProviderId, accountNumber, amount });

                    // Emit gamification event for utility payment (fire and forget)
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var gamificationService = new GamificationService(_connectionString, null, null);
                            await gamificationService.ProcessEventAsync("HEALTHBASE_UTILITY_PAID", memberReferral);
                        }
                        catch { /* Gamification should never block health operations */ }
                    });

                    return Ok(new
                    {
                        success = true,
                        payment,
                        balanceAfter = currentBalance - amount,
                        message = "Utility payment processed successfully"
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing utility payment");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================
        // INSURANCE ENDPOINTS
        // ============================================================

        [HttpGet("insurance/policies")]
        public async Task<IActionResult> GetInsurancePolicies([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        p.id,
                        p.member_referral,
                        p.insurance_provider_id,
                        p.policy_type,
                        p.policy_number,
                        p.premium_amount,
                        p.coverage_amount,
                        p.start_date,
                        p.end_date,
                        p.status,
                        p.next_payment_date,
                        p.is_active,
                        p.created_at,
                        p.updated_at,
                        ip.name as insurance_provider_name
                    FROM healthbase_insurance_policies p
                    LEFT JOIN healthbase_insurance_providers ip ON p.insurance_provider_id = ip.id
                    WHERE p.member_referral = @memberReferral
                    ORDER BY p.created_at DESC;
                ";

                var policies = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var policy = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        policy[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    policies.Add(policy);
                }

                return Ok(new { success = true, policies, count = policies.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching insurance policies for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("insurance/policies/enroll")]
        public async Task<IActionResult> EnrollInsurance([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("memberReferral", out var memberRefObj) || memberRefObj == null)
                {
                    return BadRequest(new { success = false, error = "memberReferral is required" });
                }

                if (!request.TryGetValue("insuranceProviderId", out var providerIdObj) || providerIdObj == null)
                {
                    return BadRequest(new { success = false, error = "insuranceProviderId is required" });
                }

                if (!request.TryGetValue("policyType", out var typeObj) || typeObj == null)
                {
                    return BadRequest(new { success = false, error = "policyType is required" });
                }

                if (!request.TryGetValue("policyNumber", out var numberObj) || numberObj == null)
                {
                    return BadRequest(new { success = false, error = "policyNumber is required" });
                }

                var memberReferral = memberRefObj.ToString() ?? "";
                var insuranceProviderId = Convert.ToInt32(providerIdObj);
                var policyType = typeObj.ToString() ?? "";
                var policyNumber = numberObj.ToString() ?? "";
                var premiumAmount = request.TryGetValue("premiumAmount", out var premObj) && premObj != null
                    ? Convert.ToDecimal(premObj)
                    : 0m;
                var coverageAmount = request.TryGetValue("coverageAmount", out var covObj) && covObj != null
                    ? Convert.ToDecimal(covObj)
                    : 0m;
                var startDate = request.TryGetValue("startDate", out var startObj) && startObj != null
                    ? DateTime.Parse(startObj.ToString() ?? "")
                    : DateTime.UtcNow.Date;
                var endDate = request.TryGetValue("endDate", out var endObj) && endObj != null
                    ? DateTime.Parse(endObj.ToString() ?? "")
                    : DateTime.UtcNow.Date.AddYears(1);

                if (!await IsEligibleMemberAsync(memberReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string insertSql = @"
                    INSERT INTO healthbase_insurance_policies (
                        member_referral, insurance_provider_id, policy_type, policy_number,
                        premium_amount, coverage_amount, start_date, end_date, status
                    )
                    VALUES (
                        @memberReferral, @insuranceProviderId, @policyType, @policyNumber,
                        @premiumAmount, @coverageAmount, @startDate, @endDate, 'active'
                    )
                    RETURNING id, member_referral, insurance_provider_id, policy_type, policy_number,
                              premium_amount, coverage_amount, start_date, end_date, status,
                              next_payment_date, is_active, created_at, updated_at;
                ";

                using var cmd = new NpgsqlCommand(insertSql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                cmd.Parameters.AddWithValue("insuranceProviderId", insuranceProviderId);
                cmd.Parameters.AddWithValue("policyType", policyType);
                cmd.Parameters.AddWithValue("policyNumber", policyNumber);
                cmd.Parameters.AddWithValue("premiumAmount", premiumAmount);
                cmd.Parameters.AddWithValue("coverageAmount", coverageAmount);
                cmd.Parameters.AddWithValue("startDate", startDate);
                cmd.Parameters.AddWithValue("endDate", endDate);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var policy = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        policy[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Insurance enrollment: {policyNumber}",
                        new { memberReferral, policyId = policy["id"] });

                    // Emit gamification event for insurance enrollment (fire and forget)
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var gamificationService = new GamificationService(_connectionString, null, null);
                            await gamificationService.ProcessEventAsync("HEALTHBASE_INSURANCE_ENROLLED", memberReferral);
                        }
                        catch { /* Gamification should never block health operations */ }
                    });

                    return Ok(new { success = true, policy, message = "Insurance enrollment submitted" });
                }

                return StatusCode(500, new { success = false, error = "Failed to enroll insurance" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error enrolling insurance");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpGet("insurance/claims")]
        public async Task<IActionResult> GetInsuranceClaims([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        c.id,
                        c.policy_id,
                        c.appointment_id,
                        c.claim_amount,
                        c.claim_date,
                        c.status,
                        c.processed_by,
                        c.processed_at,
                        c.rejection_reason,
                        c.created_at,
                        c.updated_at,
                        p.policy_number,
                        ip.name as insurance_provider_name
                    FROM healthbase_insurance_claims c
                    INNER JOIN healthbase_insurance_policies p ON c.policy_id = p.id
                    LEFT JOIN healthbase_insurance_providers ip ON p.insurance_provider_id = ip.id
                    WHERE p.member_referral = @memberReferral
                    ORDER BY c.claim_date DESC;
                ";

                var claims = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var claim = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        claim[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    claims.Add(claim);
                }

                return Ok(new { success = true, claims, count = claims.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching insurance claims for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpPost("insurance/claims/submit")]
        public async Task<IActionResult> SubmitInsuranceClaim([FromBody] Dictionary<string, object> request)
        {
            try
            {
                if (!request.TryGetValue("policyId", out var policyIdObj) || policyIdObj == null)
                {
                    return BadRequest(new { success = false, error = "policyId is required" });
                }

                if (!request.TryGetValue("claimAmount", out var amountObj) || amountObj == null)
                {
                    return BadRequest(new { success = false, error = "claimAmount is required" });
                }

                var policyId = Convert.ToInt32(policyIdObj);
                var claimAmount = Convert.ToDecimal(amountObj);
                var appointmentId = request.TryGetValue("appointmentId", out var apptObj) && apptObj != null
                    ? (int?)Convert.ToInt32(apptObj)
                    : null;

                if (claimAmount <= 0)
                {
                    return BadRequest(new { success = false, error = "claimAmount must be greater than 0" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                // Verify policy exists and is active
                string? memberReferral = null;
                string? policyStatus = null;
                const string policySql = @"
                    SELECT member_referral, status
                    FROM healthbase_insurance_policies
                    WHERE id = @policyId
                    LIMIT 1;
                ";
                using (var policyCheckCmd = new NpgsqlCommand(policySql, connection))
                {
                    policyCheckCmd.Parameters.AddWithValue("policyId", policyId);
                    using var policyReader = await policyCheckCmd.ExecuteReaderAsync();
                    if (await policyReader.ReadAsync())
                    {
                        memberReferral = policyReader.IsDBNull(0) ? null : policyReader.GetString(0);
                        policyStatus = policyReader.IsDBNull(1) ? null : policyReader.GetString(1);
                    }
                }

                if (memberReferral == null)
                {
                    return NotFound(new { success = false, error = "Insurance policy not found" });
                }

                if (policyStatus != "active")
                {
                    return BadRequest(new { success = false, error = $"Policy is not active. Current status: {policyStatus}" });
                }

                if (!await IsEligibleMemberAsync(memberReferral))
                {
                    return Forbid("Member is not eligible to access HealthBase");
                }

                const string insertSql = @"
                    INSERT INTO healthbase_insurance_claims (
                        policy_id, appointment_id, claim_amount, claim_date, status
                    )
                    VALUES (
                        @policyId, @appointmentId, @claimAmount, NOW(), 'pending'
                    )
                    RETURNING id, policy_id, appointment_id, claim_amount, claim_date, status,
                              processed_by, processed_at, rejection_reason, created_at, updated_at;
                ";

                using var claimCmd = new NpgsqlCommand(insertSql, connection);
                claimCmd.Parameters.AddWithValue("policyId", policyId);
                claimCmd.Parameters.AddWithValue("appointmentId", (object?)appointmentId ?? DBNull.Value);
                claimCmd.Parameters.AddWithValue("claimAmount", claimAmount);

                using var claimReader = await claimCmd.ExecuteReaderAsync();
                if (await claimReader.ReadAsync())
                {
                    var claim = new Dictionary<string, object?>();
                    for (int i = 0; i < claimReader.FieldCount; i++)
                    {
                        claim[claimReader.GetName(i)] = claimReader.IsDBNull(i) ? null : claimReader.GetValue(i);
                    }

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Insurance claim submitted: {claimAmount}",
                        new { policyId, claimId = claim["id"], memberReferral });

                    return Ok(new { success = true, claim, message = "Claim submitted successfully" });
                }

                return StatusCode(500, new { success = false, error = "Failed to submit claim" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error submitting insurance claim");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpGet("insurance/providers")]
        public async Task<IActionResult> GetInsuranceProviders()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        id,
                        name,
                        description,
                        is_active
                    FROM healthbase_insurance_providers
                    WHERE is_active = true
                    ORDER BY name;
                ";

                var providers = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var provider = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    providers.Add(provider);
                }

                return Ok(new { success = true, providers });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching insurance providers");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================
        // UTILITY ENDPOINTS
        // ============================================================

        [HttpGet("utilities/providers")]
        public async Task<IActionResult> GetUtilityProviders()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        id,
                        code,
                        name,
                        description,
                        category,
                        is_active,
                        created_at,
                        updated_at
                    FROM healthbase_utility_providers
                    WHERE is_active = true
                    ORDER BY name;
                ";

                var providers = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var provider = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    providers.Add(provider);
                }

                return Ok(new { success = true, providers });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching utility providers");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================
        // SPECIALIZATIONS & APPOINTMENT TYPES
        // ============================================================

        [HttpGet("specializations")]
        public async Task<IActionResult> GetSpecializations()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        id,
                        code,
                        name,
                        description,
                        is_active
                    FROM healthbase_specializations
                    WHERE is_active = true
                    ORDER BY name;
                ";

                var specializations = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var spec = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        spec[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    specializations.Add(spec);
                }

                return Ok(new { success = true, specializations });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching specializations");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("appointment-types")]
        public async Task<IActionResult> GetAppointmentTypes()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        id,
                        code,
                        name,
                        description,
                        default_duration_minutes,
                        is_active
                    FROM healthbase_appointment_types
                    WHERE is_active = true
                    ORDER BY name;
                ";

                var types = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var type = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        type[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    types.Add(type);
                }

                return Ok(new { success = true, appointmentTypes = types });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching appointment types");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================
        // REWARDS ENDPOINTS
        // ============================================================

        [HttpGet("rewards/activities")]
        public async Task<IActionResult> GetRewardActivities()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        id,
                        activity_name,
                        description,
                        points_awarded,
                        kes_amount,
                        category,
                        is_active
                    FROM healthbase_reward_activities
                    WHERE is_active = true
                    ORDER BY activity_name;
                ";

                var activities = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var activity = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        activity[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    activities.Add(activity);
                }

                return Ok(new { success = true, activities });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching reward activities");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        [HttpGet("rewards/user")]
        public async Task<IActionResult> GetUserRewards([FromQuery] string memberReferral)
        {
            if (string.IsNullOrWhiteSpace(memberReferral))
            {
                return BadRequest(new { success = false, message = "memberReferral is required" });
            }

            if (!await IsEligibleMemberAsync(memberReferral))
            {
                return Unauthorized(new { success = false, message = "Member is not eligible to access HealthBase" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        r.id,
                        r.member_referral,
                        r.activity_id,
                        r.points_earned,
                        r.kes_earned,
                        r.description,
                        r.awarded_at,
                        a.activity_name,
                        a.category
                    FROM healthbase_user_rewards r
                    LEFT JOIN healthbase_reward_activities a ON r.activity_id = a.id
                    WHERE r.member_referral = @memberReferral
                    ORDER BY r.awarded_at DESC;
                ";

                var rewards = new List<Dictionary<string, object?>>();
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var reward = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        reward[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    rewards.Add(reward);
                }

                // Calculate totals
                var totalPoints = rewards.Sum(r => r.TryGetValue("points_earned", out var pts) && pts != null ? Convert.ToDecimal(pts) : 0m);
                var totalKes = rewards.Sum(r => r.TryGetValue("kes_earned", out var kes) && kes != null ? Convert.ToDecimal(kes) : 0m);

                return Ok(new
                {
                    success = true,
                    rewards,
                    count = rewards.Count,
                    totalPoints,
                    totalKes
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching user rewards for {MemberReferral}", memberReferral);
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // ============================================================
        // UTILITY TABLE CRUD ENDPOINTS
        // ============================================================

        // Specializations CRUD
        [HttpPost("utility/specializations")]
        public async Task<IActionResult> CreateSpecialization([FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var code = request.TryGetValue("code", out var codeObj) ? codeObj?.ToString() : null;
                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { success = false, error = "name is required" });
                }

                const string sql = @"
                    INSERT INTO healthbase_specializations (code, name, description, is_active)
                    VALUES (@code, @name, @description, @isActive)
                    RETURNING id, code, name, description, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("code", (object?)code ?? DBNull.Value);
                cmd.Parameters.AddWithValue("name", name);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, specialization = result });
                }

                return StatusCode(500, new { success = false, error = "Failed to create specialization" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating specialization");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("utility/specializations/{id}")]
        public async Task<IActionResult> UpdateSpecialization(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var code = request.TryGetValue("code", out var codeObj) ? codeObj?.ToString() : null;
                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                const string sql = @"
                    UPDATE healthbase_specializations
                    SET code = @code, name = @name, description = @description, is_active = @isActive
                    WHERE id = @id
                    RETURNING id, code, name, description, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("code", (object?)code ?? DBNull.Value);
                cmd.Parameters.AddWithValue("name", name ?? "");
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, specialization = result });
                }

                return NotFound(new { success = false, error = "Specialization not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating specialization");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpDelete("utility/specializations/{id}")]
        public async Task<IActionResult> DeleteSpecialization(int id)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = "DELETE FROM healthbase_specializations WHERE id = @id";
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                var rowsAffected = await cmd.ExecuteNonQueryAsync();

                if (rowsAffected > 0)
                {
                    return Ok(new { success = true });
                }
                return NotFound(new { success = false, error = "Specialization not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting specialization");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // Appointment Types CRUD
        [HttpPost("utility/appointment-types")]
        public async Task<IActionResult> CreateAppointmentType([FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var code = request.TryGetValue("code", out var codeObj) ? codeObj?.ToString() : null;
                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var defaultDuration = request.TryGetValue("defaultDurationMinutes", out var durObj) ? Convert.ToInt32(durObj) : 30;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { success = false, error = "name is required" });
                }

                const string sql = @"
                    INSERT INTO healthbase_appointment_types (code, name, description, default_duration_minutes, is_active)
                    VALUES (@code, @name, @description, @defaultDuration, @isActive)
                    RETURNING id, code, name, description, default_duration_minutes, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("code", (object?)code ?? DBNull.Value);
                cmd.Parameters.AddWithValue("name", name);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("defaultDuration", defaultDuration);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, appointmentType = result });
                }

                return StatusCode(500, new { success = false, error = "Failed to create appointment type" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating appointment type");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("utility/appointment-types/{id}")]
        public async Task<IActionResult> UpdateAppointmentType(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var code = request.TryGetValue("code", out var codeObj) ? codeObj?.ToString() : null;
                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var defaultDuration = request.TryGetValue("defaultDurationMinutes", out var durObj) ? Convert.ToInt32(durObj) : 30;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                const string sql = @"
                    UPDATE healthbase_appointment_types
                    SET code = @code, name = @name, description = @description, default_duration_minutes = @defaultDuration, is_active = @isActive
                    WHERE id = @id
                    RETURNING id, code, name, description, default_duration_minutes, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("code", (object?)code ?? DBNull.Value);
                cmd.Parameters.AddWithValue("name", name ?? "");
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("defaultDuration", defaultDuration);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, appointmentType = result });
                }

                return NotFound(new { success = false, error = "Appointment type not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating appointment type");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpDelete("utility/appointment-types/{id}")]
        public async Task<IActionResult> DeleteAppointmentType(int id)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = "DELETE FROM healthbase_appointment_types WHERE id = @id";
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                var rowsAffected = await cmd.ExecuteNonQueryAsync();

                if (rowsAffected > 0)
                {
                    return Ok(new { success = true });
                }
                return NotFound(new { success = false, error = "Appointment type not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting appointment type");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // Utility Providers CRUD
        [HttpPost("utility/utility-providers")]
        public async Task<IActionResult> CreateUtilityProvider([FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { success = false, error = "name is required" });
                }

                const string sql = @"
                    INSERT INTO healthbase_utility_providers (name, description, is_active)
                    VALUES (@name, @description, @isActive)
                    RETURNING id, name, description, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("name", name);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, utilityProvider = result });
                }

                return StatusCode(500, new { success = false, error = "Failed to create utility provider" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating utility provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("utility/utility-providers/{id}")]
        public async Task<IActionResult> UpdateUtilityProvider(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                const string sql = @"
                    UPDATE healthbase_utility_providers
                    SET name = @name, description = @description, is_active = @isActive
                    WHERE id = @id
                    RETURNING id, name, description, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", name ?? "");
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, utilityProvider = result });
                }

                return NotFound(new { success = false, error = "Utility provider not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating utility provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpDelete("utility/utility-providers/{id}")]
        public async Task<IActionResult> DeleteUtilityProvider(int id)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = "DELETE FROM healthbase_utility_providers WHERE id = @id";
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                var rowsAffected = await cmd.ExecuteNonQueryAsync();

                if (rowsAffected > 0)
                {
                    return Ok(new { success = true });
                }
                return NotFound(new { success = false, error = "Utility provider not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting utility provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // Insurance Providers CRUD
        [HttpPost("utility/insurance-providers")]
        public async Task<IActionResult> CreateInsuranceProvider([FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { success = false, error = "name is required" });
                }

                const string sql = @"
                    INSERT INTO healthbase_insurance_providers (name, description, is_active)
                    VALUES (@name, @description, @isActive)
                    RETURNING id, name, description, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("name", name);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, insuranceProvider = result });
                }

                return StatusCode(500, new { success = false, error = "Failed to create insurance provider" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating insurance provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("utility/insurance-providers/{id}")]
        public async Task<IActionResult> UpdateInsuranceProvider(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var name = request.TryGetValue("name", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                const string sql = @"
                    UPDATE healthbase_insurance_providers
                    SET name = @name, description = @description, is_active = @isActive
                    WHERE id = @id
                    RETURNING id, name, description, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("name", name ?? "");
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, insuranceProvider = result });
                }

                return NotFound(new { success = false, error = "Insurance provider not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating insurance provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpDelete("utility/insurance-providers/{id}")]
        public async Task<IActionResult> DeleteInsuranceProvider(int id)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = "DELETE FROM healthbase_insurance_providers WHERE id = @id";
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                var rowsAffected = await cmd.ExecuteNonQueryAsync();

                if (rowsAffected > 0)
                {
                    return Ok(new { success = true });
                }
                return NotFound(new { success = false, error = "Insurance provider not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting insurance provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // Reward Activities CRUD
        [HttpPost("utility/reward-activities")]
        public async Task<IActionResult> CreateRewardActivity([FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var activityName = request.TryGetValue("activityName", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var pointsAwarded = request.TryGetValue("pointsAwarded", out var ptsObj) ? Convert.ToDecimal(ptsObj) : 0m;
                var kesAmount = request.TryGetValue("kesAmount", out var kesObj) ? Convert.ToDecimal(kesObj) : 0m;
                var category = request.TryGetValue("category", out var catObj) ? catObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                if (string.IsNullOrWhiteSpace(activityName))
                {
                    return BadRequest(new { success = false, error = "activityName is required" });
                }

                const string sql = @"
                    INSERT INTO healthbase_reward_activities (activity_name, description, points_awarded, kes_amount, category, is_active)
                    VALUES (@activityName, @description, @pointsAwarded, @kesAmount, @category, @isActive)
                    RETURNING id, activity_name, description, points_awarded, kes_amount, category, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("activityName", activityName);
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("pointsAwarded", pointsAwarded);
                cmd.Parameters.AddWithValue("kesAmount", kesAmount);
                cmd.Parameters.AddWithValue("category", (object?)category ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, rewardActivity = result });
                }

                return StatusCode(500, new { success = false, error = "Failed to create reward activity" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating reward activity");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("utility/reward-activities/{id}")]
        public async Task<IActionResult> UpdateRewardActivity(int id, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                var activityName = request.TryGetValue("activityName", out var nameObj) ? nameObj?.ToString() : null;
                var description = request.TryGetValue("description", out var descObj) ? descObj?.ToString() : null;
                var pointsAwarded = request.TryGetValue("pointsAwarded", out var ptsObj) ? Convert.ToDecimal(ptsObj) : 0m;
                var kesAmount = request.TryGetValue("kesAmount", out var kesObj) ? Convert.ToDecimal(kesObj) : 0m;
                var category = request.TryGetValue("category", out var catObj) ? catObj?.ToString() : null;
                var isActive = request.TryGetValue("isActive", out var activeObj) ? Convert.ToBoolean(activeObj) : true;

                const string sql = @"
                    UPDATE healthbase_reward_activities
                    SET activity_name = @activityName, description = @description, points_awarded = @pointsAwarded, 
                        kes_amount = @kesAmount, category = @category, is_active = @isActive
                    WHERE id = @id
                    RETURNING id, activity_name, description, points_awarded, kes_amount, category, is_active;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                cmd.Parameters.AddWithValue("activityName", activityName ?? "");
                cmd.Parameters.AddWithValue("description", (object?)description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("pointsAwarded", pointsAwarded);
                cmd.Parameters.AddWithValue("kesAmount", kesAmount);
                cmd.Parameters.AddWithValue("category", (object?)category ?? DBNull.Value);
                cmd.Parameters.AddWithValue("isActive", isActive);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var result = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, rewardActivity = result });
                }

                return NotFound(new { success = false, error = "Reward activity not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating reward activity");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpDelete("utility/reward-activities/{id}")]
        public async Task<IActionResult> DeleteRewardActivity(int id)
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = "DELETE FROM healthbase_reward_activities WHERE id = @id";
                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("id", id);
                var rowsAffected = await cmd.ExecuteNonQueryAsync();

                if (rowsAffected > 0)
                {
                    return Ok(new { success = true });
                }
                return NotFound(new { success = false, error = "Reward activity not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting reward activity");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================
        // ADMIN ENDPOINTS - Provider Approval
        // ============================================================
        
        [HttpPut("admin/provider/{providerId}/approve")]
        public async Task<IActionResult> ApproveProvider(int providerId, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                var approvedBy = request.TryGetValue("approvedBy", out var approverObj) ? approverObj?.ToString() : null;
                if (string.IsNullOrWhiteSpace(approvedBy))
                {
                    return BadRequest(new { success = false, error = "approvedBy is required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    UPDATE healthbase_providers
                    SET status = 'approved',
                        approved_by = @approvedBy,
                        approved_at = NOW(),
                        updated_at = NOW()
                    WHERE id = @providerId
                    RETURNING id, member_referral, channel_referral, status, approved_by, approved_at;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("providerId", providerId);
                cmd.Parameters.AddWithValue("approvedBy", approvedBy);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var provider = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Provider approved: {providerId} by {approvedBy}",
                        new { providerId, approvedBy });

                    return Ok(new { success = true, provider });
                }

                return NotFound(new { success = false, error = "Provider not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error approving provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPut("admin/provider/{providerId}/reject")]
        public async Task<IActionResult> RejectProvider(int providerId, [FromBody] Dictionary<string, object> request)
        {
            try
            {
                var rejectedBy = request.TryGetValue("rejectedBy", out var rejecterObj) ? rejecterObj?.ToString() : null;
                var reason = request.TryGetValue("reason", out var reasonObj) ? reasonObj?.ToString() : null;
                
                if (string.IsNullOrWhiteSpace(rejectedBy))
                {
                    return BadRequest(new { success = false, error = "rejectedBy is required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    UPDATE healthbase_providers
                    SET status = 'rejected',
                        updated_at = NOW()
                    WHERE id = @providerId
                    RETURNING id, member_referral, status;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("providerId", providerId);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var provider = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Provider rejected: {providerId} by {rejectedBy}, reason: {reason}",
                        new { providerId, rejectedBy, reason });

                    return Ok(new { success = true, provider });
                }

                return NotFound(new { success = false, error = "Provider not found" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error rejecting provider");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpGet("admin/providers/pending")]
        public async Task<IActionResult> GetPendingProviders()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        p.id,
                        p.member_referral,
                        p.channel_referral,
                        p.specialization_id,
                        p.license_number,
                        p.license_expiry_date,
                        p.years_experience,
                        p.bio,
                        p.education,
                        p.consultation_fee,
                        p.status,
                        p.created_at,
                        s.name as specialization_name,
                        m.fullname as member_name
                    FROM healthbase_providers p
                    LEFT JOIN healthbase_specializations s ON p.specialization_id = s.id
                    LEFT JOIN members m ON p.member_referral = m.assignedreferral
                    WHERE p.status = 'pending'
                    ORDER BY p.created_at DESC;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                var providers = new List<Dictionary<string, object?>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    var provider = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        provider[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    providers.Add(provider);
                }

                return Ok(new { success = true, providers, count = providers.Count });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching pending providers");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================
        // INSURANCE COMPANY REPRESENTATIVES
        // ============================================================

        [HttpPost("admin/insurance/assign-representative")]
        public async Task<IActionResult> AssignInsuranceRepresentative([FromBody] Dictionary<string, object> request)
        {
            try
            {
                var memberReferral = request.TryGetValue("memberReferral", out var memberObj) ? memberObj?.ToString() : null;
                var insuranceProviderId = request.TryGetValue("insuranceProviderId", out var providerIdObj) ? Convert.ToInt32(providerIdObj) : 0;
                var role = request.TryGetValue("role", out var roleObj) ? roleObj?.ToString() : "representative";
                var assignedBy = request.TryGetValue("assignedBy", out var assignerObj) ? assignerObj?.ToString() : null;

                if (string.IsNullOrWhiteSpace(memberReferral) || insuranceProviderId <= 0)
                {
                    return BadRequest(new { success = false, error = "memberReferral and insuranceProviderId are required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();

                try
                {
                    // Check if assignment already exists
                    const string checkSql = @"
                        SELECT id FROM healthbase_insurance_representatives
                        WHERE member_referral = @memberReferral AND insurance_provider_id = @providerId;
                    ";
                    using (var checkCmd = new NpgsqlCommand(checkSql, connection, transaction))
                    {
                        checkCmd.Parameters.AddWithValue("memberReferral", memberReferral);
                        checkCmd.Parameters.AddWithValue("providerId", insuranceProviderId);
                        var existing = await checkCmd.ExecuteScalarAsync();
                        if (existing != null && existing != DBNull.Value)
                        {
                            await transaction.RollbackAsync();
                            return BadRequest(new { success = false, error = "Representative already assigned to this insurance provider" });
                        }
                    }

                    // Insert representative assignment
                    const string insertSql = @"
                        INSERT INTO healthbase_insurance_representatives (
                            member_referral, insurance_provider_id, role, status, assigned_by
                        )
                        VALUES (
                            @memberReferral, @providerId, @role, 'active', @assignedBy
                        )
                        RETURNING id, member_referral, insurance_provider_id, role, status, assigned_at;
                    ";

                    using var cmd = new NpgsqlCommand(insertSql, connection, transaction);
                    cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                    cmd.Parameters.AddWithValue("providerId", insuranceProviderId);
                    cmd.Parameters.AddWithValue("role", (object?)role ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("assignedBy", (object?)assignedBy ?? DBNull.Value);

                    using var reader = await cmd.ExecuteReaderAsync();
                    if (await reader.ReadAsync())
                    {
                        var representative = new Dictionary<string, object?>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            representative[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                        }

                        await transaction.CommitAsync();

                        _activityService?.Record("HealthBaseController", "SUCCESS",
                            $"Insurance representative assigned: {memberReferral} to provider {insuranceProviderId}",
                            new { memberReferral, insuranceProviderId, role, assignedBy });

                        return Ok(new { success = true, representative });
                    }

                    await transaction.RollbackAsync();
                    return StatusCode(500, new { success = false, error = "Failed to assign representative" });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error assigning insurance representative");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpGet("insurance/representative")]
        public async Task<IActionResult> GetInsuranceRepresentative([FromQuery] string memberReferral)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(memberReferral))
                {
                    return BadRequest(new { success = false, message = "memberReferral is required" });
                }

                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();

                const string sql = @"
                    SELECT 
                        ir.id,
                        ir.member_referral,
                        ir.insurance_provider_id,
                        ir.role,
                        ir.status,
                        ir.assigned_at,
                        ip.name as insurance_provider_name,
                        ip.code as insurance_provider_code
                    FROM healthbase_insurance_representatives ir
                    INNER JOIN healthbase_insurance_providers ip ON ir.insurance_provider_id = ip.id
                    WHERE ir.member_referral = @memberReferral AND ir.status = 'active'
                    LIMIT 1;
                ";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("memberReferral", memberReferral);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    var representative = new Dictionary<string, object?>();
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        representative[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    }
                    return Ok(new { success = true, representative });
                }

                return Ok(new { success = true, representative = (object?)null });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching insurance representative");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================
        // VITALS AI SCAN (Phase 2 - Scaffold)
        // ============================================================
        [HttpPost("vitals/ai-scan")]
        public Task<IActionResult> ProcessAiVitalsScan([FromBody] Dictionary<string, object> request)
        {
            // Phase 2 implementation - scaffold endpoint
            return Task.FromResult<IActionResult>(Ok(new { success = false, message = "AI vitals scan not yet implemented (Phase 2)" }));
        }

        // ============================================================
        // KPI ENDPOINTS
        // ============================================================
        [HttpGet("kpis/snapshots")]
        public IActionResult GetKpiSnapshots()
        {
            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                const string sql = @"
                    SELECT kpi_key, numeric_value, json_value, last_computed_utc, status, error_message
                    FROM healthbase_kpi_snapshots
                    ORDER BY kpi_key;";

                var snapshots = new List<object>();
                using var cmd = new NpgsqlCommand(sql, connection);
                using var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Newtonsoft.Json.Linq.JObject? jsonValue = null;
                    if (!reader.IsDBNull(2))
                    {
                        try
                        {
                            string jsonStr = reader.GetString(2);
                            jsonValue = Newtonsoft.Json.Linq.JObject.Parse(jsonStr);
                        }
                        catch
                        {
                            // If parsing fails, jsonValue remains null
                        }
                    }

                    snapshots.Add(new
                    {
                        kpiKey = reader.GetString(0),
                        numericValue = reader.IsDBNull(1) ? (long?)null : reader.GetInt64(1),
                        jsonValue = jsonValue,
                        lastComputedUtc = reader.GetDateTime(3),
                        status = reader.GetString(4),
                        errorMessage = reader.IsDBNull(5) ? null : reader.GetString(5)
                    });
                }

                return Ok(new { success = true, snapshots });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error fetching HealthBase KPI snapshots");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        [HttpPost("kpis/refresh")]
        public IActionResult RefreshKpi([FromBody] Dictionary<string, object> request)
        {
            if (request == null || !request.TryGetValue("kpiKey", out var kpiKeyObj) || string.IsNullOrWhiteSpace(kpiKeyObj?.ToString()))
            {
                return BadRequest(new { success = false, message = "kpiKey is required" });
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                var payload = new Dictionary<string, object>
                {
                    ["kpiKey"] = kpiKeyObj.ToString()!
                };

                const string sql = @"
                    INSERT INTO backendqueue (transactionpriority, transactiontype, transactioncategory, transactionidentifier, payload)
                    VALUES (3, 'healthbase_kpi', 'healthbase', 'refreshHealthBaseKpi', @payload::jsonb)
                    RETURNING id;";

                using var cmd = new NpgsqlCommand(sql, connection);
                cmd.Parameters.AddWithValue("payload", Newtonsoft.Json.JsonConvert.SerializeObject(payload));

                int queueId = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);

                return Ok(new { success = true, queueId, message = $"KPI refresh queued for {kpiKeyObj}" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error queuing HealthBase KPI refresh");
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================
        // TELEMEDICINE VIDEO ENDPOINTS
        // ============================================================
        // These endpoints wrap the shared VideoConferenceService for HealthBase telemedicine use case

        /// <summary>
        /// Create or get video room for telemedicine appointment
        /// POST /api/healthbase/telemed/appointments/{appointmentId}/video/room
        /// </summary>
        [HttpPost("telemed/appointments/{appointmentId}/video/room")]
        public IActionResult CreateOrGetTelemedRoom(int appointmentId)
        {
            try
            {
                // Verify appointment exists and is telemedicine
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                const string checkSql = @"
                    SELECT id, is_telemedicine, status
                    FROM healthbase_appointments
                    WHERE id = @appointmentId
                    LIMIT 1;
                ";

                bool isTelemedicine = false;
                string status = "";
                using (var cmd = new NpgsqlCommand(checkSql, connection))
                {
                    cmd.Parameters.AddWithValue("appointmentId", appointmentId);
                    using var reader = cmd.ExecuteReader();
                    if (!reader.Read())
                    {
                        return NotFound(new { success = false, error = "Appointment not found" });
                    }
                    isTelemedicine = reader.GetBoolean(1);
                    status = reader.GetString(2);
                }

                if (!isTelemedicine)
                {
                    return BadRequest(new { success = false, error = "Appointment is not a telemedicine appointment" });
                }

                // Initialize video conference service
                ILogger<VideoConferenceService> vcLogger;
                if (Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) is ILoggerFactory loggerFactory)
                {
                    vcLogger = loggerFactory.CreateLogger<VideoConferenceService>();
                }
                else
                {
                    var factory = LoggerFactory.Create(builder => builder.AddConsole());
                    vcLogger = factory.CreateLogger<VideoConferenceService>();
                }

                var videoService = new VideoConferenceService(
                    _connectionString,
                    vcLogger,
                    _activityService,
                    null,
                    Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) as ILoggerFactory);

                // Create or get session
                var session = videoService.CreateOrGetSession("telemedicine", appointmentId.ToString());

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"Created/retrieved telemedicine video room for appointment {appointmentId}",
                    new { appointmentId, sessionId = session.Id });

                return Ok(new
                {
                    success = true,
                    roomId = session.Id,
                    state = session.State,
                    expiresAtUtc = session.ExpiresAtUtc
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating/getting telemedicine room for appointment {AppointmentId}", appointmentId);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        /// <summary>
        /// Issue join token for telemedicine appointment
        /// POST /api/healthbase/telemed/appointments/{appointmentId}/video/token
        /// </summary>
        [HttpPost("telemed/appointments/{appointmentId}/video/token")]
        public IActionResult IssueTelemedToken(int appointmentId, [FromBody] TelemedTokenRequest? request)
        {
            try
            {
                if (request == null)
                {
                    return BadRequest(new { success = false, error = "Request body is required" });
                }

                // Get user ID from request (should come from authenticated session in production)
                var userId = request.UserId ?? "";

                // Verify appointment and user authorization
                using var connection = new NpgsqlConnection(_connectionString);
                connection.Open();

                const string checkSql = @"
                    SELECT id, is_telemedicine, patient_member_referral, provider_id
                    FROM healthbase_appointments
                    WHERE id = @appointmentId
                    LIMIT 1;
                ";

                string? patientReferral = null;
                int? providerId = null;
                bool isTelemedicine = false;
                using (var cmd = new NpgsqlCommand(checkSql, connection))
                {
                    cmd.Parameters.AddWithValue("appointmentId", appointmentId);
                    using var reader = cmd.ExecuteReader();
                    if (!reader.Read())
                    {
                        return NotFound(new { success = false, error = "Appointment not found" });
                    }
                    isTelemedicine = reader.GetBoolean(1);
                    patientReferral = reader.IsDBNull(2) ? null : reader.GetString(2);
                    providerId = reader.IsDBNull(3) ? null : reader.GetInt32(3);
                }

                if (!isTelemedicine)
                {
                    return BadRequest(new { success = false, error = "Appointment is not a telemedicine appointment" });
                }

                // Verify user is patient or provider
                bool isAuthorized = false;
                if (!string.IsNullOrWhiteSpace(patientReferral) && patientReferral == userId)
                {
                    isAuthorized = true;
                }
                else if (providerId.HasValue)
                {
                    const string providerSql = @"
                        SELECT member_referral
                        FROM healthbase_providers
                        WHERE id = @providerId
                        LIMIT 1;
                    ";
                    using (var cmd = new NpgsqlCommand(providerSql, connection))
                    {
                        cmd.Parameters.AddWithValue("providerId", providerId.Value);
                        var result = cmd.ExecuteScalar();
                        if (result != null && result != DBNull.Value && result.ToString() == userId)
                        {
                            isAuthorized = true;
                        }
                    }
                }

                if (!isAuthorized)
                {
                    return StatusCode(403, new { success = false, error = "User is not authorized for this appointment" });
                }

                // Initialize token service
                ILogger<VideoTokenService> tokenLogger;
                ILogger<VideoConferenceService> vcLogger;
                if (Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) is ILoggerFactory loggerFactory)
                {
                    tokenLogger = loggerFactory.CreateLogger<VideoTokenService>();
                    vcLogger = loggerFactory.CreateLogger<VideoConferenceService>();
                }
                else
                {
                    var factory = LoggerFactory.Create(builder => builder.AddConsole());
                    tokenLogger = factory.CreateLogger<VideoTokenService>();
                    vcLogger = factory.CreateLogger<VideoConferenceService>();
                }

                var videoService = new VideoConferenceService(
                    _connectionString,
                    vcLogger,
                    _activityService,
                    null,
                    Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) as ILoggerFactory);

                var tokenService = new VideoTokenService(
                    _connectionString,
                    tokenLogger,
                    _activityService,
                    videoService,
                    null,
                    Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) as ILoggerFactory);

                // Issue token
                var tokenResponse = tokenService.IssueToken(
                    "telemedicine",
                    appointmentId.ToString(),
                    userId,
                    request.DeviceId ?? "",
                    request.ClientVersion ?? "");

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"Issued telemedicine token for appointment {appointmentId}, user {userId}",
                    new { appointmentId, userId });

                return Ok(new
                {
                    success = true,
                    token = tokenResponse.Token,
                    role = tokenResponse.Role,
                    permissions = new
                    {
                        canAdmit = tokenResponse.Permissions.CanAdmit,
                        canLock = tokenResponse.Permissions.CanLock,
                        canEnd = tokenResponse.Permissions.CanEnd
                    },
                    roomState = tokenResponse.RoomState,
                    expiresAtUtc = tokenResponse.ExpiresAtUtc
                });
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning(ex, "Unauthorized token request for appointment {AppointmentId}", appointmentId);
                return StatusCode(403, new { success = false, error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error issuing telemedicine token for appointment {AppointmentId}", appointmentId);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        /// <summary>
        /// Admit patient to telemedicine session (provider only)
        /// POST /api/healthbase/telemed/appointments/{appointmentId}/video/admit
        /// </summary>
        [HttpPost("telemed/appointments/{appointmentId}/video/admit")]
        public IActionResult AdmitTelemedPatient(int appointmentId, [FromBody] TelemedAdmitRequest? request)
        {
            try
            {
                if (request == null || string.IsNullOrWhiteSpace(request.ParticipantUserId))
                {
                    return BadRequest(new { success = false, error = "participantUserId is required" });
                }

                // Get session for this appointment
                ILogger<VideoConferenceService> vcLogger;
                if (Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) is ILoggerFactory loggerFactory)
                {
                    vcLogger = loggerFactory.CreateLogger<VideoConferenceService>();
                }
                else
                {
                    var factory = LoggerFactory.Create(builder => builder.AddConsole());
                    vcLogger = factory.CreateLogger<VideoConferenceService>();
                }

                var videoService = new VideoConferenceService(
                    _connectionString,
                    vcLogger,
                    _activityService,
                    null,
                    Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) as ILoggerFactory);

                var session = videoService.GetSession("telemedicine", appointmentId.ToString());
                if (session == null)
                {
                    return NotFound(new { success = false, error = "Video session not found for this appointment" });
                }

                // Get actor user ID (should be provider, from authenticated session in production)
                var actorUserId = request.ActorUserId ?? "system";

                videoService.AdmitParticipant(session.Id, request.ParticipantUserId, actorUserId);

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"Admitted patient {request.ParticipantUserId} to telemedicine session for appointment {appointmentId}",
                    new { appointmentId, participantUserId = request.ParticipantUserId, actorUserId });

                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error admitting patient to telemedicine session for appointment {AppointmentId}", appointmentId);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        /// <summary>
        /// Lock telemedicine room
        /// POST /api/healthbase/telemed/appointments/{appointmentId}/video/lock
        /// </summary>
        [HttpPost("telemed/appointments/{appointmentId}/video/lock")]
        public IActionResult LockTelemedRoom(int appointmentId)
        {
            try
            {
                ILogger<VideoConferenceService> vcLogger;
                if (Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) is ILoggerFactory loggerFactory)
                {
                    vcLogger = loggerFactory.CreateLogger<VideoConferenceService>();
                }
                else
                {
                    var factory = LoggerFactory.Create(builder => builder.AddConsole());
                    vcLogger = factory.CreateLogger<VideoConferenceService>();
                }

                var videoService = new VideoConferenceService(
                    _connectionString,
                    vcLogger,
                    _activityService,
                    null,
                    Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) as ILoggerFactory);

                var session = videoService.GetSession("telemedicine", appointmentId.ToString());
                if (session == null)
                {
                    return NotFound(new { success = false, error = "Video session not found for this appointment" });
                }

                var userId = "system"; // Should come from authenticated session in production

                videoService.LockRoom(session.Id, userId);

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"Locked telemedicine room for appointment {appointmentId}",
                    new { appointmentId, userId });

                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error locking telemedicine room for appointment {AppointmentId}", appointmentId);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        /// <summary>
        /// End telemedicine visit
        /// POST /api/healthbase/telemed/appointments/{appointmentId}/video/end
        /// </summary>
        [HttpPost("telemed/appointments/{appointmentId}/video/end")]
        public async Task<IActionResult> EndTelemedVisit(int appointmentId)
        {
            try
            {
                ILogger<VideoConferenceService> vcLogger;
                if (Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) is ILoggerFactory loggerFactory)
                {
                    vcLogger = loggerFactory.CreateLogger<VideoConferenceService>();
                }
                else
                {
                    var factory = LoggerFactory.Create(builder => builder.AddConsole());
                    vcLogger = factory.CreateLogger<VideoConferenceService>();
                }

                var videoService = new VideoConferenceService(
                    _connectionString,
                    vcLogger,
                    _activityService,
                    null,
                    Request.HttpContext.RequestServices.GetService(typeof(ILoggerFactory)) as ILoggerFactory);

                var session = videoService.GetSession("telemedicine", appointmentId.ToString());
                if (session == null)
                {
                    return NotFound(new { success = false, error = "Video session not found for this appointment" });
                }

                var userId = "system"; // Should come from authenticated session in production

                videoService.EndSession(session.Id, userId);

                // Update appointment status to completed and award reward
                using var connection = new NpgsqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = await connection.BeginTransactionAsync();
                try
                {
                    // Get patient referral before updating
                    string? patientReferral = null;
                    const string getPatientSql = @"
                        SELECT patient_member_referral
                        FROM healthbase_appointments
                        WHERE id = @appointmentId;
                    ";
                    using (var getCmd = new NpgsqlCommand(getPatientSql, connection, transaction))
                    {
                        getCmd.Parameters.AddWithValue("appointmentId", appointmentId);
                        var result = await getCmd.ExecuteScalarAsync();
                        if (result != null && result != DBNull.Value)
                        {
                            patientReferral = result.ToString();
                        }
                    }

                    // Update appointment status
                    const string updateSql = @"
                        UPDATE healthbase_appointments
                        SET status = 'completed',
                            updated_at = NOW()
                        WHERE id = @appointmentId;
                    ";
                    using (var cmd = new NpgsqlCommand(updateSql, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("appointmentId", appointmentId);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Award reward for completing appointment (if patient referral exists)
                    if (!string.IsNullOrWhiteSpace(patientReferral))
                    {
                        // Get reward activity for "Appointment Completed" (activity_id = 1 or find by name)
                        int? rewardActivityId = null;
                        decimal rewardKesAmount = 50m; // Default reward: 50 KES
                        const string rewardActivitySql = @"
                            SELECT id, kes_amount
                            FROM healthbase_reward_activities
                            WHERE activity_name ILIKE '%appointment%complete%'
                              AND is_active = true
                            LIMIT 1;
                        ";
                        using (var rewardCmd = new NpgsqlCommand(rewardActivitySql, connection, transaction))
                        {
                            using var rewardReader = await rewardCmd.ExecuteReaderAsync();
                            if (await rewardReader.ReadAsync())
                            {
                                rewardActivityId = rewardReader.GetInt32(0);
                                rewardKesAmount = rewardReader.GetDecimal(1);
                            }
                        }

                        // Credit wallet for reward
                        if (rewardKesAmount > 0)
                        {
                            await CreditWalletForRewardAsync(
                                patientReferral,
                                rewardKesAmount,
                                "Appointment Completed",
                                rewardActivityId,
                                connection,
                                transaction
                            );
                        }
                    }

                    await transaction.CommitAsync();
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }

                _activityService?.Record("HealthBaseController", "SUCCESS",
                    $"Ended telemedicine visit for appointment {appointmentId}",
                    new { appointmentId, userId });

                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error ending telemedicine visit for appointment {AppointmentId}", appointmentId);
                return StatusCode(500, new { success = false, error = ex.Message });
            }
        }

        // ============================================================================
        // HELPER: Credit HelloKenya Wallet for HealthBase Rewards
        // ============================================================================
        /// <summary>
        /// Credits HelloKenya wallet when a HealthBase reward is earned
        /// This method should be called whenever a reward activity is completed
        /// </summary>
        private async Task<bool> CreditWalletForRewardAsync(
            string memberReferral,
            decimal kesAmount,
            string activityName,
            int? activityId = null,
            NpgsqlConnection? existingConnection = null,
            NpgsqlTransaction? existingTransaction = null)
        {
            try
            {
                if (kesAmount <= 0)
                {
                    return false; // No reward to credit
                }

                using var connection = existingConnection ?? new NpgsqlConnection(_connectionString);
                if (existingConnection == null)
                {
                    await connection.OpenAsync();
                }

                using var txn = existingTransaction ?? await connection.BeginTransactionAsync();
                try
                {
                    // Credit wallet using AccountingService
                    if (_accountingService == null)
                    {
                        _logger.LogWarning("AccountingService not available for wallet credit");
                        if (existingTransaction == null)
                        {
                            await txn.RollbackAsync();
                        }
                        return false;
                    }

                    // Create ImagineBC transaction first
                    long imaginebcTransactionId;
                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.Transaction = txn;
                        cmd.CommandText = @"
                            INSERT INTO transactions
                                (transaction_type, buyer_referral, seller_referral, amount, metadata)
                            VALUES
                                ('HELLOKENYA_WALLET_CREDIT', @buyer, NULL, @amount, @metadata::jsonb)
                            RETURNING transaction_id";
                        cmd.Parameters.AddWithValue("buyer", memberReferral);
                        cmd.Parameters.AddWithValue("amount", (double)kesAmount);
                        cmd.Parameters.AddWithValue("metadata", System.Text.Json.JsonSerializer.Serialize(new
                        {
                            source = "healthbase_reward",
                            activityName = activityName,
                            activityId = activityId?.ToString() ?? "",
                            transactionType = "wallet_credit"
                        }));
                        imaginebcTransactionId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    // Credit wallet using ProcessDirectCredit
                    var payload = new Newtonsoft.Json.Linq.JObject
                    {
                        ["memberReferral"] = memberReferral,
                        ["kesAmount"] = kesAmount,
                        ["activityName"] = activityName,
                        ["activityId"] = activityId?.ToString() ?? ""
                    };

                    var metadata = new Newtonsoft.Json.Linq.JObject
                    {
                        ["transactionType"] = "wallet_credit",
                        ["source"] = "healthbase_reward",
                        ["txId"] = imaginebcTransactionId.ToString(),
                        ["activityName"] = activityName
                    };

                    var creditResult = await Task.Run(() => _accountingService.ProcessDirectCredit(
                        memberReferral,
                        kesAmount,
                        "Transferable",
                        payload,
                        metadata,
                        "production",
                        connection,
                        txn
                    ));

                    if (creditResult["ok"]?.ToObject<bool>() != true)
                    {
                        var error = creditResult["error"]?.ToString() ?? "Unknown error";
                        _logger.LogError("Failed to credit wallet for reward: {Error}", error);
                        if (existingTransaction == null)
                        {
                            await txn.RollbackAsync();
                        }
                        return false;
                    }

                    // Create transaction record in HelloKenya shadow ledger
                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.Transaction = txn;
                        cmd.CommandText = @"
                            INSERT INTO hellokenya_transactions
                                (member_id, type, gross_amount_kes, fee_amount_kes, net_amount_kes, status, metadata, created_at, updated_at)
                            VALUES
                                (@memberId, 'TOPUP', @gross, 0, @net, 'succeeded', @metadata::jsonb, NOW(), NOW())
                            RETURNING id";
                        cmd.Parameters.AddWithValue("memberId", memberReferral);
                        cmd.Parameters.AddWithValue("gross", kesAmount);
                        cmd.Parameters.AddWithValue("net", kesAmount);
                        cmd.Parameters.AddWithValue("metadata", System.Text.Json.JsonSerializer.Serialize(new
                        {
                            source = "healthbase_reward",
                            description = $"HealthBase Reward: {activityName}",
                            activityName = activityName,
                            activityId = activityId,
                            imaginebcTransactionId = imaginebcTransactionId
                        }));
                        var transactionId = Convert.ToInt64(await cmd.ExecuteScalarAsync());
                    }

                    // Update wallet metadata (total_earned)
                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.Transaction = txn;
                        cmd.CommandText = @"
                            INSERT INTO hellokenya_wallet_metadata (member_id, total_earned_kes, currency)
                            VALUES (@memberId, @earned, 'KES')
                            ON CONFLICT (member_id) 
                            DO UPDATE SET 
                                total_earned_kes = hellokenya_wallet_metadata.total_earned_kes + @earned,
                                updated_at = NOW()";
                        cmd.Parameters.AddWithValue("memberId", memberReferral);
                        cmd.Parameters.AddWithValue("earned", kesAmount);
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Record reward in healthbase_user_rewards if activityId provided
                    if (activityId.HasValue)
                    {
                        using (var cmd = connection.CreateCommand())
                        {
                            cmd.Transaction = txn;
                            cmd.CommandText = @"
                                INSERT INTO healthbase_user_rewards (member_referral, activity_id, points_earned, kes_earned, earned_at)
                                VALUES (@memberReferral, @activityId, 0, @kesAmount, NOW())
                                ON CONFLICT (member_referral, activity_id) 
                                DO UPDATE SET 
                                    kes_earned = healthbase_user_rewards.kes_earned + @kesAmount,
                                    earned_at = NOW()";
                            cmd.Parameters.AddWithValue("memberReferral", memberReferral);
                            cmd.Parameters.AddWithValue("activityId", activityId.Value);
                            cmd.Parameters.AddWithValue("kesAmount", kesAmount);
                            await cmd.ExecuteNonQueryAsync();
                        }
                    }

                    if (existingTransaction == null)
                    {
                        await txn.CommitAsync();
                    }

                    _activityService?.Record("HealthBaseController", "SUCCESS",
                        $"Wallet credited for HealthBase reward: {kesAmount} KES for {activityName}",
                        new { memberReferral, kesAmount, activityName, activityId });

                    return true;
                }
                catch
                {
                    if (existingTransaction == null)
                    {
                        await txn.RollbackAsync();
                    }
                    throw;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ CreditWalletForRewardAsync failed for memberReferral={MemberReferral}, activity={ActivityName}", memberReferral, activityName);
                return false;
            }
        }
    }

    // Request DTOs for telemedicine endpoints
    public class TelemedTokenRequest
    {
        public string? UserId { get; set; }
        public string? DeviceId { get; set; }
        public string? ClientVersion { get; set; }
    }

    public class TelemedAdmitRequest
    {
        public string ParticipantUserId { get; set; } = string.Empty;
        public string? ActorUserId { get; set; }
    }
}
