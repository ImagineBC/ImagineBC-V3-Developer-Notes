// ============================================================================
// Map Detail Panel
// Displays entity information when user is within proximity
// Shows: image, name, description, tagline, and enter button
// Special handling for bulletin boards: shows announcement carousel only
// ============================================================================

import React, { useState } from 'react';

// Expandable text component
function ExpandableText({ text, maxLength = 140 }) {
  const [isExpanded, setIsExpanded] = useState(false);
  
  if (!text) return null;
  
  const shouldTruncate = text.length > maxLength;
  const displayText = shouldTruncate && !isExpanded 
    ? text.substring(0, maxLength) + '...' 
    : text;
  
  return (
    <div>
      <p
        style={{
          fontSize: '16px',
          color: '#444',
          margin: 0,
          lineHeight: '1.5',
        }}
      >
        {displayText}
      </p>
      {shouldTruncate && (
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          style={{
            background: 'none',
            border: 'none',
            color: '#56AF9B',
            fontSize: '15px',
            fontWeight: 600,
            cursor: 'pointer',
            padding: '4px 0',
            marginTop: '4px',
          }}
        >
          {isExpanded ? 'Show less' : 'Show more'}
        </button>
      )}
    </div>
  );
}
import { AnnouncementCarousel } from './AnnouncementCarousel.jsx';
import { cleanPath } from '@utils/strings.js';
import { runChannel } from '@components/bizbase/rendering/runChannel.jsx';
import { runContent } from '@components/bizbase/rendering/runContent.jsx';
import { getChannelContent } from '@wrappers/ioSocialContent.jsx';
import { t } from "@shared/translations.js";
import { addMapSteps } from '@api/homebase.js';
import { gvUser } from '@core/state.js';
import { processGamificationEvent } from '@wrappers/ioGamification.jsx';

/**
 * MapDetailPanel component
 * @param {object} props
 * @param {object} props.entity - Entity object with details
 * @param {Function} props.onEnter - Callback when user clicks to enter
 * @param {Function} props.onClose - Callback when user clicks to close the panel (optional)
 * @param {Function} props.t - Translation function
 */
export function MapDetailPanel({ entity, onEnter, onClose, t }) {
  // All hooks must run before any early return (React rules of hooks)
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showAudioModal, setShowAudioModal] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [videoUrl, setVideoUrl] = useState(null);
  const [audioUrl, setAudioUrl] = useState(null);
  const [messageText, setMessageText] = useState('');
  const [messageTitle, setMessageTitle] = useState('');
  const [imageHovered, setImageHovered] = useState(false);

  if (!entity) {
    return null;
  }

  // Extract entity type
  const entityType = entity.entity_type || entity.entityType || '';
  const isBulletinBoard = entityType === 'bulletinboard';
  const isATM = entityType === 'atm';
  const centerKeyLower = (entity.center_key || entity.centerKey || '').toLowerCase();
  const isNewsstand = entityType === 'public_center' || entityType === 'publicCenter' ? centerKeyLower === 'newsstand' : false;
  // Special locations: no "Tap to Visit" button — not entered
  const isSpecialLocation = isBulletinBoard || isATM || isNewsstand;

  // Check if this is a Community Power Infrastructure location
  const centerKey = (entity.center_key || entity.centerKey || '').toUpperCase();
  const metadata = entity.metadata || {};
  const componentType = metadata.component_type || metadata.componentType || '';
  const visibilityScope = metadata.visibility_scope || metadata.visibilityScope || '';
  const isPowerStation = centerKey === 'POWER_STATION';
  const isGridHub = centerKey === 'GRID_HUB';
  const isPowerInfrastructure = isPowerStation || isGridHub || 
                                componentType === 'SPECIAL-LOCATION' || visibilityScope === 'MAP_ONLY';
  const powerStatus = entity._powerStatus || 'STABLE';
  const sponsorCount = entity._sponsorCount || 0;
  const sponsors = entity._sponsors || [];
  
  // Extract entity fields (case-insensitive; support Description/tagline from API)
  const entityName = entity.name || entity.fullname || entity.shortname || entity.entity_referral || '';
  const entityDescription = entity.description || entity.Description || '';
  const entityTagline = entity.tagline || entity.Tagline || '';
  const entityImage = entity.image || entity.logo || entity.banner || null;
  const imageUrl = entityImage ? cleanPath(entityImage) : null;

  // Fully implemented announcement action handlers
  const handleAnnouncementClick = async (announcement) => {
    // Parse action from contentMeta or structuremap
    const contentMeta = announcement?.contentMeta || announcement?.ContentMeta || {};
    let action = contentMeta.action?.type || contentMeta.action || contentMeta.Action || 'no_action';
    let actionTarget = contentMeta.action?.target || contentMeta.actionTarget || contentMeta.ActionTarget || null;
    const announcementTitle = contentMeta.title || announcement?.title || 'Announcement';

    // If action is an object, extract type and target
    if (typeof action === 'object' && action !== null) {
      actionTarget = action.target || actionTarget;
      action = action.type || 'no_action';
    }

    // Parse structuremap if available
    if (announcement?.structuremap) {
      try {
        const structuremap = typeof announcement.structuremap === 'string'
          ? JSON.parse(announcement.structuremap)
          : announcement.structuremap;
        
        if (structuremap.action) {
          action = structuremap.action.type || action;
          actionTarget = structuremap.action.target || actionTarget;
        }
      } catch (err) {
        console.warn('⚠️ Failed to parse structuremap:', err);
      }
    }

    console.log('📋 Announcement clicked:', {
      announcement,
      action,
      actionTarget,
    });

    // Execute action
    try {
      switch (action) {
        case 'runChannel':
          if (actionTarget) {
            await runChannel(actionTarget);
          }
          break;
        case 'runContent':
          if (actionTarget) {
            await runContent(actionTarget);
          }
          break;
        case 'playVideo':
          if (actionTarget) {
            // Fetch content to get video URL
            const contentResult = await getChannelContent(actionTarget);
            if (contentResult?.success && contentResult.content) {
              const content = contentResult.content;
              // Parse structuremap to find video block
              let structuremap = {};
              try {
                structuremap = typeof content.structuremap === 'string'
                  ? JSON.parse(content.structuremap || '{}')
                  : content.structuremap || {};
              } catch (err) {
                console.warn('⚠️ Failed to parse content structuremap:', err);
              }
              const blocks = structuremap.blocks || [];
              const videoBlock = blocks.find((b) => b.type === 'video');
              if (videoBlock?.url) {
                setVideoUrl(cleanPath(videoBlock.url));
                setShowVideoModal(true);
              } else {
                console.error('❌ Video block not found in content');
              }
            } else {
              console.error('❌ Failed to fetch video content');
            }
          }
          break;
        case 'playAudio':
          if (actionTarget) {
            // Fetch content to get audio URL
            const contentResult = await getChannelContent(actionTarget);
            if (contentResult?.success && contentResult.content) {
              const content = contentResult.content;
              // Parse structuremap to find audio block
              let structuremap = {};
              try {
                structuremap = typeof content.structuremap === 'string'
                  ? JSON.parse(content.structuremap || '{}')
                  : content.structuremap || {};
              } catch (err) {
                console.warn('⚠️ Failed to parse content structuremap:', err);
              }
              const blocks = structuremap.blocks || [];
              const audioBlock = blocks.find((b) => b.type === 'audio');
              if (audioBlock?.url) {
                setAudioUrl(cleanPath(audioBlock.url));
                setShowAudioModal(true);
              } else {
                console.error('❌ Audio block not found in content');
              }
            } else {
              console.error('❌ Failed to fetch audio content');
            }
          }
          break;
        case 'showMessage':
          if (actionTarget) {
            setMessageText(actionTarget);
            setMessageTitle(announcementTitle);
            setShowMessageModal(true);
          }
          break;
        case 'no_action':
        default:
          // Show detail view (handled by AnnouncementCarousel or fallback)
          break;
      }
    } catch (err) {
      console.error('❌ Action execution error:', err);
      // Fallback: show detail view on error
    }
  };

  // Channel/public center referral for runChannel (channels and public centers launched via runChannel)
  const channelReferral = entity.entity_referral || entity.entityReferral || entity.center_key || entity.centerKey || '';

  const handleEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (onEnter) {
      onEnter(entity);
    }
  };

  const handleVisit = async (e) => {
    console.log("entered function handleVisit");
    e.preventDefault();
    e.stopPropagation();
    if (channelReferral) {
      await runChannel({ channelReferral });
      const memberReferral = gvUser?.memberreferral;
      if (memberReferral) {
        addMapSteps(memberReferral, 4).then((res) => {
          if (res?.success && typeof res.totalToday === 'number' && typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('mapStepsUpdated', { detail: { totalToday: res.totalToday } }));
          }
        });
        // Fire gamification event for map location entry
        processGamificationEvent("MAP_LOCATION_ENTERED", memberReferral, { channelReferral }).catch(() => {});
      }
    }
  };

  const handleImageClick = (e) => {
    console.log("entered function handleImageClick");
    e.preventDefault();
    e.stopPropagation();
    if (isSpecialLocation) return;
    if (channelReferral) {
      runChannel({ channelReferral });
      const memberReferral = gvUser?.memberreferral;
      if (memberReferral) {
        addMapSteps(memberReferral, 4).then((res) => {
          if (res?.success && typeof res.totalToday === 'number' && typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent('mapStepsUpdated', { detail: { totalToday: res.totalToday } }));
          }
        });
        // Fire gamification event for map location entry
        processGamificationEvent("MAP_LOCATION_ENTERED", memberReferral, { channelReferral }).catch(() => {});
      }
    } else if (onEnter) {
      onEnter(entity);
    }
  };

  const handleDeposit = (e) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('🏧 ATM Deposit action (scaffolded)');
    // TODO: Implement deposit action
  };

  const handleWithdraw = (e) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('🏧 ATM Withdraw action (scaffolded)');
    // TODO: Implement withdraw action
  };

  const handleClose = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (onClose) onClose();
  };

  // Community Power Infrastructure: Special rendering (no entry, proximity only)
  if (isPowerInfrastructure) {
    const getStatusColor = () => {
      switch (powerStatus) {
        case 'BOOSTED':
          return '#00FF64'; // Bright green
        case 'LIMITED':
          return '#FFA500'; // Orange
        case 'STABLE':
        default:
          return '#6496FF'; // Blue
      }
    };
    
    const getStatusLabel = () => {
      switch (powerStatus) {
        case 'BOOSTED':
          return t("communityPowerStatusBoosted");
        case 'LIMITED':
          return t("communityPowerStatusLimited");
        case 'STABLE':
        default:
          return t("communityPowerStatusStable");
      }
    };
    
    // Grid Hub: Engagement-based community power (Layer 1). No dollar amounts or sponsor count.
    if (isGridHub) {
      const gridHubPower = typeof window !== 'undefined' ? window.__GRID_HUB_POWER__ : null;
      const communityPowerTier = (gridHubPower && gridHubPower.communityPowerTier) || 'Dormant';
      const tierKey = 'gridHubCommunityPower' + communityPowerTier;
      return (
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: '#fff',
            borderTopLeftRadius: '20px',
            borderTopRightRadius: '20px',
            boxShadow: '0 -4px 20px rgba(0, 0, 0, 0.15)',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            height: 'auto',
            maxHeight: '40%',
            zIndex: 100,
          }}
        >
          <div style={{ fontSize: '18px', fontWeight: 700, color: '#333' }}>
            {t("gridHubTitle")}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '14px', color: '#666' }}>{t("gridHubCommunityPowerLabel")}</span>
            <span style={{ fontSize: '14px', fontWeight: 600, color: '#333' }}>
              {t(tierKey)}
            </span>
          </div>
          <div style={{ fontSize: '13px', color: '#666', lineHeight: 1.4 }}>
            {t("gridHubSubtext")}
          </div>
          <div style={{ fontSize: '12px', color: '#888', lineHeight: 1.35 }}>
            {t("gridHubMicrotext")}
          </div>
          {onEnter && (
            <button
              onClick={handleEnter}
              style={{
                width: '100%',
                padding: '12px 20px',
                backgroundColor: '#56AF9B',
                color: '#fff',
                border: 'none',
                borderRadius: '12px',
                fontSize: '15px',
                fontWeight: 600,
                cursor: 'pointer',
                marginTop: '4px',
                transition: 'background-color 0.2s ease, transform 0.1s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#3d8a7a';
                e.currentTarget.style.transform = 'scale(1.02)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#56AF9B';
                e.currentTarget.style.transform = 'scale(1.0)';
              }}
            >
              {t("gridHubEnter")}
            </button>
          )}
        </div>
      );
    }
    
    // Power Station: Shows active sponsors (explicit)
    if (isPowerStation) {
      return (
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: '#fff',
            borderTopLeftRadius: '20px',
            borderTopRightRadius: '20px',
            boxShadow: '0 -4px 20px rgba(0, 0, 0, 0.15)',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '12px',
            height: 'auto',
            maxHeight: '40%',
            overflowY: 'auto',
            zIndex: 100,
          }}
        >
          <div style={{ fontSize: '18px', fontWeight: 700, color: '#333' }}>
            {t("communityPowerPowerStation")}
          </div>
          <div style={{ fontSize: '14px', color: '#666', marginBottom: '8px' }}>
            {t("communityPowerActivePartners")}
          </div>
          {sponsors && sponsors.length > 0 ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {sponsors.map((sponsor, index) => (
                <div
                  key={index}
                  style={{
                    padding: '8px',
                    backgroundColor: '#f5f5f5',
                    borderRadius: '8px',
                    fontSize: '13px',
                  }}
                >
                  <div style={{ fontWeight: 600, color: '#333', marginBottom: '4px' }}>
                    {sponsor.sponsorName || sponsor.SponsorName || t("communityPowerNoActiveSponsors")}
                  </div>
                  {(sponsor.countryCoverage || sponsor.CountryCoverage) && (sponsor.countryCoverage || sponsor.CountryCoverage).length > 0 && (
                    <div style={{ fontSize: '12px', color: '#666' }}>
                      {t("communityPowerCountries")} {(sponsor.countryCoverage || sponsor.CountryCoverage).join(', ')}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div style={{ fontSize: '13px', color: '#888', fontStyle: 'italic' }}>
              {t("communityPowerNoActiveSponsors")}
            </div>
          )}
        </div>
      );
    }
  }

  // Bulletin board: show carousel only (no title/description), with same X close as standard panel
  if (isBulletinBoard) {
    const announcements = entity.announcements || [];
    return (
      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: '#fff',
          borderTopLeftRadius: '20px',
          borderTopRightRadius: '20px',
          boxShadow: '0 -4px 20px rgba(0, 0, 0, 0.15)',
          padding: '20px',
          display: 'flex',
          flexDirection: 'column',
          height: '35%',
          zIndex: 100,
        }}
      >
        {onClose && (
          <button
            type="button"
            onClick={handleClose}
            onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); }}
            aria-label="Close"
            style={{
              position: 'absolute',
              top: '12px',
              right: '12px',
              width: '32px',
              height: '32px',
              borderRadius: '50%',
              border: 'none',
              backgroundColor: 'rgba(0,0,0,0.4)',
              color: '#fff',
              fontSize: '18px',
              fontWeight: 'bold',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              zIndex: 101,
            }}
          >
            ×
          </button>
        )}
        <AnnouncementCarousel
          announcements={announcements}
          onAnnouncementClick={handleAnnouncementClick}
        />
      </div>
    );
  }

  // Extract storefront image (banner) and logo separately for channels (case-insensitive for channelStorefront)
  const isChannel = entityType === 'channel' || (typeof entityType === 'string' && entityType.toLowerCase() === 'channelstorefront');
  const isPublicCenter = entityType === 'public_center' || entityType === 'publicCenter';
  const showVisitButton = !isSpecialLocation && (isChannel || isPublicCenter);
  
  // For channels: use custom map building image if set, else /images/map/storefront.jpg
  // For public centers: use /images/map/{center_key}.jpg
  let storefrontImageUrl = null;
  if (isChannel) {
    const mapBuildingImage = entity.mapbuildingimage || entity.mapBuildingImage;
    storefrontImageUrl = mapBuildingImage ? cleanPath(mapBuildingImage) : '/images/map/storefront.jpg';
  } else if (isPublicCenter) {
    // Public centers use building path from public_centers.building when present, else center_key.jpg
    const buildingPath = entity.building;
    if (buildingPath) {
      storefrontImageUrl = cleanPath(buildingPath);
    } else {
      const centerKey = entity.center_key || entity.centerKey || entity.entity_referral || entity.entityReferral || '';
      if (centerKey) {
        storefrontImageUrl = `/images/map/${centerKey.toLowerCase()}.jpg`;
      }
    }
  } else {
    // Other entities (ATMs, bulletin boards) use their image if available
    storefrontImageUrl = imageUrl;
  }

  const imageSource = isChannel
    ? (entity.mapbuildingimage || entity.mapBuildingImage ? 'custom' : 'fallback')
    : 'other';
  // console.log('[MapBuildingImage] panel', {
  //   entityRef: entity.entity_referral || entity.entityReferral || entity.name,
  //   entityType,
  //   isChannel,
  //   entityMapbuildingimage: entity.mapbuildingimage ?? '(missing)',
  //   entityMapBuildingImage: entity.mapBuildingImage ?? '(missing)',
  //   storefrontImageUrl: storefrontImageUrl ?? '(null)',
  //   source: imageSource,
  // });

  const logoImage = isChannel ? (entity.logo || entity.channelLogo) : null;
  const logoImageUrl = logoImage ? cleanPath(logoImage) : null;

  // Regular entities: card layout - left = name, tagline, description; right = image (35%) + Enter underneath
  // Panel height auto, max 36%, padding bottom 10px beneath button
  return (
    <div
      style={{
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: '#fff',
        borderTopLeftRadius: '20px',
        borderTopRightRadius: '20px',
        border: '1px solid rgba(0,0,0,0.08)',
        boxShadow: '0 -4px 20px rgba(0, 0, 0, 0.15)',
        display: 'flex',
        flexDirection: 'row',
        padding: '14px 44px 10px 16px',
        gap: '16px',
        height: 'auto',
        maxHeight: '36%',
        overflow: 'hidden',
        zIndex: 100,
      }}
    >
      {onClose && (
        <button
          type="button"
          onClick={handleClose}
          onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); }}
          aria-label="Close"
          style={{
            position: 'absolute',
            top: '12px',
            right: '12px',
            width: '32px',
            height: '32px',
            borderRadius: '50%',
            border: 'none',
            backgroundColor: 'rgba(0,0,0,0.4)',
            color: '#fff',
            fontSize: '18px',
            fontWeight: 'bold',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 101,
          }}
        >
          ×
        </button>
      )}

      {/* Left column: name, tagline, description */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          gap: '10px',
          overflowY: 'auto',
          minWidth: 0,
          paddingRight: '8px',
        }}
      >
        {entityName && (
          <h3
            style={{
              fontSize: '24px',
              fontWeight: 700,
              color: '#111',
              margin: 0,
              lineHeight: '1.2',
              flexShrink: 0,
            }}
          >
            {entityName}
          </h3>
        )}

        {entityTagline && (
          <p
            style={{
              fontSize: '15px',
              fontWeight: 500,
              color: '#666',
              margin: 0,
              lineHeight: '1.4',
              flexShrink: 0,
            }}
          >
            {entityTagline}
          </p>
        )}

        {entityDescription && (
          <div style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
            <ExpandableText text={entityDescription} maxLength={140} />
          </div>
        )}

        {isATM && (
          <div style={{ display: 'flex', gap: '12px', marginTop: 'auto', flexShrink: 0 }}>
            <button
              onClick={handleDeposit}
              style={{
                flex: 1,
                minHeight: '44px',
                padding: '12px 20px',
                backgroundColor: '#56AF9B',
                color: '#fff',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'background-color 0.2s ease, transform 0.1s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#3d8a7a';
                e.currentTarget.style.transform = 'scale(1.02)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#56AF9B';
                e.currentTarget.style.transform = 'scale(1.0)';
              }}
            >
              Deposit
            </button>
            <button
              onClick={handleWithdraw}
              style={{
                flex: 1,
                minHeight: '44px',
                padding: '12px 20px',
                backgroundColor: '#56AF9B',
                color: '#fff',
                border: 'none',
                borderRadius: '12px',
                fontSize: '16px',
                fontWeight: 600,
                cursor: 'pointer',
                transition: 'background-color 0.2s ease, transform 0.1s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#3d8a7a';
                e.currentTarget.style.transform = 'scale(1.02)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#56AF9B';
                e.currentTarget.style.transform = 'scale(1.0)';
              }}
            >
              Withdraw
            </button>
          </div>
        )}
      </div>

      {/* Right column: image (35% width) + Enter underneath */}
      <div
        style={{
          width: '35%',
          flexShrink: 0,
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
        }}
      >
        <div
          onClick={handleImageClick}
          onMouseEnter={() => !isSpecialLocation && setImageHovered(true)}
          onMouseLeave={() => setImageHovered(false)}
          style={{
            width: '100%',
            aspectRatio: '4/3',
            flexShrink: 0,
            overflow: 'hidden',
            borderRadius: '12px',
            backgroundColor: '#f0f0f0',
            cursor: isSpecialLocation ? 'default' : 'pointer',
            opacity: imageHovered ? 0.9 : 1,
            transform: imageHovered ? 'scale(1.02)' : 'scale(1)',
            transition: 'opacity 0.2s ease, transform 0.2s ease',
            boxShadow: imageHovered ? '0 4px 12px rgba(0,0,0,0.15)' : 'none',
          }}
        >
          {storefrontImageUrl ? (
            <img
              src={storefrontImageUrl}
              alt={entityName}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
              onLoad={(e) => {
                // console.log('[MapBuildingImage] img onLoad OK', storefrontImageUrl);
                e.target.style.display = '';
              }}
              onError={(e) => {
                // console.log('[MapBuildingImage] img onError', { url: storefrontImageUrl, entityRef: entity.entity_referral || entity.entityReferral });
                e.target.style.display = 'none';
              }}
            />
          ) : (
            <div style={{ width: '100%', height: '100%', backgroundColor: '#e8e8e8' }} />
          )}
        </div>

        {showVisitButton && (
          <button
            onClick={handleVisit}
            style={{
              width: '100%',
              minHeight: '44px',
              padding: '12px 20px',
              backgroundColor: '#56AF9B',
              color: '#fff',
              border: 'none',
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: 600,
              cursor: 'pointer',
              flexShrink: 0,
              transition: 'background-color 0.2s ease, transform 0.1s ease',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#3d8a7a';
              e.currentTarget.style.transform = 'scale(1.02)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#56AF9B';
              e.currentTarget.style.transform = 'scale(1.0)';
            }}
          >
            {t("map_detail_panel_enter")}
          </button>
        )}
      </div>

      {/* Modals for announcement actions */}
      {showVideoModal && (
        <VideoPlayerModal
          videoUrl={videoUrl}
          onClose={() => {
            setShowVideoModal(false);
            setVideoUrl(null);
          }}
        />
      )}
      {showAudioModal && (
        <AudioPlayerModal
          audioUrl={audioUrl}
          onClose={() => {
            setShowAudioModal(false);
            setAudioUrl(null);
          }}
        />
      )}
      {showMessageModal && (
        <MessageModal
          title={messageTitle}
          messageText={messageText}
          onClose={() => {
            setShowMessageModal(false);
            setMessageText('');
            setMessageTitle('');
          }}
        />
      )}
    </div>
  );
}

// Video Player Modal Component
function VideoPlayerModal({ videoUrl, onClose }) {
  const videoRef = React.useRef(null);

  React.useEffect(() => {
    function esc(e) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', esc);
    return () => document.removeEventListener('keydown', esc);
  }, [onClose]);

  return (
    <div
      onClick={(e) => {
        if (e.target.id === 'videoModalOverlay') onClose();
      }}
      id="videoModalOverlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.75)',
        zIndex: 10000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backdropFilter: 'blur(3px)',
      }}
    >
      <div
        style={{
          width: '92%',
          maxWidth: '800px',
          backgroundColor: '#000',
          borderRadius: '14px',
          overflow: 'hidden',
          position: 'relative',
          boxShadow: '0 8px 24px rgba(0,0,0,0.6)',
        }}
      >
        {/* Close Button */}
        <div
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '10px',
            right: '14px',
            fontSize: '22px',
            color: '#fff',
            cursor: 'pointer',
            userSelect: 'none',
            zIndex: 2,
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: 'rgba(0,0,0,0.5)',
            borderRadius: '50%',
          }}
        >
          ✕
        </div>

        {/* Video Player */}
        <video
          ref={videoRef}
          src={videoUrl}
          controls
          autoPlay
          style={{
            width: '100%',
            maxHeight: '90vh',
            display: 'block',
          }}
        />
      </div>
    </div>
  );
}

// Audio Player Modal Component
function AudioPlayerModal({ audioUrl, onClose }) {
  const audioRef = React.useRef(null);

  React.useEffect(() => {
    function esc(e) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', esc);
    return () => document.removeEventListener('keydown', esc);
  }, [onClose]);

  return (
    <div
      onClick={(e) => {
        if (e.target.id === 'audioModalOverlay') onClose();
      }}
      id="audioModalOverlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.75)',
        zIndex: 10000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backdropFilter: 'blur(3px)',
      }}
    >
      <div
        style={{
          width: '92%',
          maxWidth: '500px',
          backgroundColor: '#fff',
          borderRadius: '14px',
          overflow: 'hidden',
          position: 'relative',
          boxShadow: '0 8px 24px rgba(0,0,0,0.6)',
          padding: '24px',
        }}
      >
        {/* Close Button */}
        <div
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '10px',
            right: '14px',
            fontSize: '22px',
            color: '#666',
            cursor: 'pointer',
            userSelect: 'none',
            zIndex: 2,
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          ✕
        </div>

        {/* Audio Player */}
        <div style={{ marginTop: '8px' }}>
          <audio
            ref={audioRef}
            src={audioUrl}
            controls
            autoPlay
            style={{
              width: '100%',
            }}
          />
        </div>
      </div>
    </div>
  );
}

// Message Modal Component
function MessageModal({ title, messageText, onClose }) {
  React.useEffect(() => {
    function esc(e) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', esc);
    return () => document.removeEventListener('keydown', esc);
  }, [onClose]);

  return (
    <div
      onClick={(e) => {
        if (e.target.id === 'messageModalOverlay') onClose();
      }}
      id="messageModalOverlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.7)',
        zIndex: 10000,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backdropFilter: 'blur(3px)',
      }}
    >
      <div
        style={{
          width: '92%',
          maxWidth: '500px',
          backgroundColor: '#fff',
          borderRadius: '16px',
          overflow: 'hidden',
          position: 'relative',
          boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
        }}
      >
        {/* Close Button */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
            padding: '12px 16px',
            borderBottom: '1px solid #f0f0f0',
          }}
        >
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '24px',
              cursor: 'pointer',
              color: '#666',
              padding: '0',
              width: '32px',
              height: '32px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            ×
          </button>
        </div>

        {/* Message Content */}
        <div style={{ padding: '24px' }}>
          <h2
            style={{
              fontSize: '24px',
              fontWeight: 700,
              margin: '0 0 16px 0',
              color: '#1a1a1a',
            }}
          >
            {title}
          </h2>
          <div
            style={{
              fontSize: '15px',
              lineHeight: '1.6',
              color: '#333',
              whiteSpace: 'pre-wrap',
            }}
          >
            {messageText}
          </div>
        </div>
      </div>
    </div>
  );
}