import React, { useEffect, useState, useRef } from "react";
import { createPortal } from "react-dom";
import { gvUser } from "@core/state.js";
import { checkRecentUnlocks } from "@wrappers/ioGamification.jsx";
import { AchievementCelebration } from "./AchievementCelebration.jsx";
import { t } from "@shared/translations.js";

/**
 * Global component that checks for recent achievement unlocks and displays celebrations
 * Renders the full-screen celebration overlay within the mobile sim container (homebaseFeedPage)
 * Queues multiple unlocks so they display one at a time
 */
export function GamificationUnlockNotifier() {
    console.log("entered function GamificationUnlockNotifier");
    const [currentUnlock, setCurrentUnlock] = useState(null);
    const [unlockQueue, setUnlockQueue] = useState([]);
    const [checkedIds, setCheckedIds] = useState(new Set());
    const [container, setContainer] = useState(null);
    const memberReferral = gvUser?.memberreferral;
    const processingRef = useRef(false);

    // Find the mobile sim container (homebaseFeedPage)
    useEffect(() => {
        const findContainer = () => {
            const feedPage = document.getElementById("homebaseFeedPage");
            if (feedPage) {
                setContainer(feedPage);
            } else {
                setTimeout(findContainer, 100);
            }
        };
        findContainer();
    }, []);

    // Poll for new unlocks
    useEffect(() => {
        if (!memberReferral) return;

        const interval = setInterval(async () => {
            try {
                const unlocks = await checkRecentUnlocks(memberReferral, 30);
                if (unlocks && unlocks.length > 0) {
                    // Collect all new unlocks we haven't shown yet
                    const newUnlocks = unlocks.filter(u => !checkedIds.has(u.achievementId));
                    if (newUnlocks.length > 0) {
                        // Mark all as checked immediately to avoid re-queuing
                        setCheckedIds(prev => {
                            const next = new Set(prev);
                            newUnlocks.forEach(u => next.add(u.achievementId));
                            return next;
                        });
                        // Add to queue
                        setUnlockQueue(prev => [...prev, ...newUnlocks]);
                    }
                }
            } catch (err) {
                // Silently fail - don't spam console
            }
        }, 5000);

        return () => clearInterval(interval);
    }, [memberReferral, checkedIds]);

    // Process the queue: show next unlock when current one closes
    useEffect(() => {
        if (!currentUnlock && unlockQueue.length > 0 && !processingRef.current) {
            processingRef.current = true;
            const [next, ...rest] = unlockQueue;
            setUnlockQueue(rest);
            // Small delay between celebrations if queued
            setTimeout(() => {
                setCurrentUnlock(next);
                processingRef.current = false;
            }, currentUnlock === null ? 0 : 600);
        }
    }, [currentUnlock, unlockQueue]);

    const handleClose = () => {
        setCurrentUnlock(null);
        // Dispatch event to refresh achievements page if it's open
        if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("achievementsUpdated"));
        }
    };

    if (!container || !currentUnlock) return null;

    // Render celebration inside the mobile sim container using portal
    return createPortal(
        <AchievementCelebration achievement={currentUnlock} onClose={handleClose} />,
        container
    );
}

/**
 * Mount the unlock notifier component
 * This will be rendered within HomeBaseReactRoot
 */
export function GamificationUnlockNotifierComponent() {
    return <GamificationUnlockNotifier />;
}
