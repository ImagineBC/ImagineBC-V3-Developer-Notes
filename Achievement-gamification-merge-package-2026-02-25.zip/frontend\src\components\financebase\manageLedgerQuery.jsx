/**
 * Em2 Ledger Query Tool
 * Comprehensive financial ledger query interface for CPA-level analysis
 * Features: Hybrid query builder, filters, aggregations, exports, saved queries
 */

import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { gvUser } from "@core/state.js";
import { t } from "@shared/translations.js";
import { registerFunction } from "@core/state.js";
import { showToastReact } from "@react/toast.jsx";
import { processGamificationEvent } from "@wrappers/ioGamification.jsx";
import {
  ioLedgerQueryExecute,
  ioLedgerQueryGetAccountCodes,
  ioLedgerQueryGetTransactionTypes,
  ioLedgerQueryGetPointTypes,
  ioLedgerQueryListSavedQueries,
  ioLedgerQuerySaveQuery,
  ioLedgerQueryUpdateQuery,
  ioLedgerQueryDeleteQuery,
  ioLedgerQueryGetWalletBalanceHistory,
  ioLedgerQueryQueueExport,
  ioLedgerQueryGetExportStatus,
  ioLedgerQueryListExports,
  ioLedgerQueryDownloadExport,
} from "@wrappers/ioLedgerQuery.jsx";
import { formatLedgerAmount } from "@utils/formatting.js";

// ============================================================================
// ENTRY POINT
// ============================================================================

export function runLedgerQuery() {
  console.log("👉 Entering FinanceBase: Em2 Ledger Query Tool");

  // CRITICAL: Project portal uses window.newWorkspaceRoot, fallback to window.workspaceRoot
  let workspaceRoot = null;
  if (window.newWorkspaceRoot && typeof window.newWorkspaceRoot.render === 'function') {
    workspaceRoot = window.newWorkspaceRoot;
  } else if (window.workspaceRoot && typeof window.workspaceRoot.render === 'function') {
    workspaceRoot = window.workspaceRoot;
  } else {
    console.error("❌ No valid workspace React root found");
    return;
  }

  workspaceRoot.render(<LedgerQueryPage />);
}

registerFunction("runLedgerQuery", runLedgerQuery);

// Also set on window as fallback (in case workspaceIndex hasn't loaded yet)
if (typeof window !== "undefined") {
  window.runLedgerQuery = runLedgerQuery;
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

function LedgerQueryPage() {
  // Query mode: 'simple' or 'advanced'
  const [queryMode, setQueryMode] = useState("simple");
  
  // Helper function to get today's date in YYYY-MM-DD format
  const getTodayDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  // Filters - default to today's date for both start and end
  const [filters, setFilters] = useState({
    startDate: getTodayDate(),
    endDate: getTodayDate(),
    accountNumber: "",
    txType: "",
    txSubtype: "",
    pointType: "",
    referralCode: "",
    counterpartyCode: "",
    channelReferral: "",
    txId: "",
    sourceSystem: "",
    isTest: null,
    minAmount: "",
    maxAmount: "",
    metadata: {},
  });

  // Aggregations
  const [aggregations, setAggregations] = useState({});
  const [grouping, setGrouping] = useState([]);
  
  // Display options
  const [selectedColumns, setSelectedColumns] = useState([]);
  const [sortBy, setSortBy] = useState("transaction_date");
  const [sortDirection, setSortDirection] = useState("DESC");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(100);

  // Data state
  const [results, setResults] = useState([]);
  const [totalCount, setTotalCount] = useState(null);
  const [loading, setLoading] = useState(false);
  const [executionTime, setExecutionTime] = useState(null);
  const [error, setError] = useState(null);

  // Reference data
  const [accountCodes, setAccountCodes] = useState([]);
  const [transactionTypes, setTransactionTypes] = useState([]);
  const [pointTypes, setPointTypes] = useState([]);

  // Saved queries
  const [savedQueries, setSavedQueries] = useState([]);
  const [showSavedQueries, setShowSavedQueries] = useState(false);

  // UI state
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showColumnManager, setShowColumnManager] = useState(false);
  
  // Balance history state
  const [selectedRow, setSelectedRow] = useState(null);
  const [balanceHistory, setBalanceHistory] = useState(null);
  const [loadingBalance, setLoadingBalance] = useState(false);
  const [showBalanceModal, setShowBalanceModal] = useState(false);

  // Export state
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportScope, setExportScope] = useState("current_page");
  const [activeExports, setActiveExports] = useState(new Map()); // Map of exportId -> status
  const [recentExports, setRecentExports] = useState([]);
  const [showExportsList, setShowExportsList] = useState(false);

  // Track if auto-execution has been done
  const hasAutoExecuted = useRef(false);
  // Track if query is currently executing to prevent concurrent calls
  const isExecutingRef = useRef(false);
  // Track pending timeout to cancel if needed
  const autoExecuteTimeoutRef = useRef(null);

  // Load reference data on mount
  useEffect(() => {
    console.log("entered function LedgerQueryPage");
    loadReferenceData();
    loadSavedQueries();

    // Fire gamification event for ledger opened
    const memberReferral = gvUser?.memberreferral;
    if (memberReferral) {
      processGamificationEvent("LEDGER_OPENED", memberReferral).catch(() => {});
    }
  }, []);

  // Auto-execute query once on mount after reference data is loaded
  useEffect(() => {
    // CRITICAL: Guard against multiple executions - check ref FIRST before any operations
    if (hasAutoExecuted.current) {
      return;
    }
    
    // Check if dates are available (they should be from initial state)
    if (!filters.startDate || !filters.endDate) {
      return;
    }
    
    // Atomic check-and-set: Mark as executed IMMEDIATELY to claim execution rights
    // This prevents React Strict Mode double execution from causing issues
    hasAutoExecuted.current = true;
    
    // Clear any existing timeout (safety check for React Strict Mode)
    if (autoExecuteTimeoutRef.current) {
      clearTimeout(autoExecuteTimeoutRef.current);
      autoExecuteTimeoutRef.current = null;
    }
    
    // Set up timeout with reference tracking
    autoExecuteTimeoutRef.current = setTimeout(() => {
      // Clear the timeout ref immediately
      autoExecuteTimeoutRef.current = null;
      
      // MULTIPLE safety checks before execution - defense in depth
      if (isExecutingRef.current) {
        console.warn("⚠️ Auto-execute: Query already executing, aborting duplicate");
        return;
      }
      
      // Double-check the execution flag
      if (!hasAutoExecuted.current) {
        console.warn("⚠️ Auto-execute: Execution cancelled, aborting");
        return;
      }
      
      // All checks passed - execute query
      executeQuery();
    }, 300);
    
    // Cleanup function to cancel timeout on unmount or re-render
    return () => {
      if (autoExecuteTimeoutRef.current) {
        clearTimeout(autoExecuteTimeoutRef.current);
        autoExecuteTimeoutRef.current = null;
      }
    };
    // Only run once on mount - dates are set in initial state
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadReferenceData = async () => {
    try {
      const [accounts, txTypes, ptTypes] = await Promise.all([
        ioLedgerQueryGetAccountCodes(),
        ioLedgerQueryGetTransactionTypes(),
        ioLedgerQueryGetPointTypes(),
      ]);

      if (accounts?.success) setAccountCodes(accounts.data || []);
      if (txTypes?.success) setTransactionTypes(txTypes.data || []);
      if (ptTypes?.success) setPointTypes(ptTypes.data || []);
    } catch (err) {
      console.error("Error loading reference data:", err);
    }
  };

  const loadSavedQueries = async () => {
    try {
      const result = await ioLedgerQueryListSavedQueries();
      if (result?.success) {
        setSavedQueries(result.data || []);
      }
    } catch (err) {
      console.error("Error loading saved queries:", err);
    }
  };

  const executeQuery = async () => {
    // STRICT guard: Prevent concurrent executions - check ref FIRST
    if (isExecutingRef.current) {
      console.warn("⚠️ executeQuery: Already executing, ignoring duplicate call");
      return;
    }
    
    // Also check loading state as secondary guard
    if (loading) {
      console.warn("⚠️ executeQuery: Already loading, ignoring duplicate call");
      return;
    }

    // Validate date range
    if (!filters.startDate || !filters.endDate) {
      showToastReact("Date range is required", "error");
      return;
    }

    // Set execution flag IMMEDIATELY to block any concurrent calls
    isExecutingRef.current = true;
    setLoading(true);
    setError(null);

    try {
      // Clean filters: remove empty strings, undefined values, and empty objects
      // Note: null is a valid value for isTest (means "all"), so we preserve it
      const cleanedFilters = {};
      Object.keys(filters).forEach((key) => {
        const value = filters[key];
        // Keep date values (they'll be converted to ISO strings)
        if (key === "startDate" || key === "endDate") {
          if (value) {
            cleanedFilters[key] = value;
          }
        }
        // Keep isTest values (null, true, or false are all valid)
        else if (key === "isTest" && (value === null || value === true || value === false)) {
          cleanedFilters[key] = value;
        }
        // Skip undefined, empty strings, and empty objects (but keep null for other fields that might use it)
        else if (value !== undefined && value !== "" && 
                 !(typeof value === "object" && value !== null && Object.keys(value).length === 0)) {
          cleanedFilters[key] = value;
        }
      });

      // Convert dates to ISO strings
      // CRITICAL: If startDate and endDate are the same day, set endDate to start of next day
      // This ensures we capture all transactions for that day (since backend uses < endDate)
      
      // Parse dates as UTC to avoid timezone issues (YYYY-MM-DD format)
      const parseDateAsUTC = (dateStr) => {
        const [year, month, day] = dateStr.split('-').map(Number);
        return new Date(Date.UTC(year, month - 1, day, 0, 0, 0, 0));
      };
      
      const startDateObj = parseDateAsUTC(filters.startDate);
      const endDateObj = parseDateAsUTC(filters.endDate);
      
      // Check if both dates are the same day
      const startDateStr = filters.startDate;
      const endDateStr = filters.endDate;
      
      let endDateISO;
      if (startDateStr === endDateStr) {
        // Same day: set endDate to start of next day (in UTC) to include all of today
        const nextDay = new Date(endDateObj);
        nextDay.setUTCDate(nextDay.getUTCDate() + 1);
        endDateISO = nextDay.toISOString();
      } else {
        // Different days: use the end date at start of day (already set by parseDateAsUTC)
        // But add 1 day to make it exclusive (since backend uses < endDate)
        const exclusiveEnd = new Date(endDateObj);
        exclusiveEnd.setUTCDate(exclusiveEnd.getUTCDate() + 1);
        endDateISO = exclusiveEnd.toISOString();
      }
      
      const startDateISO = startDateObj.toISOString();

      const queryRequest = {
        filters: {
          ...cleanedFilters,
          startDate: startDateISO,
          endDate: endDateISO,
        },
        aggregations: Object.keys(aggregations).length > 0 ? aggregations : null,
        grouping: grouping.length > 0 ? grouping : null,
        columns: selectedColumns.length > 0 ? selectedColumns : null,
        sortBy,
        sortDirection,
        page,
        pageSize,
      };

      const result = await ioLedgerQueryExecute(queryRequest);

      if (result?.success) {
        // Ensure data is an array - handle various response formats AGGRESSIVELY
        let dataArray = [];
        
        console.log("📊 RAW API Response:", {
          success: result.success,
          resultData: result.data,
          resultDataType: typeof result.data,
          resultDataIsArray: Array.isArray(result.data),
          resultKeys: result.data && typeof result.data === 'object' && !Array.isArray(result.data) ? Object.keys(result.data) : null,
          resultDataLength: Array.isArray(result.data) ? result.data.length : null,
          resultDataFirstElement: Array.isArray(result.data) && result.data.length > 0 ? result.data[0] : null,
          resultDataFirstElementKeys: Array.isArray(result.data) && result.data.length > 0 && typeof result.data[0] === 'object' ? Object.keys(result.data[0]) : null,
          fullResult: result,
          fullResultStringified: JSON.stringify(result, null, 2)
        });
        
        if (Array.isArray(result.data)) {
          dataArray = result.data;
        } else if (result.data && typeof result.data === 'object' && result.data !== null) {
          // Try multiple ways to extract the array
          if (Array.isArray(result.data.rows)) {
            dataArray = result.data.rows;
          } else if (Array.isArray(result.data.data)) {
            dataArray = result.data.data;
          } else if (Array.isArray(result.data.items)) {
            dataArray = result.data.items;
          } else if (Array.isArray(result.data.results)) {
            dataArray = result.data.results;
          } else if (Array.isArray(result.data.values)) {
            dataArray = result.data.values;
          } else {
            // If it's a single object, wrap it in an array
            dataArray = [result.data];
          }
        } else if (result.data !== null && result.data !== undefined) {
          // Even if it's a primitive, wrap it
          dataArray = [result.data];
        }
        
        // Ensure every element in the array is properly formatted
        dataArray = dataArray.map((item, idx) => {
          // If item is already an object/array, use it as-is
          if (item !== null && item !== undefined) {
            // Log each item to debug empty objects
            if (typeof item === 'object' && !Array.isArray(item)) {
              const keys = Object.keys(item);
              if (keys.length === 0) {
                console.error(`❌ Row ${idx} is an empty object! Backend serialization issue.`);
              } else {
                console.log(`✅ Row ${idx} has ${keys.length} keys:`, keys.slice(0, 5));
              }
            }
            return item;
          }
          // Otherwise, wrap it
          return { value: item, index: idx };
        });
        
        console.log("📊 Processed Query result:", {
          success: result.success,
          dataLength: dataArray.length,
          totalCount: result.totalCount,
          rawData: result.data,
          processedData: dataArray,
          firstRow: dataArray[0],
          firstRowType: typeof dataArray[0],
          firstRowIsArray: Array.isArray(dataArray[0]),
          firstRowKeys: dataArray[0] && typeof dataArray[0] === 'object' ? Object.keys(dataArray[0]) : null,
          dataType: typeof result.data,
          isArray: Array.isArray(result.data),
        });
        
        // Force state update even if array is empty to trigger re-render
        setResults(dataArray);
        setTotalCount(result.totalCount ?? null);
        setExecutionTime(result.executionTimeMs ?? null);
        
        // Additional logging to debug
        if (result.totalCount > 0 && dataArray.length === 0) {
          console.error("❌ Data mismatch: totalCount > 0 but dataArray is empty", {
            result,
            dataArray
          });
        }
      } else {
        setError(result?.error || "Query failed");
        showToastReact(result?.error || "Query failed", "error");
      }
    } catch (err) {
      const errorMsg = err.message || "Error executing query";
      setError(errorMsg);
      showToastReact(errorMsg, "error");
    } finally {
      setLoading(false);
      isExecutingRef.current = false;
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleSaveQuery = async () => {
    const name = prompt("Enter query name:");
    if (!name) return;

    const category = prompt("Enter category (optional):") || null;

    const queryData = {
      name,
      category,
      queryJson: JSON.stringify({
        filters,
        aggregations,
        grouping,
        selectedColumns,
        sortBy,
        sortDirection,
      }),
      isShared: false,
    };

    try {
      const result = await ioLedgerQuerySaveQuery(queryData);
      if (result?.success) {
        showToastReact("Query saved successfully", "success");
        loadSavedQueries();
      } else {
        showToastReact(result?.error || "Failed to save query", "error");
      }
    } catch (err) {
      showToastReact("Error saving query", "error");
    }
  };

  const handleLoadQuery = (savedQuery) => {
    try {
      const queryJson = JSON.parse(savedQuery.queryJson);
      if (queryJson.filters) setFilters(queryJson.filters);
      if (queryJson.aggregations) setAggregations(queryJson.aggregations);
      if (queryJson.grouping) setGrouping(queryJson.grouping);
      if (queryJson.selectedColumns) setSelectedColumns(queryJson.selectedColumns);
      if (queryJson.sortBy) setSortBy(queryJson.sortBy);
      if (queryJson.sortDirection) setSortDirection(queryJson.sortDirection);
      setShowSavedQueries(false);
      showToastReact("Query loaded", "success");
    } catch (err) {
      showToastReact("Error loading query", "error");
    }
  };

  const handleRowClick = async (row) => {
    const referralCode = row.referral_code || row.referralCode;
    const txId = row.tx_id || row.txId;
    const isTest = row.is_test !== undefined ? row.is_test : filters.isTest === true;

    if (!referralCode || !txId) {
      showToastReact("Row missing referral_code or tx_id", "error");
      return;
    }

    setSelectedRow(row);
    setLoadingBalance(true);
    setShowBalanceModal(true);

    try {
      const result = await ioLedgerQueryGetWalletBalanceHistory(referralCode, txId, isTest);
      if (result?.success) {
        setBalanceHistory(result.data || []);
      } else {
        setBalanceHistory([]);
        showToastReact(result?.error || "No balance history found for this transaction", "info");
      }
    } catch (err) {
      console.error("Error fetching balance history:", err);
      setBalanceHistory([]);
      showToastReact("Error fetching balance history", "error");
    } finally {
      setLoadingBalance(false);
    }
  };

  // Load recent exports on mount
  useEffect(() => {
    loadRecentExports();
  }, []);

  // Poll active exports
  useEffect(() => {
    if (activeExports.size === 0) return;

    const pollInterval = setInterval(async () => {
      const exportIds = Array.from(activeExports.keys());
      for (const exportId of exportIds) {
        try {
          const status = await ioLedgerQueryGetExportStatus(exportId);
          if (status?.success && status?.data) {
            const exportData = status.data;
            if (exportData.status === "COMPLETED") {
              setActiveExports(prev => {
                const next = new Map(prev);
                next.delete(exportId);
                return next;
              });
              showToastReact("Export completed! Click to download.", "success");
              loadRecentExports();
            } else if (exportData.status === "FAILED") {
              setActiveExports(prev => {
                const next = new Map(prev);
                next.delete(exportId);
                return next;
              });
              showToastReact(`Export failed: ${exportData.errorMessage || "Unknown error"}`, "error");
              loadRecentExports();
            }
          }
        } catch (err) {
          console.error(`Error polling export ${exportId}:`, err);
        }
      }
    }, 3000); // Poll every 3 seconds

    return () => clearInterval(pollInterval);
  }, [activeExports]);

  const loadRecentExports = async () => {
    try {
      const result = await ioLedgerQueryListExports(20);
      if (result?.success && result?.data) {
        setRecentExports(result.data);
      }
    } catch (err) {
      console.error("Error loading recent exports:", err);
    }
  };

  const handleQueueExport = async () => {
    if (results.length === 0 && exportScope === "current_page") {
      showToastReact("No data to export", "error");
      return;
    }

    try {
      // Build query JSON from current state
      const queryJson = JSON.stringify({
        filters,
        aggregations: Object.keys(aggregations).length > 0 ? aggregations : null,
        grouping: grouping.length > 0 ? grouping : null,
        columns: selectedColumns.length > 0 ? selectedColumns : null,
        sortBy,
        sortDirection,
        page: exportScope === "current_page" ? page : null,
        pageSize: exportScope === "current_page" ? pageSize : null,
      });

      const result = await ioLedgerQueryQueueExport(queryJson, exportScope);
      
      if (result?.success) {
        const exportId = result.exportId;
        setActiveExports(prev => new Map(prev).set(exportId, "QUEUED"));
        setShowExportModal(false);
        showToastReact(
          exportScope === "all_results" 
            ? "Export queued. You'll be notified when it's ready."
            : "Export queued. You'll be notified when it's ready.",
          "success"
        );
        loadRecentExports();
      } else {
        showToastReact(result?.error || "Failed to queue export", "error");
      }
    } catch (err) {
      console.error("Error queueing export:", err);
      showToastReact("Error queueing export", "error");
    }
  };

  const handleDownloadExport = async (exportId) => {
    try {
      await ioLedgerQueryDownloadExport(exportId);
      showToastReact("Download started", "success");
    } catch (err) {
      console.error("Error downloading export:", err);
      showToastReact("Error downloading export", "error");
    }
  };

  // Available columns
  const availableColumns = [
    "id", "tx_id", "referral_code", "counterparty_code", "channel_referral",
    "tx_type", "posting_code", "tx_subtype", "point_type", "amount", "gross_amount", "net_amount",
    "tax_amount", "fee_amount", "vendor_fee_amount", "fx_amount", "encumbered_delta",
    "transaction_date", "metadata", "source_system", "is_test", "created_at",
    "account_number", "tx_description", "entry_type"
  ];

  return (
    <div style={{ 
      height: "100vh", 
      display: "flex", 
      flexDirection: "column", 
      overflow: "hidden",
      backgroundColor: "#f5f5f5"
    }}>
      {/* Header */}
      <div style={{ 
        padding: "20px 24px", 
        backgroundColor: "#fff", 
        borderBottom: "1px solid #e5e5e5",
        flexShrink: 0
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <h1 style={{ fontSize: "24px", fontWeight: 600, margin: 0, marginBottom: "4px" }}>
              Em2 Ledger Query Tool
            </h1>
            <p style={{ color: "#666", fontSize: "14px", margin: 0 }}>
              Comprehensive financial ledger query interface for CPA-level analysis
            </p>
          </div>
          <div style={{ display: "flex", gap: "10px" }}>
            <button
              onClick={() => setQueryMode("simple")}
              style={{
                padding: "8px 16px",
                backgroundColor: queryMode === "simple" ? "#F59E0B" : "#e5e5e5",
                color: queryMode === "simple" ? "#fff" : "#333",
                border: "none",
                borderRadius: "4px",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              Simple Mode
            </button>
            <button
              onClick={() => setQueryMode("advanced")}
              style={{
                padding: "8px 16px",
                backgroundColor: queryMode === "advanced" ? "#F59E0B" : "#e5e5e5",
                color: queryMode === "advanced" ? "#fff" : "#333",
                border: "none",
                borderRadius: "4px",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              Advanced Mode
            </button>
            <button
              onClick={() => setShowSavedQueries(!showSavedQueries)}
              style={{
                padding: "8px 16px",
                backgroundColor: "#4CAF50",
                color: "#fff",
                border: "none",
                borderRadius: "4px",
                cursor: "pointer",
                fontSize: "14px",
              }}
            >
              Saved Queries
            </button>
          </div>
        </div>
      </div>

      {/* Two-Panel Layout: Left (Filters) and Right (Results) */}
      <div style={{ 
        display: "flex", 
        flex: 1, 
        overflow: "hidden",
        gap: "0"
      }}>
        {/* LEFT PANEL: Filters */}
        <div style={{
          width: "400px",
          backgroundColor: "#fff",
          borderRight: "1px solid #e5e5e5",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden"
        }}>
          {/* Saved Queries Panel */}
          {showSavedQueries && (
            <div
              style={{
                padding: "15px",
                backgroundColor: "#f9fafb",
                borderBottom: "1px solid #e5e5e5",
                maxHeight: "200px",
                overflowY: "auto"
              }}
            >
              <h3 style={{ marginBottom: "10px", fontSize: "16px" }}>Saved Queries</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
                {savedQueries.map((sq) => (
                  <div
                    key={sq.id}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      padding: "8px",
                      backgroundColor: "#fff",
                      borderRadius: "4px",
                    }}
                  >
                    <span style={{ fontSize: "14px" }}>{sq.name}</span>
                    <button
                      onClick={() => handleLoadQuery(sq)}
                      style={{
                        padding: "4px 8px",
                        backgroundColor: "#F59E0B",
                        color: "#fff",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer",
                        fontSize: "12px",
                      }}
                    >
                      Load
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Query Builder - Scrollable */}
          <div
            style={{
              padding: "20px",
              overflowY: "auto",
              flex: 1
            }}
          >
            <h2 style={{ marginBottom: "15px", fontSize: "18px" }}>Query Filters</h2>
        <h2 style={{ marginBottom: "15px" }}>Query Filters</h2>

        {/* Date Range - Required */}
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: 600 }}>
            Date Range (Required) *
          </label>
          <div style={{ display: "flex", gap: "10px" }}>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => handleFilterChange("startDate", e.target.value)}
              style={{
                padding: "8px",
                border: "1px solid #e5e5e5",
                borderRadius: "4px",
                flex: 1,
              }}
            />
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => handleFilterChange("endDate", e.target.value)}
              style={{
                padding: "8px",
                border: "1px solid #e5e5e5",
                borderRadius: "4px",
                flex: 1,
              }}
            />
          </div>
        </div>

        {/* Basic Filters */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "15px", marginBottom: "15px" }}>
          <div>
            <label style={{ display: "block", marginBottom: "5px" }}>Account Number</label>
            <select
              value={filters.accountNumber}
              onChange={(e) => handleFilterChange("accountNumber", e.target.value)}
              style={{
                width: "100%",
                padding: "8px",
                border: "1px solid #e5e5e5",
                borderRadius: "4px",
              }}
            >
              <option value="">All Accounts</option>
              {accountCodes.map((ac) => (
                <option key={ac.accountNumber} value={ac.accountNumber}>
                  {ac.accountNumber} - {ac.accountName}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ display: "block", marginBottom: "5px" }}>Transaction Type</label>
            <select
              value={filters.txType}
              onChange={(e) => handleFilterChange("txType", e.target.value)}
              style={{
                width: "100%",
                padding: "8px",
                border: "1px solid #e5e5e5",
                borderRadius: "4px",
              }}
            >
              <option value="">All Types</option>
              {transactionTypes.map((tt) => (
                <option key={tt} value={tt}>
                  {tt}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ display: "block", marginBottom: "5px" }}>Point Type</label>
            <select
              value={filters.pointType}
              onChange={(e) => handleFilterChange("pointType", e.target.value)}
              style={{
                width: "100%",
                padding: "8px",
                border: "1px solid #e5e5e5",
                borderRadius: "4px",
              }}
            >
              <option value="">All Types</option>
              {pointTypes.map((pt) => (
                <option key={pt} value={pt}>
                  {pt}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ display: "block", marginBottom: "5px" }}>Is Test</label>
            <select
              value={filters.isTest === null ? "" : filters.isTest ? "true" : "false"}
              onChange={(e) =>
                handleFilterChange("isTest", e.target.value === "" ? null : e.target.value === "true")
              }
              style={{
                width: "100%",
                padding: "8px",
                border: "1px solid #e5e5e5",
                borderRadius: "4px",
              }}
            >
              <option value="">All</option>
              <option value="false">Production</option>
              <option value="true">Test</option>
            </select>
          </div>
        </div>

        {/* Advanced Filters Toggle */}
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{
            marginBottom: "15px",
            padding: "8px 16px",
            backgroundColor: "#6c757d",
            color: "#fff",
            border: "none",
            borderRadius: "4px",
            cursor: "pointer",
          }}
        >
          {showAdvanced ? "Hide" : "Show"} Advanced Filters
        </button>

        {/* Advanced Filters */}
        {showAdvanced && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "15px", marginBottom: "15px" }}>
            <div>
              <label style={{ display: "block", marginBottom: "5px" }}>Transaction ID</label>
              <input
                type="text"
                value={filters.txId}
                onChange={(e) => handleFilterChange("txId", e.target.value)}
                style={{
                  width: "100%",
                  padding: "8px",
                  border: "1px solid #e5e5e5",
                  borderRadius: "4px",
                }}
              />
            </div>

            <div>
              <label style={{ display: "block", marginBottom: "5px" }}>Referral Code</label>
              <input
                type="text"
                value={filters.referralCode}
                onChange={(e) => handleFilterChange("referralCode", e.target.value)}
                style={{
                  width: "100%",
                  padding: "8px",
                  border: "1px solid #e5e5e5",
                  borderRadius: "4px",
                }}
              />
            </div>

            <div>
              <label style={{ display: "block", marginBottom: "5px" }}>Min Amount</label>
              <input
                type="number"
                value={filters.minAmount}
                onChange={(e) => handleFilterChange("minAmount", e.target.value)}
                style={{
                  width: "100%",
                  padding: "8px",
                  border: "1px solid #e5e5e5",
                  borderRadius: "4px",
                }}
              />
            </div>

            <div>
              <label style={{ display: "block", marginBottom: "5px" }}>Max Amount</label>
              <input
                type="number"
                value={filters.maxAmount}
                onChange={(e) => handleFilterChange("maxAmount", e.target.value)}
                style={{
                  width: "100%",
                  padding: "8px",
                  border: "1px solid #e5e5e5",
                  borderRadius: "4px",
                }}
              />
            </div>
          </div>
        )}

        {/* Execute Button */}
        <div style={{ display: "flex", gap: "10px", marginTop: "20px" }}>
          <button
            onClick={executeQuery}
            disabled={loading || !filters.startDate || !filters.endDate}
            style={{
              padding: "10px 20px",
              backgroundColor: loading ? "#ccc" : "#F59E0B",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: loading ? "not-allowed" : "pointer",
              fontWeight: 600,
            }}
          >
            {loading ? "Executing..." : "Execute Query"}
          </button>
          <button
            onClick={handleSaveQuery}
            style={{
              padding: "10px 20px",
              backgroundColor: "#4CAF50",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Save Query
          </button>
        </div>
        {/* Execute Button */}
          </div>
          {/* End Query Builder - Scrollable */}
        </div>
        {/* End LEFT PANEL */}

        {/* RIGHT PANEL: Results */}
        <div style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          backgroundColor: "#fff"
        }}>
          {/* Results Header with Stats */}
          <div style={{
            padding: "16px 20px",
            borderBottom: "1px solid #e5e5e5",
            backgroundColor: "#f9fafb",
            flexShrink: 0
          }}>
            {executionTime !== null && (
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ color: "#666", fontSize: "14px" }}>
                  Query executed in {executionTime.toFixed(2)}ms
                  {totalCount !== null && ` | Total rows: ${totalCount.toLocaleString()}`}
                  {results.length > 0 && (
                    <span style={{ marginLeft: "10px", color: "#F59E0B", fontWeight: 500 }}>
                      💡 Click any row to view wallet balances at transaction time
                    </span>
                  )}
                </div>
                <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                  {results.length > 0 && (
                    <button
                      onClick={() => setShowExportModal(true)}
                      style={{
                        padding: "8px 16px",
                        backgroundColor: "#2196F3",
                        color: "#fff",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer",
                        fontSize: "14px",
                      }}
                    >
                      {t("ledger_export_csv")}
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setShowExportsList(!showExportsList);
                      if (!showExportsList) {
                        loadRecentExports();
                      }
                    }}
                    style={{
                      padding: "8px 16px",
                      backgroundColor: showExportsList ? "#4CAF50" : "#6c757d",
                      color: "#fff",
                      border: "none",
                      borderRadius: "4px",
                      cursor: "pointer",
                      fontSize: "14px",
                    }}
                  >
                    {t("ledger_recent_exports")}
                    {activeExports.size > 0 && (
                      <span style={{ marginLeft: "6px", backgroundColor: "#fff", color: "#4CAF50", borderRadius: "10px", padding: "2px 6px", fontSize: "11px" }}>
                        {activeExports.size}
                      </span>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Results Content - Scrollable */}
          <div style={{
            flex: 1,
            overflow: "hidden", // Prevent this level from scrolling - let inner table container handle it
            padding: "20px",
            display: "flex",
            flexDirection: "column"
          }}>
                  {/* Error Display */}
            {error && (
              <div
                style={{
                  padding: "15px",
                  backgroundColor: "#fee",
                  color: "#c00",
                  borderRadius: "8px",
                  marginBottom: "20px",
                }}
              >
                Error: {error}
              </div>
            )}

            {/* Loading Spinner */}
            {loading && (
        <div
          style={{
            padding: "40px",
            textAlign: "center",
            backgroundColor: "#fff",
            borderRadius: "8px",
            border: "1px solid #e5e5e5",
            marginBottom: "20px",
          }}
        >
          <div
            style={{
              display: "inline-block",
              width: "40px",
              height: "40px",
              border: "4px solid #f3f3f3",
              borderTop: "4px solid #F59E0B",
              borderRadius: "50%",
              animation: "spin 1s linear infinite",
            }}
          />
          <div
            style={{
              marginTop: "16px",
              color: "#666",
              fontSize: "16px",
              fontWeight: 500,
            }}
          >
            Loading ledger data...
          </div>
          <style>{`
            @keyframes spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
          `}</style>
            </div>
            )}

            {/* Results Table - Always show if we have results or totalCount */}
            {!loading && (
              (results && results.length > 0) || (totalCount !== null && totalCount > 0)
            ) && (() => {
              // Em2: Convert database column names to readable display names
              const getDisplayColumnName = (dbColumnName) => {
                const columnNameMap = {
                  'id': 'ID',
                  'tx_id': 'Transaction ID',
                  'referral_code': 'Referral Code',
                  'counterparty_code': 'Counterparty Code',
                  'channel_referral': 'Channel Referral',
                  'tx_type': 'Transaction Type',
                  'posting_code': 'Posting Code',
                  'tx_subtype': 'Transaction Subtype',
                  'point_type': 'Point Type',
                  'amount': 'Amount',
                  'gross_amount': 'Gross Amount',
                  'net_amount': 'Net Amount',
                  'tax_amount': 'Tax Amount',
                  'fee_amount': 'Fee Amount',
                  'vendor_fee_amount': 'Vendor Fee Amount',
                  'fx_amount': 'FX Amount',
                  'encumbered_delta': 'Encumbered Delta',
                  'transaction_date': 'Transaction Date',
                  'metadata': 'Metadata',
                  'source_system': 'Source System',
                  'is_test': 'Is Test',
                  'created_at': 'Created At',
                  'account_number': 'Account Number',
                  'tx_description': 'Description',
                  'entry_type': 'Entry Type'
                };
                
                // Return mapped name or convert snake_case to Title Case
                if (columnNameMap[dbColumnName]) {
                  return columnNameMap[dbColumnName];
                }
                
                // Fallback: Convert snake_case to Title Case
                return dbColumnName
                  .split('_')
                  .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                  .join(' ');
              };
              
              // Define optimal column order for financial ledger data (Em2's accounting expertise)
              // Priority: Chronological → Identity → Account → Type → Description → Financial Impact → Context → Technical
              // Description is critical - understanding WHAT happened is essential before seeing amounts
              const ledgerSchemaColumns = [
                // 1. TIME-BASED (Most critical for period analysis and chronological review)
                'transaction_date',
                
                // 2. IDENTIFICATION (Key identifiers for reference and tracking)
                'tx_id',
                
                // 3. ACCOUNT & ENTITY (Essential for GL reconciliation and account analysis)
                'account_number',
                
                // 4. TRANSACTION CLASSIFICATION (What type of transaction occurred)
                'tx_type',
                'posting_code',        // BO, PI, SCO, etc. (line-level code)
                'tx_subtype',
                'entry_type',          // CREDIT/DEBIT - critical for accounting analysis
                
                // 5. BUSINESS CONTEXT / DESCRIPTION (CRITICAL - What happened? Most important for understanding transaction)
                'tx_description',      // Description is high priority - accountants need to understand the narrative
                
                // 6. FINANCIAL IMPACT - Core Amounts (Most important financial figures, in logical order)
                'gross_amount',        // Total before deductions
                'net_amount',          // Actual amount (most critical for P&L)
                'amount',              // Base amount (legacy/alternative)
                
                // 7. FINANCIAL IMPACT - Breakdown Components (Tax, fees, adjustments)
                'tax_amount',
                'fee_amount',
                'vendor_fee_amount',
                'fx_amount',
                'encumbered_delta',    // Advanced accounting: encumbrance tracking
                
                // 8. POINT SYSTEM (For point-based accounting systems)
                'point_type',
                
                // 9. BUSINESS ATTRIBUTION (Marketing, channel, counterparty tracking)
                'referral_code',
                'counterparty_code',
                'channel_referral',
                
                // 10. DATA QUALITY & SYSTEM (Distinguish test vs production, source tracking)
                'is_test',
                'source_system',
                
                // 11. TECHNICAL METADATA (Least important for business users)
                'created_at',
                'id',                  // Internal DB ID - least important
                'metadata'             // JSON data - least important for initial review
              ];
              
              // Collect ALL columns from ALL rows
              const allColumns = new Set();
              
              if (results && results.length > 0) {
                results.forEach((row, idx) => {
                  console.log(`🔍 Processing row ${idx}:`, {
                    row,
                    type: typeof row,
                    isArray: Array.isArray(row),
                    isObject: row && typeof row === 'object' && !Array.isArray(row),
                    keys: row && typeof row === 'object' && !Array.isArray(row) ? Object.keys(row) : null,
                    keyCount: row && typeof row === 'object' && !Array.isArray(row) ? Object.keys(row).length : 0,
                    rowStringified: JSON.stringify(row)
                  });
                  
                  // Handle arrays - convert to object with index keys
                  if (Array.isArray(row)) {
                    row.forEach((val, i) => allColumns.add(`column_${i}`));
                  }
                  // Handle objects - extract all keys
                  else if (row && typeof row === 'object' && row !== null) {
                    const keys = Object.keys(row);
                    if (keys.length > 0) {
                      keys.forEach((key) => allColumns.add(key));
                      console.log(`  ✅ Added ${keys.length} columns from row ${idx}:`, keys);
                    } else {
                      console.warn(`  ⚠️ Row ${idx} is an empty object!`);
                    }
                  }
                  // Handle primitives - just show as value
                  else if (row !== null && row !== undefined) {
                    allColumns.add('value');
                  }
                });
              }
              
              // CRITICAL FIX: If we have results but no columns detected, use schema columns
              // This handles the case where backend returns empty objects
              if ((results && results.length > 0) && allColumns.size === 0) {
                console.warn("⚠️ No columns detected from data, using ledger schema columns as fallback");
                console.warn("⚠️ Results array:", results);
                console.warn("⚠️ First row:", results[0]);
                console.warn("⚠️ First row type:", typeof results[0]);
                console.warn("⚠️ First row keys:", results[0] && typeof results[0] === 'object' ? Object.keys(results[0]) : 'N/A');
                ledgerSchemaColumns.forEach(col => allColumns.add(col));
              }
              
              // If we still have totalCount but no results, also use schema
              if (totalCount !== null && totalCount > 0 && allColumns.size === 0) {
                console.warn("⚠️ Using ledger schema columns because totalCount > 0 but no columns found");
                ledgerSchemaColumns.forEach(col => allColumns.add(col));
              }
              
              // ALWAYS use schema columns if we have totalCount > 0, even if we found some columns
              // This ensures we show all expected columns
              if (totalCount !== null && totalCount > 0) {
                ledgerSchemaColumns.forEach(col => allColumns.add(col));
              }
              
              // Sort columns: preferred order first, then any others alphabetically
              const columnArray = Array.from(allColumns).sort((a, b) => {
                const aIndex = ledgerSchemaColumns.indexOf(a);
                const bIndex = ledgerSchemaColumns.indexOf(b);
                
                if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
                if (aIndex !== -1) return -1;
                if (bIndex !== -1) return 1;
                return a.localeCompare(b);
              });
              
              console.log("🔍 Table rendering FINAL:", {
                resultsCount: results?.length,
                totalCount,
                allColumns: columnArray,
                firstRow: results?.[0],
                firstRowType: typeof results?.[0],
                firstRowIsArray: Array.isArray(results?.[0]),
                allRows: results
              });
              
              return (
              <>
                {/* WebKit scrollbar styling */}
                <style>{`
                  .ledger-table-scroll::-webkit-scrollbar {
                    height: 12px;
                    width: 12px;
                  }
                  .ledger-table-scroll::-webkit-scrollbar-track {
                    background: #f1f5f9;
                    border-radius: 6px;
                  }
                  .ledger-table-scroll::-webkit-scrollbar-thumb {
                    background: #cbd5e0;
                    border-radius: 6px;
                    border: 2px solid #f1f5f9;
                  }
                  .ledger-table-scroll::-webkit-scrollbar-thumb:hover {
                    background: #94a3b8;
                  }
                `}</style>
                <div
                  className="ledger-table-scroll"
                  style={{
                    backgroundColor: "#fff",
                    borderRadius: "8px",
                    border: "1px solid #e5e5e5",
                    overflowX: "auto",  // Enable horizontal scrolling
                    overflowY: "auto",  // Enable vertical scrolling
                    width: "100%",
                    maxHeight: "calc(100vh - 300px)", // Dynamic height based on viewport
                    position: "relative",
                    // Ensure scrollbar styling is visible (Firefox)
                    scrollbarWidth: "thin",
                    scrollbarColor: "#cbd5e0 #f1f5f9"
                  }}
                >
                {columnArray.length > 0 ? (
                <table style={{ 
                  width: "max-content", // Allow table to expand beyond container width
                  minWidth: "100%",     // At minimum, fill container
                  borderCollapse: "collapse",
                  tableLayout: "auto"
                }}>
                  <thead style={{
                    position: "sticky",
                    top: 0,
                    zIndex: 10,
                    backgroundColor: "#f9fafb"
                  }}>
                    <tr style={{ backgroundColor: "#f9fafb", borderBottom: "2px solid #e5e5e5" }}>
                      {columnArray.map((col) => (
                        <th
                          key={col}
                          style={{
                            padding: "6px 10px", // Reduced padding for Excel-like compact rows
                            textAlign: "left",
                            fontWeight: 600,
                            fontSize: "13px",
                            whiteSpace: "nowrap",
                            backgroundColor: "#f9fafb", // Ensure header background is solid
                            borderBottom: "2px solid #e5e5e5"
                          }}
                        >
                          {getDisplayColumnName(col)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(() => {
                      // CRITICAL: Always try to render rows, even if they appear empty
                      const rowsToRender = results && results.length > 0 ? results : [];
                      
                      console.log("🔍 Rendering table body:", {
                        resultsLength: results?.length,
                        rowsToRenderLength: rowsToRender.length,
                        firstRow: rowsToRender[0],
                        columnArray,
                        totalCount
                      });
                      
                      // CRITICAL: Always render rows if we have totalCount > 0, even if row objects are empty
                      // The backend found the data, so we should display it (even if backend serialization is broken)
                      if (rowsToRender.length === 0) {
                        if (totalCount > 0) {
                          // We have a count but no rows array - this is a backend issue
                          return (
                            <tr>
                              <td colSpan={columnArray.length} style={{ padding: "40px", textAlign: "center", color: "#FF6B6B" }}>
                                ⚠️ Backend returned totalCount={totalCount} but results array is empty. Check backend logs.
                              </td>
                            </tr>
                          );
                        } else {
                          return (
                            <tr>
                              <td colSpan={columnArray.length} style={{ padding: "40px", textAlign: "center", color: "#666" }}>
                                No results found
                              </td>
                            </tr>
                          );
                        }
                      }
                      
                      // Render all rows, even if they're empty objects
                      return rowsToRender.map((row, idx) => {
                        // Extract value based on data type - be VERY aggressive
                        const getValue = (col) => {
                          // Try multiple ways to get the value
                          if (Array.isArray(row)) {
                            const colIndex = parseInt(col.replace('column_', ''));
                            return row[colIndex];
                          } else if (row && typeof row === 'object' && row !== null) {
                            // Try direct property access
                            if (col in row) {
                              return row[col];
                            }
                            // Try case-insensitive match
                            const lowerCol = col.toLowerCase();
                            for (const key in row) {
                              if (key.toLowerCase() === lowerCol) {
                                return row[key];
                              }
                            }
                          } else if (col === 'value') {
                            return row;
                          }
                          return null;
                        };
                        
                        console.log(`🔍 Rendering row ${idx}:`, {
                          row,
                          rowType: typeof row,
                          rowKeys: row && typeof row === 'object' ? Object.keys(row) : null,
                          rowKeyCount: row && typeof row === 'object' ? Object.keys(row).length : 0,
                          rowEntries: row && typeof row === 'object' ? Object.entries(row) : null,
                          rowStringified: JSON.stringify(row)
                        });
                        
                        // If row is empty object but we have schema columns, try to get values anyway
                        const rowKeys = row && typeof row === 'object' && !Array.isArray(row) ? Object.keys(row) : [];
                        if (rowKeys.length === 0 && columnArray.length > 0) {
                          console.warn(`⚠️ Row ${idx} is empty but we have ${columnArray.length} schema columns. Backend likely didn't populate row data correctly.`);
                        }
                      
                      return (
                      <tr
                        key={idx}
                        onClick={() => handleRowClick(row)}
                        style={{
                          borderBottom: "1px solid #e5e5e5",
                          cursor: "pointer",
                          transition: "background-color 0.2s ease",
                          height: "32px" // Excel-like compact row height
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = "#f5f5f5";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = "transparent";
                        }}
                      >
                        {columnArray.map((col) => {
                          const value = getValue(col);
                          
                          // Format values based on column type
                          let displayValue = "";
                          if (value !== null && value !== undefined) {
                            if (typeof value === "object") {
                              displayValue = JSON.stringify(value);
                            } else if (col.includes('amount') || col.includes('delta')) {
                              // Format numeric/currency to exactly 6 decimals (shared with Test Tools / FinanceBase)
                              const numVal = parseFloat(value);
                              if (!isNaN(numVal)) {
                                displayValue = formatLedgerAmount(numVal);
                              } else {
                                displayValue = String(value);
                              }
                            } else if (col === 'transaction_date' || col === 'created_at') {
                              // Format dates
                              try {
                                const dateVal = new Date(value);
                                displayValue = dateVal.toLocaleString('en-US');
                              } catch {
                                displayValue = String(value);
                              }
                            } else if (col === 'is_test' || typeof value === 'boolean') {
                              displayValue = value ? 'Yes' : 'No';
                            } else if (col === 'entry_type') {
                              // Format entry_type with color coding
                              displayValue = String(value);
                            } else {
                              displayValue = String(value);
                            }
                          }
                          
                          // Right-align numeric columns
                          const isNumeric = col.includes('amount') || col.includes('delta') || col === 'id';
                          const alignStyle = isNumeric ? { textAlign: 'right', fontFamily: 'monospace' } : { textAlign: 'left' };
                          
                          // Special styling for entry_type column
                          const isEntryType = col === 'entry_type';
                          const entryTypeStyle = isEntryType ? {
                            fontWeight: displayValue === 'DEBIT' ? 600 : displayValue === 'CREDIT' ? 500 : 400,
                            color: displayValue === 'DEBIT' ? '#c00' : displayValue === 'CREDIT' ? '#060' : '#666'
                          } : {};
                          
                          return (
                          <td
                            key={col}
                            style={{
                              padding: "4px 10px", // Reduced padding for Excel-like compact cells
                              fontSize: "12px", // Slightly smaller font
                              lineHeight: "1.4", // Tighter line height
                              ...alignStyle,
                              ...entryTypeStyle,
                              whiteSpace: "nowrap", // Prevent text wrapping
                              overflow: "hidden",
                              textOverflow: "ellipsis"
                            }}
                          >
                            {displayValue}
                          </td>
                        );
                        })}
                      </tr>
                    );
                    });
                    })()}
                  </tbody>
                </table>
                ) : (
                  // If we have results but no columns, show raw data
                  <div style={{ padding: "20px" }}>
                    <div style={{ fontWeight: 600, marginBottom: "10px" }}>Raw Data (No Columns Detected):</div>
                    <pre style={{ 
                      backgroundColor: "#f5f5f5", 
                      padding: "15px", 
                      borderRadius: "4px",
                      overflow: "auto",
                      fontSize: "12px"
                    }}>
                      {JSON.stringify(results, null, 2)}
                    </pre>
                  </div>
                )}
                </div>
              </>
              );
            })()}
            
            {/* Debug: Show results info if data exists but table doesn't render */}
            {!loading && totalCount !== null && totalCount > 0 && (!results || results.length === 0) && (
              <div style={{ padding: "20px", backgroundColor: "#FFF3CD", borderRadius: "8px", border: "1px solid #FFC107" }}>
                <div style={{ fontWeight: 600, marginBottom: "8px", color: "#856404" }}>⚠️ Data Found But Not Displayed</div>
                <div style={{ color: "#856404" }}>Total count: {totalCount}, but results array is empty or invalid.</div>
                <div style={{ fontSize: "12px", marginTop: "8px", color: "#856404" }}>
                  Check browser console for details. Results state: {JSON.stringify({ 
                    hasResults: !!results, 
                    resultsLength: results?.length, 
                    resultsType: typeof results,
                    isArray: Array.isArray(results)
                  })}
                </div>
              </div>
            )}

            {/* No Results Message */}
            {!loading && results.length === 0 && executionTime !== null && totalCount === null && (
              <div style={{ padding: "40px", textAlign: "center", color: "#666" }}>
                No results found
              </div>
            )}
            
            {/* Data Mismatch Warning */}
            {!loading && results.length === 0 && executionTime !== null && totalCount !== null && totalCount > 0 && (
              <div style={{ padding: "40px", textAlign: "center", color: "#FF6B6B", backgroundColor: "#FFF5F5", borderRadius: "8px", border: "1px solid #FFE5E5" }}>
                <div style={{ fontWeight: 600, marginBottom: "8px" }}>⚠️ Data Mismatch Detected</div>
                <div>Total count: {totalCount}, but no rows returned in data array.</div>
                <div style={{ fontSize: "12px", marginTop: "8px", color: "#999" }}>
                  Check console for details.
                </div>
              </div>
            )}
          </div>
        </div>
        {/* End RIGHT PANEL */}
      </div>
      {/* End Two-Panel Layout */}

      {/* Balance History Modal */}
      {showBalanceModal && (
        <BalanceHistoryModal
          row={selectedRow}
          balanceHistory={balanceHistory}
          loading={loadingBalance}
          onClose={() => {
            setShowBalanceModal(false);
            setSelectedRow(null);
            setBalanceHistory(null);
          }}
        />
      )}

      {/* Export Modal */}
      {showExportModal && (
        <ExportModal
          exportScope={exportScope}
          setExportScope={setExportScope}
          onExport={handleQueueExport}
          onClose={() => setShowExportModal(false)}
          t={t}
        />
      )}

      {/* Recent Exports List */}
      {showExportsList && (
        <RecentExportsList
          exports={recentExports}
          activeExports={activeExports}
          onDownload={handleDownloadExport}
          onClose={() => setShowExportsList(false)}
          onRefresh={loadRecentExports}
          t={t}
        />
      )}
    </div>
  );
}

// ============================================================================
// EXPORT MODAL COMPONENT
// ============================================================================

function ExportModal({ exportScope, setExportScope, onExport, onClose, t }) {
  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        zIndex: 10000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          backgroundColor: "#ffffff",
          borderRadius: "12px",
          boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
          width: "500px",
          padding: "24px",
          display: "flex",
          flexDirection: "column",
          gap: "20px",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ margin: 0, fontSize: "20px", fontWeight: 600 }}>
            {t("ledger_export_title")}
          </h2>
          <button
            onClick={onClose}
            style={{
              background: "transparent",
              border: "none",
              fontSize: "24px",
              cursor: "pointer",
              color: "#666",
            }}
          >
            ×
          </button>
        </div>

        <div>
          <label style={{ display: "block", marginBottom: "10px", fontWeight: 600 }}>
            {t("ledger_export_scope")}
          </label>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <label style={{ display: "flex", alignItems: "center", cursor: "pointer" }}>
              <input
                type="radio"
                value="current_page"
                checked={exportScope === "current_page"}
                onChange={(e) => setExportScope(e.target.value)}
                style={{ marginRight: "8px" }}
              />
              <div>
                <div style={{ fontWeight: 500 }}>
                  {t("ledger_export_current_page")}
                </div>
                <div style={{ fontSize: "12px", color: "#666", marginTop: "2px" }}>
                  {t("ledger_export_current_page_desc")}
                </div>
              </div>
            </label>
            <label style={{ display: "flex", alignItems: "center", cursor: "pointer" }}>
              <input
                type="radio"
                value="all_results"
                checked={exportScope === "all_results"}
                onChange={(e) => setExportScope(e.target.value)}
                style={{ marginRight: "8px" }}
              />
              <div>
                <div style={{ fontWeight: 500 }}>
                  {t("ledger_export_all_results")}
                </div>
                <div style={{ fontSize: "12px", color: "#666", marginTop: "2px" }}>
                  {t("ledger_export_all_results_desc")}
                </div>
              </div>
            </label>
          </div>
        </div>

        <div style={{ display: "flex", gap: "10px", justifyContent: "flex-end" }}>
          <button
            onClick={onClose}
            style={{
              padding: "10px 20px",
              backgroundColor: "#e5e5e5",
              color: "#333",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            {t("ledger_export_cancel")}
          </button>
          <button
            onClick={onExport}
            style={{
              padding: "10px 20px",
              backgroundColor: "#2196F3",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            {t("ledger_export_start")}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// RECENT EXPORTS LIST COMPONENT
// ============================================================================

function RecentExportsList({ exports, activeExports, onDownload, onClose, onRefresh, t }) {
  const formatDate = (dateStr) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleString();
    } catch {
      return dateStr;
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return "N/A";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div
      style={{
        position: "fixed",
        top: "80px",
        right: "20px",
        width: "500px",
        maxHeight: "600px",
        backgroundColor: "#ffffff",
        borderRadius: "12px",
        boxShadow: "0 10px 40px rgba(0, 0, 0, 0.2)",
        zIndex: 9999,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          padding: "16px 20px",
          borderBottom: "1px solid #e5e5e5",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          backgroundColor: "#f9fafb",
        }}
      >
        <h3 style={{ margin: 0, fontSize: "16px", fontWeight: 600 }}>
          {t("ledger_recent_exports")}
        </h3>
        <div style={{ display: "flex", gap: "8px" }}>
          <button
            onClick={onRefresh}
            style={{
              padding: "4px 8px",
              backgroundColor: "#2196F3",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
              fontSize: "12px",
            }}
          >
            {t("ledger_refresh")}
          </button>
          <button
            onClick={onClose}
            style={{
              background: "transparent",
              border: "none",
              fontSize: "20px",
              cursor: "pointer",
              color: "#666",
            }}
          >
            ×
          </button>
        </div>
      </div>

      <div style={{ overflowY: "auto", flex: 1 }}>
        {exports.length === 0 ? (
          <div style={{ padding: "40px", textAlign: "center", color: "#666" }}>
            {t("ledger_no_exports")}
          </div>
        ) : (
          exports.map((exp) => (
            <div
              key={exp.id}
              style={{
                padding: "16px 20px",
                borderBottom: "1px solid #e5e5e5",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 500, marginBottom: "4px" }}>
                  {exp.fileName || `Export #${exp.id}`}
                </div>
                <div style={{ fontSize: "12px", color: "#666" }}>
                  {formatDate(exp.createdAt)} • {exp.exportScope === "all_results" ? "All Results" : "Current Page"}
                  {exp.rowCount && ` • ${exp.rowCount.toLocaleString()} rows`}
                  {exp.fileSize && ` • ${formatFileSize(exp.fileSize)}`}
                </div>
                {exp.status === "PROCESSING" && (
                  <div style={{ fontSize: "12px", color: "#F59E0B", marginTop: "4px" }}>
                    {t("ledger_export_processing")}
                  </div>
                )}
                {exp.status === "QUEUED" && (
                  <div style={{ fontSize: "12px", color: "#2196F3", marginTop: "4px" }}>
                    {t("ledger_export_queued")}
                  </div>
                )}
                {exp.status === "FAILED" && exp.errorMessage && (
                  <div style={{ fontSize: "12px", color: "#c00", marginTop: "4px" }}>
                    {t("ledger_export_failed")}: {exp.errorMessage}
                  </div>
                )}
              </div>
              {exp.status === "COMPLETED" && (
                <button
                  onClick={() => onDownload(exp.id)}
                  style={{
                    padding: "6px 12px",
                    backgroundColor: "#4CAF50",
                    color: "#fff",
                    border: "none",
                    borderRadius: "4px",
                    cursor: "pointer",
                    fontSize: "12px",
                  }}
                >
                  {t("ledger_download")}
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// ============================================================================
// BALANCE HISTORY MODAL COMPONENT
// ============================================================================

function BalanceHistoryModal({ row, balanceHistory, loading, onClose }) {
  if (!row) return null;

  const referralCode = row.referral_code || row.referralCode || "N/A";
  const txId = row.tx_id || row.txId || "N/A";
  const transactionDate = row.transaction_date || row.transactionDate || "N/A";

  // Format point type names for display
  const formatPointType = (pointType) => {
    const mapping = {
      transferable: "Transferable",
      nonTransferable: "Non-Transferable",
      community: "Community",
      special: "Special",
      overflow: "Overflow",
      subscription: "Subscription",
    };
    return mapping[pointType] || pointType;
  };

  // Format currency
  const formatCurrency = (value) => {
    if (value === null || value === undefined) return "$0.00";
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(Number(value));
  };

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        zIndex: 10000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          backgroundColor: "#ffffff",
          borderRadius: "12px",
          boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)",
          width: "600px",
          maxHeight: "80vh",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "20px 24px",
            borderBottom: "1px solid #e5e5e5",
            backgroundColor: "#F59E0B",
            color: "#ffffff",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div>
            <h2 style={{ margin: 0, fontSize: "18px", fontWeight: 600 }}>
              Wallet Balances at Transaction
            </h2>
            <div style={{ fontSize: "12px", marginTop: "4px", opacity: 0.9 }}>
              {referralCode} | TX: {txId.substring(0, 16)}...
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              background: "transparent",
              border: "none",
              color: "#ffffff",
              fontSize: "28px",
              fontWeight: "bold",
              cursor: "pointer",
              padding: "4px 8px",
              minWidth: "32px",
              minHeight: "32px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderRadius: "4px",
              transition: "background 0.2s ease",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = "rgba(255, 255, 255, 0.2)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = "transparent";
            }}
            title="Close"
            type="button"
            aria-label="Close modal"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div
          style={{
            padding: "24px",
            overflowY: "auto",
            flex: 1,
          }}
        >
          {loading ? (
            <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>
              Loading balance history...
            </div>
          ) : balanceHistory && balanceHistory.length > 0 ? (
            <div>
              <div style={{ marginBottom: "20px", color: "#666", fontSize: "14px" }}>
                <strong>Transaction Date:</strong> {new Date(transactionDate).toLocaleString()}
              </div>

              <div
                style={{
                  backgroundColor: "#f9fafb",
                  borderRadius: "8px",
                  border: "1px solid #e5e5e5",
                  overflow: "hidden",
                }}
              >
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#ffffff", borderBottom: "2px solid #e5e5e5" }}>
                      <th
                        style={{
                          padding: "12px",
                          textAlign: "left",
                          fontWeight: 600,
                          fontSize: "14px",
                        }}
                      >
                        Point Type
                      </th>
                      <th
                        style={{
                          padding: "12px",
                          textAlign: "right",
                          fontWeight: 600,
                          fontSize: "14px",
                        }}
                      >
                        Balance
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {balanceHistory.map((balance, idx) => (
                      <tr
                        key={idx}
                        style={{
                          borderBottom: "1px solid #e5e5e5",
                          backgroundColor: idx % 2 === 0 ? "#ffffff" : "#fafafa",
                        }}
                      >
                        <td
                          style={{
                            padding: "12px",
                            fontSize: "14px",
                            fontWeight: 500,
                          }}
                        >
                          {formatPointType(balance.pointType)}
                        </td>
                        <td
                          style={{
                            padding: "12px",
                            fontSize: "14px",
                            textAlign: "right",
                            fontFamily: "monospace",
                            fontWeight: 600,
                            color: Number(balance.balance) >= 0 ? "#2a7a4d" : "#c00",
                          }}
                        >
                          {formatCurrency(balance.balance)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Total */}
              {balanceHistory.length > 0 && (
                <div
                  style={{
                    marginTop: "16px",
                    padding: "12px",
                    backgroundColor: "#f0f9ff",
                    borderRadius: "8px",
                    border: "1px solid #bae6fd",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <span style={{ fontWeight: 600, fontSize: "14px" }}>Total Points:</span>
                  <span
                    style={{
                      fontWeight: 700,
                      fontSize: "16px",
                      fontFamily: "monospace",
                      color: "#0369a1",
                    }}
                  >
                    {formatCurrency(
                      balanceHistory.reduce((sum, b) => sum + Number(b.balance || 0), 0)
                    )}
                  </span>
                </div>
              )}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>
              No balance history found for this transaction.
              <div style={{ fontSize: "12px", marginTop: "8px", color: "#999" }}>
                Balance snapshots are only available for transactions processed after the audit trail feature was enabled.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

