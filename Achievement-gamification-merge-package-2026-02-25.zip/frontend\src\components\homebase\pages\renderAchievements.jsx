import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { gvUser, registerFunction } from "@core/state.js";
import { getMemberAchievements } from "@wrappers/ioGamification.jsx";

import { t } from "@shared/translations.js";
// Listen for achievements updates
if (typeof window !== 'undefined') {
    window.addEventListener('achievementsUpdated', () => {
        // Trigger a reload of achievements data
        const memberReferral = gvUser?.memberreferral;
        if (memberReferral && window.loadAchievements) {
            window.loadAchievements();
        }
    });
}

//-----------------------------------------------------------------------------------------------------------------
//-- Entry point
export async function renderAchievementsPage() {
    try {
        console.log("entered function renderAchievementsPage");

        const host = document.getElementById("homebaseFeedPage");
        if (!host) {
            console.warn("homebaseFeedPage container not found");
            return;
        }

        // Use the router instead of manual rendering
        try {
            const { navigateToPage } = await import("@components/homebase/navigation/NavigationManager.js");
            navigateToPage('achievements', {
                agent: null,
                onBack: null,
                entrySource: 'clubhouse',
                channelInfo: null,
            });
        } catch (err) {
            console.error("renderAchievementsPage: Error navigating to achievements page:", err);
            // Fallback: Use navigation state directly
            try {
                const { navigateTo, getReturnContext } = await import("@components/homebase/navigation/NavigationState.js");
                const currentReturnContext = getReturnContext();

                navigateTo(
                    {
                        type: 'page',
                        id: 'achievements',
                        coordinates: null,
                        context: {
                            agent: null,
                            onBack: null,
                            channelInfo: null,
                        },
                    },
                    {
                        source: currentReturnContext?.source || 'clubhouse',
                        channelInfo: currentReturnContext?.channelInfo || null,
                        modalAgent: null,
                        pageType: 'achievements',
                        updateHistory: true,
                    }
                );
            } catch (err2) {
                console.error("renderAchievementsPage: Error with fallback navigation:", err2);
            }
        }
    } catch (err) {
        console.error("renderAchievementsPage failed:", err);
    }
}

registerFunction("renderAchievementsPage", renderAchievementsPage);

//-----------------------------------------------------------------------------------------------------------------
//-- SVG Progress Ring Component
function ProgressRing({ radius, stroke, progress, color, bgColor = "rgba(255,255,255,0.08)" }) {
    const normalizedRadius = radius - stroke;
    const circumference = normalizedRadius * 2 * Math.PI;
    const strokeDashoffset = circumference - (progress / 100) * circumference;

    return (
        <svg height={radius * 2} width={radius * 2}>
            <circle
                stroke={bgColor}
                fill="transparent"
                strokeWidth={stroke}
                r={normalizedRadius}
                cx={radius}
                cy={radius}
            />
            <circle
                stroke={color}
                fill="transparent"
                strokeWidth={stroke}
                strokeLinecap="round"
                strokeDasharray={`${circumference} ${circumference}`}
                strokeDashoffset={strokeDashoffset}
                r={normalizedRadius}
                cx={radius}
                cy={radius}
                style={{ transition: "stroke-dashoffset 0.6s ease", transform: "rotate(-90deg)", transformOrigin: "50% 50%" }}
            />
        </svg>
    );
}

//-----------------------------------------------------------------------------------------------------------------
//-- Shimmer keyframes (injected once)
const STYLE_ID = "achievements-redesign-styles";
function injectStyles() {
    if (typeof document === 'undefined') return;
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
        @keyframes achievementShimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        @keyframes achievementFadeIn {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulseGlow {
            0%, 100% { box-shadow: 0 0 8px rgba(255,180,0,0.15); }
            50% { box-shadow: 0 0 16px rgba(255,180,0,0.3); }
        }
    `;
    document.head.appendChild(style);
}

//-----------------------------------------------------------------------------------------------------------------
//-- Constants
const PILLARS = [
    { code: "CITIZEN", name: "Citizen", icon: "🏛️", color: "#56AF9B", darkColor: "rgba(86,175,155,0.15)" },
    { code: "EXPLORER", name: "Explorer", icon: "🗺️", color: "#4A90E2", darkColor: "rgba(74,144,226,0.15)" },
    { code: "GAMER", name: "Gamer", icon: "🎮", color: "#E74C3C", darkColor: "rgba(231,76,60,0.15)" },
    { code: "PATRON", name: "Patron", icon: "💰", color: "#F39C12", darkColor: "rgba(243,156,18,0.15)" },
];

const TYPE_ICONS = {
    BINARY: "◆",
    PROGRESSIVE: "▣",
    META: "✦",
};

//-----------------------------------------------------------------------------------------------------------------
//-- Main Achievements Page Component
export function AchievementsPage() {
    console.log("entered function AchievementsPage");
    const [achievements, setAchievements] = useState([]);
    const [progress, setProgress] = useState([]);
    const [titles, setTitles] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedPillar, setSelectedPillar] = useState(null);
    const [expandedId, setExpandedId] = useState(null);
    const [collapsedPillars, setCollapsedPillars] = useState({});

    const memberReferral = gvUser?.memberreferral;

    useEffect(() => {
        injectStyles();
        if (memberReferral) {
            loadAchievements();
        } else {
            setLoading(false);
        }
    }, [memberReferral]);

    async function loadAchievements() {
        console.log("entered function loadAchievements");
        try {
            setLoading(true);
            const data = await getMemberAchievements(memberReferral);
            setAchievements(data.achievements || []);
            setProgress(data.progress || []);
            setTitles(data.titles || []);

            if (typeof window !== 'undefined') {
                window.loadAchievements = loadAchievements;
            }

            const progressMap = new Map();
            (data.progress || []).forEach(p => {
                progressMap.set(p.achievementId, p);
            });

            const achievementsWithProgress = (data.achievements || []).map(achievement => {
                const memberProgress = progressMap.get(achievement.id);
                return {
                    ...achievement,
                    memberProgress: memberProgress || {
                        progress: 0,
                        isCompleted: false,
                        completedAt: null
                    }
                };
            });

            setAchievements(achievementsWithProgress);
        } catch (err) {
            console.error("Error loading achievements:", err);
        } finally {
            setLoading(false);
        }
    }

    // Group achievements by pillar
    const achievementsByPillar = {};
    achievements.forEach(achievement => {
        if (!achievementsByPillar[achievement.pillarCode]) {
            achievementsByPillar[achievement.pillarCode] = [];
        }
        achievementsByPillar[achievement.pillarCode].push(achievement);
    });

    // Compute stats
    const activeTitle = titles.find(ti => ti.isActive);
    const totalCompleted = progress.filter(p => p.isCompleted).length;
    const totalAchievements = achievements.length;
    const overallPercent = totalAchievements > 0 ? Math.round((totalCompleted / totalAchievements) * 100) : 0;

    // Per-pillar stats
    const pillarStats = {};
    PILLARS.forEach(p => {
        const pillarAch = achievementsByPillar[p.code] || [];
        const pillarCompleted = pillarAch.filter(a => a.memberProgress?.isCompleted).length;
        pillarStats[p.code] = { total: pillarAch.length, completed: pillarCompleted };
    });

    const togglePillarCollapse = (code) => {
        setCollapsedPillars(prev => ({ ...prev, [code]: !prev[code] }));
    };

    if (loading) {
        return (
            <div style={{ padding: "60px 20px", textAlign: "center", color: "#888", background: "#0a0a0a", minHeight: "100%" }}>
                <div style={{ fontSize: "32px", marginBottom: "12px" }}>🏆</div>
                <div style={{ fontSize: "14px", letterSpacing: "1px" }}>{t("loading")}</div>
            </div>
        );
    }

    return (
        <div style={{
            background: "#0a0a0a",
            color: "#fff",
            minHeight: "100%",
            display: "flex",
            flexDirection: "column",
            fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        }}>
            {/* ─── Header: Progress Dashboard ─── */}
            <div style={{
                padding: "20px 16px 16px",
                background: "linear-gradient(180deg, rgba(255,180,0,0.06) 0%, rgba(0,0,0,0) 100%)",
                borderBottom: "1px solid rgba(255,255,255,0.06)",
            }}>
                {/* Top row: title + back */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                    <h1 style={{ margin: 0, fontSize: "20px", fontWeight: 600, letterSpacing: "0.3px" }}>
                        {t("achievements")}
                    </h1>
                    <button
                        onClick={async () => {
                            const { navigateBack } = await import("@components/homebase/navigation/NavigationManager.js");
                            navigateBack();
                        }}
                        style={{
                            padding: "6px 14px",
                            background: "rgba(255,255,255,0.06)",
                            border: "1px solid rgba(255,255,255,0.1)",
                            borderRadius: "6px",
                            color: "#aaa",
                            cursor: "pointer",
                            fontSize: "13px",
                            transition: "all 0.2s ease",
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.1)"; e.currentTarget.style.color = "#fff"; }}
                        onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.color = "#aaa"; }}
                    >
                        {t("back")}
                    </button>
                </div>

                {/* Progress Dashboard */}
                <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
                    {/* Overall progress ring */}
                    <div style={{ position: "relative", flexShrink: 0 }}>
                        <ProgressRing radius={38} stroke={5} progress={overallPercent} color="#FFB400" />
                        <div style={{
                            position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
                            textAlign: "center",
                        }}>
                            <div style={{ fontSize: "18px", fontWeight: 700, color: "#FFB400", lineHeight: 1 }}>{overallPercent}%</div>
                        </div>
                    </div>

                    {/* Stats + Title */}
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", gap: "16px", marginBottom: "8px" }}>
                            <div>
                                <span style={{ fontSize: "22px", fontWeight: 700, color: "#FFB400" }}>{totalCompleted}</span>
                                <span style={{ fontSize: "13px", color: "#666", marginLeft: "4px" }}>/ {totalAchievements}</span>
                            </div>
                        </div>
                        {activeTitle && (
                            <div style={{
                                display: "inline-flex", alignItems: "center", gap: "6px",
                                padding: "4px 10px", borderRadius: "12px",
                                background: "rgba(255,180,0,0.1)", border: "1px solid rgba(255,180,0,0.2)",
                            }}>
                                <span style={{ fontSize: "11px" }}>👑</span>
                                <span style={{ fontSize: "12px", fontWeight: 600, color: "#FFB400" }}>{activeTitle.title}</span>
                            </div>
                        )}
                    </div>
                </div>

                {/* Mini pillar progress rings */}
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: "16px", padding: "0 4px" }}>
                    {PILLARS.map(pillar => {
                        const stats = pillarStats[pillar.code];
                        const pct = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
                        return (
                            <div
                                key={pillar.code}
                                onClick={() => setSelectedPillar(selectedPillar === pillar.code ? null : pillar.code)}
                                style={{
                                    display: "flex", flexDirection: "column", alignItems: "center", gap: "4px",
                                    cursor: "pointer", opacity: selectedPillar && selectedPillar !== pillar.code ? 0.4 : 1,
                                    transition: "opacity 0.2s ease",
                                }}
                            >
                                <div style={{ position: "relative" }}>
                                    <ProgressRing radius={22} stroke={3} progress={pct} color={pillar.color} />
                                    <div style={{
                                        position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
                                        fontSize: "14px",
                                    }}>
                                        {pillar.icon}
                                    </div>
                                </div>
                                <div style={{ fontSize: "10px", color: selectedPillar === pillar.code ? pillar.color : "#888", fontWeight: 500, letterSpacing: "0.3px" }}>
                                    {stats.completed}/{stats.total}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* ─── Achievements List ─── */}
            <div style={{ flex: 1, overflowY: "auto", padding: "12px 12px 24px" }}>
                {(selectedPillar ? [PILLARS.find(p => p.code === selectedPillar)] : PILLARS).map(pillar => {
                    if (!pillar) return null;
                    const pillarAchievements = achievementsByPillar[pillar.code] || [];
                    if (pillarAchievements.length === 0) return null;
                    const stats = pillarStats[pillar.code];
                    const isCollapsed = collapsedPillars[pillar.code];

                    // Sort: completed last so in-progress items are visible first
                    const sorted = [...pillarAchievements].sort((a, b) => {
                        const aComplete = a.memberProgress?.isCompleted ? 1 : 0;
                        const bComplete = b.memberProgress?.isCompleted ? 1 : 0;
                        if (aComplete !== bComplete) return aComplete - bComplete;
                        // META achievements appear last within their completion group
                        const aMeta = a.achievementType === "META" ? 1 : 0;
                        const bMeta = b.achievementType === "META" ? 1 : 0;
                        return aMeta - bMeta;
                    });

                    return (
                        <div key={pillar.code} style={{
                            marginBottom: "16px",
                            animation: "achievementFadeIn 0.3s ease",
                        }}>
                            {/* Pillar Section Header */}
                            <div
                                onClick={() => togglePillarCollapse(pillar.code)}
                                style={{
                                    display: "flex", alignItems: "center", justifyContent: "space-between",
                                    padding: "10px 12px", borderRadius: "10px",
                                    background: pillar.darkColor,
                                    borderLeft: `3px solid ${pillar.color}`,
                                    cursor: "pointer",
                                    marginBottom: isCollapsed ? 0 : "8px",
                                    transition: "all 0.2s ease",
                                }}
                            >
                                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                                    <span style={{ fontSize: "16px" }}>{pillar.icon}</span>
                                    <span style={{ fontSize: "15px", fontWeight: 600, color: pillar.color }}>{pillar.name}</span>
                                </div>
                                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                                    {/* Mini progress bar */}
                                    <div style={{ width: "60px", height: "4px", borderRadius: "2px", background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                                        <div style={{
                                            height: "100%", borderRadius: "2px",
                                            width: stats.total > 0 ? `${(stats.completed / stats.total) * 100}%` : "0%",
                                            background: pillar.color, transition: "width 0.4s ease",
                                        }} />
                                    </div>
                                    <span style={{ fontSize: "12px", color: "#888", minWidth: "32px", textAlign: "right" }}>
                                        {stats.completed}/{stats.total}
                                    </span>
                                    <span style={{ fontSize: "12px", color: "#555", transition: "transform 0.2s ease", transform: isCollapsed ? "rotate(-90deg)" : "rotate(0)" }}>
                                        ▾
                                    </span>
                                </div>
                            </div>

                            {/* Achievement Rows */}
                            {!isCollapsed && (
                                <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                                    {sorted.map(achievement => (
                                        <AchievementRow
                                            key={achievement.id}
                                            achievement={achievement}
                                            titles={titles}
                                            pillar={pillar}
                                            isExpanded={expandedId === achievement.id}
                                            onToggle={() => setExpandedId(expandedId === achievement.id ? null : achievement.id)}
                                        />
                                    ))}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

//-----------------------------------------------------------------------------------------------------------------
//-- Achievement Row (Compact + Expandable)
function AchievementRow({ achievement, titles, pillar, isExpanded, onToggle }) {
    console.log("entered function AchievementRow");
    const memberProgress = achievement.memberProgress || { progress: 0, isCompleted: false };
    const isCompleted = memberProgress.isCompleted;
    const isMeta = achievement.achievementType === "META";
    const isProgressive = achievement.achievementType === "PROGRESSIVE";
    const progressPercent = achievement.progressRequired
        ? Math.min((memberProgress.progress / achievement.progressRequired) * 100, 100)
        : (memberProgress.progress > 0 ? 100 : 0);
    const hasProgress = isProgressive && memberProgress.progress > 0 && !isCompleted;

    const achievementTitle = titles?.find(ti => ti.achievementId === achievement.id);
    const typeIcon = TYPE_ICONS[achievement.achievementType] || "◆";

    // Determine visual state
    let bgColor, borderColor, nameColor, rowOpacity;
    if (isCompleted) {
        bgColor = "rgba(255,180,0,0.06)";
        borderColor = "rgba(255,180,0,0.25)";
        nameColor = "#FFB400";
        rowOpacity = 1;
    } else if (hasProgress) {
        bgColor = "rgba(255,255,255,0.03)";
        borderColor = `rgba(${pillar.color === "#56AF9B" ? "86,175,155" : pillar.color === "#4A90E2" ? "74,144,226" : pillar.color === "#E74C3C" ? "231,76,60" : "243,156,18"},0.2)`;
        nameColor = "#fff";
        rowOpacity = 1;
    } else {
        bgColor = "rgba(255,255,255,0.02)";
        borderColor = "rgba(255,255,255,0.05)";
        nameColor = "#ccc";
        rowOpacity = 0.85;
    }

    if (isMeta) {
        bgColor = isCompleted ? "rgba(255,180,0,0.08)" : "rgba(255,180,0,0.03)";
        borderColor = isCompleted ? "rgba(255,180,0,0.3)" : "rgba(255,180,0,0.1)";
    }

    return (
        <div
            onClick={onToggle}
            style={{
                background: bgColor,
                border: `1px solid ${borderColor}`,
                borderRadius: "10px",
                padding: isExpanded ? "12px 14px" : "10px 14px",
                opacity: rowOpacity,
                cursor: "pointer",
                transition: "all 0.2s ease",
                animation: isCompleted ? "pulseGlow 3s ease infinite" : "none",
                ...(isMeta && !isCompleted ? { borderStyle: "dashed" } : {}),
            }}
            onMouseEnter={e => { e.currentTarget.style.background = isCompleted ? "rgba(255,180,0,0.1)" : "rgba(255,255,255,0.05)"; }}
            onMouseLeave={e => { e.currentTarget.style.background = bgColor; }}
        >
            {/* Collapsed Row */}
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                {/* Type badge */}
                <div style={{
                    width: "32px", height: "32px", borderRadius: "8px", flexShrink: 0,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    background: isCompleted ? "rgba(255,180,0,0.15)" : isMeta ? "rgba(255,180,0,0.08)" : "rgba(255,255,255,0.05)",
                    border: isCompleted ? "1px solid rgba(255,180,0,0.3)" : "1px solid rgba(255,255,255,0.08)",
                    fontSize: isCompleted ? "16px" : "13px",
                    color: isCompleted ? "#FFB400" : isMeta ? "#FFB400" : "#666",
                }}>
                    {isCompleted ? "✓" : isMeta ? "✦" : typeIcon}
                </div>

                {/* Name + mini info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{
                        fontSize: "14px", fontWeight: isCompleted ? 600 : 500,
                        color: nameColor,
                        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                    }}>
                        {achievement.name}
                    </div>
                    {achievement.title && (
                        <div style={{ fontSize: "11px", color: "rgba(255,180,0,0.7)", marginTop: "1px" }}>
                            👑 {achievement.title}
                        </div>
                    )}
                </div>

                {/* Right side: progress or status */}
                <div style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: "8px" }}>
                    {isProgressive && achievement.progressRequired && !isCompleted && (
                        <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                            <div style={{ width: "40px", height: "4px", borderRadius: "2px", background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
                                <div style={{
                                    height: "100%", borderRadius: "2px",
                                    width: `${progressPercent}%`,
                                    background: pillar.color, transition: "width 0.3s ease",
                                }} />
                            </div>
                            <span style={{ fontSize: "11px", color: "#666", minWidth: "28px", textAlign: "right" }}>
                                {memberProgress.progress}/{achievement.progressRequired}
                            </span>
                        </div>
                    )}
                    {isCompleted && (
                        <span style={{ fontSize: "14px" }}>🏆</span>
                    )}
                    <span style={{
                        fontSize: "10px", color: "#555",
                        transition: "transform 0.2s ease",
                        transform: isExpanded ? "rotate(180deg)" : "rotate(0)",
                    }}>▾</span>
                </div>
            </div>

            {/* Expanded Details */}
            {isExpanded && (
                <div style={{
                    marginTop: "12px", paddingTop: "12px",
                    borderTop: "1px solid rgba(255,255,255,0.06)",
                    animation: "achievementFadeIn 0.2s ease",
                }}>
                    {/* Description */}
                    {achievement.description && (
                        <div style={{ fontSize: "13px", color: "#999", lineHeight: 1.5, marginBottom: "12px" }}>
                            {achievement.description}
                        </div>
                    )}

                    {/* Full progress bar for PROGRESSIVE */}
                    {isProgressive && achievement.progressRequired && (
                        <div style={{ marginBottom: "12px" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", color: "#888", marginBottom: "6px" }}>
                                <span>{t("progress")}</span>
                                <span style={{ color: isCompleted ? "#FFB400" : pillar.color, fontWeight: 600 }}>
                                    {memberProgress.progress} / {achievement.progressRequired}
                                    {progressPercent > 0 && ` (${Math.round(progressPercent)}%)`}
                                </span>
                            </div>
                            <div style={{
                                height: "12px", background: "rgba(255,255,255,0.06)",
                                borderRadius: "6px", overflow: "hidden",
                                border: "1px solid rgba(255,255,255,0.04)",
                            }}>
                                <div style={{
                                    height: "100%", borderRadius: "5px",
                                    width: `${progressPercent}%`,
                                    background: isCompleted
                                        ? "linear-gradient(90deg, #FFB400, #FFD700)"
                                        : `linear-gradient(90deg, ${pillar.color}, ${pillar.color}dd)`,
                                    transition: "width 0.4s ease",
                                    ...(isCompleted ? {
                                        backgroundSize: "200% 100%",
                                        animation: "achievementShimmer 2s ease infinite",
                                        backgroundImage: `linear-gradient(90deg, #FFB400 0%, #FFD700 25%, #fff 50%, #FFD700 75%, #FFB400 100%)`,
                                    } : {}),
                                }} />
                            </div>
                        </div>
                    )}

                    {/* META dependency hint */}
                    {isMeta && !isCompleted && (
                        <div style={{
                            padding: "8px 10px", borderRadius: "6px",
                            background: "rgba(255,180,0,0.05)", border: "1px dashed rgba(255,180,0,0.15)",
                            fontSize: "12px", color: "#888", marginBottom: "12px",
                            display: "flex", alignItems: "center", gap: "6px",
                        }}>
                            <span style={{ color: "#FFB400" }}>✦</span>
                            {t("meta_achievement_hint") || "Complete all required achievements to unlock"}
                        </div>
                    )}

                    {/* Completion date */}
                    {isCompleted && memberProgress.completedAt && (
                        <div style={{ fontSize: "11px", color: "#555", marginBottom: "10px", display: "flex", alignItems: "center", gap: "4px" }}>
                            <span style={{ color: "#FFB400" }}>●</span>
                            {t("completed_on")}: {new Date(memberProgress.completedAt).toLocaleDateString()}
                        </div>
                    )}

                    {/* Title badge (quick preview) */}
                    {achievement.title && (
                        <div style={{
                            display: "inline-flex", alignItems: "center", gap: "6px",
                            padding: "4px 10px", borderRadius: "10px",
                            background: isCompleted ? "rgba(255,180,0,0.1)" : "rgba(255,255,255,0.03)",
                            border: isCompleted ? "1px solid rgba(255,180,0,0.2)" : "1px solid rgba(255,255,255,0.06)",
                            marginBottom: "12px",
                        }}>
                            <span style={{ fontSize: "11px" }}>👑</span>
                            <span style={{ fontSize: "12px", fontWeight: 600, color: isCompleted ? "#FFB400" : "#666" }}>
                                {achievement.title}
                            </span>
                            {achievementTitle?.isActive && (
                                <span style={{ fontSize: "10px", color: "rgba(255,180,0,0.6)" }}>✓</span>
                            )}
                        </div>
                    )}

                    {/* View Details Button */}
                    <button
                        onClick={async (e) => {
                            e.stopPropagation();
                            try {
                                const { navigateTo, getReturnContext } = await import("@components/homebase/navigation/NavigationState.js");
                                const currentReturnContext = getReturnContext();
                                navigateTo(
                                    {
                                        type: 'page',
                                        id: 'achievement-detail',
                                        coordinates: null,
                                        context: {
                                            achievementId: achievement.id,
                                            achievement: achievement,
                                        },
                                    },
                                    {
                                        source: currentReturnContext?.source || 'achievements',
                                        channelInfo: currentReturnContext?.channelInfo || null,
                                        modalAgent: null,
                                        pageType: 'achievement-detail',
                                        updateHistory: true,
                                    }
                                );
                            } catch (err) {
                                console.error("Error navigating to achievement detail:", err);
                            }
                        }}
                        style={{
                            width: "100%",
                            padding: "10px 14px",
                            background: isCompleted ? "rgba(255,180,0,0.12)" : `${pillar.color}18`,
                            border: isCompleted ? "1px solid rgba(255,180,0,0.25)" : `1px solid ${pillar.color}33`,
                            borderRadius: "8px",
                            fontSize: "13px",
                            fontWeight: 600,
                            color: isCompleted ? "#FFB400" : pillar.color,
                            cursor: "pointer",
                            transition: "all 0.2s ease",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            gap: "6px",
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = isCompleted ? "rgba(255,180,0,0.18)" : `${pillar.color}28`; }}
                        onMouseLeave={e => { e.currentTarget.style.background = isCompleted ? "rgba(255,180,0,0.12)" : `${pillar.color}18`; }}
                    >
                        {t("view_details") || "View Details"}
                        <span style={{ fontSize: "12px" }}>→</span>
                    </button>
                </div>
            )}
        </div>
    );
}
