using System;
using System.Collections.Generic;
using System.Linq;
using Npgsql;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ImagineBC.MainService.Services;

namespace ImagineBC.MainService.Services.Arcade
{
    /// <summary>
    /// Poll Battle: Daily + feed polls. Uses poll, poll_vote, arcade_user_game_state tables.
    /// </summary>
    public class PollsService
    {
        private readonly string _connectionString;
        private readonly ILogger<PollsService> _logger;
        private static readonly TimeZoneInfo EasternZone = TimeZoneInfo.FindSystemTimeZoneById(
            OperatingSystem.IsWindows() ? "Eastern Standard Time" : "America/New_York");

        public PollsService(string connectionString, ILogger<PollsService> logger)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public static DateTime GetTodayEastern() =>
            TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, EasternZone).Date;

        public (JObject? poll, bool alreadyVoted, string? userVote, JObject? results)? GetDailyPoll(string? memberReferral, string? sessionId)
        {
            var today = GetTodayEastern();
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            const string sql = @"
                SELECT id, type, status, question, options, tags, is_daily, daily_date, created_at
                FROM poll
                WHERE status = 'ACTIVE' AND is_daily = TRUE AND daily_date = @today
                ORDER BY created_at DESC LIMIT 1";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("today", today);

            JObject poll;
            using (var r = cmd.ExecuteReader())
            {
                if (!r.Read()) return null;
                poll = new JObject
                {
                    ["id"] = r.GetGuid(0).ToString(),
                    ["type"] = r.GetString(1),
                    ["question"] = r.GetString(3),
                    ["options"] = r.IsDBNull(4) ? new JArray() : JArray.Parse(r.GetString(4)),
                    ["tags"] = r.IsDBNull(5) ? new JArray() : JArray.FromObject(r.GetFieldValue<string[]>(5) ?? Array.Empty<string>()),
                    ["isDaily"] = r.GetBoolean(6),
                    ["dailyDate"] = r.GetDateTime(7).ToString("yyyy-MM-dd")
                };
            }

            var pollId = poll["id"]!.ToString();
            string? userVote = null;
            var alreadyVoted = false;

            if (!string.IsNullOrEmpty(memberReferral))
            {
                var voteSql = "SELECT option_id FROM poll_vote WHERE poll_id = @pollId AND member_referral = @memberRef";
                using var vCmd = new NpgsqlCommand(voteSql, conn);
                vCmd.Parameters.AddWithValue("pollId", Guid.Parse(pollId));
                vCmd.Parameters.AddWithValue("memberRef", memberReferral);
                var v = vCmd.ExecuteScalar();
                if (v != null && v != DBNull.Value) { userVote = v.ToString(); alreadyVoted = true; }
            }
            else if (!string.IsNullOrEmpty(sessionId))
            {
                var voteSql = "SELECT option_id FROM poll_vote WHERE poll_id = @pollId AND session_id = @sessionId";
                using var vCmd = new NpgsqlCommand(voteSql, conn);
                vCmd.Parameters.AddWithValue("pollId", Guid.Parse(pollId));
                vCmd.Parameters.AddWithValue("sessionId", sessionId);
                var v = vCmd.ExecuteScalar();
                if (v != null && v != DBNull.Value) { userVote = v.ToString(); alreadyVoted = true; }
            }

            JObject? results = null;
            if (alreadyVoted)
            {
                results = GetPollResults(conn, Guid.Parse(pollId));
            }

            return (poll, alreadyVoted, userVote, results);
        }

        private static string? GetExistingVote(NpgsqlConnection conn, Guid pollId, string? memberReferral, string? sessionId)
        {
            var sql = memberReferral != null
                ? "SELECT option_id FROM poll_vote WHERE poll_id = @pollId AND member_referral = @memberRef"
                : "SELECT option_id FROM poll_vote WHERE poll_id = @pollId AND session_id = @sessionId";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("pollId", pollId);
            if (memberReferral != null) cmd.Parameters.AddWithValue("memberRef", memberReferral);
            else cmd.Parameters.AddWithValue("sessionId", sessionId!);
            var v = cmd.ExecuteScalar();
            return v?.ToString();
        }

        public JObject? GetPollResultsPublic(Guid pollId)
        {
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();
            return GetPollResults(conn, pollId);
        }

        public JObject? GetPollResults(NpgsqlConnection conn, Guid pollId)
        {
            const string sql = @"
                SELECT option_id, COUNT(*)::int
                FROM poll_vote
                WHERE poll_id = @pollId
                GROUP BY option_id";
            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("pollId", pollId);

            var counts = new Dictionary<string, int>();
            var total = 0;
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    var opt = r.GetString(0);
                    var c = r.GetInt32(1);
                    counts[opt] = c;
                    total += c;
                }
            }

            if (total == 0) return new JObject { ["total"] = 0, ["counts"] = new JObject(), ["percents"] = new JObject() };

            var percents = new JObject();
            foreach (var kv in counts)
                percents[kv.Key] = Math.Round(100.0 * kv.Value / total, 1);

            return new JObject
            {
                ["total"] = total,
                ["counts"] = JObject.FromObject(counts),
                ["percents"] = percents
            };
        }

        public (bool success, string? error, JObject? response) SubmitVote(Guid pollId, string optionId, string? memberReferral, string? sessionId)
        {
            if (string.IsNullOrEmpty(memberReferral) && string.IsNullOrEmpty(sessionId))
                return (false, "memberReferral or sessionId required", null);

            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            // Validate poll exists and is active
            using (var checkCmd = new NpgsqlCommand("SELECT id, status, is_daily, daily_date FROM poll WHERE id = @id", conn))
            {
                checkCmd.Parameters.AddWithValue("id", pollId);
                using var r = checkCmd.ExecuteReader();
                if (!r.Read()) return (false, "Poll not found", null);
                if (r.GetString(1) != "ACTIVE") return (false, "Poll not active", null);
            }

            try
            {
                // Check if already voted
                var checkSql = memberReferral != null
                    ? "SELECT 1 FROM poll_vote WHERE poll_id = @pollId AND member_referral = @memberRef"
                    : "SELECT 1 FROM poll_vote WHERE poll_id = @pollId AND session_id = @sessionId";
                using (var checkCmd = new NpgsqlCommand(checkSql, conn))
                {
                    checkCmd.Parameters.AddWithValue("pollId", pollId);
                    if (memberReferral != null) checkCmd.Parameters.AddWithValue("memberRef", memberReferral);
                    else checkCmd.Parameters.AddWithValue("sessionId", sessionId!);
                    var alreadyVotedCheck = checkCmd.ExecuteScalar();
                    if (alreadyVotedCheck != null && alreadyVotedCheck != DBNull.Value)
                    {
                        var existing = GetExistingVote(conn, pollId, memberReferral, sessionId);
                        var results = GetPollResults(conn, pollId);
                        var (completed, streak, best) = memberReferral != null ? UpdateDailyStreak(conn, pollId, memberReferral) : (false, 0, 0);
                        return (true, null, new JObject
                        {
                            ["pollId"] = pollId.ToString(),
                            ["yourOptionId"] = existing ?? optionId,
                            ["results"] = results ?? new JObject(),
                            ["daily"] = new JObject { ["completed"] = completed, ["streak"] = streak, ["bestStreak"] = best }
                        });
                    }
                }

                var insertSql = memberReferral != null
                    ? "INSERT INTO poll_vote (poll_id, member_referral, option_id) VALUES (@pollId, @memberRef, @optionId)"
                    : "INSERT INTO poll_vote (poll_id, session_id, option_id) VALUES (@pollId, @sessionId, @optionId)";

                using var insertCmd = new NpgsqlCommand(insertSql, conn);
                insertCmd.Parameters.AddWithValue("pollId", pollId);
                insertCmd.Parameters.AddWithValue("optionId", optionId);
                if (memberReferral != null)
                    insertCmd.Parameters.AddWithValue("memberRef", memberReferral);
                else
                    insertCmd.Parameters.AddWithValue("sessionId", sessionId!);

                var rows = insertCmd.ExecuteNonQuery();

                // If 0 rows (duplicate vote), fetch existing vote and return results
                if (rows == 0)
                {
                    string? existing = null;
                    var voteSql = memberReferral != null
                        ? "SELECT option_id FROM poll_vote WHERE poll_id = @pollId AND member_referral = @memberRef"
                        : "SELECT option_id FROM poll_vote WHERE poll_id = @pollId AND session_id = @sessionId";
                    using var vCmd = new NpgsqlCommand(voteSql, conn);
                    vCmd.Parameters.AddWithValue("pollId", pollId);
                    if (memberReferral != null) vCmd.Parameters.AddWithValue("memberRef", memberReferral);
                    else vCmd.Parameters.AddWithValue("sessionId", sessionId!);
                    var v = vCmd.ExecuteScalar();
                    if (v != null) existing = v.ToString();
                    var results = GetPollResults(conn, pollId);
                    var (completed, streak, best) = memberReferral != null ? UpdateDailyStreak(conn, pollId, memberReferral) : (false, 0, 0);
                    return (true, null, new JObject
                    {
                        ["pollId"] = pollId.ToString(),
                        ["yourOptionId"] = existing ?? optionId,
                        ["results"] = results ?? new JObject(),
                        ["daily"] = new JObject { ["completed"] = completed, ["streak"] = streak, ["bestStreak"] = best }
                    });
                }

                var results2 = GetPollResults(conn, pollId);
                var (completed2, streak2, best2) = memberReferral != null ? UpdateDailyStreak(conn, pollId, memberReferral) : (false, 0, 0);

                // Emit gamification event for poll vote (fire and forget)
                if (memberReferral != null)
                {
                    _ = Task.Run(async () =>
                    {
                        try
                        {
                            var gamificationService = new GamificationService(_connectionString, null, null);
                            await gamificationService.ProcessEventAsync("POLL_VOTE_CAST", memberReferral);
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning(ex, "Failed to process poll vote gamification event for {MemberReferral}", memberReferral);
                        }
                    });
                }

                return (true, null, new JObject
                {
                    ["pollId"] = pollId.ToString(),
                    ["yourOptionId"] = optionId,
                    ["results"] = results2 ?? new JObject(),
                    ["daily"] = new JObject { ["completed"] = completed2, ["streak"] = streak2, ["bestStreak"] = best2 }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error submitting poll vote");
                return (false, ex.Message, null);
            }
        }

        private (bool completed, int streak, int bestStreak) UpdateDailyStreak(NpgsqlConnection conn, Guid pollId, string memberReferral)
        {
            const string isDailySql = "SELECT is_daily, daily_date FROM poll WHERE id = @pollId";
            using (var dc = new NpgsqlCommand(isDailySql, conn))
            {
                dc.Parameters.AddWithValue("pollId", pollId);
                using var dr = dc.ExecuteReader();
                if (!dr.Read() || !dr.GetBoolean(0)) return (false, 0, 0);
            }

            var today = GetTodayEastern();
            const string upsertSql = @"
                INSERT INTO arcade_user_game_state (member_referral, poll_daily_last_completed, poll_daily_streak, poll_daily_best_streak, updated_at)
                VALUES (@memberRef, @today, 1, 1, NOW())
                ON CONFLICT (member_referral) DO UPDATE SET
                    poll_daily_last_completed = @today,
                    poll_daily_streak = CASE
                        WHEN arcade_user_game_state.poll_daily_last_completed = @today THEN arcade_user_game_state.poll_daily_streak
                        WHEN arcade_user_game_state.poll_daily_last_completed = @today - INTERVAL '1 day' THEN arcade_user_game_state.poll_daily_streak + 1
                        ELSE 1
                    END,
                    poll_daily_best_streak = GREATEST(
                        arcade_user_game_state.poll_daily_best_streak,
                        CASE
                            WHEN arcade_user_game_state.poll_daily_last_completed = @today THEN arcade_user_game_state.poll_daily_streak
                            WHEN arcade_user_game_state.poll_daily_last_completed = @today - INTERVAL '1 day' THEN arcade_user_game_state.poll_daily_streak + 1
                            ELSE 1
                        END
                    ),
                    updated_at = NOW()";

            using var cmd = new NpgsqlCommand(upsertSql, conn);
            cmd.Parameters.AddWithValue("memberRef", memberReferral);
            cmd.Parameters.AddWithValue("today", today);
            cmd.ExecuteNonQuery();

            const string selectSql = "SELECT poll_daily_streak, poll_daily_best_streak FROM arcade_user_game_state WHERE member_referral = @memberRef";
            using var scmd = new NpgsqlCommand(selectSql, conn);
            scmd.Parameters.AddWithValue("memberRef", memberReferral);
            using var sr = scmd.ExecuteReader();
            if (sr.Read())
                return (true, sr.GetInt32(0), sr.GetInt32(1));
            return (true, 1, 1);
        }

        public JObject? GetNextFeedPoll(string? memberReferral, string? sessionId, Guid[] excludeIds)
        {
            var exclude = excludeIds ?? Array.Empty<Guid>();
            using var conn = new NpgsqlConnection(_connectionString);
            conn.Open();

            // Diagnostic: count feed polls
            using (var countCmd = new NpgsqlCommand(
                @"SELECT COUNT(*)::int FROM poll WHERE status = 'ACTIVE' AND (is_daily = FALSE OR daily_date IS NULL)
                  AND (start_at IS NULL OR start_at <= NOW()) AND (end_at IS NULL OR end_at > NOW())", conn))
            {
                var feedCount = (int)(countCmd.ExecuteScalar() ?? 0);
                _logger.LogInformation("GetNextFeedPoll: feed poll count={Count}, memberRef={MemberRef}, sessionId={SessionId}, excludeCount={ExcludeCount}",
                    feedCount, memberReferral ?? "(null)", string.IsNullOrEmpty(sessionId) ? "(null)" : sessionId.Substring(0, Math.Min(8, sessionId?.Length ?? 0)) + "...", exclude.Length);
            }

            var sql = @"
                SELECT p.id, p.type, p.question, p.options, p.tags, p.is_daily
                FROM poll p
                WHERE p.status = 'ACTIVE' AND (p.is_daily = FALSE OR p.daily_date IS NULL)
                  AND (p.start_at IS NULL OR p.start_at <= NOW())
                  AND (p.end_at IS NULL OR p.end_at > NOW())
                  AND (NOT (p.id = ANY(@exclude)))";
            if (memberReferral != null)
                sql += " AND p.id NOT IN (SELECT pv.poll_id FROM poll_vote pv WHERE pv.member_referral = @memberRef)";
            else if (!string.IsNullOrEmpty(sessionId))
                sql += " AND p.id NOT IN (SELECT pv.poll_id FROM poll_vote pv WHERE pv.session_id = @sessionId)";
            sql += " ORDER BY p.created_at DESC LIMIT 1";

            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("exclude", exclude);
            if (memberReferral != null) cmd.Parameters.AddWithValue("memberRef", memberReferral);
            else if (!string.IsNullOrEmpty(sessionId)) cmd.Parameters.AddWithValue("sessionId", sessionId!);

            using var r = cmd.ExecuteReader();
            if (!r.Read()) return null;

            return new JObject
            {
                ["id"] = r.GetGuid(0).ToString(),
                ["type"] = r.GetString(1),
                ["question"] = r.GetString(2),
                ["options"] = r.IsDBNull(3) ? new JArray() : JArray.Parse(r.GetString(3)),
                ["tags"] = r.IsDBNull(4) ? new JArray() : JArray.FromObject(r.GetFieldValue<string[]>(4) ?? Array.Empty<string>()),
                ["isDaily"] = r.GetBoolean(5)
            };
        }
    }
}
