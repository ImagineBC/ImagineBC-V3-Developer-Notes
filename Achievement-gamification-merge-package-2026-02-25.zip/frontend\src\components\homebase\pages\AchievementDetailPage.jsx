import React, { useEffect, useState } from "react";
import { gvUser, gvMember } from "@core/state.js";
import {
    getMemberAchievements,
    activateTitle,
    deactivateAllTitles,
    createTitle,
} from "@wrappers/ioGamification.jsx";
import { encryptedGet, encryptedPost } from "@shared/encryptedApi.js";
import { getApiBase } from "@shared/apiBase.js";
import { showToastReact } from "@react/toast.jsx";
import { getCurrentLocation } from "@components/homebase/navigation/NavigationState.js";
import { t } from "@shared/translations.js";

// ─── Pillar Themes ───
const PILLAR_THEMES = {
    CITIZEN: {
        color: "#56AF9B",
        gradient: "linear-gradient(135deg, #56AF9B 0%, #3D8B7A 100%)",
        darkBg: "rgba(86,175,155,0.08)",
        midBg: "rgba(86,175,155,0.15)",
        icon: "\u{1F3DB}\uFE0F", // 🏛️
        name: "Citizen",
    },
    EXPLORER: {
        color: "#4A90E2",
        gradient: "linear-gradient(135deg, #4A90E2 0%, #357ABD 100%)",
        darkBg: "rgba(74,144,226,0.08)",
        midBg: "rgba(74,144,226,0.15)",
        icon: "\u{1F5FA}\uFE0F", // 🗺️
        name: "Explorer",
    },
    GAMER: {
        color: "#E74C3C",
        gradient: "linear-gradient(135deg, #E74C3C 0%, #C0392B 100%)",
        darkBg: "rgba(231,76,60,0.08)",
        midBg: "rgba(231,76,60,0.15)",
        icon: "\u{1F3AE}", // 🎮
        name: "Gamer",
    },
    PATRON: {
        color: "#F39C12",
        gradient: "linear-gradient(135deg, #F39C12 0%, #D68910 100%)",
        darkBg: "rgba(243,156,18,0.08)",
        midBg: "rgba(243,156,18,0.15)",
        icon: "\u{1F4B0}", // 💰
        name: "Patron",
    },
};

const TYPE_INFO = {
    BINARY: { icon: "\u25C6", label: "One-Time", desc: "Complete the objective once to unlock" },
    PROGRESSIVE: { icon: "\u25A3", label: "Progressive", desc: "Reach the required count to unlock" },
    META: { icon: "\u2726", label: "Meta", desc: "Complete all required achievements to unlock" },
};

// ─── Style injection ───
const STYLE_ID = "achievement-detail-styles";
function injectDetailStyles() {
    if (typeof document === "undefined") return;
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
        @keyframes detailFadeIn {
            from { opacity: 0; transform: translateY(12px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes detailPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        @keyframes detailShimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        @keyframes detailRingFill {
            from { stroke-dashoffset: var(--ring-circumference); }
            to { stroke-dashoffset: var(--ring-target); }
        }
        @keyframes detailBadgeIn {
            0% { opacity: 0; transform: scale(0.5); }
            60% { transform: scale(1.1); }
            100% { opacity: 1; transform: scale(1); }
        }
        @keyframes detailTitleGlow {
            0%, 100% { box-shadow: 0 0 8px rgba(255,180,0,0.2); }
            50% { box-shadow: 0 0 20px rgba(255,180,0,0.4); }
        }
    `;
    document.head.appendChild(style);
}

// ─── SVG Progress Ring ───
function DetailProgressRing({ radius, stroke, progress, color }) {
    const normalizedRadius = radius - stroke;
    const circumference = normalizedRadius * 2 * Math.PI;
    const strokeDashoffset = circumference - (progress / 100) * circumference;

    return (
        <svg height={radius * 2} width={radius * 2} style={{ filter: progress >= 100 ? `drop-shadow(0 0 8px ${color})` : "none" }}>
            <circle
                stroke="rgba(255,255,255,0.06)"
                fill="transparent"
                strokeWidth={stroke}
                r={normalizedRadius}
                cx={radius}
                cy={radius}
            />
            <circle
                stroke={color}
                fill="transparent"
                strokeWidth={stroke}
                strokeLinecap="round"
                strokeDasharray={`${circumference} ${circumference}`}
                strokeDashoffset={strokeDashoffset}
                r={normalizedRadius}
                cx={radius}
                cy={radius}
                style={{
                    transition: "stroke-dashoffset 1s ease",
                    transform: "rotate(-90deg)",
                    transformOrigin: "50% 50%",
                }}
            />
        </svg>
    );
}

// ═════════════════════════════════════════════════════════════════
// Main Achievement Detail Page
// ═════════════════════════════════════════════════════════════════
export function AchievementDetailPage() {
    console.log("entered function AchievementDetailPage");
    const [achievement, setAchievement] = useState(null);
    const [memberProgress, setMemberProgress] = useState(null);
    const [memberTitle, setMemberTitle] = useState(null);
    const [allTitles, setAllTitles] = useState([]);
    const [dependencies, setDependencies] = useState([]);
    const [allProgress, setAllProgress] = useState([]);
    const [loading, setLoading] = useState(true);
    const [titleLoading, setTitleLoading] = useState(false);
    const [activeTitle, setActiveTitle] = useState(null);

    const memberReferral = gvUser?.memberreferral;

    // Get achievement ID from navigation context
    const ctx = (() => {
        try {
            const loc = getCurrentLocation();
            return loc?.context || {};
        } catch {
            return {};
        }
    })();
    const achievementId = ctx.achievementId;
    const passedAchievement = ctx.achievement; // Full achievement object passed from list

    useEffect(() => {
        injectDetailStyles();
        loadData();
    }, [achievementId]);

    async function loadData() {
        console.log("entered function loadData");
        try {
            setLoading(true);

            if (!memberReferral) {
                setLoading(false);
                return;
            }

            // Fetch member achievements (reuses existing API)
            const data = await getMemberAchievements(memberReferral);
            const achievements = data.achievements || [];
            const progress = data.progress || [];
            const titles = data.titles || [];

            setAllTitles(titles);
            setAllProgress(progress);

            // Find the specific achievement
            const found = achievements.find((a) => a.id === achievementId) || passedAchievement;
            if (!found) {
                setLoading(false);
                return;
            }
            setAchievement(found);

            // Find member progress for this achievement
            const mp = progress.find((p) => p.achievementId === achievementId);
            setMemberProgress(mp || { progress: 0, isCompleted: false, completedAt: null });

            // Find title for this achievement
            const title = titles.find((ti) => ti.achievementId === achievementId);
            setMemberTitle(title || null);

            // Find active title
            const active = titles.find((ti) => ti.isActive);
            setActiveTitle(active || null);

            // If META achievement, load dependencies
            if (found.achievementType === "META") {
                await loadDependencies(found.id, achievements, progress);
            }
        } catch (err) {
            console.error("Error loading achievement detail:", err);
        } finally {
            setLoading(false);
        }
    }

    async function loadDependencies(achievementId, allAchievements, allProg) {
        console.log("entered function loadDependencies");
        try {
            const url = `${getApiBase()}/api/gamification/achievements/${achievementId}`;
            const data = await encryptedGet(url);
            if (data && data.success && data.dependencies && data.dependencies.length > 0) {
                // Map dependency IDs to achievement objects with progress
                const deps = data.dependencies
                    .map((depId) => {
                        const depAch = allAchievements.find((a) => a.id === depId);
                        if (!depAch) return null;
                        const depProg = allProg.find((p) => p.achievementId === depId);
                        return {
                            ...depAch,
                            memberProgress: depProg || { progress: 0, isCompleted: false },
                        };
                    })
                    .filter(Boolean);
                setDependencies(deps);
            }
        } catch (err) {
            // Dependencies are optional display — don't block
            console.error("Error loading dependencies:", err);
        }
    }

    // ─── Title Actions ───
    async function handleEquipTitle() {
        console.log("entered function handleEquipTitle");
        if (!achievement || !achievement.title) return;
        setTitleLoading(true);
        try {
            const memberId = gvUser.memberreferral || gvMember?.id;
            if (!memberId) throw new Error("Member reference not found");

            let titleId = memberTitle?.id;

            // Create title record if it doesn't exist yet
            if (!titleId) {
                const createdId = await createTitle(memberId, achievement.id);
                if (!createdId) {
                    showToastReact(t("title_equip_error"), "error");
                    setTitleLoading(false);
                    return;
                }
                titleId = createdId;
            }

            // Activate the title
            const success = await activateTitle(titleId);
            if (!success) {
                showToastReact(t("title_equip_error"), "error");
                setTitleLoading(false);
                return;
            }

            // Save to member aliases
            let aliasesArray = [];
            if (gvUser.aliases && Array.isArray(gvUser.aliases)) {
                aliasesArray = JSON.parse(JSON.stringify(gvUser.aliases));
            }
            const idx = aliasesArray.findIndex(
                (a) => a && (a.type || "").toLowerCase() === "achievementtitle"
            );
            if (idx >= 0) {
                aliasesArray[idx].aliasName = achievement.title;
            } else {
                aliasesArray.push({ type: "AchievementTitle", aliasName: achievement.title });
            }

            const aliasesJson = JSON.stringify(aliasesArray);
            const payload = { memberId, field: "aliases", value: aliasesJson, table: "members" };
            const result = await encryptedPost(`${getApiBase()}/api/ManagerMembers/update-field`, payload);

            if (result && result.success) {
                gvUser.aliases = aliasesArray;
                if (gvMember?.record) gvMember.record.aliases = aliasesJson;
                showToastReact(t("title_equipped"), "success");
                window.dispatchEvent(new CustomEvent("titleEquipped"));
                // Refresh data
                await loadData();
            } else {
                throw new Error("Failed to save title");
            }
        } catch (err) {
            console.error("Error equipping title:", err);
            showToastReact(t("title_equip_error"), "error");
        } finally {
            setTitleLoading(false);
        }
    }

    async function handleRemoveTitle() {
        console.log("entered function handleRemoveTitle");
        setTitleLoading(true);
        try {
            const memberId = gvUser.memberreferral || gvMember?.id;
            if (!memberId) throw new Error("Member reference not found");

            await deactivateAllTitles(memberId);

            // Remove from aliases
            let aliasesArray = [];
            if (gvUser.aliases && Array.isArray(gvUser.aliases)) {
                aliasesArray = JSON.parse(JSON.stringify(gvUser.aliases));
            }
            const filtered = aliasesArray.filter(
                (a) => !(a && (a.type || "").toLowerCase() === "achievementtitle")
            );

            const aliasesJson = JSON.stringify(filtered);
            const payload = { memberId, field: "aliases", value: aliasesJson, table: "members" };
            const result = await encryptedPost(`${getApiBase()}/api/ManagerMembers/update-field`, payload);

            if (result && result.success) {
                gvUser.aliases = filtered;
                if (gvMember?.record) gvMember.record.aliases = aliasesJson;
                showToastReact(t("title_removed"), "success");
                window.dispatchEvent(new CustomEvent("titleEquipped"));
                await loadData();
            } else {
                throw new Error("Failed to remove title");
            }
        } catch (err) {
            console.error("Error removing title:", err);
            showToastReact(t("title_remove_error"), "error");
        } finally {
            setTitleLoading(false);
        }
    }

    // ─── Navigate Back ───
    async function handleBack() {
        try {
            const { navigateBack } = await import("@components/homebase/navigation/NavigationManager.js");
            navigateBack();
        } catch {
            // Fallback
        }
    }

    // ─── Render ───
    if (loading) {
        return (
            <div style={{ padding: "60px 20px", textAlign: "center", color: "#888", background: "#0a0a0a", minHeight: "100%" }}>
                <div style={{ fontSize: "32px", marginBottom: "12px" }}>🏆</div>
                <div style={{ fontSize: "14px", letterSpacing: "1px" }}>{t("loading")}</div>
            </div>
        );
    }

    if (!achievement) {
        return (
            <div style={{ padding: "60px 20px", textAlign: "center", color: "#888", background: "#0a0a0a", minHeight: "100%" }}>
                <div style={{ fontSize: "24px", marginBottom: "12px" }}>?</div>
                <div style={{ fontSize: "14px" }}>{t("achievement_not_found") || "Achievement not found"}</div>
                <button onClick={handleBack} style={backBtnStyle}>
                    {t("back")}
                </button>
            </div>
        );
    }

    const theme = PILLAR_THEMES[achievement.pillarCode] || PILLAR_THEMES.CITIZEN;
    const isCompleted = memberProgress?.isCompleted;
    const isMeta = achievement.achievementType === "META";
    const isProgressive = achievement.achievementType === "PROGRESSIVE";
    const progressPercent = achievement.progressRequired
        ? Math.min((memberProgress?.progress / achievement.progressRequired) * 100, 100)
        : memberProgress?.progress > 0 ? 100 : 0;
    const typeInfo = TYPE_INFO[achievement.achievementType] || TYPE_INFO.BINARY;

    // Is this achievement's title currently active?
    const isTitleEquipped = activeTitle && activeTitle.achievementId === achievement.id;

    return (
        <div
            style={{
                background: "#0a0a0a",
                color: "#fff",
                minHeight: "100%",
                display: "flex",
                flexDirection: "column",
                fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
                overflowY: "auto",
            }}
        >
            {/* ═══ Hero Section ═══ */}
            <div
                style={{
                    position: "relative",
                    padding: "20px 16px 24px",
                    background: `linear-gradient(180deg, ${theme.darkBg} 0%, rgba(0,0,0,0) 100%)`,
                    borderBottom: `1px solid rgba(255,255,255,0.06)`,
                    overflow: "hidden",
                }}
            >
                {/* Subtle pillar accent line at top */}
                <div
                    style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        right: 0,
                        height: "3px",
                        background: theme.gradient,
                    }}
                />

                {/* Back button */}
                <button
                    onClick={handleBack}
                    style={{
                        padding: "6px 14px",
                        background: "rgba(255,255,255,0.06)",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: "6px",
                        color: "#aaa",
                        cursor: "pointer",
                        fontSize: "13px",
                        marginBottom: "20px",
                        transition: "all 0.2s ease",
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.background = "rgba(255,255,255,0.1)";
                        e.currentTarget.style.color = "#fff";
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.background = "rgba(255,255,255,0.06)";
                        e.currentTarget.style.color = "#aaa";
                    }}
                >
                    {t("back")}
                </button>

                {/* Central badge */}
                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        animation: "detailBadgeIn 0.5s ease",
                    }}
                >
                    {/* Progress ring with icon center */}
                    <div style={{ position: "relative", marginBottom: "16px" }}>
                        <DetailProgressRing
                            radius={52}
                            stroke={6}
                            progress={isCompleted ? 100 : progressPercent}
                            color={isCompleted ? "#FFB400" : theme.color}
                        />
                        <div
                            style={{
                                position: "absolute",
                                top: "50%",
                                left: "50%",
                                transform: "translate(-50%, -50%)",
                                fontSize: isCompleted ? "36px" : "28px",
                                animation: isCompleted ? "detailPulse 2s ease infinite" : "none",
                            }}
                        >
                            {isCompleted ? "\u{1F3C6}" : isMeta ? "\u2726" : theme.icon}
                        </div>
                    </div>

                    {/* Achievement name */}
                    <h1
                        style={{
                            margin: "0 0 6px",
                            fontSize: "22px",
                            fontWeight: 700,
                            textAlign: "center",
                            color: isCompleted ? "#FFB400" : "#fff",
                            letterSpacing: "0.3px",
                        }}
                    >
                        {achievement.name}
                    </h1>

                    {/* Pillar + Type badges */}
                    <div style={{ display: "flex", gap: "8px", marginBottom: "12px", flexWrap: "wrap", justifyContent: "center" }}>
                        <span
                            style={{
                                padding: "3px 10px",
                                borderRadius: "10px",
                                background: theme.midBg,
                                border: `1px solid ${theme.color}33`,
                                fontSize: "11px",
                                fontWeight: 600,
                                color: theme.color,
                                letterSpacing: "0.5px",
                            }}
                        >
                            {theme.icon} {theme.name}
                        </span>
                        <span
                            style={{
                                padding: "3px 10px",
                                borderRadius: "10px",
                                background: "rgba(255,255,255,0.05)",
                                border: "1px solid rgba(255,255,255,0.08)",
                                fontSize: "11px",
                                fontWeight: 500,
                                color: "#888",
                                letterSpacing: "0.5px",
                            }}
                        >
                            {typeInfo.icon} {typeInfo.label}
                        </span>
                    </div>

                    {/* Status badge */}
                    {isCompleted ? (
                        <div
                            style={{
                                display: "inline-flex",
                                alignItems: "center",
                                gap: "6px",
                                padding: "6px 16px",
                                borderRadius: "16px",
                                background: "rgba(255,180,0,0.15)",
                                border: "1px solid rgba(255,180,0,0.3)",
                                animation: "detailTitleGlow 3s ease infinite",
                            }}
                        >
                            <span style={{ fontSize: "14px" }}>✓</span>
                            <span style={{ fontSize: "13px", fontWeight: 600, color: "#FFB400" }}>
                                {t("completed")}
                            </span>
                            {memberProgress?.completedAt && (
                                <span style={{ fontSize: "11px", color: "rgba(255,180,0,0.6)", marginLeft: "4px" }}>
                                    {new Date(memberProgress.completedAt).toLocaleDateString()}
                                </span>
                            )}
                        </div>
                    ) : (
                        <div
                            style={{
                                fontSize: "12px",
                                color: "#666",
                                fontWeight: 500,
                            }}
                        >
                            {t("in_progress") || "In Progress"}
                        </div>
                    )}
                </div>
            </div>

            {/* ═══ Content Sections ═══ */}
            <div style={{ padding: "16px", display: "flex", flexDirection: "column", gap: "16px", animation: "detailFadeIn 0.4s ease 0.2s both" }}>
                {/* ─── Description Card ─── */}
                {achievement.description && (
                    <div style={cardStyle}>
                        <div style={cardHeaderStyle}>{t("description") || "Description"}</div>
                        <div style={{ fontSize: "14px", color: "#ccc", lineHeight: 1.6 }}>
                            {achievement.description}
                        </div>
                    </div>
                )}

                {/* ─── Progress Card (PROGRESSIVE) ─── */}
                {isProgressive && achievement.progressRequired && (
                    <div style={cardStyle}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                            <div style={cardHeaderStyle}>{t("progress")}</div>
                            <div style={{ fontSize: "14px", fontWeight: 600, color: isCompleted ? "#FFB400" : theme.color }}>
                                {memberProgress?.progress || 0} / {achievement.progressRequired}
                            </div>
                        </div>

                        {/* Full progress bar */}
                        <div
                            style={{
                                height: "16px",
                                background: "rgba(255,255,255,0.06)",
                                borderRadius: "8px",
                                overflow: "hidden",
                                border: "1px solid rgba(255,255,255,0.04)",
                                marginBottom: "8px",
                            }}
                        >
                            <div
                                style={{
                                    height: "100%",
                                    borderRadius: "7px",
                                    width: `${progressPercent}%`,
                                    background: isCompleted
                                        ? "linear-gradient(90deg, #FFB400, #FFD700)"
                                        : `linear-gradient(90deg, ${theme.color}, ${theme.color}cc)`,
                                    transition: "width 0.8s ease",
                                    ...(isCompleted
                                        ? {
                                              backgroundSize: "200% 100%",
                                              animation: "detailShimmer 2s ease infinite",
                                              backgroundImage:
                                                  "linear-gradient(90deg, #FFB400 0%, #FFD700 25%, #fff 50%, #FFD700 75%, #FFB400 100%)",
                                          }
                                        : {}),
                                }}
                            />
                        </div>

                        <div style={{ fontSize: "12px", color: "#555", textAlign: "center" }}>
                            {Math.round(progressPercent)}% {t("complete") || "complete"}
                        </div>
                    </div>
                )}

                {/* ─── META Dependencies Card ─── */}
                {isMeta && dependencies.length > 0 && (
                    <div style={cardStyle}>
                        <div style={{ ...cardHeaderStyle, marginBottom: "12px" }}>
                            {t("required_achievements") || "Required Achievements"}
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                            {dependencies.map((dep) => {
                                const depCompleted = dep.memberProgress?.isCompleted;
                                const depPillar = PILLAR_THEMES[dep.pillarCode] || PILLAR_THEMES.CITIZEN;
                                return (
                                    <div
                                        key={dep.id}
                                        style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: "10px",
                                            padding: "10px 12px",
                                            borderRadius: "8px",
                                            background: depCompleted ? "rgba(255,180,0,0.06)" : "rgba(255,255,255,0.02)",
                                            border: depCompleted
                                                ? "1px solid rgba(255,180,0,0.2)"
                                                : "1px solid rgba(255,255,255,0.05)",
                                        }}
                                    >
                                        <div
                                            style={{
                                                width: "28px",
                                                height: "28px",
                                                borderRadius: "6px",
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "center",
                                                background: depCompleted ? "rgba(255,180,0,0.15)" : "rgba(255,255,255,0.05)",
                                                border: depCompleted
                                                    ? "1px solid rgba(255,180,0,0.3)"
                                                    : "1px solid rgba(255,255,255,0.08)",
                                                fontSize: depCompleted ? "14px" : "12px",
                                                color: depCompleted ? "#FFB400" : "#555",
                                                flexShrink: 0,
                                            }}
                                        >
                                            {depCompleted ? "✓" : depPillar.icon}
                                        </div>
                                        <div style={{ flex: 1, minWidth: 0 }}>
                                            <div
                                                style={{
                                                    fontSize: "13px",
                                                    fontWeight: depCompleted ? 600 : 500,
                                                    color: depCompleted ? "#FFB400" : "#ccc",
                                                    whiteSpace: "nowrap",
                                                    overflow: "hidden",
                                                    textOverflow: "ellipsis",
                                                }}
                                            >
                                                {dep.name}
                                            </div>
                                        </div>
                                        {depCompleted && (
                                            <span style={{ fontSize: "11px", color: "rgba(255,180,0,0.6)", flexShrink: 0 }}>
                                                {t("completed")}
                                            </span>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* ─── Title Card (Trophy Case) ─── */}
                {achievement.title && (
                    <div
                        style={{
                            ...cardStyle,
                            ...(isCompleted
                                ? {
                                      border: "1px solid rgba(255,180,0,0.2)",
                                      background: "rgba(255,180,0,0.04)",
                                  }
                                : {}),
                        }}
                    >
                        <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px" }}>
                            <span style={{ fontSize: "18px" }}>{"\u{1F451}"}</span>
                            <div style={cardHeaderStyle}>{t("title_reward") || "Title Reward"}</div>
                        </div>

                        <div
                            style={{
                                padding: "14px",
                                borderRadius: "10px",
                                background: isCompleted
                                    ? "linear-gradient(135deg, rgba(255,180,0,0.1) 0%, rgba(255,210,0,0.05) 100%)"
                                    : "rgba(255,255,255,0.03)",
                                border: isCompleted
                                    ? "1px solid rgba(255,180,0,0.25)"
                                    : "1px dashed rgba(255,255,255,0.1)",
                                textAlign: "center",
                            }}
                        >
                            <div
                                style={{
                                    fontSize: "20px",
                                    fontWeight: 700,
                                    color: isCompleted ? "#FFB400" : "#555",
                                    marginBottom: "6px",
                                    letterSpacing: "0.5px",
                                }}
                            >
                                {achievement.title}
                            </div>
                            {!isCompleted && (
                                <div style={{ fontSize: "12px", color: "#555" }}>
                                    {t("complete_to_unlock") || "Complete this achievement to unlock"}
                                </div>
                            )}
                            {isCompleted && isTitleEquipped && (
                                <div style={{ fontSize: "12px", color: "rgba(255,180,0,0.7)", marginBottom: "12px" }}>
                                    {t("currently_equipped") || "Currently equipped"}
                                </div>
                            )}
                            {isCompleted && !isTitleEquipped && (
                                <div style={{ fontSize: "12px", color: "#888", marginBottom: "12px" }}>
                                    {t("title_available") || "Available to equip"}
                                </div>
                            )}

                            {/* Title action buttons */}
                            {isCompleted && (
                                <div style={{ display: "flex", gap: "8px", justifyContent: "center", marginTop: "4px" }}>
                                    {isTitleEquipped ? (
                                        <button
                                            onClick={handleRemoveTitle}
                                            disabled={titleLoading}
                                            style={{
                                                padding: "10px 24px",
                                                background: "rgba(255,255,255,0.06)",
                                                border: "1px solid rgba(255,255,255,0.1)",
                                                borderRadius: "8px",
                                                color: "#aaa",
                                                fontSize: "13px",
                                                fontWeight: 600,
                                                cursor: titleLoading ? "not-allowed" : "pointer",
                                                opacity: titleLoading ? 0.5 : 1,
                                                transition: "all 0.2s ease",
                                            }}
                                            onMouseEnter={(e) => {
                                                if (!titleLoading) {
                                                    e.currentTarget.style.background = "rgba(255,255,255,0.1)";
                                                    e.currentTarget.style.color = "#fff";
                                                }
                                            }}
                                            onMouseLeave={(e) => {
                                                if (!titleLoading) {
                                                    e.currentTarget.style.background = "rgba(255,255,255,0.06)";
                                                    e.currentTarget.style.color = "#aaa";
                                                }
                                            }}
                                        >
                                            {titleLoading ? t("loading") : t("remove_title") || "Remove Title"}
                                        </button>
                                    ) : (
                                        <button
                                            onClick={handleEquipTitle}
                                            disabled={titleLoading}
                                            style={{
                                                padding: "10px 28px",
                                                background: "rgba(255,180,0,0.9)",
                                                border: "none",
                                                borderRadius: "8px",
                                                color: "#000",
                                                fontSize: "14px",
                                                fontWeight: 700,
                                                cursor: titleLoading ? "not-allowed" : "pointer",
                                                opacity: titleLoading ? 0.5 : 1,
                                                transition: "all 0.2s ease",
                                                letterSpacing: "0.3px",
                                            }}
                                            onMouseEnter={(e) => {
                                                if (!titleLoading) e.currentTarget.style.background = "rgba(255,210,0,1)";
                                            }}
                                            onMouseLeave={(e) => {
                                                if (!titleLoading) e.currentTarget.style.background = "rgba(255,180,0,0.9)";
                                            }}
                                        >
                                            {titleLoading ? t("loading") : `\u{1F451} ${t("equip_title")}`}
                                        </button>
                                    )}
                                </div>
                            )}
                        </div>

                        {/* Other available titles (quick-switch) */}
                        {isCompleted && allTitles.length > 1 && (
                            <div style={{ marginTop: "16px" }}>
                                <div style={{ fontSize: "12px", color: "#555", fontWeight: 500, marginBottom: "8px", letterSpacing: "0.5px" }}>
                                    {t("other_titles") || "Other Titles"}
                                </div>
                                <div style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
                                    {allTitles
                                        .filter((ti) => ti.achievementId !== achievement.id)
                                        .slice(0, 5)
                                        .map((ti) => (
                                            <div
                                                key={ti.id || ti.achievementId}
                                                style={{
                                                    display: "flex",
                                                    alignItems: "center",
                                                    justifyContent: "space-between",
                                                    padding: "8px 10px",
                                                    borderRadius: "6px",
                                                    background: ti.isActive ? "rgba(255,180,0,0.06)" : "rgba(255,255,255,0.02)",
                                                    border: ti.isActive
                                                        ? "1px solid rgba(255,180,0,0.15)"
                                                        : "1px solid rgba(255,255,255,0.04)",
                                                }}
                                            >
                                                <span style={{ fontSize: "13px", color: ti.isActive ? "#FFB400" : "#888" }}>
                                                    {"\u{1F451}"} {ti.title}
                                                </span>
                                                {ti.isActive && (
                                                    <span style={{ fontSize: "10px", color: "rgba(255,180,0,0.6)", fontWeight: 600 }}>
                                                        {t("equipped")}
                                                    </span>
                                                )}
                                            </div>
                                        ))}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {/* ─── Achievement Type Info ─── */}
                <div style={cardStyle}>
                    <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <div
                            style={{
                                width: "36px",
                                height: "36px",
                                borderRadius: "8px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                background: isMeta ? "rgba(255,180,0,0.08)" : "rgba(255,255,255,0.04)",
                                border: isMeta ? "1px solid rgba(255,180,0,0.15)" : "1px solid rgba(255,255,255,0.06)",
                                fontSize: "16px",
                                color: isMeta ? "#FFB400" : "#666",
                            }}
                        >
                            {typeInfo.icon}
                        </div>
                        <div>
                            <div style={{ fontSize: "13px", fontWeight: 600, color: "#ccc" }}>
                                {typeInfo.label} {t("achievement") || "Achievement"}
                            </div>
                            <div style={{ fontSize: "12px", color: "#666" }}>{typeInfo.desc}</div>
                        </div>
                    </div>
                </div>

                {/* Bottom spacer */}
                <div style={{ height: "24px" }} />
            </div>
        </div>
    );
}

// ─── Shared Styles ───
const cardStyle = {
    padding: "16px",
    borderRadius: "12px",
    background: "rgba(255,255,255,0.02)",
    border: "1px solid rgba(255,255,255,0.06)",
};

const cardHeaderStyle = {
    fontSize: "13px",
    fontWeight: 600,
    color: "#888",
    letterSpacing: "0.5px",
    textTransform: "uppercase",
    marginBottom: "8px",
};

const backBtnStyle = {
    padding: "8px 18px",
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.1)",
    borderRadius: "6px",
    color: "#aaa",
    cursor: "pointer",
    fontSize: "13px",
    marginTop: "16px",
};
