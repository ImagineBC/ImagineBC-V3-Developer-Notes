using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using ImagineBC.MainService.Services;
using ImagineBC.MainService.Services.Guardians;

namespace ImagineBC.MainService.Controllers
{
    [ApiController]
    [Route("api/guardians")]
    public class GuardiansController : ControllerBase
    {
        private readonly string _connectionString;
        private readonly ILogger<GuardiansController> _logger;
        private readonly GuardiansProgressService _progressService;
        private readonly GuardiansTelemetryService _telemetryService;

        public GuardiansController(
            IConfiguration config,
            ILogger<GuardiansController> logger,
            ILoggerFactory loggerFactory)
        {
            _connectionString = config.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Missing connection string.");
            _logger = logger;
            
            var progressLogger = loggerFactory.CreateLogger<GuardiansProgressService>();
            _progressService = new GuardiansProgressService(_connectionString, progressLogger);
            
            var telemetryLogger = loggerFactory.CreateLogger<GuardiansTelemetryService>();
            _telemetryService = new GuardiansTelemetryService(telemetryLogger);
        }

        [HttpGet("progress")]
        public IActionResult GetProgress([FromQuery] string memberId)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(memberId))
                {
                    return BadRequest(new { success = false, message = "memberId is required" });
                }

                _logger.LogInformation("GET /progress requested for member {MemberId}", memberId);

                var progress = _progressService.GetGuardiansProgress(memberId);
                if (progress == null)
                {
                    progress = new GuardiansProgressSchema();
                }

                return Ok(new { success = true, progress });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting guardians progress");
                return StatusCode(500, new { success = false, message = "Internal server error" });
            }
        }

        [HttpPost("progress")]
        public IActionResult SaveProgress([FromBody] JObject payload)
        {
            try
            {
                var memberId = payload.Value<string>("memberId");
                var progressData = payload["progress"];

                if (string.IsNullOrWhiteSpace(memberId) || progressData == null)
                {
                    return BadRequest(new { success = false, message = "memberId and progress are required" });
                }

                _logger.LogInformation("POST /progress requested for member {MemberId}", memberId);

                var progress = progressData.ToObject<GuardiansProgressSchema>();
                if (progress == null)
                {
                    return BadRequest(new { success = false, message = "Invalid progress data" });
                }

                if (!progress.Validate())
                {
                    return BadRequest(new { success = false, message = "Invalid schema version" });
                }

                _progressService.SaveGuardiansProgress(memberId, progress);

                return Ok(new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving guardians progress");
                return StatusCode(500, new { success = false, message = "Internal server error" });
            }
        }

        [HttpPost("telemetry")]
        public IActionResult RecordTelemetry([FromBody] JObject payload)
        {
            try
            {
                var eventName = payload.Value<string>("eventName");
                var eventPayload = payload["payload"]?.ToObject<Dictionary<string, object>>();

                if (string.IsNullOrWhiteSpace(eventName))
                {
                    return BadRequest(new { success = false, message = "eventName is required" });
                }

                _logger.LogInformation("POST /telemetry event: {EventName}", eventName);

                bool success = _telemetryService.RecordTelemetry(eventName, eventPayload);

                // Emit gamification event for patrol completion (fire and forget)
                if (success && eventName == "guardians_patrol_completed")
                {
                    var memberReferral = eventPayload?.ContainsKey("memberReferral") == true
                        ? eventPayload["memberReferral"]?.ToString()
                        : payload.Value<string>("memberReferral");
                    if (!string.IsNullOrWhiteSpace(memberReferral))
                    {
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                var gamificationService = new GamificationService(_connectionString, null, null);
                                await gamificationService.ProcessEventAsync("GUARDIANS_PATROL_COMPLETED", memberReferral);
                            }
                            catch (Exception ex)
                            {
                                _logger.LogWarning(ex, "Failed to process guardians patrol gamification event");
                            }
                        });
                    }
                }

                return Ok(new { success });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error recording telemetry");
                return StatusCode(500, new { success = false, message = "Internal server error" });
            }
        }
    }
}

