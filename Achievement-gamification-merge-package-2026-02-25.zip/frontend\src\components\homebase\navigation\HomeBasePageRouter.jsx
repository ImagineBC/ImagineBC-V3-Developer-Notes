// ============================================================================
// HomeBase Page Router
// Pure React component that conditionally renders pages based on navigation state
// Replaces the old portal + separate render functions approach
// ============================================================================

// CRITICAL: Use window.React if available (CDN) for consistency with rendering
// This prevents React instance mismatch errors when rendering with window.React.createElement
import ReactModule, { useState as useStateModule, useEffect as useEffectModule, Suspense as SuspenseModule } from 'react';

// Use window.React if available (CDN), otherwise use module React
const React = window.React || ReactModule;
const useState = window.React?.useState || useStateModule;
const useEffect = window.React?.useEffect || useEffectModule;
const Suspense = window.React?.Suspense || SuspenseModule;

// CRITICAL: Verify React instance consistency
if (window.React && React !== window.React) {
  console.error("❌ [HomeBasePageRouter] React instance mismatch!", {
    moduleReact: React,
    windowReact: window.React
  });
  window.React = React;
}

import { getCurrentLocation, navigateBack } from './NavigationState.js';
import { ImaginariumRoot } from '../imaginarium/ImaginariumRoot.jsx';

// Lazy load page components for better performance
// These are named exports, so we wrap them as default for React.lazy
// Add error handling to prevent crashes if exports are missing
const createLazyPage = (importFn, exportName, fallbackName) => {
  return React.lazy(() => 
    importFn().then(module => {
      const Component = module[exportName];
      if (!Component || typeof Component !== 'function') {
        console.error(`❌ [HomeBasePageRouter] ${exportName} not found or invalid in ${fallbackName}:`, {
          module: module,
          hasExport: !!Component,
          type: typeof Component,
          availableExports: Object.keys(module)
        });
        return { default: () => <div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>{fallbackName} unavailable</div> };
      }
      return { default: Component };
    }).catch(err => {
      console.error(`❌ [HomeBasePageRouter] Error loading ${fallbackName}:`, err);
      return { default: () => <div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Error loading {fallbackName}</div> };
    })
  );
};

const NotesPage = createLazyPage(
  () => import('../pages/renderNotes.jsx'),
  'NotesPage',
  'Notes'
);
const RewardPage = createLazyPage(
  () => import('../pages/renderRewards.jsx'),
  'RewardPage',
  'Rewards'
);
const RewardPageG4ME = createLazyPage(
  () => import('../pages/rewardspageg4me/RewardPageG4ME.jsx'),
  'RewardPageG4ME',
  'Rewards G4ME'
);
const ArcadePage = createLazyPage(
  () => import('../public/arcade.jsx'),
  'ArcadePage',
  'Arcade'
);
const TownHallPage = createLazyPage(
  () => import('../../townhall/renderTownHall.jsx'),
  'TownHallPage',
  'Town Hall'
);
const MartPage = createLazyPage(
  () => import('../mart/renderMart.jsx'),
  'MartPage',
  'Mart'
);
const ExchangePage = createLazyPage(
  () => import('../public/theexchange.jsx'),
  'ExchangePage',
  'The Exchange'
);
const CompoundPage = createLazyPage(
  () => import('../public/theCompound.jsx'),
  'CompoundPage',
  'The Compound'
);
const WonderNookPage = createLazyPage(
  () => import('../public/wonderNook.jsx'),
  'WonderNookPage',
  'Wonder Nook'
);
const WonderBoxPage = createLazyPage(
  () => import('../public/wonderBox.jsx'),
  'WonderBoxPage',
  'Wonder Box'
);
const CommonsPage = createLazyPage(
  () => import('../public/commonsOfMeaning.jsx'),
  'CommonsOfMeaningPage',
  'Commons'
);
const JobFairPage = createLazyPage(
  () => import('../public/jobfair.jsx'),
  'JobFairPageWrapper',
  'Job Fair'
);
const ShoppingDistrictPage = createLazyPage(
  () => import('../public/ShoppingDistrictPage.jsx'),
  'ShoppingDistrictPage',
  'Shopping District'
);
const MuseumPage = createLazyPage(
  () => import('../public/museum.jsx'),
  'MuseumPage',
  'Museum'
);
const GalleryPage = createLazyPage(
  () => import('../public/gallery.jsx'),
  'GalleryPage',
  'Gallery'
);
const ProfilePage = createLazyPage(
  () => import('../pages/renderProfile.jsx'),
  'ProfilePage',
  'Profile'
);
const WalletPage = createLazyPage(
  () => import('../pages/renderWallet.jsx'),
  'WalletPage',
  'Wallet'
);
const AchievementsPage = createLazyPage(
  () => import('../pages/renderAchievements.jsx'),
  'AchievementsPage',
  'Achievements'
);
const AchievementDetailPage = createLazyPage(
  () => import('../pages/AchievementDetailPage.jsx'),
  'AchievementDetailPage',
  'Achievement Detail'
);
const FamilySafetyPage = createLazyPage(
  () => import('../../family/GuardianDashboard.jsx'),
  'GuardianDashboard',
  'Family & Safety'
);
const HealthBasePage = React.lazy(() => 
  import('../../healthbase/HealthBaseEntryPage.jsx').then(module => {
    if (!module.HealthBaseEntry || typeof module.HealthBaseEntry !== 'function') {
      console.error("❌ [HomeBasePageRouter] HealthBaseEntry not found or invalid:", {
        module: module,
        hasHealthBaseEntry: !!module.HealthBaseEntry,
        type: typeof module.HealthBaseEntry
      });
      // Return a fallback component
      return { default: () => <div style={{ padding: '20px', color: 'white' }}>HealthBase page unavailable</div> };
    }
    return { default: module.HealthBaseEntry };
  }).catch(err => {
    console.error("❌ [HomeBasePageRouter] Error loading HealthBaseEntry:", err);
    // Return a fallback component on error
    return { default: () => <div style={{ padding: '20px', color: 'white' }}>Error loading HealthBase</div> };
  })
);

/**
 * Router component that conditionally renders the appropriate page based on navigation state
 * This replaces the old portal + innerHTML manipulation approach with pure React conditional rendering
 */
export function HomeBasePageRouter() {
  console.log("👉 entered function HomeBasePageRouter");
  const [currentLocation, setCurrentLocation] = useState(getCurrentLocation());

  // Listen for navigation state changes
  useEffect(() => {
    const handleNavigationChange = () => {
      setCurrentLocation(getCurrentLocation());
    };

    // Check state immediately on mount (in case state was initialized before router mounted)
    handleNavigationChange();

    // Listen for custom events that indicate navigation state changed
    // NavigationState already emits these events in navigateTo() and navigateBack()
    window.addEventListener('navigationStateChanged', handleNavigationChange);

    return () => {
      window.removeEventListener('navigationStateChanged', handleNavigationChange);
    };
  }, []);

  // Determine what to render based on current location
  const locationType = currentLocation?.type;
  const locationId = currentLocation?.id;
  const context = currentLocation?.context || {};

  // Fallback: If navigation state is not initialized, render clubhouse (fixes blank workspace issue)
  if (!locationType) {
    console.warn("⚠️ [HomeBasePageRouter] Navigation state not initialized, rendering clubhouse as fallback");
    return <ImaginariumRoot />;
  }

  // CRITICAL: If interior type with channel context, don't render router content
  // Channel/MySpace roots handle their own rendering directly into the container
  // Router portal would conflict with these roots
  if (locationType === 'interior' && context?.type === 'channel') {
    // Channel is being rendered by runChannel - router should not render
    return null;
  }
  
  // Also check if locationType is 'myspace' directly (MySpace uses this type)
  if (locationType === 'myspace') {
    // MySpace is being rendered by runMySpace - router should not render
    return null;
  }

  if (locationType === 'page') {
    // Render a specific page (notes, rewards, arcade, profile, etc.)
    if (locationId === 'notes') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading notes...</div>}>
          <NotesPage agent={context.agent || 'expo'} onBack={context.onBack || null} />
        </Suspense>
      );
    } else if (locationId === 'rewards') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading rewards...</div>}>
          <RewardPage agent={context.agent || 'cash'} onBack={context.onBack || null} onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'rewardspageg4me') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading rewards...</div>}>
          <RewardPageG4ME onBack={context.onBack || null} onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'arcade') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading arcade...</div>}>
          <ArcadePage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'townhall') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Town Hall...</div>}>
          <TownHallPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'mart') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading The Mart...</div>}>
          <MartPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'the-exchange') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading The Exchange...</div>}>
          <ExchangePage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'the-compound') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading The Compound...</div>}>
          <CompoundPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'wonder-nook') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Wonder Nook...</div>}>
          <WonderNookPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'wonder-box') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Wonder Box...</div>}>
          <WonderBoxPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'commons') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Commons...</div>}>
          <CommonsPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'jobfair') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Job Fair...</div>}>
          <JobFairPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'shopping_district') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Shopping District...</div>}>
          <ShoppingDistrictPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'museum') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Museum...</div>}>
          <MuseumPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'gallery') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading The Gallery...</div>}>
          <GalleryPage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'profile') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading profile...</div>}>
          <ProfilePage onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'wallet') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading wallet...</div>}>
          <WalletPage onBack={context.onBack || null} onExit={navigateBack} />
        </Suspense>
      );
    } else if (locationId === 'achievements') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading achievements...</div>}>
          <AchievementsPage />
        </Suspense>
      );
    } else if (locationId === 'achievement-detail') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading achievement...</div>}>
          <AchievementDetailPage />
        </Suspense>
      );
    } else if (locationId === 'healthbase') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading HealthBase...</div>}>
          <HealthBasePage />
        </Suspense>
      );
    } else if (locationId === 'family-safety') {
      return (
        <Suspense fallback={<div style={{ padding: '20px', color: 'white', textAlign: 'center' }}>Loading Family & Safety...</div>}>
          <FamilySafetyPage onExit={navigateBack} />
        </Suspense>
      );
    }
  }

  // Default: Render ImaginariumRoot (clubhouse, map, etc.)
  return <ImaginariumRoot />;
}

