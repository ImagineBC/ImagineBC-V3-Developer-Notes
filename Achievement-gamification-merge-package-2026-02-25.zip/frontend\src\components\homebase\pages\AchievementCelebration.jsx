import React, { useEffect, useRef, useState, useCallback } from "react";
import { t } from "@shared/translations.js";

// ============================================================================
// Achievement Celebration — Full-Screen Unlock Experience
// PlayStation/Steam/Xbox-tier celebration with confetti, light burst, and drama
// ============================================================================

const PILLAR_THEMES = {
    CITIZEN:  { color: "#56AF9B", rgb: "86,175,155",  name: "Citizen",  icon: "🏛️" },
    EXPLORER: { color: "#4A90E2", rgb: "74,144,226",  name: "Explorer", icon: "🗺️" },
    GAMER:    { color: "#E74C3C", rgb: "231,76,60",   name: "Gamer",    icon: "🎮" },
    PATRON:   { color: "#F39C12", rgb: "243,156,18",  name: "Patron",   icon: "💰" },
};

const CELEBRATION_STYLE_ID = "achievement-celebration-styles";

function injectCelebrationStyles() {
    if (typeof document === "undefined") return;
    if (document.getElementById(CELEBRATION_STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = CELEBRATION_STYLE_ID;
    style.textContent = `
        @keyframes celebrationBackdropIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes celebrationBackdropOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
        @keyframes celebrationLightBurst {
            0% { transform: scale(0); opacity: 0.8; }
            60% { transform: scale(1.2); opacity: 0.4; }
            100% { transform: scale(1.5); opacity: 0; }
        }
        @keyframes celebrationBadgeIn {
            0% { transform: scale(0); opacity: 0; }
            50% { transform: scale(1.15); }
            70% { transform: scale(0.95); }
            100% { transform: scale(1); opacity: 1; }
        }
        @keyframes celebrationTrophySpin {
            0% { transform: rotateY(0deg) scale(1); }
            25% { transform: rotateY(90deg) scale(1.1); }
            50% { transform: rotateY(180deg) scale(1); }
            75% { transform: rotateY(270deg) scale(1.1); }
            100% { transform: rotateY(360deg) scale(1); }
        }
        @keyframes celebrationTitleIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes celebrationTextReveal {
            from { opacity: 0; letter-spacing: 12px; }
            to { opacity: 1; letter-spacing: 4px; }
        }
        @keyframes celebrationNameIn {
            from { opacity: 0; transform: translateY(15px) scale(0.9); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes celebrationGlow {
            0%, 100% { box-shadow: 0 0 20px rgba(255,180,0,0.3), 0 0 60px rgba(255,180,0,0.1); }
            50% { box-shadow: 0 0 40px rgba(255,180,0,0.5), 0 0 80px rgba(255,180,0,0.2); }
        }
        @keyframes celebrationShine {
            0% { background-position: -200% center; }
            100% { background-position: 200% center; }
        }
        @keyframes celebrationPillarPulse {
            0%, 100% { opacity: 0.6; }
            50% { opacity: 1; }
        }
        @keyframes celebrationRingExpand {
            0% { transform: translate(-50%, -50%) scale(0.3); opacity: 0.8; border-width: 3px; }
            100% { transform: translate(-50%, -50%) scale(2.5); opacity: 0; border-width: 1px; }
        }
    `;
    document.head.appendChild(style);
}

// ─────────────────────────────────────────────────────────────────────────────
// Confetti Canvas — Pure JS particle system
// ─────────────────────────────────────────────────────────────────────────────
function ConfettiCanvas({ pillarColor, active }) {
    console.log("entered function ConfettiCanvas");
    const canvasRef = useRef(null);
    const particlesRef = useRef([]);
    const animFrameRef = useRef(null);

    useEffect(() => {
        if (!active || !canvasRef.current) return;

        const canvas = canvasRef.current;
        const ctx = canvas.getContext("2d");
        const rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;

        // Confetti colors: pillar color + gold + white + light variants
        const colors = [
            pillarColor,
            "#FFB400", "#FFD700", "#FFF8DC",
            "#ffffff",
            adjustBrightness(pillarColor, 40),
            adjustBrightness(pillarColor, -30),
        ];

        // Spawn particles — burst from center-top
        const particles = [];
        const centerX = canvas.width / 2;
        const launchY = canvas.height * 0.3;

        for (let i = 0; i < 90; i++) {
            const angle = (Math.random() * Math.PI * 2);
            const velocity = 3 + Math.random() * 6;
            const size = 4 + Math.random() * 6;
            particles.push({
                x: centerX + (Math.random() - 0.5) * 40,
                y: launchY + (Math.random() - 0.5) * 20,
                vx: Math.cos(angle) * velocity * (0.6 + Math.random() * 0.8),
                vy: Math.sin(angle) * velocity * -1.2 - Math.random() * 2,
                width: size,
                height: size * (0.4 + Math.random() * 0.6),
                color: colors[Math.floor(Math.random() * colors.length)],
                rotation: Math.random() * 360,
                rotationSpeed: (Math.random() - 0.5) * 12,
                gravity: 0.12 + Math.random() * 0.08,
                drag: 0.98 + Math.random() * 0.015,
                opacity: 1,
                fadeStart: 2500 + Math.random() * 1500, // when to start fading (ms)
                shape: Math.random() > 0.4 ? "rect" : "circle",
            });
        }
        particlesRef.current = particles;

        const startTime = Date.now();

        function animate() {
            const elapsed = Date.now() - startTime;
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            let alive = 0;
            for (const p of particles) {
                // Physics
                p.vy += p.gravity;
                p.vx *= p.drag;
                p.vy *= p.drag;
                p.x += p.vx;
                p.y += p.vy;
                p.rotation += p.rotationSpeed;

                // Fade out
                if (elapsed > p.fadeStart) {
                    p.opacity = Math.max(0, p.opacity - 0.02);
                }

                if (p.opacity <= 0 || p.y > canvas.height + 20) continue;
                alive++;

                ctx.save();
                ctx.globalAlpha = p.opacity;
                ctx.translate(p.x, p.y);
                ctx.rotate((p.rotation * Math.PI) / 180);
                ctx.fillStyle = p.color;

                if (p.shape === "rect") {
                    ctx.fillRect(-p.width / 2, -p.height / 2, p.width, p.height);
                } else {
                    ctx.beginPath();
                    ctx.arc(0, 0, p.width / 2, 0, Math.PI * 2);
                    ctx.fill();
                }
                ctx.restore();
            }

            if (alive > 0 && elapsed < 5000) {
                animFrameRef.current = requestAnimationFrame(animate);
            }
        }

        animFrameRef.current = requestAnimationFrame(animate);

        return () => {
            if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
        };
    }, [active, pillarColor]);

    return (
        <canvas
            ref={canvasRef}
            style={{
                position: "absolute",
                top: 0, left: 0, right: 0, bottom: 0,
                width: "100%", height: "100%",
                pointerEvents: "none",
                zIndex: 3,
            }}
        />
    );
}

// Helper: adjust hex color brightness
function adjustBrightness(hex, amount) {
    const num = parseInt(hex.replace("#", ""), 16);
    const r = Math.min(255, Math.max(0, ((num >> 16) & 0xff) + amount));
    const g = Math.min(255, Math.max(0, ((num >> 8) & 0xff) + amount));
    const b = Math.min(255, Math.max(0, (num & 0xff) + amount));
    return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Celebration Component
// ─────────────────────────────────────────────────────────────────────────────
export function AchievementCelebration({ achievement, onClose }) {
    console.log("entered function AchievementCelebration");
    const [phase, setPhase] = useState("entering"); // entering | visible | exiting
    const [showConfetti, setShowConfetti] = useState(false);
    const timeoutsRef = useRef([]);

    const theme = PILLAR_THEMES[achievement?.pillarCode] || PILLAR_THEMES.CITIZEN;

    const addTimeout = useCallback((fn, delay) => {
        const id = setTimeout(fn, delay);
        timeoutsRef.current.push(id);
        return id;
    }, []);

    useEffect(() => {
        injectCelebrationStyles();

        // Phase timeline
        addTimeout(() => setShowConfetti(true), 300);
        addTimeout(() => setPhase("visible"), 100);

        // No auto-dismiss — celebration lingers until user taps to dismiss

        return () => {
            timeoutsRef.current.forEach(clearTimeout);
        };
    }, []);

    const handleDismiss = useCallback(() => {
        if (phase === "exiting") return;
        setPhase("exiting");
        const id = setTimeout(() => {
            if (onClose) onClose();
        }, 400);
        timeoutsRef.current.push(id);
    }, [phase, onClose]);

    if (!achievement) return null;

    const isExiting = phase === "exiting";

    return (
        <div
            onClick={handleDismiss}
            style={{
                position: "absolute",
                top: 0, left: 0, right: 0, bottom: 0,
                zIndex: 9999,
                cursor: "pointer",
                overflow: "hidden",
                animation: isExiting
                    ? "celebrationBackdropOut 0.4s ease forwards"
                    : "celebrationBackdropIn 0.3s ease forwards",
            }}
        >
            {/* ── Dark backdrop ── */}
            <div style={{
                position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
                background: "rgba(0,0,0,0.85)",
                zIndex: 0,
            }} />

            {/* ── Light burst ── */}
            <div style={{
                position: "absolute",
                top: "35%", left: "50%",
                width: "300px", height: "300px",
                marginLeft: "-150px", marginTop: "-150px",
                borderRadius: "50%",
                background: `radial-gradient(circle, rgba(${theme.rgb},0.3) 0%, rgba(${theme.rgb},0.05) 50%, transparent 70%)`,
                animation: "celebrationLightBurst 1.5s ease-out forwards",
                zIndex: 1,
            }} />

            {/* ── Expanding rings ── */}
            {[0, 300, 600].map((delay, i) => (
                <div
                    key={i}
                    style={{
                        position: "absolute",
                        top: "35%", left: "50%",
                        width: "80px", height: "80px",
                        borderRadius: "50%",
                        border: `2px solid ${theme.color}`,
                        opacity: 0,
                        animation: `celebrationRingExpand 1.2s ease-out ${delay}ms forwards`,
                        zIndex: 1,
                    }}
                />
            ))}

            {/* ── Confetti ── */}
            <ConfettiCanvas pillarColor={theme.color} active={showConfetti} />

            {/* ── Central content ── */}
            <div style={{
                position: "absolute",
                top: "50%", left: "50%",
                transform: "translate(-50%, -50%)",
                display: "flex", flexDirection: "column", alignItems: "center",
                gap: "0px",
                zIndex: 4,
                width: "90%",
                maxWidth: "320px",
            }}>
                {/* Trophy badge */}
                <div style={{
                    position: "relative",
                    width: "88px", height: "88px",
                    borderRadius: "50%",
                    background: `linear-gradient(135deg, rgba(${theme.rgb},0.15) 0%, rgba(${theme.rgb},0.05) 100%)`,
                    border: `2px solid ${theme.color}`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    animation: "celebrationBadgeIn 0.7s cubic-bezier(0.34, 1.56, 0.64, 1) 0.2s both, celebrationGlow 2s ease-in-out 1s infinite",
                    marginBottom: "16px",
                }}>
                    <span style={{
                        fontSize: "40px",
                        animation: "celebrationTrophySpin 1.2s ease-in-out 0.6s",
                        display: "block",
                    }}>
                        🏆
                    </span>
                </div>

                {/* "ACHIEVEMENT UNLOCKED" text */}
                <div style={{
                    fontSize: "11px",
                    fontWeight: 700,
                    color: theme.color,
                    textTransform: "uppercase",
                    letterSpacing: "4px",
                    animation: "celebrationTextReveal 0.8s ease-out 0.6s both",
                    marginBottom: "12px",
                    textAlign: "center",
                    textShadow: `0 0 20px rgba(${theme.rgb},0.5)`,
                }}>
                    {t("achievement_unlocked")}
                </div>

                {/* Achievement name */}
                <div style={{
                    fontSize: "22px",
                    fontWeight: 700,
                    color: "#fff",
                    textAlign: "center",
                    animation: "celebrationNameIn 0.5s ease-out 1.0s both",
                    marginBottom: "8px",
                    textShadow: "0 2px 10px rgba(0,0,0,0.5)",
                    lineHeight: 1.2,
                }}>
                    {achievement.name}
                </div>

                {/* Achievement description */}
                {achievement.description && (
                    <div style={{
                        fontSize: "12px",
                        color: "rgba(255,255,255,0.6)",
                        textAlign: "center",
                        animation: "celebrationTitleIn 0.4s ease-out 1.3s both",
                        marginBottom: "12px",
                        lineHeight: 1.4,
                        maxWidth: "260px",
                    }}>
                        {achievement.description}
                    </div>
                )}

                {/* Title reward badge */}
                {achievement.title && (
                    <div style={{
                        display: "inline-flex", alignItems: "center", gap: "6px",
                        padding: "6px 16px",
                        borderRadius: "20px",
                        background: `linear-gradient(135deg, rgba(${theme.rgb},0.2), rgba(255,180,0,0.15))`,
                        border: `1px solid rgba(${theme.rgb},0.4)`,
                        animation: "celebrationTitleIn 0.5s ease-out 1.5s both",
                        marginBottom: "8px",
                    }}>
                        <span style={{ fontSize: "14px" }}>👑</span>
                        <span style={{
                            fontSize: "14px", fontWeight: 600, color: "#FFB400",
                            background: "linear-gradient(90deg, #FFB400, #FFD700, #FFB400)",
                            backgroundSize: "200% auto",
                            WebkitBackgroundClip: "text",
                            WebkitTextFillColor: "transparent",
                            animation: "celebrationShine 2s linear 2s infinite",
                        }}>
                            {achievement.title}
                        </span>
                    </div>
                )}

                {/* Pillar badge */}
                <div style={{
                    display: "flex", alignItems: "center", gap: "6px",
                    padding: "4px 12px",
                    borderRadius: "12px",
                    background: `rgba(${theme.rgb},0.1)`,
                    border: `1px solid rgba(${theme.rgb},0.2)`,
                    animation: "celebrationTitleIn 0.4s ease-out 1.8s both",
                }}>
                    <span style={{ fontSize: "12px" }}>{theme.icon}</span>
                    <span style={{ fontSize: "11px", fontWeight: 600, color: theme.color, letterSpacing: "0.5px" }}>
                        {theme.name}
                    </span>
                </div>

                {/* Tap to dismiss hint */}
                <div style={{
                    marginTop: "24px",
                    fontSize: "10px",
                    color: "rgba(255,255,255,0.25)",
                    letterSpacing: "1px",
                    textTransform: "uppercase",
                    animation: "celebrationTitleIn 0.4s ease-out 2.5s both",
                }}>
                    {t("tap_to_dismiss") || "tap to dismiss"}
                </div>
            </div>
        </div>
    );
}
